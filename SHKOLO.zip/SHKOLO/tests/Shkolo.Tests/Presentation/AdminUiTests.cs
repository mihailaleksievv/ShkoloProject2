// Owner: Shared
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Presentation;

/// <summary>End-to-end administrator workflows from login through the command centre (scripted keyboard).</summary>
public class AdminUiTests
{
    // Students screen: 8 actions, then "← Назад".
    private const int AddStudent = 3;
    private const int StudentsBack = 8;

    private static UiApp AdminSession()
    {
        var ui = new UiApp();
        ui.Login("admin", "Admin123!");
        return ui;
    }

    private static void Finish(UiApp ui)
    {
        ui.LeaveShell().Console.Choose(2);
        ui.Run();
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Admin_adds_student_through_the_form()
    {
        var ui = AdminSession();
        ui.Console.Keys("2").Keys("у").Choose(AddStudent)
            .Type("2001").Type("Тодор").Type("Тестов")
            .Search("10Б")
            .Type("")
            .Type("н")
            .Key()
            .Choose(StudentsBack);
        Finish(ui);

        var student = Assert.Single(ui.Db.Students, s => s.StudentNumber == "2001");
        Assert.Equal("10Б", ui.Db.Classes.Single(c => c.Id == student.ClassId).DisplayName);
        Assert.Contains("е добавен", ui.Console.Output);
    }

    [Fact]
    public void Duplicate_student_number_shows_service_error()
    {
        var ui = AdminSession();
        ui.Console.Keys("2").Keys("у").Choose(AddStudent)
            .Type("1001").Type("Тодор").Type("Тестов")
            .Search("10А")
            .Type("")
            .Key()
            .Choose(StudentsBack);
        Finish(ui);

        Assert.Contains("вече съществува", ui.Console.Output);
        Assert.Equal(18, ui.Db.Students.Count);
    }

    [Fact]
    public void Subject_with_markup_characters_is_saved_and_listed()
    {
        var ui = AdminSession();
        ui.Console.Keys("3").Keys("п").Choose(0).Type("Химия [лаб]").Type("").Key().Choose(4);
        Finish(ui);

        Assert.Contains(ui.Db.Subjects, s => s.Name == "Химия [лаб]");
        Assert.Contains("Химия [лаб]", ui.Console.Output);
    }

    [Fact]
    public void Statistics_and_audit_screens_render()
    {
        var ui = AdminSession();
        ui.Console.Keys("6").Keys("с").Choose(0).Key().Choose(3)
            .Keys("8").Keys("и").Choose(1);
        Finish(ui);

        Assert.Contains("Успех по предмети", ui.Console.Output);
        Assert.Contains("Последни 100 действия", ui.Console.Output);
        Assert.Contains("Auth.Login", ui.Console.Output);
    }
}
