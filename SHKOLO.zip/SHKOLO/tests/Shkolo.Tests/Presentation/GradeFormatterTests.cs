// Owner: Shared
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;

namespace Shkolo.Tests.Presentation;

public class GradeFormatterTests
{
    [Theory]
    [InlineData("2.50", ShkoloTheme.ErrorHex)]
    [InlineData("3.00", ShkoloTheme.PeachHex)]
    [InlineData("4.00", ShkoloTheme.WarningHex)]
    [InlineData("5.00", ShkoloTheme.AccentHex)]
    [InlineData("5.50", ShkoloTheme.SuccessHex)]
    public void Color_follows_grade_band(string value, string hex)
        => Assert.Contains(hex, GradeFormatter.Markup(decimal.Parse(value, System.Globalization.CultureInfo.InvariantCulture)));

    [Fact]
    public void Uses_decimal_comma()
        => Assert.Contains("5,43", GradeFormatter.Markup(5.425m));

    [Fact]
    public void Null_shows_no_data()
        => Assert.Contains("Няма данни", GradeFormatter.Markup(null));
}
