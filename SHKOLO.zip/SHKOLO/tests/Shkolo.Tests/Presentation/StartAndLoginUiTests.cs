﻿// Owner: Shared
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Presentation;

/// <summary>End-to-end: start screen → login → command centre → logout, on the real screens (scripted keyboard).</summary>
public class StartAndLoginUiTests
{
    [Fact]
    public void About_screen_shows_data_path_and_returns()
    {
        var ui = new UiApp();
        ui.Console.Choose(1).Key().Choose(2);

        ui.Run();

        Assert.Contains("memory://school-data.json", ui.Console.Output);
        Assert.Contains("Presentation", ui.Console.Output);
        Assert.Empty(ui.Errors);
    }

    [Fact]
    public void Sky_start_screen_shows_buttons_and_school_strip()
    {
        var ui = new UiApp();
        ui.Console.Press(ConsoleKey.RightArrow).Press(ConsoleKey.LeftArrow)   // walk the buttons
            .Choose(2);                                                     // Изход

        ui.Run();

        var output = ui.Console.Output;
        Assert.Contains("Вход", output);
        Assert.Contains("За проекта", output);
        Assert.Contains("Изход", output);
        Assert.Contains("Училищният ден – под контрол.", output);
        Assert.Contains("2026/2027", output);
        Assert.Contains("18 ученици", output);
        Assert.Contains("▀", output);              // the sky is drawn
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Login_card_has_a_demo_accounts_tab_that_fills_the_form()
    {
        var ui = new UiApp();
        ui.Console.Choose(0)                       // Вход
            .Tab()                                 // Демо акаунти
            .Down()                                // teacher1
            .Enter()                               // fill the form, back on the login tab
            .Enter();                              // log in
        ui.LeaveShell().Console.Choose(2);

        ui.Run();

        var output = ui.Console.Output;
        Assert.Contains("ДЕМО АКАУНТИ", output);
        Assert.Contains("Student123!", output);
        Assert.Contains("Иван Иванов", output);   // logged in as teacher1
        Assert.Contains("Довиждане", output);
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Password_is_masked_in_the_login_card()
    {
        var ui = new UiApp();
        ui.Login("admin", "Admin123!").LeaveShell().Console.Choose(2);

        ui.Run();

        Assert.Contains("•••••••••", ui.Console.Output);
        Assert.DoesNotContain("Admin123!", ui.Console.Output);   // never echoed in clear text
        Assert.Empty(ui.Errors);
    }

    [Fact]
    public void Wrong_password_shows_generic_error_and_stays_on_login()
    {
        var ui = new UiApp();
        ui.Login("admin", "wrong").Console.Key().Type("").Choose(2);

        ui.Run();

        Assert.Contains("Невалидно потребителско име или парола.", ui.Console.Output);
        Assert.False(ui.App.Session.IsAuthenticated);
        Assert.Empty(ui.Errors);
    }

    [Theory]
    [InlineData("admin", "Admin123!", "Администратор")]
    [InlineData("teacher1", "Teacher123!", "Иван Иванов")]
    [InlineData("student1", "Student123!", "Михаил")]
    public void Each_role_logs_into_the_command_centre_and_out_again(string username, string password, string expected)
    {
        var ui = new UiApp();
        ui.Login(username, password).LeaveShell().Console.Choose(2);

        ui.Run();

        Assert.Contains(expected, ui.Console.Output);
        Assert.Contains("Довиждане", ui.Console.Output);
        Assert.False(ui.App.Session.IsAuthenticated);
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }
}
