﻿// Owner: Shared
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Presentation;

/// <summary>End-to-end student workflows from login through the command centre (scripted keyboard).</summary>
public class StudentUiTests
{
    private static UiApp StudentSession()
    {
        var ui = new UiApp();
        ui.Login("student1", "Student123!");
        return ui;
    }

    private static void Finish(UiApp ui)
    {
        ui.LeaveShell().Console.Choose(2);
        ui.Run();
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Dashboard_shows_own_data()
    {
        var ui = StudentSession();
        Finish(ui);

        Assert.Contains("МИХАИЛ АЛЕКСИЕВ", ui.Console.Output);
        Assert.Contains("Среден успех", ui.Console.Output);
        Assert.Contains("Присъствия", ui.Console.Output);
    }

    [Fact]
    public void Grades_screen_groups_by_subject()
    {
        var ui = StudentSession();
        ui.Console.Keys("2").Keys("ф").Choose(4);
        Finish(ui);

        Assert.Contains("Оценки по предмети", ui.Console.Output);
    }

    [Fact]
    public void Student_submits_homework()
    {
        var ui = StudentSession();
        var student = ui.Db.Students.Single(s => s.StudentNumber == "1001");
        ui.Console.Keys("4").Keys("п").Choose(0).Choose(IndexOfPending(ui, student.ClassId))
            .Type("Решенията са в тетрадката.").Key().Choose(2);
        Finish(ui);

        Assert.Contains(ui.Db.HomeworkSubmissions, s => s.StudentId == student.Id && s.Content == "Решенията са в тетрадката.");
        Assert.Contains("Отговорът е предаден.", ui.Console.Output);
    }

    private static int IndexOfPending(UiApp ui, Guid classId)
    {
        // Same order as the screen: active homework of the class by due date, then title.
        var list = ui.Db.Homework.Where(h => h.ClassId == classId && h.IsActive)
            .OrderBy(h => h.DueDate).ThenBy(h => h.Title, StringComparer.CurrentCulture).ToList();
        var index = list.FindIndex(h => h.DueDate >= ui.App.Clock.Today);
        Assert.True(index >= 0, "Demo data must contain an open homework.");
        return index;
    }

    [Fact]
    public void Notifications_can_be_marked_read()
    {
        var ui = StudentSession();
        ui.Console.Keys("6").Keys("и").Choose(0).Choose(2);
        Finish(ui);

        var userId = ui.Db.Users.Single(u => u.Username == "student1").Id;
        Assert.DoesNotContain(ui.Db.Notifications, n => n.RecipientUserId == userId && !n.IsRead);
    }
}
