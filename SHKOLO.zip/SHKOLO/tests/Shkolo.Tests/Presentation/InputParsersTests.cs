// Owner: Shared
using Shkolo.Presentation.Input;

namespace Shkolo.Tests.Presentation;

public class InputParsersTests
{
    private static readonly DateOnly Today = new(2026, 11, 20);

    [Theory]
    [InlineData("5,50", 5.50)]
    [InlineData("5.50", 5.50)]
    [InlineData(" 6 ", 6)]
    [InlineData("2,5", 2.5)]
    public void Decimal_accepts_comma_and_dot(string input, double expected)
    {
        Assert.True(InputParsers.TryParseDecimal(input, out var value));
        Assert.Equal((decimal)expected, value);
    }

    [Theory]
    [InlineData("abc")]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("5,5,5")]
    [InlineData("1 000")]
    public void Decimal_rejects_garbage(string? input)
        => Assert.False(InputParsers.TryParseDecimal(input, out _));

    [Theory]
    [InlineData("1.2.2027", 2027, 2, 1)]
    [InlineData("01.02.2027", 2027, 2, 1)]
    [InlineData("днес", 2026, 11, 20)]
    [InlineData("Вчера", 2026, 11, 19)]
    [InlineData("утре", 2026, 11, 21)]
    public void Date_accepts_bulgarian_format_and_words(string input, int y, int m, int d)
    {
        Assert.True(InputParsers.TryParseDate(input, Today, out var date));
        Assert.Equal(new DateOnly(y, m, d), date);
    }

    [Theory]
    [InlineData("31.02.2027")]
    [InlineData("2027-02-01")]
    [InlineData("утрe-ish")]
    [InlineData("")]
    public void Date_rejects_invalid(string input)
        => Assert.False(InputParsers.TryParseDate(input, Today, out _));

    [Theory]
    [InlineData("8:05", 8, 5)]
    [InlineData("13:50", 13, 50)]
    public void Time_accepts_hours_and_minutes(string input, int h, int m)
    {
        Assert.True(InputParsers.TryParseTime(input, out var time));
        Assert.Equal(new TimeOnly(h, m), time);
    }

    [Theory]
    [InlineData("25:00")]
    [InlineData("8")]
    [InlineData("x")]
    public void Time_rejects_invalid(string input)
        => Assert.False(InputParsers.TryParseTime(input, out _));

    [Theory]
    [InlineData("5", 1, 10, true)]
    [InlineData("0", 1, 10, false)]
    [InlineData("11", 1, 10, false)]
    [InlineData("five", 1, 10, false)]
    public void Int_respects_range(string input, int min, int max, bool ok)
        => Assert.Equal(ok, InputParsers.TryParseInt(input, min, max, out _));
}
