// Owner: Shared
using Shkolo.Domain.Enums;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Presentation;

/// <summary>End-to-end teacher workflows from login through the command centre (scripted keyboard).</summary>
public class TeacherUiTests
{
    private static UiApp TeacherSession()
    {
        var ui = new UiApp();
        ui.Login("teacher1", "Teacher123!");
        return ui;
    }

    private static void Finish(UiApp ui)
    {
        ui.LeaveShell().Console.Choose(2);
        ui.Run();
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Teacher_records_a_lesson_with_absence_and_grade_in_one_flow()
    {
        var ui = TeacherSession();
        var lessonsBefore = ui.Db.Lessons.Count;
        ui.Console.Keys("п")             // dashboard hotkey: Провеждане на час
            .Choose(0)
            .Type("Квадратни неравенства")
            .Type("")
            .MultiSelect(0)
            .Choose(0)
            .Type("д")
            .Choose(0)
            .Type("5,50")
            .Choose(0)
            .Type("")
            .Type("н")
            .Type("д")
            .Key();
        Finish(ui);

        Assert.Equal(lessonsBefore + 1, ui.Db.Lessons.Count);
        var lesson = ui.Db.Lessons.Single(l => l.Topic == "Квадратни неравенства");
        Assert.Equal(ui.App.Clock.Today, lesson.Date);
        Assert.Single(ui.Db.AttendanceRecords, a => a.LessonId == lesson.Id && a.Status == AttendanceStatus.Absent);
        Assert.Equal(5.50m, Assert.Single(ui.Db.Grades, g => g.LessonId == lesson.Id).Value);
        Assert.Contains("Часът е записан.", ui.Console.Output);
        Assert.Contains("Готово", ui.Console.Output);
    }

    [Fact]
    public void Out_of_range_grade_is_rejected_by_input_validation()
    {
        var ui = TeacherSession();
        var gradesBefore = ui.Db.Grades.Count;
        ui.Console.Keys("4").Keys("н")   // Оценки › Нова оценка
            .Choose(0).Choose(0)
            .Type("7")
            .Type("");
        Finish(ui);

        Assert.Equal(gradesBefore, ui.Db.Grades.Count);
        Assert.Contains("Въведете число от", ui.Console.Output);
    }

    [Fact]
    public void Term_grade_sheet_shows_suggestions()
    {
        var ui = TeacherSession();
        ui.Console.Keys("5").Keys("с").Choose(0).Choose(0).Choose(6);
        Finish(ui);

        Assert.Contains("Предложение", ui.Console.Output);
        Assert.Contains("Текущ успех", ui.Console.Output);
    }
}
