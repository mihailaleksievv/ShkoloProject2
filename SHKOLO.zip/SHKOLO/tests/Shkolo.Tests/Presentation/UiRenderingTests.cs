// Owner: Shared
using Shkolo.Presentation.Components;
using Spectre.Console;

namespace Shkolo.Tests.Presentation;

public class UiRenderingTests
{
    private static (IAnsiConsole Console, StringWriter Output) TestConsole()
    {
        var writer = new StringWriter();
        var console = AnsiConsole.Create(new AnsiConsoleSettings
        {
            Out = new AnsiConsoleOutput(writer),
            Ansi = AnsiSupport.No,
            ColorSystem = ColorSystemSupport.NoColors,
            Interactive = InteractionSupport.No,
        });
        console.Profile.Width = 160;
        return (console, writer);
    }

    private sealed record Row(string Name, string Note);

    [Fact]
    public void Table_with_markup_characters_renders_literally()
    {
        var (console, output) = TestConsole();
        var rows = new[] { new Row("Иван [test] [/]", "[red]не е цвят[/]") };

        TableRenderer.Render(console, "Ученици [10А]", rows, Col.Text<Row>("Име", r => r.Name), Col.Text<Row>("Бележка", r => r.Note));

        var text = output.ToString();
        Assert.Contains("Иван [test] [/]", text);
        Assert.Contains("[red]не е цвят[/]", text);
        Assert.Contains("Ученици [10А]", text);
    }

    [Fact]
    public void Empty_table_shows_placeholder()
    {
        var (console, output) = TestConsole();
        TableRenderer.Render(console, "Оценки", Array.Empty<Row>(), Col.Text<Row>("Име", r => r.Name));
        Assert.Contains("Няма записи", output.ToString());
    }

    [Fact]
    public void Notifier_escapes_service_messages()
    {
        var (console, output) = TestConsole();
        new Notifier(console).Error("Предмет „[x]“ вече съществува.");
        Assert.Contains("Предмет „[x]“ вече съществува.", output.ToString());
    }

    [Fact]
    public void Escape_handles_null()
        => Assert.Equal("", Ui.Escape(null));
}
