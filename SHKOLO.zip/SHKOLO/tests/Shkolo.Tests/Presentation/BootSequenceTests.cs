// Owner: Shared
using Shkolo.Application.Abstractions;
using Shkolo.Presentation.Motion;
using Shkolo.Presentation.Screens;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Presentation;

public class BootSequenceTests
{
    [Fact]
    public void Boot_shows_real_loading_steps_and_counts()
    {
        var db = Scenario.Standard().Db;
        var (console, output) = Render.Create();

        BootSequence.Run(console, new Animator(MotionSettings.Disabled, new ManualFrameTimer()), new LoadResult(LoadStatus.Loaded, db, null, []));

        var text = output.ToString();
        Assert.Contains("Зареждане на данните", text);
        Assert.Contains("Проверка на целостта", text);
        Assert.Contains("3 ученици", text);
        Assert.Contains("Училищният ден – под контрол.", text);
    }

    [Fact]
    public void Boot_without_database_does_not_throw()
    {
        var (console, output) = Render.Create();
        BootSequence.Run(console, new Animator(MotionSettings.Disabled, new ManualFrameTimer()), new LoadResult(LoadStatus.Corrupted, null, "x", []));
        Assert.Contains("Зареждане на данните", output.ToString());
    }
}
