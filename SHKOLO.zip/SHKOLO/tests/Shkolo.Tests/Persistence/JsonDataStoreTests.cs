// Owner: Shared
using System.Text.Json;
using Shkolo.Application.Abstractions;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Infrastructure.Persistence;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Persistence;

public class JsonDataStoreTests : IDisposable
{
    private readonly TempDirectory _dir = new();
    private readonly FakeClock _clock = new(new DateOnly(2026, 11, 20));
    private int _seedCalls;

    public void Dispose() => _dir.Dispose();

    private string MainFile => Path.Combine(_dir.Path, "school-data.json");

    private SchoolDatabase Seed()
    {
        _seedCalls++;
        var db = new SchoolDatabase { SchoolName = "Тест" };
        db.Users.Add(new User { Username = "admin", Role = UserRole.Administrator });
        return db;
    }

    private JsonDataStore NewStore() => new(_dir.Path, new BackupManager(_dir.Path, _clock), Seed, _clock);

    [Fact]
    public void Missing_file_creates_seed_once()
    {
        var first = NewStore().Load();
        Assert.Equal(LoadStatus.CreatedNew, first.Status);
        Assert.True(File.Exists(MainFile));

        var second = NewStore().Load();
        Assert.Equal(LoadStatus.Loaded, second.Status);
        Assert.Equal(1, _seedCalls);
        Assert.Equal("Тест", second.Database!.SchoolName);
    }

    [Fact]
    public void Missing_data_directory_is_created()
    {
        var nested = Path.Combine(_dir.Path, "a", "b");
        var store = new JsonDataStore(nested, new BackupManager(nested, _clock), Seed, _clock);

        Assert.Equal(LoadStatus.CreatedNew, store.Load().Status);
        Assert.True(File.Exists(Path.Combine(nested, "school-data.json")));
    }

    [Fact]
    public void Save_then_load_round_trips_all_collections()
    {
        var db = FullDatabase();
        NewStore().Save(db);

        var loaded = NewStore().Load();
        Assert.Equal(LoadStatus.Loaded, loaded.Status);
        Assert.Equal(JsonSerializer.Serialize(db, JsonOptions.Default), JsonSerializer.Serialize(loaded.Database, JsonOptions.Default));
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("{ not json")]
    [InlineData("null")]
    [InlineData("[1,2,3]")]
    public void Unreadable_file_is_corrupted_and_untouched(string content)
    {
        File.WriteAllText(MainFile, content);

        var result = NewStore().Load();

        Assert.Equal(LoadStatus.Corrupted, result.Status);
        Assert.Null(result.Database);
        Assert.Equal(content, File.ReadAllText(MainFile));
        Assert.Single(Directory.GetFiles(_dir.Path, "school-data.corrupt-*.json"));
        Assert.Equal(0, _seedCalls);
    }

    [Fact]
    public void Newer_schema_is_unsupported()
    {
        var db = Seed();
        db.SchemaVersion = 99;
        File.WriteAllText(MainFile, JsonSerializer.Serialize(db, JsonOptions.Default));

        Assert.Equal(LoadStatus.UnsupportedVersion, NewStore().Load().Status);
    }

    [Fact]
    public void Save_refuses_database_without_users()
    {
        var store = NewStore();
        store.Load();
        var before = File.ReadAllText(MainFile);

        Assert.Throws<DataStoreException>(() => store.Save(new SchoolDatabase()));
        Assert.Equal(before, File.ReadAllText(MainFile));
    }

    [Fact]
    public void Save_creates_backup_of_previous_version()
    {
        var store = NewStore();
        store.Save(Seed());
        _clock.Advance(TimeSpan.FromSeconds(1));
        store.Save(Seed());

        Assert.Single(Directory.GetFiles(Path.Combine(_dir.Path, "Backups")));
    }

    [Fact]
    public void Save_sets_last_saved_time()
    {
        var db = Seed();
        NewStore().Save(db);
        Assert.Equal(_clock.UtcNow, db.LastSavedAtUtc);
    }

    [Fact]
    public void Locked_file_save_throws_DataStoreException()
    {
        var store = NewStore();
        store.Load();
        var before = File.ReadAllText(MainFile);

        using (new FileStream(MainFile, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
        {
            Assert.Throws<DataStoreException>(() => store.Save(Seed()));
        }

        Assert.Equal(before, File.ReadAllText(MainFile));
        Assert.False(File.Exists(MainFile + ".tmp"));
    }

    private SchoolDatabase FullDatabase()
    {
        var db = Seed();
        var id = Guid.NewGuid();
        db.LastSavedAtUtc = _clock.UtcNow;
        db.BellSchedule.Add(new LessonSlot { LessonNumber = 1, StartTime = new TimeOnly(8, 0), EndTime = new TimeOnly(8, 40) });
        db.Students.Add(new Student { FirstName = "Иван", LastName = "Петров", StudentNumber = "1", ClassId = id });
        db.Teachers.Add(new Teacher { FirstName = "Мария", EmployeeNumber = "T1", Email = "m@s.bg" });
        db.Classes.Add(new SchoolClass { GradeLevel = 10, Section = "А", AcademicYearId = id });
        db.Subjects.Add(new Subject { Name = "Математика" });
        db.AcademicYears.Add(new AcademicYear { Name = "2026/2027", StartDate = new DateOnly(2026, 9, 15), FirstTermEndDate = new DateOnly(2027, 1, 31), EndDate = new DateOnly(2027, 6, 30), IsActive = true });
        db.TeacherAssignments.Add(new TeacherAssignment { TeacherId = id, ClassId = id, SubjectId = id });
        db.Timetable.Add(new TimetableEntry { DayOfWeek = DayOfWeek.Monday, LessonNumber = 1, Room = "101" });
        db.Lessons.Add(new Lesson { Topic = "Тема", Date = new DateOnly(2026, 10, 5), Status = LessonStatus.Cancelled });
        db.Grades.Add(new Grade { Value = 5.75m, GradeType = GradeType.Project, Comment = "к" });
        db.TermGrades.Add(new TermGrade { Period = TermPeriod.Annual, Value = 6 });
        db.AttendanceRecords.Add(new AttendanceRecord { Status = AttendanceStatus.Late, Note = "5 мин" });
        db.Homework.Add(new Homework { Title = "Д", DueDate = new DateOnly(2026, 12, 1) });
        db.HomeworkSubmissions.Add(new HomeworkSubmission { Content = "отговор" });
        db.Feedback.Add(new Feedback { Type = FeedbackType.Remark, IsVisibleToStudent = false });
        db.Announcements.Add(new Announcement { Title = "А", TargetClassId = id });
        db.SchoolEvents.Add(new SchoolEvent { Title = "С", StartDateTime = new DateTime(2026, 12, 1, 9, 0, 0) });
        db.AchievementBadges.Add(new AchievementBadge { Name = "Б", Symbol = "★" });
        db.StudentAchievements.Add(new StudentAchievement { Note = "н" });
        db.Notifications.Add(new Notification { Type = NotificationType.NewGrade, IsRead = true });
        db.AuditLog.Add(new AuditEntry { Action = "Grade.Created", Summary = "s" });
        return db;
    }
}
