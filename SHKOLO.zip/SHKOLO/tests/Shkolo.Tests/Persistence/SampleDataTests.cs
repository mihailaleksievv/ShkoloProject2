// Owner: Participant 3 – Data Developer
using System.Text.Json;
using Shkolo.Domain;
using Shkolo.Infrastructure.Persistence;
using Shkolo.Tests.Architecture;

namespace Shkolo.Tests.Persistence;

/// <summary>
/// The example database shipped in src/Shkolo/JSON (for presenting the JSON format) must stay a file
/// the program itself can read: right schema, no integrity problems, the demo accounts inside.
/// </summary>
public class SampleDataTests
{
    private static string SamplePath => Path.Combine(LayeringTests.FindRepoRoot(), "src", "Shkolo", "JSON", "school-data.example.json");

    [Fact]
    public void Sample_json_is_a_valid_database_with_the_demo_accounts()
    {
        Assert.True(File.Exists(SamplePath), "src/Shkolo/JSON/school-data.example.json is part of the project");

        var db = JsonSerializer.Deserialize<SchoolDatabase>(File.ReadAllText(SamplePath), JsonOptions.Default)!;

        Assert.Equal(SchoolDatabase.CurrentSchemaVersion, db.SchemaVersion);
        Assert.Empty(new IntegrityValidator().Validate(db));
        Assert.Equal(22, db.Users.Count);
        Assert.Contains(db.Students, s => s.FullName == "Михаил Алексиев");
        Assert.Contains(db.Teachers, t => t.FullName == "Иван Иванов");
        Assert.Contains(db.Users, u => u.Username == "student1");
        Assert.DoesNotContain("Student123!", File.ReadAllText(SamplePath));   // only hashes, never passwords
    }
}
