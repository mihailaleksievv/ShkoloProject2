// Owner: Shared
using Shkolo.Application;
using Shkolo.Application.Abstractions;
using Shkolo.Application.Requests;
using Shkolo.Application.Security;
using Shkolo.Domain.Enums;
using Shkolo.Infrastructure.Export;
using Shkolo.Infrastructure.Persistence;
using Shkolo.Presentation.Screens;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Persistence;

/// <summary>Real files on disk: changes survive a restart, and a damaged file is recovered from a backup.</summary>
public class PersistenceEndToEndTests : IDisposable
{
    private readonly TempDirectory _dir = new();
    private readonly FakeClock _clock = new(Scenario.Today);

    public void Dispose() => _dir.Dispose();

    private (JsonDataStore Store, BackupManager Backups) NewStore()
    {
        var backups = new BackupManager(_dir.Path, _clock);
        var initializer = new DatabaseInitializer(_clock, new FastHasher());
        return (new JsonDataStore(_dir.Path, backups, initializer.CreateInitialDatabase, _clock, new IntegrityValidator()), backups);
    }

    private ApplicationServices Start(out LoadResult load)
    {
        var (store, backups) = NewStore();
        load = store.Load();
        return new ApplicationServices(new UnitOfWork(store, load.Database!), new SessionContext(), _clock, new FastHasher(),
            new CsvReportExporter(Path.Combine(_dir.Path, "Exports"), _clock), backups, store.DataFilePath);
    }

    [Fact]
    public void Changes_survive_a_restart()
    {
        var first = Start(out var load1);
        Assert.Equal(LoadStatus.CreatedNew, load1.Status);
        Assert.True(first.Auth.Login("teacher1", "Teacher123!").Success);
        var student = first.Students.GetAllStudents().Value!.First();
        var subject = first.Assignments.GetForTeacher(first.Session.TeacherId!.Value).Value!.First(a => a.ClassId == student.ClassId);
        Assert.True(first.Grades.AddGrade(new GradeInput(student.Id, subject.SubjectId, 5.75m, _clock.Today, GradeType.Project, "отличен проект")).Success);

        var second = Start(out var load2);

        Assert.Equal(LoadStatus.Loaded, load2.Status);
        Assert.Contains(load2.Database!.Grades, g => g.Value == 5.75m && g.Comment == "отличен проект");
        Assert.Contains(load2.Database.AuditLog, a => a.Action == "Grade.Created");
        Assert.True(second.Auth.Login("teacher1", "Teacher123!").Success);
    }

    [Fact]
    public void Damaged_file_is_recovered_from_backup_through_the_recovery_screen()
    {
        var services = Start(out _);
        services.Auth.Login("admin", "Admin123!");
        _clock.Advance(TimeSpan.FromSeconds(2));
        services.Subjects.Add(new SubjectInput("Химия", "ХИМ"));
        var dataFile = Path.Combine(_dir.Path, "school-data.json");
        File.WriteAllText(dataFile, "{ \"Users\": [ broken");

        var (store, backups) = NewStore();
        var load = store.Load();
        Assert.Equal(LoadStatus.Corrupted, load.Status);

        var console = new ScriptedConsole();
        console.Choose(0).Choose(0); // "Възстановяване от архив" → newest backup
        var choice = RecoveryScreen.Run(console, load, backups, allowReadOnly: false);

        Assert.Equal(RecoveryChoice.Restored, choice);
        var reloaded = NewStore().Store.Load();
        Assert.Equal(LoadStatus.Loaded, reloaded.Status);
        Assert.Equal(22, reloaded.Database!.Users.Count);
        Assert.Single(Directory.GetFiles(_dir.Path, "school-data.corrupt-*.json"));
    }
}
