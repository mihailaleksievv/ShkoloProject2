// Owner: Shared
using System.Text.Json;
using Shkolo.Application.Abstractions;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Infrastructure.Persistence;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Persistence;

public class IntegrityValidatorTests
{
    private readonly IntegrityValidator _validator = new();

    /// <summary>Small but fully consistent database: one year, class, subject, teacher, student, lesson, grade.</summary>
    private static SchoolDatabase Valid()
    {
        var db = new SchoolDatabase();
        var year = new AcademicYear { Name = "2026/2027", StartDate = new DateOnly(2026, 9, 15), FirstTermEndDate = new DateOnly(2027, 1, 31), EndDate = new DateOnly(2027, 6, 30), IsActive = true };
        var cls = new SchoolClass { GradeLevel = 10, Section = "А", AcademicYearId = year.Id };
        var subject = new Subject { Name = "Математика" };
        var teacher = new Teacher { EmployeeNumber = "T1", FirstName = "М", LastName = "И", Email = "t@s.bg" };
        var student = new Student { StudentNumber = "1", FirstName = "И", LastName = "П", ClassId = cls.Id };
        var lesson = new Lesson { ClassId = cls.Id, SubjectId = subject.Id, TeacherId = teacher.Id, Date = new DateOnly(2026, 10, 1), LessonNumber = 1, Topic = "т" };
        db.BellSchedule.Add(new LessonSlot { LessonNumber = 1, StartTime = new TimeOnly(8, 0), EndTime = new TimeOnly(8, 40) });
        db.AcademicYears.Add(year);
        db.Classes.Add(cls);
        db.Subjects.Add(subject);
        db.Teachers.Add(teacher);
        db.Students.Add(student);
        db.TeacherAssignments.Add(new TeacherAssignment { TeacherId = teacher.Id, ClassId = cls.Id, SubjectId = subject.Id });
        db.Lessons.Add(lesson);
        db.Grades.Add(new Grade { StudentId = student.Id, ClassId = cls.Id, SubjectId = subject.Id, TeacherId = teacher.Id, LessonId = lesson.Id, Value = 5m, Date = lesson.Date });
        db.AttendanceRecords.Add(new AttendanceRecord { StudentId = student.Id, LessonId = lesson.Id, RecordedByTeacherId = teacher.Id });
        db.Users.Add(new User { Username = "admin", Role = UserRole.Administrator });
        db.Users.Add(new User { Username = "t1", Role = UserRole.Teacher, TeacherId = teacher.Id });
        db.Users.Add(new User { Username = "s1", Role = UserRole.Student, StudentId = student.Id });
        return db;
    }

    [Fact]
    public void Valid_database_has_no_issues() => Assert.Empty(_validator.Validate(Valid()));

    [Fact]
    public void Grade_with_unknown_student_is_reported()
    {
        var db = Valid();
        db.Grades[0].StudentId = Guid.NewGuid();
        var issue = Assert.Single(_validator.Validate(db));
        Assert.Contains("Grade", issue);
    }

    [Fact]
    public void Duplicate_student_number_is_reported()
    {
        var db = Valid();
        db.Students.Add(new Student { StudentNumber = "1", FirstName = "А", LastName = "Б", ClassId = db.Classes[0].Id });
        Assert.Single(_validator.Validate(db));
    }

    [Fact]
    public void Two_active_years_are_reported()
    {
        var db = Valid();
        db.AcademicYears.Add(new AcademicYear { Name = "x", IsActive = true });
        Assert.Single(_validator.Validate(db));
    }

    [Fact]
    public void Student_user_without_profile_is_reported()
    {
        var db = Valid();
        db.Users[2].StudentId = null;
        Assert.Single(_validator.Validate(db));
    }

    [Fact]
    public void Attendance_for_unknown_lesson_is_reported()
    {
        var db = Valid();
        db.AttendanceRecords[0].LessonId = Guid.NewGuid();
        Assert.Single(_validator.Validate(db));
    }

    [Fact]
    public void Out_of_range_grade_is_reported()
    {
        var db = Valid();
        db.Grades[0].Value = 7m;
        Assert.Single(_validator.Validate(db));
    }

    [Fact]
    public void Data_store_reports_integrity_problems_but_returns_database()
    {
        using var dir = new TempDirectory();
        var clock = new FakeClock(new DateOnly(2026, 11, 20));
        var db = Valid();
        db.Grades[0].SubjectId = Guid.NewGuid();
        File.WriteAllText(Path.Combine(dir.Path, "school-data.json"), JsonSerializer.Serialize(db, JsonOptions.Default));

        var store = new JsonDataStore(dir.Path, new BackupManager(dir.Path, clock), Valid, clock, _validator);
        var result = store.Load();

        Assert.Equal(LoadStatus.IntegrityProblems, result.Status);
        Assert.NotNull(result.Database);
        Assert.Single(result.IntegrityIssues);
    }
}
