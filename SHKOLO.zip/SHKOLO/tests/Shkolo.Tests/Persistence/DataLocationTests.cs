// Owner: Participant 3 – Data Developer
using Shkolo.Infrastructure.Persistence;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Persistence;

public class DataLocationTests
{
    [Fact]
    public void Data_argument_wins()
    {
        using var dir = new TempDirectory();
        var target = Path.Combine(dir.Path, "Моите данни");

        Assert.Equal(Path.GetFullPath(target), DataLocation.Resolve(["--data", target], dir.Path));
    }

    [Fact]
    public void Running_from_source_keeps_the_database_in_the_project_folder()
    {
        using var dir = new TempDirectory();
        var project = Path.Combine(dir.Path, "src", "Shkolo");
        var output = Path.Combine(project, "bin", "Debug", "net9.0");
        Directory.CreateDirectory(output);
        File.WriteAllText(Path.Combine(project, "Shkolo.csproj"), "<Project />");

        Assert.Equal(Path.Combine(project, "Data"), DataLocation.Resolve([], output));
    }

    [Fact]
    public void Published_build_keeps_the_database_next_to_the_executable()
    {
        using var dir = new TempDirectory();

        Assert.Equal(Path.Combine(dir.Path, "Data"), DataLocation.Resolve([], dir.Path));
    }
}
