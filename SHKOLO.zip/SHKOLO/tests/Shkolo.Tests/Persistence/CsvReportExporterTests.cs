// Owner: Shared
using System.Text;
using Shkolo.Infrastructure.Export;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Persistence;

public class CsvReportExporterTests : IDisposable
{
    private readonly TempDirectory _dir = new();

    public void Dispose() => _dir.Dispose();

    [Fact]
    public void Writes_bom_semicolons_and_escapes_values()
    {
        var exporter = new CsvReportExporter(_dir.Path, new FakeClock(new DateOnly(2026, 11, 20)));

        var path = exporter.Export("Справка 10А/тест", ["Показател", "Стойност"], [new[] { "Среден успех", "5,50" }, new[] { "a;b\"c", "x" }]);

        var bytes = File.ReadAllBytes(path);
        Assert.Equal(new byte[] { 0xEF, 0xBB, 0xBF }, bytes[..3]);
        var lines = Encoding.UTF8.GetString(bytes[3..]).Split("\r\n", StringSplitOptions.RemoveEmptyEntries);
        Assert.Equal("Показател;Стойност", lines[0]);
        Assert.Equal("Среден успех;5,50", lines[1]);
        Assert.Equal("\"a;b\"\"c\";x", lines[2]);
        Assert.DoesNotContain("/", Path.GetFileName(path));
        Assert.EndsWith(".csv", path);
    }
}
