// Owner: Shared
using System.Text.Json;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Infrastructure.Persistence;

namespace Shkolo.Tests.Persistence;

public class JsonOptionsTests
{
    [Fact]
    public void Serializes_cyrillic_enums_and_dates_readably_and_round_trips()
    {
        var db = new SchoolDatabase();
        db.Students.Add(new Student { FirstName = "Иван" });
        db.Grades.Add(new Grade { GradeType = GradeType.Oral, Value = 5.50m, Date = new DateOnly(2026, 10, 1) });
        db.BellSchedule.Add(new LessonSlot { LessonNumber = 1, StartTime = new TimeOnly(8, 0), EndTime = new TimeOnly(8, 40) });

        var json = JsonSerializer.Serialize(db, JsonOptions.Default);

        Assert.Contains("\"Иван\"", json);
        Assert.Contains("\"Oral\"", json);
        Assert.Contains("\"2026-10-01\"", json);
        Assert.DoesNotContain("FullName", json);

        var back = JsonSerializer.Deserialize<SchoolDatabase>(json, JsonOptions.Default)!;
        Assert.Equal("Иван", back.Students[0].FirstName);
        Assert.Equal(5.50m, back.Grades[0].Value);
        Assert.Equal(GradeType.Oral, back.Grades[0].GradeType);
        Assert.Equal(new TimeOnly(8, 40), back.BellSchedule[0].EndTime);
    }
}
