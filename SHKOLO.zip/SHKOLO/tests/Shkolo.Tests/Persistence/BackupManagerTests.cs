// Owner: Shared
using Shkolo.Application.Abstractions;
using Shkolo.Infrastructure.Persistence;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Persistence;

public class BackupManagerTests : IDisposable
{
    private readonly TempDirectory _dir = new();
    private readonly FakeClock _clock = new(new DateOnly(2026, 11, 20));

    public void Dispose() => _dir.Dispose();

    private string MainFile => Path.Combine(_dir.Path, "school-data.json");

    private string BackupText(BackupInfo b) => File.ReadAllText(Path.Combine(_dir.Path, "Backups", b.FileName));

    [Fact]
    public void BackupManager_keeps_only_five()
    {
        var backups = new BackupManager(_dir.Path, _clock);
        for (var i = 0; i < 7; i++)
        {
            File.WriteAllText(MainFile, "v" + i);
            backups.CreateBackup(MainFile);
            _clock.Advance(TimeSpan.FromSeconds(1));
        }

        var list = backups.GetBackups();
        Assert.Equal(5, list.Count);
        Assert.Equal("v6", BackupText(list[0]));
        Assert.Equal("v2", BackupText(list[^1]));
    }

    [Fact]
    public void Restore_backup_replaces_main_file()
    {
        var backups = new BackupManager(_dir.Path, _clock);
        File.WriteAllText(MainFile, "old");
        backups.CreateBackup(MainFile);
        _clock.Advance(TimeSpan.FromSeconds(1));
        File.WriteAllText(MainFile, "broken");

        backups.RestoreBackup(backups.GetBackups().Single().FileName);

        Assert.Equal("old", File.ReadAllText(MainFile));
        Assert.Contains(backups.GetBackups(), b => BackupText(b) == "broken");
    }

    [Fact]
    public void Restore_oldest_backup_when_at_limit_works()
    {
        var backups = new BackupManager(_dir.Path, _clock);
        for (var i = 0; i < 5; i++)
        {
            File.WriteAllText(MainFile, "v" + i);
            backups.CreateBackup(MainFile);
            _clock.Advance(TimeSpan.FromSeconds(1));
        }

        backups.RestoreBackup(backups.GetBackups()[^1].FileName);

        Assert.Equal("v0", File.ReadAllText(MainFile));
    }

    [Fact]
    public void Restore_unknown_backup_throws()
    {
        var backups = new BackupManager(_dir.Path, _clock);
        Assert.Throws<DataStoreException>(() => backups.RestoreBackup(@"..\school-data.json"));
    }

    [Fact]
    public void Get_backups_on_missing_folder_is_empty()
        => Assert.Empty(new BackupManager(_dir.Path, _clock).GetBackups());
}
