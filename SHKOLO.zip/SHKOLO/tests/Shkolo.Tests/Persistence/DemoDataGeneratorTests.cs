﻿// Owner: Shared
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Infrastructure.Persistence;
using Shkolo.Infrastructure.Security;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Persistence;

public class DemoDataGeneratorTests
{
    private static readonly DateOnly Today = new(2026, 11, 20);

    private static SchoolDatabase Generate(DateOnly? today = null)
        => new DemoDataGenerator(new FakeClock(today ?? Today), new FastHasher()).Generate();

    [Fact]
    public void Demo_accounts_have_their_names_and_student1_has_a_full_feedback_history()
    {
        var db = Generate();
        var student = db.Students.Single(s => s.Id == db.Users.Single(u => u.Username == "student1").StudentId);
        var teacher = db.Teachers.Single(t => t.Id == db.Users.Single(u => u.Username == "teacher1").TeacherId);

        Assert.Equal("Михаил Алексиев", student.FullName);
        Assert.Equal("Иван Иванов", teacher.FullName);
        var feedback = db.Feedback.Where(f => f.StudentId == student.Id && f.IsVisibleToStudent).ToList();
        Assert.True(feedback.Count(f => f.Type == FeedbackType.Praise) >= 4, "several praises");
        Assert.True(feedback.Count(f => f.Type == FeedbackType.Remark) >= 3, "several remarks");
        Assert.True(feedback.Select(f => f.TeacherId).Distinct().Count() >= 3, "from different teachers");
        Assert.True(db.StudentAchievements.Count(a => a.StudentId == student.Id) >= 2, "at least two badges");
    }

    [Fact]
    public void Generated_database_passes_integrity_validation()
        => Assert.Empty(new IntegrityValidator().Validate(Generate()));

    [Fact]
    public void Has_expected_size()
    {
        var db = Generate();
        Assert.Single(db.Users, u => u.Role == UserRole.Administrator);
        Assert.Equal(3, db.Teachers.Count);
        Assert.Equal(3, db.Classes.Count);
        Assert.Equal(18, db.Students.Count);
        Assert.Equal(9, db.Subjects.Count);
        Assert.Equal(6, db.AchievementBadges.Count);
        Assert.Equal(22, db.Users.Count);
        Assert.Single(db.AcademicYears, y => y.IsActive);
        Assert.Equal(7, db.BellSchedule.Count);
        Assert.Equal(90, db.Timetable.Count);
        Assert.NotEmpty(db.Lessons);
        Assert.NotEmpty(db.Grades);
        Assert.NotEmpty(db.AttendanceRecords);
        Assert.NotEmpty(db.Homework);
        Assert.NotEmpty(db.HomeworkSubmissions);
        Assert.NotEmpty(db.Feedback);
        Assert.Equal(4, db.Announcements.Count);
        Assert.Equal(5, db.SchoolEvents.Count);
        Assert.NotEmpty(db.StudentAchievements);
        Assert.NotEmpty(db.Notifications);
    }

    [Fact]
    public void Timetable_has_no_conflicts_and_every_entry_is_assigned()
    {
        var db = Generate();
        Assert.All(db.Timetable.GroupBy(t => (t.ClassId, t.DayOfWeek, t.LessonNumber)), g => Assert.Single(g));
        Assert.All(db.Timetable.GroupBy(t => (t.TeacherId, t.DayOfWeek, t.LessonNumber)), g => Assert.Single(g));
        Assert.All(db.Timetable.Where(t => t.Room is not null).GroupBy(t => (t.Room, t.DayOfWeek, t.LessonNumber)), g => Assert.Single(g));
        Assert.All(db.Timetable, t => Assert.Contains(db.TeacherAssignments, a => a.TeacherId == t.TeacherId && a.ClassId == t.ClassId && a.SubjectId == t.SubjectId));
    }

    [Fact]
    public void Lessons_are_past_weekdays_inside_the_year_without_duplicates()
    {
        var db = Generate();
        var year = db.AcademicYears.Single(y => y.IsActive);
        Assert.All(db.Lessons, l =>
        {
            Assert.True(l.Date <= Today);
            Assert.True(year.Contains(l.Date));
            Assert.InRange(l.Date.DayOfWeek, DayOfWeek.Monday, DayOfWeek.Friday);
            Assert.False(string.IsNullOrWhiteSpace(l.Topic));
        });
        Assert.All(db.Lessons.GroupBy(l => (l.ClassId, l.Date, l.LessonNumber)), g => Assert.Single(g));
    }

    [Fact]
    public void Grades_and_attendance_are_consistent_with_lessons()
    {
        var db = Generate();
        var lessons = db.Lessons.ToDictionary(l => l.Id);
        var students = db.Students.ToDictionary(s => s.Id);
        Assert.All(db.Grades, g =>
        {
            Assert.True(DomainRules.IsValidGrade(g.Value));
            var lesson = lessons[g.LessonId!.Value];
            Assert.Equal(lesson.Date, g.Date);
            Assert.Equal(lesson.SubjectId, g.SubjectId);
            Assert.Equal(lesson.TeacherId, g.TeacherId);
            Assert.Equal(students[g.StudentId].ClassId, g.ClassId);
        });
        Assert.All(db.AttendanceRecords, a => Assert.Equal(lessons[a.LessonId].ClassId, students[a.StudentId].ClassId));
        Assert.All(db.HomeworkSubmissions, s => Assert.Equal(db.Homework.Single(h => h.Id == s.HomeworkId).ClassId, students[s.StudentId].ClassId));
    }

    [Fact]
    public void Generation_is_deterministic()
    {
        var a = Generate();
        var b = Generate();
        Assert.Equal(a.Grades.Select(g => g.Value), b.Grades.Select(g => g.Value));
        Assert.Equal(a.AttendanceRecords.Select(x => x.Status), b.AttendanceRecords.Select(x => x.Status));
        Assert.Equal(a.Students.Select(s => s.FullName), b.Students.Select(s => s.FullName));
    }

    [Fact]
    public void Demo_accounts_can_log_in()
    {
        var db = new DemoDataGenerator(new FakeClock(Today), new Pbkdf2PasswordHasher()).Generate();
        var app = TestApp.Create(db, Today);

        Assert.True(app.Services.Auth.Login("admin", "Admin123!").Success);
        app.Services.Auth.Logout();
        Assert.True(app.Services.Auth.Login("teacher1", "Teacher123!").Success);
        app.Services.Auth.Logout();
        Assert.True(app.Services.Auth.Login("student1", "Student123!").Success);
    }

    [Fact]
    public void Year_follows_the_clock_so_the_demo_always_has_data()
    {
        var db = Generate(new DateOnly(2030, 7, 15));
        var year = db.AcademicYears.Single(y => y.IsActive);
        Assert.Equal(new DateOnly(2029, 9, 15), year.StartDate);
        Assert.NotEmpty(db.Lessons);
        Assert.Empty(new IntegrityValidator().Validate(db));
    }

    [Fact]
    public void Term_grades_exist_only_after_first_term_ended()
    {
        Assert.Empty(Generate().TermGrades);
        var february = Generate(new DateOnly(2027, 2, 10));
        Assert.NotEmpty(february.TermGrades);
        Assert.All(february.TermGrades, t => Assert.Equal(TermPeriod.FirstTerm, t.Period));
    }

    [Fact]
    public void Teacher_dashboard_today_has_lessons_on_a_school_day()
    {
        var db = Generate();
        var app = TestApp.Create(db, Today).LoginAs(db.Users.Single(u => u.Username == "teacher1").Id);
        Assert.NotEmpty(app.Services.Reports.GetTeacherDashboard().Value!.Today);
    }
}
