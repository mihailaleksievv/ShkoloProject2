﻿// Owner: Shared
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Infrastructure.Persistence;
using Shkolo.Tests.Presentation;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.ReviewFixes;

/// <summary>Regression tests for the findings of the final whole-branch review.</summary>
public class ReviewFixTests
{
    // ---------- 1 + 5: markup in prompt labels, cancellable term grade ----------

    [Fact]
    public void Term_grade_for_student_with_brackets_does_not_crash_and_empty_input_cancels()
    {
        var ui = new UiApp();
        var tenA = ui.Db.Classes.Single(c => c.DisplayName == "10А");
        foreach (var s in ui.Db.Students.Where(s => s.ClassId == tenA.Id))
        {
            s.LastName = "[x] " + s.LastName;
        }

        ui.Login("teacher1", "Teacher123!");
        ui.Console.Keys("5").Keys("с")   // Срочни оценки › Поставяне
            .Choose(0)              // 10А · first subject
            .Choose(0)              // I срок
            .Choose(0)              // first student
            .Type("")               // empty input = cancel, nothing assigned
            .Choose(6);             // ← Назад from the sheet
        ui.LeaveShell().Console.Choose(2);
        ui.Run();

        Assert.Empty(ui.Errors);
        Assert.Empty(ui.Db.TermGrades);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    // ---------- 2: year scoping ----------

    [Fact]
    public void Averages_and_reports_count_only_the_active_year()
    {
        var s = Scenario.Standard();
        var oldYear = new AcademicYear { Name = "2025/2026", StartDate = new DateOnly(2025, 9, 15), FirstTermEndDate = new DateOnly(2026, 1, 31), EndDate = new DateOnly(2026, 6, 30) };
        s.Db.AcademicYears.Add(oldYear);
        s.Db.Grades.Add(new Grade { StudentId = s.Student1, ClassId = s.Class10A, SubjectId = s.Math, TeacherId = s.MathTeacher, Value = 2m, Date = new DateOnly(2026, 3, 1) });
        s.Db.Grades.Add(new Grade { StudentId = s.Student1, ClassId = s.Class10A, SubjectId = s.Math, TeacherId = s.MathTeacher, Value = 6m, Date = Scenario.Today });
        s.Db.TermGrades.Add(new TermGrade { StudentId = s.Student1, SubjectId = s.Math, ClassId = s.Class10A, AcademicYearId = oldYear.Id, Period = TermPeriod.Annual, Value = 3, TeacherId = s.MathTeacher });
        var student = TestApp.Create(s.Db).LoginAs(s.Student1User).Services;
        var admin = TestApp.Create(s.Db).LoginAs(s.AdminUser).Services;

        Assert.Equal(6m, student.Grades.CalculateAverage(s.Student1).Value);
        Assert.Equal(6m, student.Grades.CalculateSubjectAverage(s.Student1, s.Math).Value);
        var report = student.Reports.GenerateStudentReport(s.Student1).Value!;
        Assert.Equal(6m, report.OverallAverage);
        Assert.Equal(1, report.GradeCount);
        Assert.Empty(report.TermGrades);
        Assert.Single(student.Grades.GetGradesForStudent(s.Student1).Value!);
        Assert.Equal(6m, admin.Reports.GetSchoolStatistics().Value!.SchoolAverage);
        Assert.Equal(1, admin.Reports.GetSubjectPerformance(s.Math).Value!.GradeCount);
    }

    // ---------- 3: backups are not rotated out by frequent saves ----------

    [Fact]
    public void Frequent_saves_do_not_rotate_out_recovery_points()
    {
        using var dir = new TempDirectory();
        var clock = new FakeClock(Scenario.Today);
        var backups = new BackupManager(dir.Path, clock);
        var store = new JsonDataStore(dir.Path, backups, () => Scenario.Standard().Db, clock);
        var db = store.Load().Database!;

        for (var i = 0; i < 8; i++)
        {
            clock.Advance(TimeSpan.FromMinutes(1));
            store.Save(db);
        }

        Assert.Single(backups.GetBackups());

        clock.Advance(TimeSpan.FromMinutes(11));
        store.Save(db);
        Assert.Equal(2, backups.GetBackups().Count);
    }

    // ---------- 4: editing a grade keeps its comment ----------

    [Fact]
    public void Editing_a_grade_keeps_the_comment_when_enter_is_pressed()
    {
        var ui = new UiApp();
        var teacher = ui.Db.Teachers.Single(t => t.FirstName == "Иван" && t.LastName == "Иванов");
        var tenA = ui.Db.Classes.Single(c => c.DisplayName == "10А");
        var informatics = ui.Db.Subjects.Single(x => x.Name == "Информатика");
        var student = ui.Db.Students.First(x => x.ClassId == tenA.Id);
        var grade = new Grade { StudentId = student.Id, ClassId = tenA.Id, SubjectId = informatics.Id, TeacherId = teacher.Id, Value = 5m, Date = ui.App.Clock.Today, Comment = "много добър проект", CreatedAtUtc = DateTime.UtcNow.AddYears(1) };
        ui.Db.Grades.Add(grade);

        ui.Login("teacher1", "Teacher123!");
        ui.Console.Keys("4").Keys("е")   // Оценки › Редакция
            .Choose(2)              // Редактиране на моя оценка
            .Choose(0)              // 10А · Информатика
            .Choose(0)              // newest own grade
            .Type("4")
            .Choose(0)              // oral
            .Type("")               // keep comment
            .Key()
            .Choose(4);             // back
        ui.LeaveShell().Console.Choose(2);
        ui.Run();

        Assert.Empty(ui.Errors);
        Assert.Equal(4m, grade.Value);
        Assert.Equal("много добър проект", ui.Db.Grades.Single(g => g.Id == grade.Id).Comment);
    }

    // ---------- 6: today's programme outside the year ----------

    [Fact]
    public void Today_programme_is_empty_outside_the_active_year()
    {
        var s = Scenario.Standard();
        s.Db.Timetable.Add(new TimetableEntry { ClassId = s.Class10A, SubjectId = s.Math, TeacherId = s.MathTeacher, DayOfWeek = DayOfWeek.Wednesday, LessonNumber = 1 });
        var summer = TestApp.Create(s.Db, new DateOnly(2027, 7, 14)).LoginAs(s.MathTeacherUser);
        Assert.Empty(summer.Services.Timetable.GetTodayForCurrentUser());

        s.Db.AcademicYears.Single().IsActive = false;
        var noYear = TestApp.Create(s.Db, new DateOnly(2026, 11, 18)).LoginAs(s.MathTeacherUser);
        Assert.Empty(noYear.Services.Timetable.GetTodayForCurrentUser());
    }

    // ---------- 7: students cannot list classmates ----------

    [Fact]
    public void Student_cannot_list_students_of_own_class()
    {
        var s = Scenario.Standard();
        var result = TestApp.Create(s.Db).LoginAs(s.Student1User).Services.Students.GetStudentsByClass(s.Class10A);
        Assert.Equal(ErrorKind.Forbidden, result.Error!.Kind);
    }

    // ---------- 8: login throttle survives leaving the login screen ----------

    [Fact]
    public void Failed_login_counter_survives_returning_to_the_start_screen()
    {
        var ui = new UiApp();
        ui.Login("admin", "wrong").Console.Key().Type("");     // back to start
        ui.Login("admin", "wrong").Console.Key().Type("");     // a NEW login screen
        ui.Console.Choose(2);
        ui.Run();

        Assert.Equal(2, ui.Context.FailedLoginAttempts);
    }
}
