// Owner: Shared
using System.Reflection;
using Shkolo.Domain;

namespace Shkolo.Tests.Architecture;

/// <summary>
/// Enforces the layer rules of the single-project architecture (spec §2) by reflection
/// over type signatures plus a source scan for console usage in non-UI layers.
/// </summary>
public class LayeringTests
{
    private static readonly Assembly App = typeof(SchoolDatabase).Assembly;

    private static IEnumerable<Type> TypesIn(string ns)
        => App.GetTypes().Where(t => t.Namespace != null && (t.Namespace == ns || t.Namespace.StartsWith(ns + ".")));

    private static IEnumerable<Type> Expand(Type t)
    {
        if (t.IsGenericType)
        {
            foreach (var arg in t.GetGenericArguments().SelectMany(Expand))
            {
                yield return arg;
            }
        }

        if (t.HasElementType)
        {
            foreach (var e in Expand(t.GetElementType()!))
            {
                yield return e;
            }
        }

        yield return t.IsGenericType ? t.GetGenericTypeDefinition() : t;
    }

    private static IEnumerable<Type> ReferencedTypes(Type type)
    {
        const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
        var refs = new List<Type>();
        if (type.BaseType != null) refs.Add(type.BaseType);
        refs.AddRange(type.GetInterfaces());
        refs.AddRange(type.GetFields(all).Select(f => f.FieldType));
        refs.AddRange(type.GetProperties(all).Select(p => p.PropertyType));
        foreach (var m in type.GetMethods(all))
        {
            refs.Add(m.ReturnType);
            refs.AddRange(m.GetParameters().Select(p => p.ParameterType));
        }

        foreach (var c in type.GetConstructors(all))
        {
            refs.AddRange(c.GetParameters().Select(p => p.ParameterType));
        }

        return refs.SelectMany(Expand).Distinct();
    }

    private static List<string> Violations(string fromNamespace, params string[] forbidden)
        => TypesIn(fromNamespace)
            .SelectMany(t => ReferencedTypes(t)
                .Where(r => r.Namespace != null && forbidden.Any(f => r.Namespace == f || r.Namespace.StartsWith(f + ".")))
                .Select(r => $"{t.FullName} -> {r.FullName}"))
            .ToList();

    [Fact]
    public void Domain_depends_on_nothing_else()
        => Assert.Empty(Violations("Shkolo.Domain", "Shkolo.Application", "Shkolo.Infrastructure", "Shkolo.Presentation"));

    [Fact]
    public void Application_depends_only_on_Domain()
        => Assert.Empty(Violations("Shkolo.Application", "Shkolo.Infrastructure", "Shkolo.Presentation"));

    [Fact]
    public void Infrastructure_does_not_reference_Presentation()
        => Assert.Empty(Violations("Shkolo.Infrastructure", "Shkolo.Presentation"));

    [Fact]
    public void Presentation_does_not_reference_Persistence()
        => Assert.Empty(Violations("Shkolo.Presentation", "Shkolo.Infrastructure.Persistence"));

    [Fact]
    public void Core_layers_do_not_reference_console_types()
        => Assert.Empty(
            Violations("Shkolo.Domain", "Spectre.Console")
                .Concat(Violations("Shkolo.Application", "Spectre.Console"))
                .Concat(Violations("Shkolo.Infrastructure", "Spectre.Console")));

    [Fact]
    public void Core_layer_sources_do_not_use_console()
    {
        var root = FindRepoRoot();
        var offenders = new[] { "Domain", "Application", "Infrastructure" }
            .Select(layer => Path.Combine(root, "src", "Shkolo", layer))
            .Where(Directory.Exists)
            .SelectMany(dir => Directory.EnumerateFiles(dir, "*.cs", SearchOption.AllDirectories))
            .Where(file =>
            {
                var text = File.ReadAllText(file);
                return text.Contains("Console.") || text.Contains("using Spectre");
            })
            .ToList();
        Assert.Empty(offenders);
    }

    internal static string FindRepoRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null && !File.Exists(Path.Combine(dir.FullName, "Shkolo.sln")))
        {
            dir = dir.Parent;
        }

        return dir?.FullName ?? throw new InvalidOperationException("Shkolo.sln not found above test output.");
    }
}
