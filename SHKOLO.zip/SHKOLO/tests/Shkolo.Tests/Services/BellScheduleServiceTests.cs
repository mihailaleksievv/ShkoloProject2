// Owner: Shared
using Shkolo.Application.Results;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class BellScheduleServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    [Fact]
    public void Slots_are_ordered_and_resolvable()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.Student1User);
        var slots = app.Services.BellSchedule.GetSlots();
        Assert.Equal(7, slots.Count);
        Assert.Equal(new TimeOnly(8, 0), app.Services.BellSchedule.GetSlot(1)!.StartTime);
        Assert.Null(app.Services.BellSchedule.GetSlot(9));
    }

    [Fact]
    public void Overlapping_slot_is_rejected()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);
        var result = app.Services.BellSchedule.UpdateSlot(2, new TimeOnly(8, 30), new TimeOnly(9, 30));
        Assert.Equal(ErrorCodes.InvalidInput, result.Error!.Code);
    }

    [Fact]
    public void Start_must_be_before_end()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);
        Assert.Equal(ErrorCodes.InvalidDateRange, app.Services.BellSchedule.UpdateSlot(1, new TimeOnly(8, 40), new TimeOnly(8, 0)).Error!.Code);
    }

    [Fact]
    public void Valid_change_is_saved()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);
        Assert.True(app.Services.BellSchedule.UpdateSlot(1, new TimeOnly(7, 50), new TimeOnly(8, 30)).Success);
        Assert.Equal(new TimeOnly(7, 50), app.Services.BellSchedule.GetSlot(1)!.StartTime);
    }

    [Fact]
    public void Teacher_cannot_change_bell_schedule()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);
        Assert.Equal(ErrorKind.Forbidden, app.Services.BellSchedule.UpdateSlot(1, new TimeOnly(7, 50), new TimeOnly(8, 30)).Error!.Kind);
    }
}
