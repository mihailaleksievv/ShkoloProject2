// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class StudentServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Admin() => TestApp.Create(_s.Db).LoginAs(_s.AdminUser);

    private StudentInput Input(string number = "2001", string first = "Мария", string last = "Колева", Guid? classId = null, string? email = null)
        => new(number, first, last, classId ?? _s.Class10A, email);

    [Fact]
    public void Add_student_succeeds_and_is_audited()
    {
        var result = Admin().Services.Students.AddStudent(Input());

        Assert.True(result.Success);
        Assert.Equal("Мария Колева", result.Value!.FullName);
        Assert.Contains(_s.Db.AuditLog, a => a.Action == "Student.Created" && a.EntityId == result.Value.Id);
    }

    [Fact]
    public void Duplicate_number_is_rejected_even_against_inactive_student()
    {
        _s.Db.Students.Single(x => x.Id == _s.Student1).IsActive = false;
        Assert.Equal(ErrorCodes.DuplicateStudentNumber, Admin().Services.Students.AddStudent(Input(number: "1001")).Error!.Code);
    }

    [Theory]
    [InlineData("", "Колева")]
    [InlineData("Мария", "   ")]
    public void Empty_names_are_rejected(string first, string last)
        => Assert.Equal(ErrorCodes.InvalidInput, Admin().Services.Students.AddStudent(Input(first: first, last: last)).Error!.Code);

    [Fact]
    public void Too_long_name_is_rejected()
        => Assert.Equal(ErrorCodes.InvalidInput, Admin().Services.Students.AddStudent(Input(first: new string('а', 51))).Error!.Code);

    [Fact]
    public void Unknown_class_is_not_found()
        => Assert.Equal(ErrorKind.NotFound, Admin().Services.Students.AddStudent(Input(classId: Guid.NewGuid())).Error!.Kind);

    [Fact]
    public void Inactive_class_is_rejected()
    {
        _s.Db.Classes.Single(c => c.Id == _s.Class10B).IsActive = false;
        Assert.Equal(ErrorCodes.InactiveEntity, Admin().Services.Students.AddStudent(Input(classId: _s.Class10B)).Error!.Code);
    }

    [Fact]
    public void Invalid_optional_email_is_rejected()
        => Assert.Equal(ErrorCodes.InvalidInput, Admin().Services.Students.AddStudent(Input(email: "abc")).Error!.Code);

    [Fact]
    public void Update_changes_data()
    {
        var app = Admin();
        Assert.True(app.Services.Students.UpdateStudent(_s.Student1, new StudentInput("1001", "Иван", "Иванов", _s.Class10B, "ivan@school.bg")).Success);
        var student = _s.Db.Students.Single(x => x.Id == _s.Student1);
        Assert.Equal("Иванов", student.LastName);
        Assert.Equal(_s.Class10B, student.ClassId);
    }

    [Fact]
    public void Search_by_name_is_case_insensitive_and_by_number_exact()
    {
        var students = Admin().Services.Students;
        Assert.Equal(_s.Student1, students.SearchStudents("иван").Value!.Single().Id);
        Assert.Equal(_s.Student2, students.SearchStudents("1002").Value!.Single().Id);
        Assert.Equal(_s.Student1, students.SearchStudents("Иван Петров").Value!.Single().Id);
    }

    [Fact]
    public void Deactivation_keeps_grades_and_blocks_login()
    {
        _s.Db.Grades.Add(new Grade { StudentId = _s.Student1, ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Value = 5m, Date = Scenario.Today });
        var app = Admin();

        Assert.True(app.Services.Students.DeactivateStudent(_s.Student1).Success);

        Assert.Single(_s.Db.Grades);
        Assert.False(_s.Db.Users.Single(u => u.Id == _s.Student1User).IsActive);
        Assert.DoesNotContain(app.Services.Students.GetAllStudents().Value!, x => x.Id == _s.Student1);
        Assert.True(app.Services.Students.ReactivateStudent(_s.Student1).Success);
        Assert.True(_s.Db.Users.Single(u => u.Id == _s.Student1User).IsActive);
    }

    [Fact]
    public void Student_cannot_list_students()
        => Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Students.GetAllStudents().Error!.Kind);

    [Fact]
    public void Student_cannot_open_other_profile()
    {
        var students = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Students;
        Assert.True(students.GetStudentById(_s.Student1).Success);
        Assert.Equal(ErrorKind.Forbidden, students.GetStudentById(_s.Student2).Error!.Kind);
    }

    [Fact]
    public void Teacher_sees_only_students_of_taught_classes()
    {
        var students = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Students;
        Assert.Equal(new[] { _s.Student2, _s.Student1 }, students.GetAllStudents().Value!.Select(x => x.Id).ToArray());
        Assert.Equal(ErrorKind.Forbidden, students.GetStudentsByClass(_s.Class10B).Error!.Kind);
    }

    [Fact]
    public void Class_list_is_sorted_by_last_name()
    {
        var list = Admin().Services.Students.GetStudentsByClass(_s.Class10A).Value!;
        Assert.Equal(new[] { "Георгиева", "Петров" }, list.Select(x => x.LastName).ToArray());
    }

    [Fact]
    public void Teacher_cannot_add_student()
        => Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Students.AddStudent(Input()).Error!.Kind);
}
