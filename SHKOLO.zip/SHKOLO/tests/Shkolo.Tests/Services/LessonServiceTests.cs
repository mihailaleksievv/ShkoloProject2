// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class LessonServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Math() => TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);

    private LessonInput Input(DateOnly? date = null, int lesson = 1, string topic = "Квадратни уравнения", Guid? classId = null, Guid? subjectId = null)
        => new(classId ?? _s.Class10A, subjectId ?? _s.Math, date ?? Scenario.Today, lesson, topic, null);

    [Fact]
    public void Assigned_teacher_creates_lesson()
    {
        var result = Math().Services.Lessons.CreateLesson(Input());

        Assert.True(result.Success);
        Assert.Equal(_s.MathTeacher, result.Value!.TeacherId);
        Assert.Equal(LessonStatus.Held, result.Value.Status);
        Assert.Contains(_s.Db.AuditLog, a => a.Action == "Lesson.Created");
    }

    [Fact]
    public void Unassigned_teacher_is_rejected()
        => Assert.Equal(ErrorCodes.NoAssignment, Math().Services.Lessons.CreateLesson(Input(classId: _s.Class10B)).Error!.Code);

    [Fact]
    public void Future_date_is_rejected()
        => Assert.Equal(ErrorCodes.FutureDate, Math().Services.Lessons.CreateLesson(Input(date: Scenario.Today.AddDays(1))).Error!.Code);

    [Fact]
    public void Date_outside_year_is_rejected()
        => Assert.Equal(ErrorCodes.OutOfAcademicYear, Math().Services.Lessons.CreateLesson(Input(date: new DateOnly(2026, 9, 1))).Error!.Code);

    [Fact]
    public void Duplicate_held_lesson_is_rejected()
    {
        var lessons = Math().Services.Lessons;
        lessons.CreateLesson(Input());
        Assert.Equal(ErrorCodes.DuplicateLesson, lessons.CreateLesson(Input()).Error!.Code);
    }

    [Fact]
    public void Empty_topic_is_rejected()
        => Assert.Equal(ErrorCodes.InvalidInput, Math().Services.Lessons.CreateLesson(Input(topic: "  ")).Error!.Code);

    [Fact]
    public void Open_from_timetable_requires_matching_weekday()
    {
        var entry = new TimetableEntry { ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, DayOfWeek = DayOfWeek.Monday, LessonNumber = 2 };
        _s.Db.Timetable.Add(entry);
        var lessons = Math().Services.Lessons;

        Assert.Equal(ErrorCodes.DayMismatch, lessons.OpenFromTimetable(entry.Id, Scenario.Today, "Тема", null).Error!.Code);

        var monday = new DateOnly(2026, 11, 16);
        var opened = lessons.OpenFromTimetable(entry.Id, monday, "Тема", null);
        Assert.True(opened.Success);
        Assert.Equal(entry.Id, opened.Value!.TimetableEntryId);
        Assert.Equal(2, opened.Value.LessonNumber);
    }

    [Fact]
    public void Lesson_with_attendance_cannot_be_cancelled()
    {
        var lessons = Math().Services.Lessons;
        var lesson = lessons.CreateLesson(Input()).Value!;
        _s.Db.AttendanceRecords.Add(new AttendanceRecord { LessonId = lesson.Id, StudentId = _s.Student1, RecordedByTeacherId = _s.MathTeacher });

        Assert.Equal(ErrorCodes.LessonHasRecords, lessons.CancelLesson(lesson.Id).Error!.Code);
    }

    [Fact]
    public void Empty_lesson_can_be_cancelled()
    {
        var lessons = Math().Services.Lessons;
        var lesson = lessons.CreateLesson(Input()).Value!;

        Assert.True(lessons.CancelLesson(lesson.Id).Success);
        Assert.Equal(LessonStatus.Cancelled, _s.Db.Lessons.Single().Status);
    }

    [Fact]
    public void Topic_can_be_updated_only_by_lesson_teacher()
    {
        var lesson = Math().Services.Lessons.CreateLesson(Input()).Value!;
        Assert.True(Math().Services.Lessons.UpdateLessonTopic(lesson.Id, "Нова тема").Success);
        Assert.Equal("Нова тема", _s.Db.Lessons.Single().Topic);
        Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.BelTeacherUser).Services.Lessons.UpdateLessonTopic(lesson.Id, "x").Error!.Kind);
    }

    [Fact]
    public void Roster_lists_active_class_students_sorted()
    {
        var lessons = Math().Services.Lessons;
        var lesson = lessons.CreateLesson(Input()).Value!;

        var roster = lessons.GetLessonRoster(lesson.Id).Value!;

        Assert.Equal(new[] { "Елена Георгиева", "Иван Петров" }, roster.Select(r => r.FullName).ToArray());
        Assert.All(roster, r => Assert.Null(r.Status));
    }

    [Fact]
    public void Search_filters_by_date_range()
    {
        var lessons = Math().Services.Lessons;
        lessons.CreateLesson(Input(date: new DateOnly(2026, 11, 16)));
        lessons.CreateLesson(Input(date: Scenario.Today));

        var found = lessons.Search(new LessonFilter(From: new DateOnly(2026, 11, 18))).Value!;

        Assert.Equal(Scenario.Today, Assert.Single(found).Date);
    }

    [Fact]
    public void Student_cannot_create_lesson()
        => Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Lessons.CreateLesson(Input()).Error!.Kind);

    [Fact]
    public void Admin_cannot_create_lesson()
        => Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Lessons.CreateLesson(Input()).Error!.Kind);
}
