// Owner: Shared
using Shkolo.Application.Reports;
using Shkolo.Application.Results;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class ReportServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    public ReportServiceTests()
    {
        // Known fixture: student1 Math 6 and 5, student2 Math 3. Student3 (10Б) has no grades.
        AddGrade(_s.Student1, 6m);
        AddGrade(_s.Student1, 5m);
        AddGrade(_s.Student2, 3m);
    }

    private void AddGrade(Guid student, decimal value)
        => _s.Db.Grades.Add(new Grade { StudentId = student, ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Value = value, Date = Scenario.Today });

    private TestApp Admin(DateOnly? today = null) => TestApp.Create(_s.Db, today).LoginAs(_s.AdminUser);

    [Fact]
    public void Student_report_has_exact_averages()
    {
        var report = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Reports.GenerateStudentReport(_s.Student1).Value!;

        Assert.Equal(5.5m, report.OverallAverage);
        Assert.Equal(2, report.GradeCount);
        var math = Assert.Single(report.SubjectAverages);
        Assert.Equal("Математика", math.SubjectName);
        Assert.Equal(5.5m, math.Average);
        Assert.Equal(2, math.GradeCount);
        Assert.Equal("10А", report.ClassName);
    }

    [Fact]
    public void Class_average_is_mean_of_all_grades()
    {
        var report = Admin().Services.Reports.GenerateClassReport(_s.Class10A).Value!;

        Assert.Equal(14m / 3, report.ClassAverage);
        Assert.Equal(3, report.GradeCount);
        Assert.Equal(2, report.StudentCount);
        Assert.Equal(new GradeDistribution(0, 1, 0, 1, 1), report.Distribution);
        Assert.Equal("Математика", report.MostActiveSubjects.First().SubjectName);
    }

    [Fact]
    public void Class_change_keeps_old_grades_in_old_class()
    {
        _s.Db.Students.Single(x => x.Id == _s.Student1).ClassId = _s.Class10B;
        var reports = Admin().Services.Reports;

        Assert.Equal(3, reports.GenerateClassReport(_s.Class10A).Value!.GradeCount);
        Assert.Equal(0, reports.GenerateClassReport(_s.Class10B).Value!.GradeCount);
    }

    [Fact]
    public void Class_without_grades_has_null_average()
        => Assert.Null(Admin().Services.Reports.GenerateClassReport(_s.Class10B).Value!.ClassAverage);

    [Fact]
    public void School_statistics_match_database()
    {
        var stats = Admin().Services.Reports.GetSchoolStatistics().Value!;

        Assert.Equal(3, stats.ActiveStudents);
        Assert.Equal(2, stats.ActiveTeachers);
        Assert.Equal(2, stats.Classes);
        Assert.Equal(2, stats.Subjects);
        Assert.Equal(3, stats.TotalGrades);
        Assert.Equal(14m / 3, stats.SchoolAverage);
        Assert.Equal(14m / 3, stats.ClassAverages.Single(c => c.ClassId == _s.Class10A).Average);
        Assert.Null(stats.ClassAverages.Single(c => c.ClassId == _s.Class10B).Average);
    }

    [Fact]
    public void Admin_dashboard_without_active_year_is_valid()
    {
        _s.Db.AcademicYears.Single().IsActive = false;
        var dashboard = Admin().Services.Reports.GetAdminDashboard();

        Assert.True(dashboard.Success);
        Assert.Null(dashboard.Value!.ActiveYearName);
        Assert.Null(dashboard.Value.CurrentTerm);
    }

    [Fact]
    public void Admin_dashboard_shows_recent_actions_with_user_names()
    {
        var app = Admin();
        app.Services.Subjects.Add(new("Химия", null));

        var action = app.Services.Reports.GetAdminDashboard().Value!.RecentActions.First();

        Assert.Equal("Администратор", action.UserName);
        Assert.Equal("Subject.Created", action.Action);
    }

    [Fact]
    public void Teacher_dashboard_on_saturday_has_no_lessons_today()
    {
        _s.Db.Timetable.Add(new TimetableEntry { ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, DayOfWeek = DayOfWeek.Friday, LessonNumber = 1 });
        var friday = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Reports.GetTeacherDashboard().Value!;
        var saturday = TestApp.Create(_s.Db, new DateOnly(2026, 11, 21)).LoginAs(_s.MathTeacherUser).Services.Reports.GetTeacherDashboard().Value!;

        Assert.Single(friday.Today);
        Assert.Empty(saturday.Today);
        Assert.Equal(2, friday.Classes.Single().StudentCount);
        Assert.Equal(3, friday.RecentGrades.Count);
    }

    [Fact]
    public void Teacher_dashboard_marks_recorded_entries()
    {
        var entry = new TimetableEntry { ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, DayOfWeek = DayOfWeek.Friday, LessonNumber = 1 };
        _s.Db.Timetable.Add(entry);
        _s.Db.Lessons.Add(new Lesson { TimetableEntryId = entry.Id, ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Date = Scenario.Today, LessonNumber = 1, Topic = "т" });

        var dashboard = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Reports.GetTeacherDashboard().Value!;

        Assert.Contains(entry.Id, dashboard.TodayRecordedEntryIds);
    }

    [Fact]
    public void Student_dashboard_contains_report_and_unread()
    {
        _s.Db.Notifications.Add(new Notification { RecipientUserId = _s.Student1User, Title = "x" });
        var dashboard = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Reports.GetStudentDashboard().Value!;

        Assert.Equal(5.5m, dashboard.Report.OverallAverage);
        Assert.Single(dashboard.Unread);
    }

    [Fact]
    public void Role_restrictions_on_reports()
    {
        Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Reports.GetSchoolStatistics().Error!.Kind);
        Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Reports.GenerateClassReport(_s.Class10B).Error!.Kind);
        Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Reports.GenerateStudentReport(_s.Student2).Error!.Kind);
        Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Reports.GetAdminDashboard().Error!.Kind);
    }

    [Fact]
    public void Teacher_statistics_are_limited_to_taught_classes()
    {
        var stats = TestApp.Create(_s.Db).LoginAs(_s.BelTeacherUser).Services.Reports.GetSchoolStatistics().Value!;

        Assert.Equal(1, stats.ActiveStudents);
        Assert.Equal(0, stats.TotalGrades);
        Assert.Equal(_s.Class10B, Assert.Single(stats.ClassAverages).ClassId);
    }

    [Fact]
    public void Subject_performance_and_teacher_report()
    {
        var reports = Admin().Services.Reports;
        var math = reports.GetSubjectPerformance(_s.Math).Value!;
        Assert.Equal(3, math.GradeCount);
        Assert.Equal(14m / 3, math.Average);

        var teacher = reports.GenerateTeacherReport(_s.MathTeacher).Value!;
        Assert.Equal(3, teacher.GradesGiven);
        Assert.Equal(new[] { "10А" }, teacher.Classes.ToArray());
    }
}
