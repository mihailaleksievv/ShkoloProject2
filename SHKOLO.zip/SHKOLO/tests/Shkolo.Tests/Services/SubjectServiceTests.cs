// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class SubjectServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    [Fact]
    public void Admin_adds_subject_and_audit_is_written()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);

        var result = app.Services.Subjects.Add(new SubjectInput("  История и цивилизации ", "ИЦ"));

        Assert.True(result.Success);
        Assert.Equal("История и цивилизации", result.Value!.Name);
        Assert.Contains(_s.Db.AuditLog, a => a.Action == "Subject.Created");
        Assert.Equal(1, app.Store.SaveCount);
    }

    [Fact]
    public void Teacher_cannot_add_subject()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);
        Assert.Equal(ErrorKind.Forbidden, app.Services.Subjects.Add(new SubjectInput("Физика", null)).Error!.Kind);
    }

    [Fact]
    public void Duplicate_name_ignoring_case_is_rejected()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);
        Assert.Equal(ErrorCodes.DuplicateSubject, app.Services.Subjects.Add(new SubjectInput("математика", null)).Error!.Code);
    }

    [Fact]
    public void Empty_name_is_rejected()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);
        Assert.Equal(ErrorCodes.InvalidInput, app.Services.Subjects.Add(new SubjectInput("  ", null)).Error!.Code);
    }

    [Fact]
    public void Update_to_own_name_is_allowed_but_not_to_another_subjects_name()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);
        Assert.True(app.Services.Subjects.Update(_s.Math, new SubjectInput("Математика", "МАТ")).Success);
        Assert.Equal(ErrorCodes.DuplicateSubject, app.Services.Subjects.Update(_s.Math, new SubjectInput("Български език и литература", null)).Error!.Code);
    }

    [Fact]
    public void Deactivated_subject_is_hidden_by_default()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);

        Assert.True(app.Services.Subjects.Deactivate(_s.Bel).Success);

        Assert.DoesNotContain(app.Services.Subjects.GetAll(), x => x.Id == _s.Bel);
        Assert.Contains(app.Services.Subjects.GetAll(includeInactive: true), x => x.Id == _s.Bel);
    }

    [Fact]
    public void Search_matches_part_of_name()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);
        Assert.Single(app.Services.Subjects.Search("матем"));
    }
}
