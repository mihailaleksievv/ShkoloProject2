// Owner: Shared
using System.Globalization;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class GradeServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Math() => TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);

    private GradeInput Input(string value = "5.50", Guid? student = null, DateOnly? date = null, Guid? lessonId = null, GradeType type = GradeType.Oral)
        => new(student ?? _s.Student1, _s.Math, decimal.Parse(value, CultureInfo.InvariantCulture), date ?? Scenario.Today, type, null, lessonId);

    private void SeedGrade(Guid student, decimal value, DateOnly date, Guid? teacher = null)
        => _s.Db.Grades.Add(new Grade { StudentId = student, ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = teacher ?? _s.MathTeacher, Value = value, Date = date });

    [Theory]
    [InlineData("2.00")]
    [InlineData("6.00")]
    [InlineData("5.50")]
    public void Valid_grades_are_accepted(string value)
        => Assert.True(Math().Services.Grades.AddGrade(Input(value)).Success);

    [Theory]
    [InlineData("1.00")]
    [InlineData("7.00")]
    [InlineData("5.555")]
    public void Invalid_grades_are_rejected(string value)
        => Assert.Equal(ErrorCodes.InvalidGrade, Math().Services.Grades.AddGrade(Input(value)).Error!.Code);

    [Fact]
    public void Unknown_student_is_not_found()
        => Assert.Equal(ErrorKind.NotFound, Math().Services.Grades.AddGrade(Input(student: Guid.NewGuid())).Error!.Kind);

    [Fact]
    public void Teacher_without_assignment_for_students_class_is_rejected()
        => Assert.Equal(ErrorCodes.NoAssignment, Math().Services.Grades.AddGrade(Input(student: _s.Student3)).Error!.Code);

    [Fact]
    public void Future_date_is_rejected()
        => Assert.Equal(ErrorCodes.FutureDate, Math().Services.Grades.AddGrade(Input(date: Scenario.Today.AddDays(1))).Error!.Code);

    [Fact]
    public void Date_outside_year_is_rejected()
        => Assert.Equal(ErrorCodes.OutOfAcademicYear, Math().Services.Grades.AddGrade(Input(date: new DateOnly(2026, 9, 10))).Error!.Code);

    [Fact]
    public void Lesson_of_another_class_is_rejected()
    {
        _s.Db.TeacherAssignments.Add(new TeacherAssignment { TeacherId = _s.MathTeacher, ClassId = _s.Class10B, SubjectId = _s.Math });
        var lesson = new Lesson { ClassId = _s.Class10B, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Date = Scenario.Today, LessonNumber = 1, Topic = "т" };
        _s.Db.Lessons.Add(lesson);

        Assert.Equal(ErrorCodes.InvalidInput, Math().Services.Grades.AddGrade(Input(lessonId: lesson.Id)).Error!.Code);
    }

    [Fact]
    public void Grade_keeps_class_at_creation_and_notifies_student()
    {
        var grade = Math().Services.Grades.AddGrade(Input()).Value!;

        Assert.Equal(_s.Class10A, grade.ClassId);
        Assert.Equal(_s.MathTeacher, grade.TeacherId);
        var notification = Assert.Single(_s.Db.Notifications);
        Assert.Equal(_s.Student1User, notification.RecipientUserId);
        Assert.Equal(NotificationType.NewGrade, notification.Type);
        Assert.Contains("5,50", notification.Message);
    }

    [Fact]
    public void Other_teacher_cannot_edit_or_delete_grade()
    {
        var grade = Math().Services.Grades.AddGrade(Input()).Value!;
        _s.Db.TeacherAssignments.Add(new TeacherAssignment { TeacherId = _s.BelTeacher, ClassId = _s.Class10A, SubjectId = _s.Math });
        var bel = TestApp.Create(_s.Db).LoginAs(_s.BelTeacherUser).Services.Grades;

        Assert.Equal(ErrorCodes.NotAuthor, bel.UpdateGrade(grade.Id, new GradeUpdate(3m, GradeType.Oral, null)).Error!.Code);
        Assert.Equal(ErrorCodes.NotAuthor, bel.DeleteGrade(grade.Id).Error!.Code);
    }

    [Fact]
    public void Author_updates_and_deletes_grade_with_audit()
    {
        var grades = Math().Services.Grades;
        var grade = grades.AddGrade(Input()).Value!;

        Assert.True(grades.UpdateGrade(grade.Id, new GradeUpdate(4m, GradeType.Test, "поправка")).Success);
        Assert.Equal(4m, _s.Db.Grades.Single().Value);
        Assert.Equal(app_now(), _s.Db.Grades.Single().UpdatedAtUtc);
        Assert.True(grades.DeleteGrade(grade.Id).Success);
        Assert.Empty(_s.Db.Grades);
        Assert.Contains(_s.Db.AuditLog, a => a.Action == "Grade.Updated");
        Assert.Contains(_s.Db.AuditLog, a => a.Action == "Grade.Deleted");

        DateTime app_now() => new FakeClock(Scenario.Today).UtcNow;
    }

    [Fact]
    public void Student_and_admin_cannot_add_grades()
    {
        Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Grades.AddGrade(Input()).Error!.Kind);
        Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Grades.AddGrade(Input()).Error!.Kind);
    }

    [Fact]
    public void Average_is_exact_sum_divided_by_count()
    {
        SeedGrade(_s.Student1, 6m, Scenario.Today);
        SeedGrade(_s.Student1, 5m, Scenario.Today);
        SeedGrade(_s.Student1, 4.50m, Scenario.Today);

        var average = Math().Services.Grades.CalculateAverage(_s.Student1);

        Assert.Equal(15.50m / 3, average.Value);
    }

    [Fact]
    public void Average_without_grades_is_null_not_zero()
    {
        var average = Math().Services.Grades.CalculateAverage(_s.Student1);
        Assert.True(average.Success);
        Assert.Null(average.Value);
    }

    [Fact]
    public void Term_average_uses_only_that_terms_grades()
    {
        SeedGrade(_s.Student1, 6m, new DateOnly(2027, 1, 15));
        SeedGrade(_s.Student1, 2m, new DateOnly(2027, 2, 15));
        var grades = TestApp.Create(_s.Db, new DateOnly(2027, 3, 1)).LoginAs(_s.MathTeacherUser).Services.Grades;

        Assert.Equal(6m, grades.CalculateAverage(_s.Student1, Term.First).Value);
        Assert.Equal(2m, grades.CalculateSubjectAverage(_s.Student1, _s.Math, Term.Second).Value);
        Assert.Equal(4m, grades.CalculateAverage(_s.Student1).Value);
    }

    [Fact]
    public void Student_sees_own_grades_but_not_others_or_class_list()
    {
        SeedGrade(_s.Student1, 5m, Scenario.Today);
        var grades = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Grades;

        Assert.Single(grades.GetGradesForStudent(_s.Student1).Value!);
        Assert.Equal(ErrorKind.Forbidden, grades.GetGradesForStudent(_s.Student2).Error!.Kind);
        Assert.Equal(ErrorKind.Forbidden, grades.GetGradesForClass(_s.Class10A).Error!.Kind);
    }

    [Fact]
    public void Filters_by_type_and_period()
    {
        var grades = Math().Services.Grades;
        grades.AddGrade(Input("5.00", date: new DateOnly(2026, 11, 2), type: GradeType.Test));
        grades.AddGrade(Input("6.00", type: GradeType.Oral));

        Assert.Single(grades.GetGradesForStudent(_s.Student1, new GradeFilter(Type: GradeType.Test)).Value!);
        Assert.Single(grades.GetGradesForStudent(_s.Student1, new GradeFilter(From: new DateOnly(2026, 11, 10))).Value!);
        Assert.Equal(6m, grades.GetGradesForStudent(_s.Student1).Value![0].Value);
    }
}
