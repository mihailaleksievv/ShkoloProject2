// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class AcademicYearServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    [Fact]
    public void Dates_must_be_ordered()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);

        var result = app.Services.AcademicYears.Create(new AcademicYearInput("2027/2028", new DateOnly(2027, 9, 15), new DateOnly(2027, 9, 1), new DateOnly(2028, 6, 30)));

        Assert.Equal(ErrorCodes.InvalidDateRange, result.Error!.Code);
    }

    [Fact]
    public void Set_active_leaves_exactly_one_active_year()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);
        var created = app.Services.AcademicYears.Create(new AcademicYearInput("2027/2028", new DateOnly(2027, 9, 15), new DateOnly(2028, 1, 31), new DateOnly(2028, 6, 30)));
        Assert.False(created.Value!.IsActive);

        Assert.True(app.Services.AcademicYears.SetActive(created.Value.Id).Success);

        Assert.Single(_s.Db.AcademicYears, y => y.IsActive);
        Assert.Equal("2027/2028", app.Services.AcademicYears.GetActive()!.Name);
    }

    [Fact]
    public void Require_active_year_containing_reports_missing_year()
    {
        _s.Db.AcademicYears[0].IsActive = false;
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);

        Assert.Equal(ErrorCodes.NoActiveYear, app.Services.AcademicYears.RequireActiveYearContaining(Scenario.Today).Error!.Code);
    }

    [Fact]
    public void Require_active_year_containing_reports_date_outside()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.AdminUser);

        Assert.True(app.Services.AcademicYears.RequireActiveYearContaining(Scenario.Today).Success);
        Assert.Equal(ErrorCodes.OutOfAcademicYear, app.Services.AcademicYears.RequireActiveYearContaining(new DateOnly(2026, 9, 1)).Error!.Code);
    }

    [Fact]
    public void Teacher_cannot_create_year()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);
        var result = app.Services.AcademicYears.Create(new AcademicYearInput("x", new DateOnly(2027, 9, 15), new DateOnly(2028, 1, 31), new DateOnly(2028, 6, 30)));
        Assert.Equal(ErrorKind.Forbidden, result.Error!.Kind);
    }
}
