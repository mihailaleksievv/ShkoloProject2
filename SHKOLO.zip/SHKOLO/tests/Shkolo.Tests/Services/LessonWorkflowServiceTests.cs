// Owner: Shared
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class LessonWorkflowServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Math() => TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);

    private LessonRecordRequest Request(AttendanceMark[]? marks = null, LessonGradeInput[]? grades = null)
        => new(new LessonInput(_s.Class10A, _s.Math, Scenario.Today, 3, "Квадратни уравнения", null), null, marks ?? [], grades ?? []);

    [Fact]
    public void Happy_path_records_lesson_attendance_and_grades_in_one_save()
    {
        var app = Math();

        var result = app.Services.LessonWorkflow.RecordLesson(Request(
            [new AttendanceMark(_s.Student2, AttendanceStatus.Absent, null)],
            [new LessonGradeInput(_s.Student1, 6m, GradeType.Oral, "отличен отговор")]));

        Assert.True(result.Success);
        var lesson = Assert.Single(_s.Db.Lessons);
        Assert.Equal(2, _s.Db.AttendanceRecords.Count);
        Assert.Equal(AttendanceStatus.Present, _s.Db.AttendanceRecords.Single(a => a.StudentId == _s.Student1).Status);
        var grade = Assert.Single(_s.Db.Grades);
        Assert.Equal(lesson.Id, grade.LessonId);
        Assert.Equal(lesson.Date, grade.Date);
        Assert.Equal(1, app.Store.SaveCount);
        Assert.Equal(new LessonRecordSummary(lesson.Id, 1, 1, 0, 1), result.Value);
    }

    [Fact]
    public void Invalid_grade_rolls_back_everything()
    {
        var app = Math();

        var result = app.Services.LessonWorkflow.RecordLesson(Request(
            [new AttendanceMark(_s.Student1, AttendanceStatus.Late, null)],
            [new LessonGradeInput(_s.Student2, 7m, GradeType.Oral, null)]));

        Assert.Equal(ErrorCodes.InvalidGrade, result.Error!.Code);
        Assert.StartsWith("Елена Георгиева", result.Error.Message);
        Assert.Empty(_s.Db.Lessons);
        Assert.Empty(_s.Db.AttendanceRecords);
        Assert.Empty(_s.Db.Grades);
        Assert.Empty(_s.Db.Notifications);
        Assert.Equal(0, app.Store.SaveCount);
    }

    [Fact]
    public void Mark_for_student_of_other_class_rolls_back()
    {
        var app = Math();
        var result = app.Services.LessonWorkflow.RecordLesson(Request([new AttendanceMark(_s.Student3, AttendanceStatus.Absent, null)]));

        Assert.Equal(ErrorCodes.StudentNotInClass, result.Error!.Code);
        Assert.Empty(_s.Db.Lessons);
        Assert.Equal(0, app.Store.SaveCount);
    }

    [Fact]
    public void Omitted_students_are_recorded_present()
    {
        Math().Services.LessonWorkflow.RecordLesson(Request());
        Assert.All(_s.Db.AttendanceRecords, a => Assert.Equal(AttendanceStatus.Present, a.Status));
        Assert.Equal(2, _s.Db.AttendanceRecords.Count);
    }

    [Fact]
    public void Invalid_lesson_is_rejected_before_anything_is_written()
    {
        var app = Math();
        var request = Request() with { Lesson = new LessonInput(_s.Class10A, _s.Math, Scenario.Today.AddDays(1), 3, "т", null) };

        Assert.Equal(ErrorCodes.FutureDate, app.Services.LessonWorkflow.RecordLesson(request).Error!.Code);
        Assert.Equal(0, app.Store.SaveCount);
    }
}
