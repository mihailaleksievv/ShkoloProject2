// Owner: Shared
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class FeedbackServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Math() => TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);

    [Fact]
    public void Praise_is_saved_and_notifies_student()
    {
        var result = Math().Services.Feedback.AddPraise(_s.Student1, "Отлично представяне на олимпиадата.", Scenario.Today);

        Assert.True(result.Success);
        Assert.Equal(FeedbackType.Praise, result.Value!.Type);
        Assert.Contains(_s.Db.Notifications, n => n.RecipientUserId == _s.Student1User && n.Type == NotificationType.NewFeedback);
        Assert.Contains(_s.Db.AuditLog, a => a.Action == "Feedback.Created");
    }

    [Fact]
    public void Hidden_remark_is_invisible_to_student_and_not_notified()
    {
        Math().Services.Feedback.AddRemark(_s.Student1, "Вътрешна бележка за класния.", Scenario.Today, visibleToStudent: false);

        Assert.Empty(TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Feedback.GetForStudent(_s.Student1).Value!);
        Assert.Single(TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Feedback.GetForStudent(_s.Student1).Value!);
        Assert.Empty(_s.Db.Notifications);
    }

    [Fact]
    public void Teacher_of_other_class_is_forbidden()
        => Assert.Equal(ErrorKind.Forbidden, Math().Services.Feedback.AddPraise(_s.Student3, "Браво", Scenario.Today).Error!.Kind);

    [Fact]
    public void Too_long_text_is_rejected()
        => Assert.Equal(ErrorCodes.InvalidInput, Math().Services.Feedback.AddPraise(_s.Student1, new string('а', 501), Scenario.Today).Error!.Code);

    [Fact]
    public void Empty_text_is_rejected()
        => Assert.Equal(ErrorCodes.InvalidInput, Math().Services.Feedback.AddRemark(_s.Student1, "  ", Scenario.Today).Error!.Code);

    [Fact]
    public void Student_cannot_add_feedback()
        => Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Feedback.AddPraise(_s.Student1, "x", Scenario.Today).Error!.Kind);

    [Fact]
    public void Filter_by_type()
    {
        var feedback = Math().Services.Feedback;
        feedback.AddPraise(_s.Student1, "Браво", Scenario.Today);
        feedback.AddRemark(_s.Student1, "Закъснение без причина", Scenario.Today);

        Assert.Single(feedback.GetForStudent(_s.Student1, FeedbackType.Remark).Value!);
        Assert.Equal(2, feedback.GetByTeacher(_s.MathTeacher).Value!.Count);
    }
}
