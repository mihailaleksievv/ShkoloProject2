// Owner: Shared
using Shkolo.Application.Results;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class TeacherAssignmentServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Admin() => TestApp.Create(_s.Db).LoginAs(_s.AdminUser);

    [Fact]
    public void Assign_creates_assignment_with_names()
    {
        var app = Admin();
        Assert.True(app.Services.Assignments.Assign(_s.MathTeacher, _s.Class10B, _s.Math).Success);

        var view = app.Services.Assignments.GetForClass(_s.Class10B).Value!.Single(a => a.SubjectId == _s.Math);
        Assert.Equal("Мария Иванова", view.TeacherName);
        Assert.Equal("10Б", view.ClassName);
    }

    [Fact]
    public void Duplicate_assignment_is_rejected()
        => Assert.Equal(ErrorCodes.DuplicateAssignment, Admin().Services.Assignments.Assign(_s.MathTeacher, _s.Class10A, _s.Math).Error!.Code);

    [Fact]
    public void Remove_is_blocked_when_lessons_exist()
    {
        _s.Db.Lessons.Add(new Lesson { ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Date = Scenario.Today, LessonNumber = 1, Topic = "т" });
        var assignment = _s.Db.TeacherAssignments.Single(a => a.TeacherId == _s.MathTeacher);

        Assert.Equal(ErrorCodes.HasDependencies, Admin().Services.Assignments.Remove(assignment.Id).Error!.Code);
    }

    [Fact]
    public void Remove_without_dependencies_succeeds()
    {
        var assignment = _s.Db.TeacherAssignments.Single(a => a.TeacherId == _s.MathTeacher);
        Assert.True(Admin().Services.Assignments.Remove(assignment.Id).Success);
        Assert.DoesNotContain(_s.Db.TeacherAssignments, a => a.Id == assignment.Id);
    }

    [Fact]
    public void Teacher_cannot_assign()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);
        Assert.Equal(ErrorKind.Forbidden, app.Services.Assignments.Assign(_s.MathTeacher, _s.Class10B, _s.Math).Error!.Kind);
    }

    [Fact]
    public void Inactive_teacher_cannot_be_assigned()
    {
        _s.Db.Teachers.Single(t => t.Id == _s.BelTeacher).IsActive = false;
        Assert.Equal(ErrorCodes.InactiveEntity, Admin().Services.Assignments.Assign(_s.BelTeacher, _s.Class10A, _s.Bel).Error!.Code);
    }
}
