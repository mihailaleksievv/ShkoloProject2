// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class ClassServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Admin() => TestApp.Create(_s.Db).LoginAs(_s.AdminUser);

    [Fact]
    public void Create_normalizes_section()
    {
        var result = Admin().Services.Classes.Create(new ClassInput(9, " в ", _s.YearId, null));
        Assert.Equal("9В", result.Value!.DisplayName);
    }

    [Fact]
    public void Same_class_in_same_year_is_duplicate()
        => Assert.Equal(ErrorCodes.DuplicateClass, Admin().Services.Classes.Create(new ClassInput(10, "а", _s.YearId, null)).Error!.Code);

    [Fact]
    public void Grade_level_must_be_1_to_12()
        => Assert.Equal(ErrorCodes.InvalidInput, Admin().Services.Classes.Create(new ClassInput(13, "А", _s.YearId, null)).Error!.Code);

    [Fact]
    public void Class_teacher_must_be_active()
    {
        _s.Db.Teachers.Single(t => t.Id == _s.MathTeacher).IsActive = false;
        Assert.Equal(ErrorCodes.InactiveEntity, Admin().Services.Classes.Create(new ClassInput(11, "А", _s.YearId, _s.MathTeacher)).Error!.Code);
    }

    [Fact]
    public void Class_with_active_students_cannot_be_deactivated()
        => Assert.Equal(ErrorCodes.HasDependencies, Admin().Services.Classes.Deactivate(_s.Class10A).Error!.Code);

    [Fact]
    public void Assign_class_teacher_is_saved()
    {
        Assert.True(Admin().Services.Classes.AssignClassTeacher(_s.Class10A, _s.MathTeacher).Success);
        Assert.Equal(_s.MathTeacher, _s.Db.Classes.Single(c => c.Id == _s.Class10A).ClassTeacherId);
    }

    [Fact]
    public void Visible_classes_depend_on_role()
    {
        Assert.Equal(2, Admin().Services.Classes.GetAll().Count);
        Assert.Equal(new[] { _s.Class10A }, TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Classes.GetAll().Select(c => c.Id).ToArray());
        Assert.Equal(new[] { _s.Class10B }, TestApp.Create(_s.Db).LoginAs(_s.Student3User).Services.Classes.GetAll().Select(c => c.Id).ToArray());
    }
}
