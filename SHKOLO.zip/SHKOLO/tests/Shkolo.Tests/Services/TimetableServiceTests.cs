// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class TimetableServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Admin() => TestApp.Create(_s.Db).LoginAs(_s.AdminUser);

    private TimetableEntryInput Math10A(DayOfWeek day = DayOfWeek.Friday, int lesson = 1, string? room = "101")
        => new(_s.Class10A, _s.Math, _s.MathTeacher, day, lesson, room);

    [Fact]
    public void Add_entry_resolves_times_from_bell_schedule()
    {
        var app = Admin();
        Assert.True(app.Services.Timetable.AddEntry(Math10A(lesson: 2)).Success);

        var row = app.Services.Timetable.GetForClass(_s.Class10A).Value!.Single();
        Assert.Equal(new TimeOnly(8, 50), row.Start);
        Assert.Equal(new TimeOnly(9, 30), row.End);
        Assert.Equal("Математика", row.SubjectName);
        Assert.Equal("Мария Иванова", row.TeacherName);
    }

    [Fact]
    public void Class_conflict_is_rejected()
    {
        var app = Admin();
        _s.Db.TeacherAssignments.Add(new() { TeacherId = _s.BelTeacher, ClassId = _s.Class10A, SubjectId = _s.Bel });
        app.Services.Timetable.AddEntry(Math10A());

        var result = app.Services.Timetable.AddEntry(new(_s.Class10A, _s.Bel, _s.BelTeacher, DayOfWeek.Friday, 1, "202"));

        Assert.Equal(ErrorCodes.TimetableClassConflict, result.Error!.Code);
    }

    [Fact]
    public void Teacher_conflict_is_rejected()
    {
        var app = Admin();
        _s.Db.TeacherAssignments.Add(new() { TeacherId = _s.MathTeacher, ClassId = _s.Class10B, SubjectId = _s.Math });
        app.Services.Timetable.AddEntry(Math10A());

        var result = app.Services.Timetable.AddEntry(new(_s.Class10B, _s.Math, _s.MathTeacher, DayOfWeek.Friday, 1, "202"));

        Assert.Equal(ErrorCodes.TimetableTeacherConflict, result.Error!.Code);
    }

    [Fact]
    public void Room_conflict_is_rejected()
    {
        var app = Admin();
        app.Services.Timetable.AddEntry(Math10A(room: "101"));

        var result = app.Services.Timetable.AddEntry(new(_s.Class10B, _s.Bel, _s.BelTeacher, DayOfWeek.Friday, 1, " 101 "));

        Assert.Equal(ErrorCodes.TimetableRoomConflict, result.Error!.Code);
    }

    [Fact]
    public void Entry_without_assignment_is_rejected()
        => Assert.Equal(ErrorCodes.NoAssignment, Admin().Services.Timetable.AddEntry(new(_s.Class10B, _s.Math, _s.MathTeacher, DayOfWeek.Monday, 1, null)).Error!.Code);

    [Fact]
    public void Lesson_number_outside_bell_schedule_is_rejected()
        => Assert.Equal(ErrorCodes.InvalidInput, Admin().Services.Timetable.AddEntry(Math10A(lesson: 9)).Error!.Code);

    [Fact]
    public void Weekend_is_rejected()
        => Assert.Equal(ErrorCodes.InvalidInput, Admin().Services.Timetable.AddEntry(Math10A(day: DayOfWeek.Saturday)).Error!.Code);

    [Fact]
    public void Update_entry_to_its_own_slot_succeeds()
    {
        var app = Admin();
        var id = app.Services.Timetable.AddEntry(Math10A()).Value!.Id;

        Assert.True(app.Services.Timetable.UpdateEntry(id, Math10A(room: "105")).Success);
        Assert.Equal("105", _s.Db.Timetable.Single().Room);
    }

    [Fact]
    public void Delete_entry_removes_it()
    {
        var app = Admin();
        var id = app.Services.Timetable.AddEntry(Math10A()).Value!.Id;
        Assert.True(app.Services.Timetable.DeleteEntry(id).Success);
        Assert.Empty(_s.Db.Timetable);
    }

    [Fact]
    public void Today_for_teacher_returns_only_today_rows()
    {
        Admin().Services.Timetable.AddEntry(Math10A(DayOfWeek.Friday, 1));
        Admin().Services.Timetable.AddEntry(Math10A(DayOfWeek.Monday, 1));

        var today = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Timetable.GetTodayForCurrentUser();

        Assert.Equal(DayOfWeek.Friday, Assert.Single(today).Day);
    }

    [Fact]
    public void Today_is_empty_on_weekend()
    {
        Admin().Services.Timetable.AddEntry(Math10A(DayOfWeek.Friday, 1));
        var app = TestApp.Create(_s.Db, new DateOnly(2026, 11, 21)).LoginAs(_s.MathTeacherUser);
        Assert.Empty(app.Services.Timetable.GetTodayForCurrentUser());
    }

    [Fact]
    public void Student_sees_own_class_timetable_only()
    {
        Admin().Services.Timetable.AddEntry(Math10A());
        var timetable = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Timetable;
        Assert.Single(timetable.GetForCurrentUser());
        Assert.Equal(ErrorKind.Forbidden, timetable.GetForClass(_s.Class10B).Error!.Kind);
    }

    [Fact]
    public void Teacher_cannot_edit_timetable()
        => Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Timetable.AddEntry(Math10A()).Error!.Kind);
}
