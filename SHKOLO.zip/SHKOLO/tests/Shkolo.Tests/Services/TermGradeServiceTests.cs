// Owner: Shared
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class TermGradeServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Math(DateOnly? today = null) => TestApp.Create(_s.Db, today).LoginAs(_s.MathTeacherUser);

    private void SeedGrade(decimal value, DateOnly? date = null, Guid? student = null)
        => _s.Db.Grades.Add(new Grade { StudentId = student ?? _s.Student1, ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Value = value, Date = date ?? Scenario.Today });

    [Fact]
    public void Suggestion_rounds_half_up()
    {
        SeedGrade(4.50m);
        SeedGrade(4.50m);
        Assert.Equal(5, Math().Services.TermGrades.GetSuggestedValue(_s.Student1, _s.Math, TermPeriod.FirstTerm).Value);
    }

    [Fact]
    public void Suggestion_rounds_down_below_half()
    {
        SeedGrade(4.00m);
        SeedGrade(4.98m);
        Assert.Equal(4, Math().Services.TermGrades.GetSuggestedValue(_s.Student1, _s.Math, TermPeriod.FirstTerm).Value);
    }

    [Fact]
    public void Annual_suggestion_uses_both_term_grades_when_present()
    {
        SeedGrade(3m);
        foreach (var (period, value) in new[] { (TermPeriod.FirstTerm, 5), (TermPeriod.SecondTerm, 6) })
        {
            _s.Db.TermGrades.Add(new TermGrade { StudentId = _s.Student1, SubjectId = _s.Math, ClassId = _s.Class10A, AcademicYearId = _s.YearId, Period = period, Value = value, TeacherId = _s.MathTeacher });
        }

        Assert.Equal(6, Math().Services.TermGrades.GetSuggestedValue(_s.Student1, _s.Math, TermPeriod.Annual).Value);
    }

    [Fact]
    public void Annual_suggestion_falls_back_to_year_average()
    {
        SeedGrade(3m, new DateOnly(2026, 10, 1));
        SeedGrade(4m, new DateOnly(2027, 3, 1));
        Assert.Equal(4, Math(new DateOnly(2027, 3, 2)).Services.TermGrades.GetSuggestedValue(_s.Student1, _s.Math, TermPeriod.Annual).Value);
    }

    [Fact]
    public void Suggestion_without_grades_is_null()
        => Assert.Null(Math().Services.TermGrades.GetSuggestedValue(_s.Student1, _s.Math, TermPeriod.FirstTerm).Value);

    [Fact]
    public void Setting_without_period_grades_is_rejected()
        => Assert.Equal(ErrorCodes.NoGradesForPeriod, Math().Services.TermGrades.SetTermGrade(_s.Student1, _s.Math, TermPeriod.FirstTerm, 5).Error!.Code);

    [Fact]
    public void Value_outside_2_to_6_is_rejected()
    {
        SeedGrade(5m);
        Assert.Equal(ErrorCodes.InvalidGrade, Math().Services.TermGrades.SetTermGrade(_s.Student1, _s.Math, TermPeriod.FirstTerm, 7).Error!.Code);
    }

    [Fact]
    public void Setting_twice_updates_single_record_and_notifies()
    {
        SeedGrade(5m);
        var terms = Math().Services.TermGrades;

        terms.SetTermGrade(_s.Student1, _s.Math, TermPeriod.FirstTerm, 5);
        terms.SetTermGrade(_s.Student1, _s.Math, TermPeriod.FirstTerm, 6);

        Assert.Equal(6, Assert.Single(_s.Db.TermGrades).Value);
        Assert.Equal(2, _s.Db.Notifications.Count(n => n.Type == NotificationType.NewTermGrade));
    }

    [Fact]
    public void Unassigned_teacher_cannot_set_term_grade()
    {
        _s.Db.Grades.Add(new Grade { StudentId = _s.Student3, ClassId = _s.Class10B, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Value = 5m, Date = Scenario.Today });
        Assert.Equal(ErrorCodes.NoAssignment, Math().Services.TermGrades.SetTermGrade(_s.Student3, _s.Math, TermPeriod.FirstTerm, 5).Error!.Code);
    }

    [Fact]
    public void Student_reads_only_own_term_grades()
    {
        var terms = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.TermGrades;
        Assert.True(terms.GetTermGradesForStudent(_s.Student1).Success);
        Assert.Equal(ErrorKind.Forbidden, terms.GetTermGradesForStudent(_s.Student2).Error!.Kind);
    }

    [Fact]
    public void Sheet_lists_every_student_with_average_suggestion_and_assigned()
    {
        SeedGrade(6m);
        SeedGrade(5m);
        _s.Db.TermGrades.Add(new TermGrade { StudentId = _s.Student1, SubjectId = _s.Math, ClassId = _s.Class10A, AcademicYearId = _s.YearId, Period = TermPeriod.FirstTerm, Value = 6, TeacherId = _s.MathTeacher });

        var sheet = Math().Services.TermGrades.GetTermGradeSheet(_s.Class10A, _s.Math, TermPeriod.FirstTerm).Value!;

        Assert.Equal(2, sheet.Count);
        var ivan = sheet.Single(r => r.StudentId == _s.Student1);
        Assert.Equal(5.5m, ivan.CurrentAverage);
        Assert.Equal(6, ivan.Suggested);
        Assert.Equal(6, ivan.Assigned);
        Assert.Null(sheet.Single(r => r.StudentId == _s.Student2).CurrentAverage);
    }
}
