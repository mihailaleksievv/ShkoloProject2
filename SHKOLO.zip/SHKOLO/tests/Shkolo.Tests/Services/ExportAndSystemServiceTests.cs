// Owner: Shared
using Shkolo.Application.Results;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class ExportAndSystemServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    [Fact]
    public void Student_exports_own_report_with_bulgarian_numbers()
    {
        _s.Db.Grades.Add(new Grade { StudentId = _s.Student1, ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Value = 5.5m, Date = Scenario.Today });
        var app = TestApp.Create(_s.Db).LoginAs(_s.Student1User);

        var result = app.Services.Export.ExportStudentReport(_s.Student1);

        Assert.True(result.Success);
        var export = app.Exporter.LastExport!;
        Assert.Contains(export.Rows, r => r.Contains("5,50"));
        Assert.Contains(export.Rows, r => r.Contains("Иван Петров"));
    }

    [Fact]
    public void Student_cannot_export_other_report()
        => Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Export.ExportStudentReport(_s.Student2).Error!.Kind);

    [Fact]
    public void Class_export_lists_every_student()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);
        Assert.True(app.Services.Export.ExportClassReport(_s.Class10A).Success);
        Assert.Contains(app.Exporter.LastExport!.Rows, r => r.Contains("Елена Георгиева"));
        Assert.Contains(app.Exporter.LastExport!.Rows, r => r.Contains("Няма данни"));
    }

    [Fact]
    public void Export_failure_is_persistence_error()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.Student1User);
        app.Exporter.FailWith = new IOException("disk");
        Assert.Equal(ErrorKind.Persistence, app.Services.Export.ExportStudentReport(_s.Student1).Error!.Kind);
    }

    [Fact]
    public void Storage_info_is_admin_only()
    {
        Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.System.GetStorageInfo().Error!.Kind);
        var info = TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.System.GetStorageInfo().Value!;
        Assert.Equal("memory://school-data.json", info.DataFilePath);
        Assert.False(info.IsReadOnly);
    }

    [Fact]
    public void Restore_failure_is_reported_not_thrown()
    {
        var result = TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.System.RestoreBackup("missing.json");
        Assert.Equal(ErrorKind.Persistence, result.Error!.Kind);
    }
}
