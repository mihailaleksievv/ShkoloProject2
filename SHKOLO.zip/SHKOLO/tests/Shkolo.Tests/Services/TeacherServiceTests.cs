// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class TeacherServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Admin() => TestApp.Create(_s.Db).LoginAs(_s.AdminUser);

    [Fact]
    public void Admin_adds_teacher()
    {
        var result = Admin().Services.Teachers.Add(new TeacherInput("T-100", "Георги", "Стоянов", "g.stoyanov@school.bg"));
        Assert.True(result.Success);
        Assert.Contains(_s.Db.AuditLog, a => a.Action == "Teacher.Created");
    }

    [Fact]
    public void Duplicate_employee_number_is_rejected()
        => Assert.Equal(ErrorCodes.DuplicateEmployeeNumber, Admin().Services.Teachers.Add(new TeacherInput("T-math", "Г", "С", "g@school.bg")).Error!.Code);

    [Fact]
    public void Invalid_email_is_rejected()
        => Assert.Equal(ErrorCodes.InvalidInput, Admin().Services.Teachers.Add(new TeacherInput("T-101", "Г", "С", "not-an-email")).Error!.Code);

    [Fact]
    public void Deactivate_returns_timetable_count_and_blocks_login()
    {
        _s.Db.Timetable.Add(new TimetableEntry { ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, DayOfWeek = DayOfWeek.Monday, LessonNumber = 1 });
        var app = Admin();

        var result = app.Services.Teachers.Deactivate(_s.MathTeacher);

        Assert.Equal(1, result.Value);
        app.Services.Auth.Logout();
        Assert.False(app.Services.Auth.Login("math", TestDatabaseBuilder.Password).Success);
    }

    [Fact]
    public void Teacher_sees_own_taught_classes_and_subjects_only()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);

        Assert.Equal(new[] { _s.Class10A }, app.Services.Teachers.GetTaughtClasses(_s.MathTeacher).Value!.Select(c => c.Id).ToArray());
        Assert.Equal(new[] { _s.Math }, app.Services.Teachers.GetTaughtSubjects(_s.MathTeacher).Value!.Select(c => c.Id).ToArray());
        Assert.Equal(ErrorKind.Forbidden, app.Services.Teachers.GetTaughtClasses(_s.BelTeacher).Error!.Kind);
    }

    [Fact]
    public void Teacher_cannot_add_teacher()
    {
        var app = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);
        Assert.Equal(ErrorKind.Forbidden, app.Services.Teachers.Add(new TeacherInput("T-102", "Г", "С", "g@school.bg")).Error!.Kind);
    }
}
