// Owner: Shared
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class AchievementServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private Guid Badge(bool active = true)
    {
        var badge = new Shkolo.Domain.Models.AchievementBadge { Name = "Постоянство", Description = "Редовна работа", Symbol = "★", IsActive = active };
        _s.Db.AchievementBadges.Add(badge);
        return badge.Id;
    }

    [Fact]
    public void Teacher_awards_badge_and_student_sees_it()
    {
        var badge = Badge();
        var result = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Achievements.Award(_s.Student1, badge, "за I срок");

        Assert.True(result.Success);
        Assert.Contains(_s.Db.Notifications, n => n.Type == NotificationType.NewAchievement && n.RecipientUserId == _s.Student1User);
        var mine = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Achievements.GetForStudent(_s.Student1).Value!;
        Assert.Equal("Постоянство", Assert.Single(mine).Name);
    }

    [Fact]
    public void Inactive_badge_cannot_be_awarded()
        => Assert.Equal(ErrorCodes.InactiveEntity, TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Achievements.Award(_s.Student1, Badge(active: false), null).Error!.Code);

    [Fact]
    public void Teacher_cannot_award_student_of_other_class()
        => Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Achievements.Award(_s.Student3, Badge(), null).Error!.Kind);

    [Fact]
    public void Only_admin_manages_catalog()
    {
        Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Achievements.AddBadge("X", "Y", "✦").Error!.Kind);
        Assert.True(TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Achievements.AddBadge("Работа в екип", "Пример за сътрудничество", "✦").Success);
        Assert.Single(TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Achievements.GetCatalog());
    }
}
