// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class NotificationServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private void GiveGrade()
        => TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Grades.AddGrade(new GradeInput(_s.Student1, _s.Math, 6m, Scenario.Today, GradeType.Oral, null));

    [Fact]
    public void New_grade_reaches_student_and_can_be_marked_read()
    {
        GiveGrade();
        GiveGrade();
        var notifications = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Notifications;

        Assert.Equal(2, notifications.GetUnreadCount());
        var first = notifications.GetForCurrentUser(unreadOnly: true)[0];
        Assert.True(notifications.MarkAsRead(first.Id).Success);
        Assert.Equal(1, notifications.GetUnreadCount());
        Assert.True(notifications.MarkAllAsRead().Success);
        Assert.Equal(0, notifications.GetUnreadCount());
        Assert.Equal(2, notifications.GetForCurrentUser().Count);
    }

    [Fact]
    public void Cannot_mark_someone_elses_notification()
    {
        GiveGrade();
        var id = _s.Db.Notifications.Single().Id;
        Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student2User).Services.Notifications.MarkAsRead(id).Error!.Kind);
    }

    [Fact]
    public void Anonymous_has_no_notifications()
        => Assert.Equal(0, TestApp.Create(_s.Db).Services.Notifications.GetUnreadCount());
}
