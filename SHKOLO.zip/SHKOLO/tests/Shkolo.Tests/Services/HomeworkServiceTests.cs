// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Application.Services;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class HomeworkServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Math() => TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);

    private HomeworkInput Input(string title = "Задачи 1–10", DateOnly? assigned = null, DateOnly? due = null, Guid? classId = null)
        => new(classId ?? _s.Class10A, _s.Math, title, "Учебник стр. 42", assigned ?? Scenario.Today, due ?? Scenario.Today.AddDays(7));

    [Fact]
    public void Create_notifies_every_student_of_class()
    {
        Assert.True(Math().Services.Homework.CreateHomework(Input()).Success);

        var recipients = _s.Db.Notifications.Where(n => n.Type == NotificationType.NewHomework).Select(n => n.RecipientUserId).ToHashSet();
        Assert.Equal(new HashSet<Guid> { _s.Student1User, _s.Student2User }, recipients);
    }

    [Fact]
    public void Due_before_assigned_is_rejected()
        => Assert.Equal(ErrorCodes.InvalidDateRange, Math().Services.Homework.CreateHomework(Input(due: Scenario.Today.AddDays(-1))).Error!.Code);

    [Fact]
    public void Empty_title_is_rejected()
        => Assert.Equal(ErrorCodes.InvalidInput, Math().Services.Homework.CreateHomework(Input(title: " ")).Error!.Code);

    [Fact]
    public void Unassigned_teacher_is_rejected()
        => Assert.Equal(ErrorCodes.NoAssignment, Math().Services.Homework.CreateHomework(Input(classId: _s.Class10B)).Error!.Code);

    [Theory]
    [InlineData(null, "2026-11-20", HomeworkStatus.Pending)]
    [InlineData(null, "2026-11-28", HomeworkStatus.Overdue)]
    [InlineData("2026-11-27", "2026-11-28", HomeworkStatus.Submitted)]
    [InlineData("2026-11-28", "2026-11-28", HomeworkStatus.SubmittedLate)]
    public void Status_is_computed(string? submitted, string today, HomeworkStatus expected)
    {
        var hw = new Homework { DueDate = new DateOnly(2026, 11, 27) };
        var submission = submitted is null ? null : new HomeworkSubmission { SubmittedAtUtc = DateOnly.Parse(submitted).ToDateTime(new TimeOnly(18, 0)) };

        Assert.Equal(expected, HomeworkService.ComputeStatus(hw, submission, DateOnly.Parse(today)));
    }

    [Fact]
    public void Student_submits_and_sees_status()
    {
        var hw = Math().Services.Homework.CreateHomework(Input()).Value!;
        var student = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Homework;

        Assert.True(student.Submit(hw.Id, "Решенията са в тетрадката.").Success);

        var view = student.GetHomeworkForStudent(_s.Student1).Value!.Single();
        Assert.Equal(HomeworkStatus.Submitted, view.StatusForStudent);
        Assert.Equal(1, view.SubmissionCount);
    }

    [Fact]
    public void Resubmission_before_due_overwrites()
    {
        var hw = Math().Services.Homework.CreateHomework(Input()).Value!;
        var student = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Homework;
        student.Submit(hw.Id, "v1");
        student.Submit(hw.Id, "v2");
        Assert.Equal("v2", Assert.Single(_s.Db.HomeworkSubmissions).Content);
    }

    [Fact]
    public void Student_of_other_class_cannot_submit()
    {
        var hw = Math().Services.Homework.CreateHomework(Input()).Value!;
        Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student3User).Services.Homework.Submit(hw.Id, "x").Error!.Kind);
    }

    [Fact]
    public void Archived_homework_is_not_upcoming()
    {
        var homework = Math().Services.Homework;
        var hw = homework.CreateHomework(Input()).Value!;
        Assert.Single(homework.GetUpcomingHomework());

        Assert.True(homework.ArchiveHomework(hw.Id).Success);

        Assert.Empty(homework.GetUpcomingHomework());
        Assert.Empty(TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Homework.GetUpcomingHomework());
    }

    [Fact]
    public void Overdue_lists_only_unsubmitted_past_due_for_student()
    {
        var hw = Math().Services.Homework.CreateHomework(Input(assigned: new DateOnly(2026, 11, 10), due: new DateOnly(2026, 11, 13))).Value!;
        Assert.Single(TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Homework.GetOverdueHomework());

        _s.Db.HomeworkSubmissions.Add(new HomeworkSubmission { HomeworkId = hw.Id, StudentId = _s.Student1, Content = "x", SubmittedAtUtc = DateTime.UtcNow });

        Assert.Empty(TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Homework.GetOverdueHomework());
    }

    [Fact]
    public void Submissions_list_every_student_with_status()
    {
        var hw = Math().Services.Homework.CreateHomework(Input()).Value!;
        TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Homework.Submit(hw.Id, "готово");

        var rows = Math().Services.Homework.GetSubmissions(hw.Id).Value!;

        Assert.Equal(2, rows.Count);
        Assert.Equal(HomeworkStatus.Submitted, rows.Single(r => r.StudentId == _s.Student1).Status);
        Assert.Equal(HomeworkStatus.Pending, rows.Single(r => r.StudentId == _s.Student2).Status);
    }

    [Fact]
    public void Only_author_updates_homework()
    {
        var hw = Math().Services.Homework.CreateHomework(Input()).Value!;
        _s.Db.TeacherAssignments.Add(new TeacherAssignment { TeacherId = _s.BelTeacher, ClassId = _s.Class10A, SubjectId = _s.Math });
        var bel = TestApp.Create(_s.Db).LoginAs(_s.BelTeacherUser).Services.Homework;

        Assert.Equal(ErrorCodes.NotAuthor, bel.UpdateHomework(hw.Id, Input(title: "Променено")).Error!.Code);
        Assert.True(Math().Services.Homework.UpdateHomework(hw.Id, Input(title: "Променено")).Success);
    }
}
