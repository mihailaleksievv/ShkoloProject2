// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class AnnouncementServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    [Fact]
    public void Teacher_cannot_publish_to_untaught_class()
    {
        var result = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Announcements.Publish(new AnnouncementInput("Контролно", "В петък", _s.Class10B));
        Assert.Equal(ErrorKind.Forbidden, result.Error!.Kind);
    }

    [Fact]
    public void General_announcement_notifies_all_active_users_except_author()
    {
        TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Announcements.Publish(new AnnouncementInput("Ваканция", "Коледна ваканция от 22.12.", null));

        var recipients = _s.Db.Notifications.Select(n => n.RecipientUserId).ToHashSet();
        Assert.Equal(_s.Db.Users.Count - 1, recipients.Count);
        Assert.DoesNotContain(_s.AdminUser, recipients);
        Assert.All(_s.Db.Notifications, n => Assert.Equal(NotificationType.NewAnnouncement, n.Type));
    }

    [Fact]
    public void Class_announcement_is_visible_only_to_that_class()
    {
        TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Announcements.Publish(new AnnouncementInput("Контролно", "В петък", _s.Class10A));

        Assert.Single(TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Announcements.GetActiveForCurrentUser());
        Assert.Empty(TestApp.Create(_s.Db).LoginAs(_s.Student3User).Services.Announcements.GetActiveForCurrentUser());
        Assert.Equal(2, _s.Db.Notifications.Count);
    }

    [Fact]
    public void Only_author_or_admin_can_edit()
    {
        var created = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Announcements.Publish(new AnnouncementInput("А", "Б", null)).Value!;

        Assert.Equal(ErrorCodes.NotAuthor, TestApp.Create(_s.Db).LoginAs(_s.BelTeacherUser).Services.Announcements.Update(created.Id, new AnnouncementInput("x", "y", null)).Error!.Code);
        Assert.True(TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Announcements.Update(created.Id, new AnnouncementInput("x", "y", null)).Success);
    }

    [Fact]
    public void Archived_announcement_is_hidden()
    {
        var admin = TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Announcements;
        var created = admin.Publish(new AnnouncementInput("А", "Б", null)).Value!;
        Assert.True(admin.Archive(created.Id).Success);
        Assert.Empty(TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Announcements.GetActiveForCurrentUser());
    }

    [Fact]
    public void Student_cannot_publish()
        => Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Announcements.Publish(new AnnouncementInput("А", "Б", null)).Error!.Kind);

    [Fact]
    public void Empty_title_is_rejected()
        => Assert.Equal(ErrorCodes.InvalidInput, TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Announcements.Publish(new AnnouncementInput("", "Б", null)).Error!.Code);
}
