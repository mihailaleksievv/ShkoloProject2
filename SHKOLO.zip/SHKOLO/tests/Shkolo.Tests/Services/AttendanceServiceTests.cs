// Owner: Shared
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class AttendanceServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp Math() => TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser);

    private Guid MathLesson(DateOnly? date = null, int number = 1, LessonStatus status = LessonStatus.Held)
    {
        var lesson = new Lesson { ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Date = date ?? Scenario.Today, LessonNumber = number, Topic = "т", Status = status };
        _s.Db.Lessons.Add(lesson);
        return lesson.Id;
    }

    [Theory]
    [InlineData(AttendanceStatus.Present)]
    [InlineData(AttendanceStatus.Absent)]
    [InlineData(AttendanceStatus.ExcusedAbsent)]
    [InlineData(AttendanceStatus.Late)]
    public void Each_status_can_be_recorded(AttendanceStatus status)
    {
        var result = Math().Services.Attendance.RecordAttendance(MathLesson(), new AttendanceMark(_s.Student1, status, null));
        Assert.True(result.Success);
        Assert.Equal(status, _s.Db.AttendanceRecords.Single().Status);
    }

    [Fact]
    public void Duplicate_record_for_same_lesson_is_rejected()
    {
        var attendance = Math().Services.Attendance;
        var lesson = MathLesson();
        attendance.RecordAttendance(lesson, new AttendanceMark(_s.Student1, AttendanceStatus.Present, null));

        Assert.Equal(ErrorCodes.DuplicateAttendance, attendance.RecordAttendance(lesson, new AttendanceMark(_s.Student1, AttendanceStatus.Absent, null)).Error!.Code);
    }

    [Fact]
    public void Student_from_other_class_is_rejected()
        => Assert.Equal(ErrorCodes.StudentNotInClass, Math().Services.Attendance.RecordAttendance(MathLesson(), new AttendanceMark(_s.Student3, AttendanceStatus.Absent, null)).Error!.Code);

    [Fact]
    public void Cancelled_lesson_is_rejected()
        => Assert.Equal(ErrorCodes.LessonCancelled, Math().Services.Attendance.RecordAttendance(MathLesson(status: LessonStatus.Cancelled), new AttendanceMark(_s.Student1, AttendanceStatus.Absent, null)).Error!.Code);

    [Fact]
    public void Only_the_lesson_teacher_records_attendance()
    {
        var lesson = MathLesson();
        var bel = TestApp.Create(_s.Db).LoginAs(_s.BelTeacherUser).Services.Attendance;
        Assert.Equal(ErrorKind.Forbidden, bel.RecordAttendance(lesson, new AttendanceMark(_s.Student1, AttendanceStatus.Absent, null)).Error!.Kind);
    }

    [Fact]
    public void Class_teacher_can_excuse_absence_but_not_set_other_status()
    {
        _s.Db.TeacherAssignments.Add(new TeacherAssignment { TeacherId = _s.MathTeacher, ClassId = _s.Class10B, SubjectId = _s.Math });
        var lesson = new Lesson { ClassId = _s.Class10B, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Date = Scenario.Today, LessonNumber = 1, Topic = "т" };
        _s.Db.Lessons.Add(lesson);
        var record = Math().Services.Attendance.RecordAttendance(lesson.Id, new AttendanceMark(_s.Student3, AttendanceStatus.Absent, null)).Value!;
        var bel = TestApp.Create(_s.Db).LoginAs(_s.BelTeacherUser).Services.Attendance;

        Assert.Equal(ErrorKind.Forbidden, bel.UpdateAttendanceStatus(record.Id, AttendanceStatus.Late, null).Error!.Kind);
        Assert.True(bel.UpdateAttendanceStatus(record.Id, AttendanceStatus.ExcusedAbsent, "медицинска бележка").Success);
        Assert.Equal(AttendanceStatus.ExcusedAbsent, _s.Db.AttendanceRecords.Single().Status);
    }

    [Fact]
    public void Lesson_teacher_corrects_status()
    {
        var attendance = Math().Services.Attendance;
        var record = attendance.RecordAttendance(MathLesson(), new AttendanceMark(_s.Student1, AttendanceStatus.Absent, null)).Value!;
        Assert.True(attendance.UpdateAttendanceStatus(record.Id, AttendanceStatus.Late, "10 мин").Success);
        Assert.Equal(AttendanceStatus.Late, _s.Db.AttendanceRecords.Single().Status);
    }

    [Fact]
    public void Summary_counts_each_kind_separately()
    {
        var attendance = Math().Services.Attendance;
        var statuses = new[] { AttendanceStatus.Present, AttendanceStatus.Absent, AttendanceStatus.ExcusedAbsent, AttendanceStatus.Late, AttendanceStatus.Late };
        for (var i = 0; i < statuses.Length; i++)
        {
            attendance.RecordAttendance(MathLesson(number: i + 1), new AttendanceMark(_s.Student1, statuses[i], null));
        }

        var summary = attendance.GetAttendanceSummary(_s.Student1).Value!;

        Assert.Equal(new AttendanceSummary(1, 1, 1, 2), summary);
        Assert.Equal(2, summary.TotalAbsences);
        Assert.Equal(5, summary.TotalRecords);
    }

    [Fact]
    public void Student_cannot_view_other_students_attendance()
    {
        var attendance = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Attendance;
        Assert.True(attendance.GetAttendanceForStudent(_s.Student1).Success);
        Assert.Equal(ErrorKind.Forbidden, attendance.GetAttendanceForStudent(_s.Student2).Error!.Kind);
    }

    [Fact]
    public void Period_filter_limits_records()
    {
        var attendance = Math().Services.Attendance;
        attendance.RecordAttendance(MathLesson(new DateOnly(2026, 11, 2)), new AttendanceMark(_s.Student1, AttendanceStatus.Absent, null));
        attendance.RecordAttendance(MathLesson(), new AttendanceMark(_s.Student1, AttendanceStatus.Absent, null));

        Assert.Single(attendance.GetAttendanceByPeriod(new DateOnly(2026, 11, 10), Scenario.Today).Value!);
        Assert.Equal(2, attendance.GetAttendanceForClass(_s.Class10A).Value!.Count);
    }
}
