﻿// Owner: Shared
using Shkolo.Application.Reports;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class InfographicReportTests
{
    private readonly StandardScenario _s = Scenario.Standard();
    private static readonly DateOnly Friday = Scenario.Today;          // 20.11.2026
    private static readonly DateOnly Thursday = Friday.AddDays(-1);

    private Guid Lesson(DateOnly date, int number = 1, Guid? classId = null)
    {
        var lesson = new Lesson { ClassId = classId ?? _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Date = date, LessonNumber = number, Topic = "т" };
        _s.Db.Lessons.Add(lesson);
        return lesson.Id;
    }

    private void Mark(Guid lessonId, Guid studentId, AttendanceStatus status)
        => _s.Db.AttendanceRecords.Add(new AttendanceRecord { LessonId = lessonId, StudentId = studentId, Status = status, RecordedByTeacherId = _s.MathTeacher });

    private void Grade(Guid studentId, decimal value, DateOnly date)
        => _s.Db.Grades.Add(new Grade { StudentId = studentId, ClassId = _s.Class10A, SubjectId = _s.Math, TeacherId = _s.MathTeacher, Value = value, Date = date });

    private TestApp As(Guid user) => TestApp.Create(_s.Db).LoginAs(user);


    [Fact]
    public void Public_overview_needs_no_login_and_counts_active_people()
    {
        _s.Db.Students[0].IsActive = false;

        var overview = TestApp.Create(_s.Db).Services.Reports.GetPublicOverview();

        Assert.Equal(_s.Db.Students.Count - 1, overview.Students);
        Assert.Equal(_s.Db.Teachers.Count(t => t.IsActive), overview.Teachers);
        Assert.Equal(_s.Db.Classes.Count(c => c.IsActive), overview.Classes);
        Assert.Equal(_s.Db.Subjects.Count(x => x.IsActive), overview.Subjects);
    }

    [Fact]
    public void Student_days_report_worst_mark_and_empty_days()
    {
        var l1 = Lesson(Friday, 1);
        var l2 = Lesson(Friday, 2);
        Mark(l1, _s.Student1, AttendanceStatus.Present);
        Mark(l2, _s.Student1, AttendanceStatus.Absent);

        var days = As(_s.Student1User).Services.Reports.GetStudentAttendanceDays(_s.Student1, Thursday, Friday).Value!;

        Assert.Equal(2, days.Count);
        Assert.Equal(new DayAttendance(Thursday, null, 0), days[0]);
        Assert.Equal(new DayAttendance(Friday, AttendanceStatus.Absent, 2), days[1]);
    }

    [Fact]
    public void Student_cannot_see_another_students_days()
        => Assert.Equal(ErrorKind.Forbidden, As(_s.Student1User).Services.Reports.GetStudentAttendanceDays(_s.Student2, Thursday, Friday).Error!.Kind);

    [Fact]
    public void Weekends_are_not_school_days()
        => Assert.Equal(5, As(_s.AdminUser).Services.Reports.GetStudentAttendanceDays(_s.Student1, new DateOnly(2026, 11, 16), new DateOnly(2026, 11, 22)).Value!.Count);

    [Fact]
    public void Class_days_take_worst_across_students_and_require_staff()
    {
        var l = Lesson(Friday);
        Mark(l, _s.Student1, AttendanceStatus.Late);
        Mark(l, _s.Student2, AttendanceStatus.ExcusedAbsent);

        var day = As(_s.MathTeacherUser).Services.Reports.GetClassAttendanceDays(_s.Class10A, Friday, Friday).Value!.Single();

        Assert.Equal(AttendanceStatus.ExcusedAbsent, day.Worst);
        Assert.Equal(ErrorKind.Forbidden, As(_s.Student1User).Services.Reports.GetClassAttendanceDays(_s.Class10A, Friday, Friday).Error!.Kind);
        Assert.Equal(ErrorKind.Forbidden, As(_s.MathTeacherUser).Services.Reports.GetClassAttendanceDays(_s.Class10B, Friday, Friday).Error!.Kind);
    }

    [Fact]
    public void Pulse_covers_recent_school_days_with_present_share()
    {
        var l = Lesson(Friday);
        Mark(l, _s.Student1, AttendanceStatus.Present);
        Mark(l, _s.Student2, AttendanceStatus.Late);
        var l2 = Lesson(Friday, 2);
        Mark(l2, _s.Student1, AttendanceStatus.Present);
        Mark(l2, _s.Student2, AttendanceStatus.Absent);

        var pulse = As(_s.AdminUser).Services.Reports.GetAttendancePulse(3).Value!;

        Assert.Equal(new[] { new DateOnly(2026, 11, 18), Thursday, Friday }, pulse.Select(p => p.Date).ToArray());
        Assert.Null(pulse[0].PresentShare);
        Assert.Equal(0.75m, pulse[2].PresentShare);
        Assert.Equal(ErrorKind.Forbidden, As(_s.Student1User).Services.Reports.GetAttendancePulse().Error!.Kind);
    }

    [Fact]
    public void Student_trend_is_weekly_oldest_first_and_null_for_empty_weeks()
    {
        Grade(_s.Student1, 6m, Friday);
        Grade(_s.Student1, 4m, Friday.AddDays(-2));
        Grade(_s.Student1, 3m, new DateOnly(2026, 3, 2)); // previous academic year – ignored

        var trend = As(_s.Student1User).Services.Reports.GetStudentGradeTrend(_s.Student1, 3).Value!;

        Assert.Equal(3, trend.Count);
        Assert.Equal(new DateOnly(2026, 11, 2), trend[0].WeekStart);
        Assert.All(trend, w => Assert.Equal(DayOfWeek.Monday, w.WeekStart.DayOfWeek));
        Assert.Null(trend[0].Average);
        Assert.Equal(0, trend[0].GradeCount);
        Assert.Equal(5m, trend[2].Average);
        Assert.Equal(2, trend[2].GradeCount);
    }

    [Fact]
    public void Class_trend_uses_grade_class()
    {
        Grade(_s.Student1, 6m, Friday);
        _s.Db.Students.Single(x => x.Id == _s.Student1).ClassId = _s.Class10B;

        var trend = As(_s.AdminUser).Services.Reports.GetClassGradeTrend(_s.Class10A, 1).Value!;

        Assert.Equal(6m, trend.Single().Average);
    }

    [Fact]
    public void Attention_list_states_facts_for_taught_classes_only()
    {
        for (var i = 1; i <= 3; i++)
        {
            Mark(Lesson(Friday.AddDays(-i * 7), i), _s.Student1, AttendanceStatus.Absent);
        }

        Grade(_s.Student2, 2m, Friday.AddDays(-2));
        Grade(_s.Student2, 2m, Friday.AddDays(-10));
        var items = As(_s.MathTeacherUser).Services.Reports.GetAttentionList().Value!;

        Assert.Contains(items, i => i.StudentId == _s.Student1 && i.Reason.Contains("3 неизвинени"));
        var weak = Assert.Single(items, i => i.StudentId == _s.Student2);
        Assert.Contains("2,00", weak.Reason);
        Assert.Contains("18.11", weak.Reason);
        Assert.Equal(ErrorKind.Forbidden, As(_s.AdminUser).Services.Reports.GetAttentionList().Error!.Kind);
        Assert.Empty(As(_s.BelTeacherUser).Services.Reports.GetAttentionList().Value!);
    }
}
