// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Services;

public class SchoolEventServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private static DateTime At(int day, int hour) => new(2026, 11, day, hour, 0, 0);

    [Fact]
    public void End_before_start_is_rejected()
    {
        var result = TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Events.Create(new SchoolEventInput("Среща", "", At(25, 18), At(25, 17), null));
        Assert.Equal(ErrorCodes.InvalidDateRange, result.Error!.Code);
    }

    [Fact]
    public void Student_cannot_create_event()
        => Assert.Equal(ErrorKind.Forbidden, TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Events.Create(new SchoolEventInput("x", "", At(25, 9), At(25, 10), null)).Error!.Kind);

    [Fact]
    public void Teacher_creates_only_class_events_for_taught_classes()
    {
        var events = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Events;
        Assert.Equal(ErrorKind.Forbidden, events.Create(new SchoolEventInput("Общо", "", At(25, 9), At(25, 10), null)).Error!.Kind);
        Assert.Equal(ErrorKind.Forbidden, events.Create(new SchoolEventInput("10Б", "", At(25, 9), At(25, 10), _s.Class10B)).Error!.Kind);
        Assert.True(events.Create(new SchoolEventInput("Контролно", "Глава 3", At(25, 9), At(25, 10), _s.Class10A)).Success);
    }

    [Fact]
    public void Upcoming_excludes_past_and_respects_scope()
    {
        var admin = TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Events;
        admin.Create(new SchoolEventInput("Минало", "", At(10, 9), At(10, 10), null));
        admin.Create(new SchoolEventInput("Общо", "", At(25, 9), At(25, 10), null));
        admin.Create(new SchoolEventInput("Само 10Б", "", At(26, 9), At(26, 10), _s.Class10B));

        var upcoming = TestApp.Create(_s.Db).LoginAs(_s.Student1User).Services.Events.GetUpcoming();

        Assert.Equal("Общо", Assert.Single(upcoming).Title);
    }

    [Fact]
    public void Only_creator_or_admin_deletes()
    {
        var created = TestApp.Create(_s.Db).LoginAs(_s.MathTeacherUser).Services.Events.Create(new SchoolEventInput("К", "", At(25, 9), At(25, 10), _s.Class10A)).Value!;
        Assert.Equal(ErrorCodes.NotAuthor, TestApp.Create(_s.Db).LoginAs(_s.BelTeacherUser).Services.Events.Delete(created.Id).Error!.Code);
        Assert.True(TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Events.Delete(created.Id).Success);
        Assert.Empty(_s.Db.SchoolEvents);
    }

    [Fact]
    public void Date_range_returns_overlapping_events()
    {
        var admin = TestApp.Create(_s.Db).LoginAs(_s.AdminUser).Services.Events;
        admin.Create(new SchoolEventInput("А", "", At(25, 9), At(25, 10), null));
        admin.Create(new SchoolEventInput("Б", "", At(28, 9), At(28, 10), null));

        Assert.Single(admin.GetByDateRange(new DateOnly(2026, 11, 24), new DateOnly(2026, 11, 26)));
    }
}
