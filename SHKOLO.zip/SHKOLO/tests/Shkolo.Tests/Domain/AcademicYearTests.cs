// Owner: Shared
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Tests.Domain;

public class AcademicYearTests
{
    private static AcademicYear Year() => new()
    {
        Name = "2026/2027",
        StartDate = new DateOnly(2026, 9, 15),
        FirstTermEndDate = new DateOnly(2027, 1, 31),
        EndDate = new DateOnly(2027, 6, 30),
        IsActive = true,
    };

    [Fact]
    public void GetTerm_splits_on_first_term_end_date()
    {
        Assert.Equal(Term.First, Year().GetTerm(new DateOnly(2027, 1, 31)));
        Assert.Equal(Term.Second, Year().GetTerm(new DateOnly(2027, 2, 1)));
    }

    [Fact]
    public void Contains_is_inclusive()
    {
        Assert.False(Year().Contains(new DateOnly(2026, 9, 14)));
        Assert.True(Year().Contains(new DateOnly(2026, 9, 15)));
        Assert.True(Year().Contains(new DateOnly(2027, 6, 30)));
        Assert.False(Year().Contains(new DateOnly(2027, 7, 1)));
    }

    [Fact]
    public void Computed_display_names()
    {
        Assert.Equal("10А", new SchoolClass { GradeLevel = 10, Section = "А" }.DisplayName);
        Assert.Equal("Иван Петров", new Student { FirstName = "Иван", LastName = "Петров" }.FullName);
    }
}
