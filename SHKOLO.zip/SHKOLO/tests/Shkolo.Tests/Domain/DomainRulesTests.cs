// Owner: Shared
using Shkolo.Domain;

namespace Shkolo.Tests.Domain;

public class DomainRulesTests
{
    [Theory]
    [InlineData("2.00", true)]
    [InlineData("6.00", true)]
    [InlineData("5.50", true)]
    [InlineData("1.00", false)]
    [InlineData("7.00", false)]
    [InlineData("1.99", false)]
    [InlineData("6.01", false)]
    [InlineData("5.555", false)]
    public void IsValidGrade_enforces_range_and_two_decimals(string value, bool expected)
        => Assert.Equal(expected, DomainRules.IsValidGrade(decimal.Parse(value, System.Globalization.CultureInfo.InvariantCulture)));

    [Theory]
    [InlineData("4.50", 5)]
    [InlineData("4.49", 4)]
    [InlineData("2.10", 2)]
    [InlineData("5.999", 6)]
    public void RoundToTermGrade_rounds_half_away_from_zero(string value, int expected)
        => Assert.Equal(expected, DomainRules.RoundToTermGrade(decimal.Parse(value, System.Globalization.CultureInfo.InvariantCulture)));

    [Fact]
    public void RoundForDisplay_uses_two_decimals_away_from_zero()
    {
        Assert.Equal(5.43m, DomainRules.RoundForDisplay(5.425m));
        Assert.Equal(5.42m, DomainRules.RoundForDisplay(5.424m));
    }

    [Theory]
    [InlineData("a@b.bg", true)]
    [InlineData("abc", false)]
    [InlineData(" a@b.bg", true)]
    [InlineData("Иван <a@b.bg>", false)]
    [InlineData("", false)]
    [InlineData(null, false)]
    public void IsEmailValid_accepts_plain_addresses_only(string? email, bool expected)
        => Assert.Equal(expected, DomainRules.IsEmailValid(email));

    [Theory]
    [InlineData("2.00", "Слаб")]
    [InlineData("3.49", "Среден")]
    [InlineData("3.50", "Добър")]
    [InlineData("4.50", "Много добър")]
    [InlineData("5.50", "Отличен")]
    public void GradeWord_maps_bulgarian_scale(string value, string expected)
        => Assert.Equal(expected, DomainRules.GradeWord(decimal.Parse(value, System.Globalization.CultureInfo.InvariantCulture)));

    [Fact]
    public void IsNameValid_rejects_blank_and_too_long()
    {
        Assert.True(DomainRules.IsNameValid("Иван"));
        Assert.False(DomainRules.IsNameValid("   "));
        Assert.False(DomainRules.IsNameValid(null));
        Assert.False(DomainRules.IsNameValid(new string('а', 51)));
    }

    [Fact]
    public void IsValidTermGrade_accepts_2_to_6()
    {
        Assert.True(DomainRules.IsValidTermGrade(2));
        Assert.True(DomainRules.IsValidTermGrade(6));
        Assert.False(DomainRules.IsValidTermGrade(1));
        Assert.False(DomainRules.IsValidTermGrade(7));
    }
}
