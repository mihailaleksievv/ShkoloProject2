// Owner: Shared
using Shkolo.Presentation.Motion;
using Shkolo.Tests.TestSupport;
using Spectre.Console;

namespace Shkolo.Tests.Motion;

public class MotionTests
{
    public static TheoryData<string> EasingNames => new() { "Linear", "EaseOutCubic", "EaseInOutQuad" };

    private static Func<double, double> EasingBy(string name) => name switch
    {
        "Linear" => Easing.Linear,
        "EaseOutCubic" => Easing.EaseOutCubic,
        _ => Easing.EaseInOutQuad,
    };

    [Theory]
    [MemberData(nameof(EasingNames))]
    public void Easing_starts_at_zero_ends_at_one_and_never_goes_back(string name)
    {
        var easing = EasingBy(name);
        Assert.Equal(0, easing(0), 6);
        Assert.Equal(1, easing(1), 6);
        var samples = Enumerable.Range(0, 11).Select(i => easing(i / 10.0)).ToList();
        Assert.True(samples.Zip(samples.Skip(1)).All(p => p.Second >= p.First));
    }

    [Fact]
    public void Tween_progress_before_during_after()
    {
        var d = TimeSpan.FromMilliseconds(200);
        Assert.Equal(0, Tween.Progress(TimeSpan.Zero, d, Easing.Linear));
        Assert.Equal(0.5, Tween.Progress(TimeSpan.FromMilliseconds(100), d, Easing.Linear), 6);
        Assert.Equal(1, Tween.Progress(TimeSpan.FromSeconds(5), d, Easing.Linear));
        Assert.Equal(1, Tween.Progress(TimeSpan.Zero, TimeSpan.Zero, Easing.Linear));
    }

    [Fact]
    public void Tween_value_interpolates()
    {
        Assert.Equal(50m, Tween.Value(0m, 100m, 0.5));
        Assert.Equal(50, Tween.Value(0, 100, 0.5));
        Assert.Equal(100, Tween.Value(0, 100, 1.0));
    }

    [Fact]
    public void Disabled_animator_draws_only_the_final_frame()
    {
        var (console, _) = Render.Create();
        var calls = new List<double>();
        new Animator(MotionSettings.Disabled, new ManualFrameTimer())
            .Play(console, TimeSpan.FromMilliseconds(200), p =>
            {
                calls.Add(p);
                return new Text("x");
            });

        Assert.Equal([1.0], calls);
    }

    [Fact]
    public void Enabled_animator_plays_frames_until_done()
    {
        var console = new ScriptedConsole();
        var timer = new ManualFrameTimer();
        var calls = new List<double>();
        var animator = new Animator(MotionSettings.Default, timer) { FrameDelay = TimeSpan.Zero, OnFrame = () => timer.Advance(TimeSpan.FromMilliseconds(50)) };

        animator.Play(console, TimeSpan.FromMilliseconds(200), p =>
        {
            calls.Add(p);
            return new Text("x");
        });

        Assert.True(calls.Count >= 4);
        Assert.Equal(1.0, calls[^1]);
    }

    [Fact]
    public void Enabled_animator_is_skipped_by_a_key()
    {
        var console = new ScriptedConsole();
        console.Enter();
        var timer = new ManualFrameTimer();
        var calls = new List<double>();
        var animator = new Animator(MotionSettings.Default, timer) { FrameDelay = TimeSpan.Zero, OnFrame = () => timer.Advance(TimeSpan.FromMilliseconds(10)) };

        animator.Play(console, TimeSpan.FromSeconds(2), p =>
        {
            calls.Add(p);
            return new Text("x");
        });

        Assert.True(calls.Count < 10);
        Assert.Equal(1.0, calls[^1]);
        Assert.Equal(0, console.RemainingKeys);
    }

    [Fact]
    public void Effects_render_final_frames()
    {
        Assert.Contains("SHKOLO", Render.ToText(Effects.Typewriter("SHKOLO", Color.White)(1.0)));
        Assert.DoesNotContain("SHKOLO", Render.ToText(Effects.Typewriter("SHKOLO", Color.White)(0.3)));
        Assert.Contains("42", Render.ToText(Effects.CountUp(42, v => v.ToString())(1.0)));
        Assert.Contains("готово", Render.ToText(Effects.Flash("готово", Color.Green)(1.0)));
        Assert.Contains("after", Render.ToText(Effects.Wipe(new Text("before"), new Text("after"))(1.0)));
    }
}
