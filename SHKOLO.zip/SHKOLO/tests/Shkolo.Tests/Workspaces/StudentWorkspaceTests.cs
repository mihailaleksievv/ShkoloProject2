﻿// Owner: Shared
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Workspaces.Learning;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Workspaces;

public class StudentWorkspaceTests
{
    [Fact]
    public void Dashboard_pages_switch_with_left_and_right()
    {
        var ui = new UiApp();
        ui.Console.Press(ConsoleKey.RightArrow)   // Присъствия
            .Press(ConsoleKey.RightArrow)         // Тенденция
            .Press(ConsoleKey.LeftArrow);         // back to Присъствия
        ui.LeaveShell();

        Assert.Equal(ShellOutcome.Logout, ui.Shell("student1", new StudentWorkspace()));

        var output = ui.Console.Output;
        Assert.Contains("МИХАИЛ АЛЕКСИЕВ", output);
        Assert.Contains("Среден успех", output);
        Assert.Contains("Успех по предмети", output);   // first page
        Assert.Contains("История и цивилизации", output);
        Assert.Contains("Неизвинено", output);          // heatmap legend on the attendance page
        Assert.Contains("■", output);
        Assert.Contains("6 седмици", output);           // trend page
        Assert.Contains("▌", output);
        Assert.Contains("I срок", output);
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Absences_and_school_events_from_v1_are_reachable()
    {
        var ui = new UiApp();
        ui.Console.Keys("о").Key()        // Табло › Моите отсъствия
            .Keys("5").Keys("б").Choose(1); // Календар › Училищни събития, then back
        ui.LeaveShell();

        ui.Shell("student1", new StudentWorkspace());

        Assert.Contains("Отсъствия и закъснения", ui.Console.Output);
        Assert.Contains("Предстоящи събития", ui.Console.Output);
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Every_section_renders()
    {
        var ui = new UiApp();
        ui.Console.Keys("1234567");
        ui.LeaveShell();

        ui.Shell("student1", new StudentWorkspace());

        Assert.All(new[] { "Табло", "Оценки", "Разписание", "Домашни", "Календар", "Съобщения", "Отличия" }, t => Assert.Contains(t, ui.Console.Output));
        Assert.Empty(ui.Errors);
    }

    [Fact]
    public void Calendar_moves_between_months()
    {
        var ui = new UiApp();
        ui.Console.Keys("5").Press(ConsoleKey.RightArrow);
        ui.LeaveShell();

        ui.Shell("student1", new StudentWorkspace());

        Assert.Contains("ноември", ui.Console.Output);
        Assert.Contains("декември", ui.Console.Output);
    }

    [Fact]
    public void Homework_shows_countdown_and_can_be_submitted_by_hotkey()
    {
        var ui = new UiApp();
        var student = ui.Db.Students.Single(s => s.StudentNumber == "1001");
        var list = ui.Db.Homework.Where(h => h.ClassId == student.ClassId && h.IsActive)
            .OrderBy(h => h.DueDate).ThenBy(h => h.Title, StringComparer.CurrentCulture).ToList();
        var open = list.FindIndex(h => h.DueDate >= ui.App.Clock.Today);
        ui.Console.Keys("4").Keys("п").Choose(0).Choose(open).Type("Готово – в тетрадката.").Key().Choose(2);
        ui.LeaveShell();

        ui.Shell("student1", new StudentWorkspace());

        Assert.Contains("остават", ui.Console.Output);
        Assert.Contains(ui.Db.HomeworkSubmissions, s => s.StudentId == student.Id && s.Content == "Готово – в тетрадката.");
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }
}
