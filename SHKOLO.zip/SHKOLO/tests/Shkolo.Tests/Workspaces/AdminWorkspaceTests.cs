﻿// Owner: Shared
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Workspaces.Administration;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Workspaces;

public class AdminWorkspaceTests
{
    [Fact]
    public void Dashboard_pages_switch_with_left_and_right()
    {
        var ui = new UiApp();
        ui.Console.Press(ConsoleKey.RightArrow)   // Разпределение
            .Press(ConsoleKey.RightArrow)         // Присъствия
            .Press(ConsoleKey.RightArrow)         // Събития и действия
            .Press(ConsoleKey.RightArrow);        // back to Успех по класове
        ui.LeaveShell();

        Assert.Equal(ShellOutcome.Logout, ui.Shell("admin", new AdminWorkspace()));

        var output = ui.Console.Output;
        Assert.Contains("18", output);
        Assert.Contains("Успех по класове", output);
        Assert.Contains("10Б", output);
        Assert.Contains("Мн. добър", output);              // histogram page
        Assert.Contains("Пулс на присъствията", output);   // attendance page
        Assert.Contains("%", output);
        Assert.Contains("Последни действия", output);      // events and actions page
        Assert.Contains("Родителска среща", output);
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Statistics_switch_views_with_left_and_right()
    {
        var ui = new UiApp();
        ui.Console.Keys("6")
            .Press(ConsoleKey.RightArrow)   // по класове
            .Press(ConsoleKey.RightArrow)   // разпределение
            .Press(ConsoleKey.RightArrow);  // обратно към предмети
        ui.LeaveShell();

        ui.Shell("admin", new AdminWorkspace());

        var output = ui.Console.Output;
        Assert.Contains("Математика", output);   // subjects view
        Assert.Contains("10А", output);          // classes view
        Assert.Contains("Мн. добър", output);    // histogram band names
        Assert.Contains("Присъствия", output);   // attendance segments
        Assert.Contains("средно", output);       // school-average marker
        Assert.Empty(ui.Errors);
    }

    [Fact]
    public void Every_section_renders()
    {
        var ui = new UiApp();
        ui.Console.Keys("12345678");
        ui.LeaveShell();

        ui.Shell("admin", new AdminWorkspace());

        Assert.All(new[] { "Табло", "Хора", "Структура", "Разписание", "Дневник", "Статистики", "Комуникация", "Система" }, t => Assert.Contains(t, ui.Console.Output));
        Assert.Contains("memory://school-data.json", ui.Console.Output);
        Assert.Empty(ui.Errors);
    }

    [Fact]
    public void Admin_adds_a_student_from_the_people_section()
    {
        var ui = new UiApp();
        ui.Console.Keys("2").Keys("у")
            .Choose(3)
            .Type("2001").Type("Тодор").Type("Тестов")
            .Search("10Б")
            .Type("")
            .Type("н")
            .Key()
            .Choose(8);
        ui.LeaveShell();

        ui.Shell("admin", new AdminWorkspace());

        Assert.Single(ui.Db.Students, s => s.StudentNumber == "2001");
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }
}
