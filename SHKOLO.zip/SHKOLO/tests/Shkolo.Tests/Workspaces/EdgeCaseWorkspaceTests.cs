﻿// Owner: Shared
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Workspaces.Administration;
using Shkolo.Presentation.Workspaces.Learning;
using Shkolo.Presentation.Workspaces.Teaching;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Workspaces;

/// <summary>Every section of every role still renders when the school data is thin.</summary>
public class EdgeCaseWorkspaceTests
{
    private static IWorkspace For(string username) => username switch
    {
        "admin" => new AdminWorkspace(),
        "teacher1" => new TeacherWorkspace(),
        _ => new StudentWorkspace(),
    };

    [Theory]
    [InlineData("admin")]
    [InlineData("teacher1")]
    [InlineData("student1")]
    public void Every_section_renders_without_an_active_school_year(string username)
    {
        var ui = new UiApp();
        ui.Db.AcademicYears.Clear();
        ui.Console.Keys("123456789");
        ui.LeaveShell();

        Assert.Equal(ShellOutcome.Logout, ui.Shell(username, For(username)));
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Every_section_renders_for_a_teacher_without_assignments()
    {
        var ui = new UiApp();
        var teacherId = ui.Db.Teachers.Single(t => t.FirstName == "Иван" && t.LastName == "Иванов").Id;
        ui.Db.TeacherAssignments.RemoveAll(a => a.TeacherId == teacherId);
        ui.Db.Timetable.RemoveAll(t => t.TeacherId == teacherId);
        ui.Console.Keys("123456789");
        ui.LeaveShell();

        Assert.Equal(ShellOutcome.Logout, ui.Shell("teacher1", new TeacherWorkspace()));
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }
}
