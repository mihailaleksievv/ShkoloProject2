﻿// Owner: Shared
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Workspaces.Teaching;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Workspaces;

public class TeacherWorkspaceTests
{
    private static readonly string[] SectionTitles = ["Табло", "Днес", "Класове", "Оценки", "Срочни", "Отсъствия", "Домашни", "Комуникация", "Справки"];

    [Fact]
    public void On_a_day_without_lessons_the_next_school_day_is_shown()
    {
        var ui = new UiApp(new DateOnly(2026, 11, 22));   // Sunday
        ui.Console.Keys("2");                            // Днес
        ui.LeaveShell();

        ui.Shell("teacher1", new TeacherWorkspace());

        var output = ui.Console.Output;
        Assert.Contains("Днес нямате часове", output);
        Assert.Contains("Следващ учебен ден", output);
        Assert.Contains("понеделник, 23.11", output);
        Assert.Contains("Математика", output);          // a real lesson of that day
        Assert.Contains("предстои", output);            // Today section cards
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Weekly_timetable_from_v1_is_reachable()
    {
        var ui = new UiApp();
        ui.Console.Keys("2").Keys("р").Key();   // Днес › Седмично разписание
        ui.LeaveShell();

        ui.Shell("teacher1", new TeacherWorkspace());

        Assert.Contains("Моето седмично разписание", ui.Console.Output);
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Dashboard_greets_and_shows_the_day_trends_and_attention()
    {
        var ui = new UiApp();
        ui.LeaveShell();

        Assert.Equal(ShellOutcome.Logout, ui.Shell("teacher1", new TeacherWorkspace()));

        var output = ui.Console.Output;
        Assert.Contains("Добро утро, Иван", output);
        Assert.Contains("●", output);
        Assert.Contains("○", output);
        Assert.True("▁▂▃▄▅▆▇█".Any(output.Contains), "a sparkline is rendered");
        Assert.Contains("Нужда от внимание", output);
        Assert.Empty(ui.Errors);
    }

    [Fact]
    public void Every_section_renders()
    {
        var ui = new UiApp();
        ui.Console.Keys("123456789");
        ui.LeaveShell();

        ui.Shell("teacher1", new TeacherWorkspace());

        Assert.All(SectionTitles, t => Assert.Contains(t, ui.Console.Output));
        Assert.Empty(ui.Errors);
    }

    [Fact]
    public void Hotkey_records_a_lesson_and_today_shows_it_done()
    {
        var ui = new UiApp();
        var before = ui.Db.Lessons.Count;
        ui.Console.Keys("2").Keys("п")
            .Choose(0)
            .Type("Квадратни неравенства")
            .Type("")
            .MultiSelect(0)
            .Choose(0)
            .Type("д")
            .Choose(0)
            .Type("5,50")
            .Choose(0)
            .Type("")
            .Type("н")
            .Type("д")
            .Key();
        ui.LeaveShell();

        ui.Shell("teacher1", new TeacherWorkspace());

        Assert.Equal(before + 1, ui.Db.Lessons.Count);
        var lesson = ui.Db.Lessons.Single(l => l.Topic == "Квадратни неравенства");
        Assert.Single(ui.Db.AttendanceRecords, a => a.LessonId == lesson.Id && a.Status == AttendanceStatus.Absent);
        Assert.Contains("✔", ui.Console.Output);
        Assert.Empty(ui.Errors);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Bracketed_student_names_render_literally()
    {
        var ui = new UiApp();
        foreach (var s in ui.Db.Students)
        {
            s.LastName = "[x] " + s.LastName;
        }

        ui.Console.Keys("4");
        ui.LeaveShell();

        ui.Shell("teacher1", new TeacherWorkspace());

        Assert.Contains("[x] ", ui.Console.Output);
        Assert.Empty(ui.Errors);
    }

    [Fact]
    public void Attendance_section_switches_class_with_arrows()
    {
        var ui = new UiApp();
        ui.Console.Keys("6").Press(ConsoleKey.RightArrow);
        ui.LeaveShell();

        ui.Shell("teacher1", new TeacherWorkspace());

        Assert.Contains("10А", ui.Console.Output);
        Assert.Contains("10Б", ui.Console.Output);
        Assert.Contains("Неизвинено", ui.Console.Output);
    }
}
