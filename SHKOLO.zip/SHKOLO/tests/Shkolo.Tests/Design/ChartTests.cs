﻿// Owner: Shared
using Shkolo.Application.Reports;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Theme;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Design;

public class ChartTests
{
    [Theory]
    [InlineData("2.50", ShkoloTheme.ErrorHex)]
    [InlineData("3.20", ShkoloTheme.PeachHex)]
    [InlineData("4.42", ShkoloTheme.WarningHex)]
    [InlineData("4.79", ShkoloTheme.AccentHex)]
    [InlineData("5.50", ShkoloTheme.SuccessHex)]
    public void Grade_scale_gives_every_band_its_own_colour(string value, string hex)
        => Assert.Equal(hex, GradeScale.HexOf(decimal.Parse(value, System.Globalization.CultureInfo.InvariantCulture)));

    [Fact]
    public void Grade_bars_are_separated_and_mark_best_and_worst()
    {
        var text = Render.ToText(GradeBars.Render(
            [new GradeBar("Биология", 4.79m), new GradeBar("Английски [B2]", 4.62m), new GradeBar("Математика", 4.42m)],
            reference: 4.61m, barWidth: 20));

        var lines = text.Replace("\r", "").Split('\n');
        var bio = Array.FindIndex(lines, l => l.Contains("Биология"));
        var eng = Array.FindIndex(lines, l => l.Contains("Английски [B2]"));
        Assert.True(eng - bio >= 2, "an empty line separates neighbouring bars");
        Assert.Contains("★", lines[bio]);
        Assert.Contains("⚠", lines[Array.FindIndex(lines, l => l.Contains("Математика"))]);
        Assert.Contains("4,79", text);
        Assert.Contains("средно 4,61", text);
    }

    [Fact]
    public void Grade_bar_length_follows_the_two_to_six_scale()
    {
        var full = Render.ToText(GradeBars.Render([new GradeBar("А", 6m)], barWidth: 20, markExtremes: false));
        var empty = Render.ToText(GradeBars.Render([new GradeBar("А", 2m)], barWidth: 20, markExtremes: false));
        var half = Render.ToText(GradeBars.Render([new GradeBar("А", 4m)], barWidth: 20, markExtremes: false));

        Assert.Equal(20, full.Count(c => c == '▆'));
        Assert.Equal(0, empty.Count(c => c == '▆'));
        Assert.Equal(10, half.Count(c => c == '▆'));
    }

    [Fact]
    public void Grade_bar_without_value_says_so()
        => Assert.Contains("няма оценки", Render.ToText(GradeBars.Render([new GradeBar("А", null)])));

    [Fact]
    public void Histogram_shows_counts_grades_and_shares()
    {
        var text = Render.ToText(GradeHistogram.Render(new GradeDistribution(Poor: 0, Average: 45, Good: 57, VeryGood: 49, Excellent: 64)));

        Assert.Contains("64", text);
        Assert.Contains("Отличен", text);
        Assert.Contains("Слаб", text);
        Assert.Contains("30%", text);   // 64 / 215
        Assert.Contains("0%", text);
        Assert.Contains("█", text);
    }

    [Fact]
    public void Histogram_without_grades_says_so()
        => Assert.Contains("Няма оценки", Render.ToText(GradeHistogram.Render(new GradeDistribution(0, 0, 0, 0, 0))));

    [Fact]
    public void Segment_bar_keeps_gaps_and_lists_shares()
    {
        var text = Render.ToText(SegmentBar.Render(
            [new Segment("Присъствия", 990, ShkoloTheme.Success), new Segment("Закъснения", 21, ShkoloTheme.Accent), new Segment("Неизвинени", 32, ShkoloTheme.Error)],
            width: 60));

        Assert.Contains("Присъствия", text);
        Assert.Contains("990", text);
        Assert.Contains("95%", text);
        Assert.Contains("█ █", text.Replace("\r", "")); // a one-column gap between segments
    }

    [Fact]
    public void Role_frames_are_the_same_soft_blue_and_badges_differ()
    {
        Assert.Equal(ShkoloTheme.Frame, RoleAccent.For(UserRole.Teacher));
        Assert.Equal(ShkoloTheme.Frame, RoleAccent.For(UserRole.Student));
        Assert.Equal(ShkoloTheme.Frame, RoleAccent.For(UserRole.Administrator));
        Assert.NotEqual(RoleAccent.BadgeHexFor(UserRole.Teacher), RoleAccent.BadgeHexFor(UserRole.Student));
    }

    [Fact]
    public void Week_columns_show_each_week_with_its_value_and_gaps()
    {
        var text = Render.ToText(WeekColumns.Render([3m, 4.5m, null, 6m]));

        Assert.Contains("3,00", text);
        Assert.Contains("6,00", text);
        Assert.Contains("·", text);                       // a week without grades
        Assert.Contains("█", text);
        Assert.DoesNotContain("████", text); // columns never touch
    }

    [Fact]
    public void Grade_bars_can_be_dense()
    {
        var text = Render.ToText(GradeBars.Render([new GradeBar("А", 5m), new GradeBar("Б", 4m)], spacing: false));
        var lines = text.Replace("\r", "").Split('\n');
        Assert.Equal(1, Array.FindIndex(lines, l => l.Contains("Б")) - Array.FindIndex(lines, l => l.Contains("А")));
    }

    [Fact]
    public void Day_columns_show_shares_with_gaps_and_labels()
    {
        var text = Render.ToText(DayColumns.Render(
            [new DayPresence(new DateOnly(2026, 11, 19), 0.95m), new DayPresence(new DateOnly(2026, 11, 20), 0.80m), new DayPresence(new DateOnly(2026, 11, 18), null)]));

        Assert.Contains("95%", text);
        Assert.Contains("80%", text);
        Assert.Contains("чт", text);
        Assert.Contains("19.11", text);
        Assert.Contains("·", text);
        Assert.DoesNotContain("██████", text);   // columns never touch
    }
}
