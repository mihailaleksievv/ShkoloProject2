// Owner: Shared
using Shkolo.Presentation.Design;
using Shkolo.Tests.TestSupport;
using Spectre.Console;

namespace Shkolo.Tests.Design;

public class SkyTests
{
    [Fact]
    public void Sky_is_deterministic_blue_on_top_with_white_clouds_lower_down()
    {
        var a = SkyPainter.Paint(120, 60);
        var b = SkyPainter.Paint(120, 60);

        Assert.Equal(a[10, 2], b[10, 2]);
        var top = a[60, 1];
        Assert.True(top.B > top.R + 40, "the top of the sky is clearly blue");
        var whiteish = 0;
        for (var x = 0; x < 120; x++)
        {
            for (var y = 45; y < 60; y++)
            {
                var c = a[x, y];
                if (c.R > 215 && c.G > 220 && c.B > 225)
                {
                    whiteish++;
                }
            }
        }

        Assert.True(whiteish > 200, $"clouds fill part of the lower sky ({whiteish} white pixels)");
    }

    [Fact]
    public void Darkened_sky_is_darker()
    {
        var light = SkyPainter.Paint(40, 20)[20, 10];
        var dark = SkyPainter.Paint(40, 20, darken: 0.4)[20, 10];
        Assert.True(dark.R + dark.G + dark.B < light.R + light.G + light.B);
    }

    [Fact]
    public void Canvas_draws_half_blocks_and_overlay_text()
    {
        var canvas = new PixelCanvas(SkyPainter.Paint(30, 10));
        canvas.Text(2, 1, "Здравей [x]", Color.White);
        canvas.Fill(0, 3, 10, 1, Color.White);

        var lines = Render.ToText(canvas, 30).Replace("\r", "").TrimEnd('\n').Split('\n');

        Assert.Equal(5, lines.Length);                // 10 pixel rows = 5 text rows
        Assert.All(lines, l => Assert.Equal(30, l.Length));
        Assert.Contains("Здравей [x]", lines[1]);    // literal, never parsed as markup
        Assert.Contains("▀", lines[0]);
    }

    [Fact]
    public void Block_logo_is_drawn_into_the_pixels()
    {
        var pixels = SkyPainter.Paint(100, 30);
        var before = pixels[50, 10];
        BlockLogo.Draw(pixels, 50, 4, Color.White);

        Assert.True(BlockLogo.Width > 60);
        var whites = 0;
        for (var x = 0; x < 100; x++)
        {
            for (var y = 0; y < 30; y++)
            {
                if (pixels[x, y] == Color.White)
                {
                    whites++;
                }
            }
        }

        Assert.True(whites > 150, "the letters are solid white pixels");
        Assert.NotNull(before.ToString());
    }
}
