﻿// Owner: Shared
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Theme;
using Shkolo.Tests.TestSupport;
using Spectre.Console;

namespace Shkolo.Tests.Design;

public class GradientTests
{
    private static readonly Color Black = new(0, 0, 0);
    private static readonly Color White = new(255, 255, 255);

    [Fact]
    public void Lerp_hits_both_endpoints()
    {
        Assert.Equal(Black, Gradient.Lerp(Black, White, 0));
        Assert.Equal(White, Gradient.Lerp(Black, White, 1));
    }

    [Fact]
    public void Lerp_midpoint_is_halfway()
    {
        var mid = Gradient.Lerp(Black, White, 0.5);
        Assert.InRange(mid.R, 127, 128);
        Assert.InRange(mid.G, 127, 128);
    }

    [Fact]
    public void Lerp_clamps_t()
    {
        Assert.Equal(Black, Gradient.Lerp(Black, White, -3));
        Assert.Equal(White, Gradient.Lerp(Black, White, 7));
    }

    [Fact]
    public void Gradient_text_escapes_markup()
        => Assert.Contains("Иван [x] [/]", Render.Markup(Gradient.Text("Иван [x] [/]", ShkoloTheme.Primary, ShkoloTheme.Accent)));

    [Fact]
    public void Gradient_text_of_empty_string_is_empty()
        => Assert.Equal("", Gradient.Text("", Black, White));

    [Fact]
    public void Logo_lines_are_padded_to_equal_width()
    {
        Assert.NotEmpty(Logo.Lines);
        Assert.Single(Logo.Lines.Select(l => l.Length).Distinct());
    }

    [Fact]
    public void Logo_reveal_shows_part_of_the_width()
    {
        var full = Render.ToText(Logo.Render(1.0)).Split('\n').Max(l => l.TrimEnd().Length);
        var half = Render.ToText(Logo.Render(0.5)).Split('\n').Max(l => l.TrimEnd().Length);
        Assert.InRange(half, full / 2 - 2, full / 2 + 2);
    }

    [Fact]
    public void Gradient_lines_render_all_lines()
        => Assert.Equal(2, Render.ToText(Gradient.Lines(["ab", "cd"], Black, White)).Trim().Split('\n').Length);
}
