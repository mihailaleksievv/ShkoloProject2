// Owner: Shared
using Shkolo.Application.Reports;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Theme;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Design;

public class ComponentTests
{
    [Fact]
    public void Sparkline_maps_min_and_max_to_lowest_and_highest_block()
        => Assert.Equal("▁█", Sparkline.Render([2m, 6m], 2m, 6m));

    [Fact]
    public void Sparkline_marks_missing_values_and_rounds_half_up()
        => Assert.Equal("·▅", Sparkline.Render([null, 4m], 2m, 6m));

    [Fact]
    public void Sparkline_with_equal_bounds_uses_middle_block()
        => Assert.Equal("▄▄", Sparkline.Render([5m, 5m], 5m, 5m));

    [Fact]
    public void Sparkline_of_nothing_is_empty()
        => Assert.Equal("", Sparkline.Render([], 2m, 6m));

    [Theory]
    [InlineData("4", "5", "▲")]
    [InlineData("5", "4", "▼")]
    [InlineData("4.00", "4.03", "▬")]
    [InlineData(null, "4", "▬")]
    public void Trend_shows_direction(string? previous, string? current, string glyph)
        => Assert.Contains(glyph, Trend.Markup(Parse(previous), Parse(current)));

    [Fact]
    public void Meter_bounds()
    {
        Assert.DoesNotContain("━", Render.Markup(Meter.Markup(0, 10, 10, ShkoloTheme.Primary, ShkoloTheme.Accent)));
        Assert.Equal(10, Render.Markup(Meter.Markup(10, 10, 10, ShkoloTheme.Primary, ShkoloTheme.Accent)).Count(c => c == '━'));
        Assert.Equal(10, Render.Markup(Meter.Markup(99, 10, 10, ShkoloTheme.Primary, ShkoloTheme.Accent)).Count(c => c == '━'));
        Assert.Equal(0, Render.Markup(Meter.Markup(5, 0, 10, ShkoloTheme.Primary, ShkoloTheme.Accent)).Count(c => c == '━'));
    }

    [Fact]
    public void Heatmap_lays_out_weeks_and_legend()
    {
        var monday = new DateOnly(2026, 11, 9);
        var days = Enumerable.Range(0, 12).Select(i => monday.AddDays(i))
            .Where(d => d.DayOfWeek is not DayOfWeek.Saturday and not DayOfWeek.Sunday)
            .Select((d, i) => new DayAttendance(d, i == 3 ? AttendanceStatus.Absent : i == 4 ? null : AttendanceStatus.Present, i == 4 ? 0 : 6))
            .ToList();

        var text = Render.ToText(Heatmap.Render(days));

        Assert.Contains("Пн", text);
        Assert.Contains("Пт", text);
        Assert.Contains("Присъства", text);
        Assert.Contains("Неизвинено", text);
        Assert.Equal(9, text.Count(c => c == '■') - 4); // 9 days with lessons + 4 legend cells
    }

    [Fact]
    public void Grade_gauge_without_average_says_no_data()
        => Assert.Contains("Няма данни", Render.ToText(GradeGauge.Render(null)));

    [Fact]
    public void Grade_gauge_shows_value_and_word()
    {
        var text = Render.ToText(GradeGauge.Render(5.5m));
        Assert.Contains("5,50", text);
        Assert.Contains("Отличен", text);
    }

    [Fact]
    public void Grade_badge_uses_decimal_comma()
        => Assert.Contains("5,50", Render.Markup(GradeBadge.Markup(5.5m)));

    [Fact]
    public void Day_timeline_marks_recorded_now_and_pending()
    {
        var slots = Enumerable.Range(1, 3).Select(n => new LessonSlot { LessonNumber = n, StartTime = new TimeOnly(7 + n, 0), EndTime = new TimeOnly(7 + n, 40) }).ToList();
        var rows = slots.Select(s => new TimetableRow(Guid.NewGuid(), DayOfWeek.Friday, s.LessonNumber, s.StartTime, s.EndTime, Guid.Empty, "10А", Guid.Empty, "Математика", Guid.Empty, "Т", null)).ToList();

        var text = Render.ToText(DayTimeline.Render(slots, rows, new HashSet<Guid> { rows[0].EntryId }, new TimeOnly(9, 10)));

        Assert.Contains("✔", text);
        Assert.Contains("●", text);
        Assert.Contains("○", text);
        Assert.Contains("08:00", text);
    }

    [Fact]
    public void Calendar_view_escapes_labels()
    {
        var text = Render.ToText(CalendarView.Render(2026, 11, [(new DateOnly(2026, 11, 25), "[x] контролно")]));
        Assert.Contains("[x] контролно", text);
        Assert.Contains("ноември", text, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Card_escapes_title_and_caption()
    {
        var text = Render.ToText(Card.Render("[a]", "[bold]5[/]", "[b]", ShkoloTheme.Primary));
        Assert.Contains("[a]", text);
        Assert.Contains("[b]", text);
        Assert.Contains("5", text);
    }

    private static decimal? Parse(string? s) => s is null ? null : decimal.Parse(s, System.Globalization.CultureInfo.InvariantCulture);
}
