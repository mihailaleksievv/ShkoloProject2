// Owner: Shared
using Shkolo.Application.Abstractions;

namespace Shkolo.Tests.TestSupport;

/// <summary>Non-cryptographic hasher that keeps data-generation tests fast. Never used by the application.</summary>
public sealed class FastHasher : IPasswordHasher
{
    public (string Hash, string Salt) Hash(string password) => ("plain:" + password, "none");

    public bool Verify(string password, string hash, string salt) => hash == "plain:" + password;
}
