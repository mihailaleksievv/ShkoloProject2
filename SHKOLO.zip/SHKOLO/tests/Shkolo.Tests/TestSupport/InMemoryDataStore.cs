// Owner: Shared
using System.Text.Json;
using Shkolo.Application.Abstractions;
using Shkolo.Domain;

namespace Shkolo.Tests.TestSupport;

/// <summary>Data store that keeps the last saved JSON in memory and counts saves.</summary>
public sealed class InMemoryDataStore : IDataStore
{
    private readonly SchoolDatabase _initial;

    public InMemoryDataStore(SchoolDatabase? initial = null) => _initial = initial ?? new SchoolDatabase();

    public string DataFilePath => "memory://school-data.json";

    public int SaveCount { get; private set; }

    public string? LastJson { get; private set; }

    public LoadResult Load() => new(LoadStatus.Loaded, _initial, null, []);

    public void Save(SchoolDatabase database)
    {
        SaveCount++;
        LastJson = JsonSerializer.Serialize(database);
    }
}
