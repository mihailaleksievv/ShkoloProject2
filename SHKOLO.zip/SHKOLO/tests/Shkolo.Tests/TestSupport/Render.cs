// Owner: Shared
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Tests.TestSupport;

/// <summary>Renders Spectre output to plain text (no ANSI, no colours) for assertions.</summary>
public static class Render
{
    public static string ToText(IRenderable renderable, int width = 200)
    {
        var (console, writer) = Create(width);
        console.Write(renderable);
        return writer.ToString();
    }

    public static string Markup(string markup, int width = 200) => ToText(new Markup(markup), width);

    public static (IAnsiConsole Console, StringWriter Writer) Create(int width = 200)
    {
        var writer = new StringWriter();
        var console = AnsiConsole.Create(new AnsiConsoleSettings
        {
            Out = new AnsiConsoleOutput(writer),
            Ansi = AnsiSupport.No,
            ColorSystem = ColorSystemSupport.NoColors,
            Interactive = InteractionSupport.No,
        });
        console.Profile.Width = width;
        return (console, writer);
    }
}
