// Owner: Shared
using Shkolo.Presentation.Motion;

namespace Shkolo.Tests.TestSupport;

/// <summary>Frame timer advanced explicitly by tests – animations become deterministic.</summary>
public sealed class ManualFrameTimer : IFrameTimer
{
    public TimeSpan Elapsed { get; private set; }

    public void Restart() => Elapsed = TimeSpan.Zero;

    public void Advance(TimeSpan by) => Elapsed += by;
}
