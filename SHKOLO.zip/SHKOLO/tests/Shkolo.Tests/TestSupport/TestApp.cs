// Owner: Shared
using Shkolo.Application;
using Shkolo.Application.Abstractions;
using Shkolo.Application.Security;
using Shkolo.Domain;
using Shkolo.Infrastructure.Security;

namespace Shkolo.Tests.TestSupport;

/// <summary>Fully wired application services over an in-memory store and a fake clock.</summary>
public sealed class TestApp
{
    private TestApp(SchoolDatabase db, FakeClock clock, InMemoryDataStore store, SessionContext session, RecordingExporter exporter, ApplicationServices services)
    {
        Db = db;
        Clock = clock;
        Store = store;
        Session = session;
        Exporter = exporter;
        Services = services;
    }

    public SchoolDatabase Db { get; }

    public FakeClock Clock { get; }

    public InMemoryDataStore Store { get; }

    public SessionContext Session { get; }

    public RecordingExporter Exporter { get; }

    public ApplicationServices Services { get; }

    public static TestApp Create(SchoolDatabase db, DateOnly? today = null)
    {
        var clock = new FakeClock(today ?? Scenario.Today);
        var store = new InMemoryDataStore(db);
        var session = new SessionContext();
        var exporter = new RecordingExporter();
        var services = new ApplicationServices(new UnitOfWork(store, db), session, clock, new Pbkdf2PasswordHasher(), exporter, new NullBackups(), store.DataFilePath);
        return new TestApp(db, clock, store, session, exporter, services);
    }

    /// <summary>Starts a session directly (bypasses the password check).</summary>
    public TestApp LoginAs(Guid userId)
    {
        Session.Begin(Db.Users.Single(u => u.Id == userId));
        return this;
    }

    public sealed record Export(string Stem, IReadOnlyList<string> Headers, IReadOnlyList<string> Rows);

    /// <summary>Keeps the last export in memory (rows joined with ";") instead of writing a file.</summary>
    public sealed class RecordingExporter : IReportExporter
    {
        public Export? LastExport { get; private set; }

        public Exception? FailWith { get; set; }

        public string Export(string fileNameStem, IReadOnlyList<string> headers, IEnumerable<IReadOnlyList<string>> rows)
        {
            if (FailWith is not null)
            {
                throw FailWith;
            }

            LastExport = new Export(fileNameStem, headers, rows.Select(r => string.Join(";", r)).ToList());
            return fileNameStem + ".csv";
        }
    }

    private sealed class NullBackups : IBackupProvider
    {
        public IReadOnlyList<BackupInfo> GetBackups() => [];

        public void RestoreBackup(string backupFileName) => throw new DataStoreException("No backups in tests.");
    }
}
