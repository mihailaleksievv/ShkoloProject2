// Owner: Shared
using Shkolo.Domain;
using Shkolo.Infrastructure.Persistence;
using Shkolo.Infrastructure.Security;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens;

namespace Shkolo.Tests.TestSupport;

/// <summary>Runs the real start screen and navigator on a scripted console over the demo database.</summary>
public sealed class UiApp
{
    private static readonly Lazy<string> DemoJson = new(() =>
        System.Text.Json.JsonSerializer.Serialize(new DemoDataGenerator(new FakeClock(Scenario.Today), new Pbkdf2PasswordHasher()).Generate(), JsonOptions.Default));

    public UiApp(DateOnly? today = null)
    {
        Db = System.Text.Json.JsonSerializer.Deserialize<SchoolDatabase>(DemoJson.Value, JsonOptions.Default)!;
        App = TestApp.Create(Db, today ?? Scenario.Today);
        Console = new ScriptedConsole();
        Errors = [];
        Context = new ScreenContext(Console, App.Services, "memory://school-data.json", Errors.Add);
    }

    public SchoolDatabase Db { get; }

    public TestApp App { get; }

    public ScriptedConsole Console { get; }

    public List<Exception> Errors { get; }

    public ScreenContext Context { get; }

    /// <summary>Runs the whole application from the start screen until the script exits it.</summary>
    public UiApp Run()
    {
        new ScreenNavigator().Run(new StartScreen(), Context);
        return this;
    }

    /// <summary>Signs a demo user in directly and runs the command centre with the given workspace.</summary>
    public Shkolo.Presentation.Shell.ShellOutcome Shell(string username, Shkolo.Presentation.Shell.IWorkspace workspace)
    {
        App.LoginAs(Db.Users.Single(u => u.Username == username).Id);
        return new Shkolo.Presentation.Shell.AppShell().Run(Context, workspace);
    }

    /// <summary>Esc + "д": leave the command centre.</summary>
    public UiApp LeaveShell()
    {
        Console.Escape().Type("д");
        return this;
    }

    /// <summary>Start screen → "Вход" → credentials.</summary>
    public UiApp Login(string username, string password)
    {
        Console.Choose(0).Type(username).Type(password);
        return this;
    }
}
