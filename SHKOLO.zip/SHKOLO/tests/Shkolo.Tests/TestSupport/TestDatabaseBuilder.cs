// Owner: Shared
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Infrastructure.Security;

namespace Shkolo.Tests.TestSupport;

/// <summary>Fluent builder of small, consistent databases for service tests.</summary>
public sealed class TestDatabaseBuilder
{
    public const string Password = "Passw0rd!";

    // PBKDF2 is deliberately slow; hash the shared test password once per test run.
    private static readonly Lazy<(string Hash, string Salt)> PasswordHash = new(() => new Pbkdf2PasswordHasher().Hash(Password));

    private readonly SchoolDatabase _db = new() { SchoolName = "Тестово училище" };
    private Guid _yearId;

    public TestDatabaseBuilder WithActiveYear(DateOnly start, DateOnly firstTermEnd, DateOnly end)
    {
        var year = new AcademicYear { Name = $"{start.Year}/{end.Year}", StartDate = start, FirstTermEndDate = firstTermEnd, EndDate = end, IsActive = true };
        _db.AcademicYears.Add(year);
        _yearId = year.Id;
        return this;
    }

    public TestDatabaseBuilder WithBellSchedule()
    {
        var start = new TimeOnly(8, 0);
        for (var n = 1; n <= 7; n++)
        {
            _db.BellSchedule.Add(new LessonSlot { LessonNumber = n, StartTime = start, EndTime = start.AddMinutes(40) });
            start = start.AddMinutes(n == 3 ? 60 : 50);
        }

        return this;
    }

    public TestDatabaseBuilder WithAdmin(string username, out Guid userId)
    {
        userId = AddUser(username, "Администратор", UserRole.Administrator, null, null).Id;
        return this;
    }

    public TestDatabaseBuilder WithTeacher(string username, out Guid teacherId, out Guid userId, string firstName = "Учител", string lastName = "Тестов")
    {
        var teacher = new Teacher { EmployeeNumber = "T-" + username, FirstName = firstName, LastName = lastName, Email = username + "@school.bg" };
        _db.Teachers.Add(teacher);
        teacherId = teacher.Id;
        userId = AddUser(username, teacher.FullName, UserRole.Teacher, null, teacher.Id).Id;
        return this;
    }

    public TestDatabaseBuilder WithClass(int grade, string section, out Guid classId, Guid? classTeacherId = null)
    {
        var cls = new SchoolClass { GradeLevel = grade, Section = section, AcademicYearId = _yearId, ClassTeacherId = classTeacherId };
        _db.Classes.Add(cls);
        classId = cls.Id;
        return this;
    }

    public TestDatabaseBuilder WithSubject(string name, out Guid subjectId)
    {
        var subject = new Subject { Name = name };
        _db.Subjects.Add(subject);
        subjectId = subject.Id;
        return this;
    }

    public TestDatabaseBuilder WithAssignment(Guid teacherId, Guid classId, Guid subjectId)
    {
        _db.TeacherAssignments.Add(new TeacherAssignment { TeacherId = teacherId, ClassId = classId, SubjectId = subjectId });
        return this;
    }

    public TestDatabaseBuilder WithStudent(Guid classId, string number, out Guid studentId, out Guid userId, string firstName = "Ученик", string? lastName = null)
    {
        var student = new Student { StudentNumber = number, FirstName = firstName, LastName = lastName ?? "Номер" + number, ClassId = classId };
        _db.Students.Add(student);
        studentId = student.Id;
        userId = AddUser("s" + number, student.FullName, UserRole.Student, student.Id, null).Id;
        return this;
    }

    public TestDatabaseBuilder WithHeldLesson(Guid classId, Guid subjectId, Guid teacherId, DateOnly date, int lessonNumber, out Guid lessonId)
    {
        var lesson = new Lesson { ClassId = classId, SubjectId = subjectId, TeacherId = teacherId, Date = date, LessonNumber = lessonNumber, Topic = "Тема " + lessonNumber };
        _db.Lessons.Add(lesson);
        lessonId = lesson.Id;
        return this;
    }

    public SchoolDatabase Build() => _db;

    private User AddUser(string username, string displayName, UserRole role, Guid? studentId, Guid? teacherId)
    {
        var (hash, salt) = PasswordHash.Value;
        var user = new User
        {
            Username = username,
            DisplayName = displayName,
            Role = role,
            StudentId = studentId,
            TeacherId = teacherId,
            PasswordHash = hash,
            PasswordSalt = salt,
        };
        _db.Users.Add(user);
        return user;
    }
}
