// Owner: Shared
using System.Text;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Tests.TestSupport;

/// <summary>
/// Interactive Spectre console driven by a scripted sequence of key presses.
/// Lets tests run real screens end-to-end: prompts, menus and forms behave exactly as for a user.
/// </summary>
public sealed class ScriptedConsole : IAnsiConsole
{
    private readonly IAnsiConsole _inner;
    private readonly StringWriter _output = new();
    private readonly ScriptedInput _input = new();

    public ScriptedConsole()
    {
        _inner = AnsiConsole.Create(new AnsiConsoleSettings
        {
            Out = new AnsiConsoleOutput(_output),
            Ansi = AnsiSupport.Yes,
            ColorSystem = ColorSystemSupport.NoColors,
            Interactive = InteractionSupport.Yes,
        });
        _inner.Profile.Width = 200;
        _inner.Profile.Height = 60;
    }

    public string Output => _output.ToString();

    public Profile Profile => _inner.Profile;

    public IAnsiConsoleCursor Cursor => _inner.Cursor;

    public IAnsiConsoleInput Input => _input;

    public IExclusivityMode ExclusivityMode => _inner.ExclusivityMode;

    public RenderPipeline Pipeline => _inner.Pipeline;

    public int RemainingKeys => _input.Remaining;

    public void Clear(bool home) => _output.WriteLine("<<CLEAR>>");

    public void Write(IRenderable renderable) => _inner.Write(renderable);

    public void WriteAnsi(Action<AnsiWriter> action) => _inner.WriteAnsi(action);

    /// <summary>Types text followed by Enter (for text prompts).</summary>
    public ScriptedConsole Type(string text)
    {
        foreach (var c in text)
        {
            _input.Push(new ConsoleKeyInfo(c, ConsoleKey.NoName, false, false, false));
        }

        return Enter();
    }

    /// <summary>Moves down <paramref name="index"/> items in a selection prompt and confirms.</summary>
    public ScriptedConsole Choose(int index)
    {
        for (var i = 0; i < index; i++)
        {
            _input.Push(new ConsoleKeyInfo('\0', ConsoleKey.DownArrow, false, false, false));
        }

        return Enter();
    }

    /// <summary>Types a search filter in a searchable selection prompt and confirms the first match.</summary>
    public ScriptedConsole Search(string text)
    {
        foreach (var c in text)
        {
            _input.Push(new ConsoleKeyInfo(c, ConsoleKey.NoName, false, false, false));
        }

        return Enter();
    }

    /// <summary>Toggles items of a multi-selection prompt by index (0-based, in order) and confirms.</summary>
    public ScriptedConsole MultiSelect(params int[] indexes)
    {
        var position = 0;
        foreach (var index in indexes.Order())
        {
            for (; position < index; position++)
            {
                _input.Push(new ConsoleKeyInfo('\0', ConsoleKey.DownArrow, false, false, false));
            }

            _input.Push(new ConsoleKeyInfo(' ', ConsoleKey.Spacebar, false, false, false));
        }

        return Enter();
    }

    /// <summary>A single key press (Tab, Escape, arrows …).</summary>
    public ScriptedConsole Press(ConsoleKey key, char ch = '\0', bool shift = false)
    {
        _input.Push(new ConsoleKeyInfo(ch, key, shift, false, false));
        return this;
    }

    /// <summary>Characters typed without a final Enter (hotkeys, digits, palette search).</summary>
    public ScriptedConsole Keys(string chars)
    {
        foreach (var c in chars)
        {
            _input.Push(new ConsoleKeyInfo(c, char.IsDigit(c) ? ConsoleKey.D0 + (c - '0') : ConsoleKey.NoName, false, false, false));
        }

        return this;
    }

    public ScriptedConsole Escape() => Press(ConsoleKey.Escape, '\u001b');

    public ScriptedConsole Tab(bool shift = false) => Press(ConsoleKey.Tab, '\t', shift);

    public ScriptedConsole Down() => Press(ConsoleKey.DownArrow);

    public ScriptedConsole Enter()
    {
        _input.Push(new ConsoleKeyInfo('\r', ConsoleKey.Enter, false, false, false));
        return this;
    }

    /// <summary>Any key (for "press a key to continue").</summary>
    public ScriptedConsole Key() => Enter();

    private sealed class ScriptedInput : IAnsiConsoleInput
    {
        private readonly Queue<ConsoleKeyInfo> _keys = new();

        public int Remaining => _keys.Count;

        public void Push(ConsoleKeyInfo key) => _keys.Enqueue(key);

        public bool IsKeyAvailable() => _keys.Count > 0;

        public ConsoleKeyInfo? ReadKey(bool intercept)
            => _keys.Count > 0 ? _keys.Dequeue() : throw new ScriptExhaustedException();

        public Task<ConsoleKeyInfo?> ReadKeyAsync(bool intercept, CancellationToken cancellationToken)
            => Task.FromResult(ReadKey(intercept));
    }
}

/// <summary>Thrown when a screen asks for more input than the test scripted – the test script is incomplete.</summary>
public sealed class ScriptExhaustedException() : Exception("The scripted console ran out of keys.");
