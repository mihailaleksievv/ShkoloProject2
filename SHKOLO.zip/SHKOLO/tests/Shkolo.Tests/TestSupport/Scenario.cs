// Owner: Shared
using Shkolo.Domain;

namespace Shkolo.Tests.TestSupport;

/// <summary>
/// Standard fixture: year 15.09.2026–31.01.2027–30.06.2027.
/// Math teacher teaches Math in 10A. BEL teacher teaches BEL in 10B and is class teacher of 10B.
/// Student1 and Student2 are in 10A, Student3 in 10B.
/// </summary>
public sealed record StandardScenario(
    SchoolDatabase Db,
    Guid AdminUser,
    Guid MathTeacher,
    Guid MathTeacherUser,
    Guid BelTeacher,
    Guid BelTeacherUser,
    Guid Class10A,
    Guid Class10B,
    Guid Math,
    Guid Bel,
    Guid Student1,
    Guid Student1User,
    Guid Student2,
    Guid Student2User,
    Guid Student3,
    Guid Student3User,
    Guid YearId);

public static class Scenario
{
    /// <summary>Friday 20.11.2026 – inside the first term.</summary>
    public static readonly DateOnly Today = new(2026, 11, 20);

    public static StandardScenario Standard()
    {
        var builder = new TestDatabaseBuilder()
            .WithActiveYear(new DateOnly(2026, 9, 15), new DateOnly(2027, 1, 31), new DateOnly(2027, 6, 30))
            .WithBellSchedule()
            .WithAdmin("admin", out var admin)
            .WithTeacher("math", out var mathTeacher, out var mathUser, "Мария", "Иванова")
            .WithTeacher("bel", out var belTeacher, out var belUser, "Петър", "Петров")
            .WithClass(10, "А", out var c10A)
            .WithClass(10, "Б", out var c10B, belTeacher)
            .WithSubject("Математика", out var math)
            .WithSubject("Български език и литература", out var bel)
            .WithAssignment(mathTeacher, c10A, math)
            .WithAssignment(belTeacher, c10B, bel)
            .WithStudent(c10A, "1001", out var s1, out var s1User, "Иван", "Петров")
            .WithStudent(c10A, "1002", out var s2, out var s2User, "Елена", "Георгиева")
            .WithStudent(c10B, "1003", out var s3, out var s3User, "Никола", "Димитров");
        var db = builder.Build();
        return new StandardScenario(db, admin, mathTeacher, mathUser, belTeacher, belUser, c10A, c10B, math, bel,
            s1, s1User, s2, s2User, s3, s3User, db.AcademicYears[0].Id);
    }
}
