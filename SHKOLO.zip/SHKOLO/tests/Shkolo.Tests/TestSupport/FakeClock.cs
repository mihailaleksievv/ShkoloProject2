// Owner: Shared
using Shkolo.Application.Abstractions;

namespace Shkolo.Tests.TestSupport;

/// <summary>Deterministic clock. Local time is treated as UTC to keep tests simple.</summary>
public sealed class FakeClock : IClock
{
    public FakeClock(DateOnly today, int hour = 10)
    {
        LocalNow = today.ToDateTime(new TimeOnly(hour, 0));
    }

    public DateTime LocalNow { get; set; }

    public DateTime UtcNow => DateTime.SpecifyKind(LocalNow, DateTimeKind.Utc);

    public DateOnly Today => DateOnly.FromDateTime(LocalNow);

    public void Advance(TimeSpan by) => LocalNow = LocalNow.Add(by);

    public void SetToday(DateOnly today) => LocalNow = today.ToDateTime(TimeOnly.FromDateTime(LocalNow));
}
