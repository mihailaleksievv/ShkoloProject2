// Owner: Shared
using Shkolo.Application.Abstractions;
using Shkolo.Domain;

namespace Shkolo.Tests.TestSupport;

/// <summary>Data store whose every save fails, used to prove rollback.</summary>
public sealed class FailingDataStore : IDataStore
{
    public string DataFilePath => "failing://school-data.json";

    public LoadResult Load() => new(LoadStatus.Loaded, new SchoolDatabase(), null, []);

    public void Save(SchoolDatabase database) => throw new DataStoreException("Disk full");
}
