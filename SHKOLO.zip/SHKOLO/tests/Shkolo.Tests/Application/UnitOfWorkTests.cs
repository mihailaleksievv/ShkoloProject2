// Owner: Shared
using System.Text.Json;
using Shkolo.Application;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Infrastructure.Persistence;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Application;

public class UnitOfWorkTests
{
    private static SchoolDatabase Db()
    {
        var db = new SchoolDatabase();
        db.Subjects.Add(new Subject { Name = "Математика" });
        return db;
    }

    [Fact]
    public void Successful_mutation_is_saved_once_and_visible()
    {
        var store = new InMemoryDataStore();
        var uow = new UnitOfWork(store, Db());

        var result = uow.Execute(db =>
        {
            db.Subjects.Add(new Subject { Name = "История" });
            return OperationResult.Ok();
        });

        Assert.True(result.Success);
        Assert.Equal(1, store.SaveCount);
        Assert.Equal(2, uow.Database.Subjects.Count);
    }

    [Fact]
    public void Failed_mutation_is_rolled_back_and_not_saved()
    {
        var store = new InMemoryDataStore();
        var uow = new UnitOfWork(store, Db());
        var original = uow.Database;

        var result = uow.Execute(db =>
        {
            db.Subjects.Add(new Subject { Name = "История" });
            db.Subjects[0].Name = "Променено";
            return OperationResult.Validation(ErrorCodes.InvalidInput, "грешка");
        });

        Assert.False(result.Success);
        Assert.Equal(0, store.SaveCount);
        Assert.Same(original, uow.Database);
        Assert.Single(uow.Database.Subjects);
        Assert.Equal("Математика", uow.Database.Subjects[0].Name);
    }

    [Fact]
    public void Save_failure_is_persistence_error_and_rolled_back()
    {
        var uow = new UnitOfWork(new FailingDataStore(), Db());

        var result = uow.Execute(db =>
        {
            db.Subjects.Add(new Subject { Name = "История" });
            return OperationResult.Ok();
        });

        Assert.Equal(ErrorKind.Persistence, result.Error!.Kind);
        Assert.Contains("Disk full", result.Error.Message);
        Assert.Single(uow.Database.Subjects);
    }

    [Fact]
    public void Exception_inside_mutation_rolls_back_and_rethrows()
    {
        var uow = new UnitOfWork(new InMemoryDataStore(), Db());

        Assert.Throws<InvalidOperationException>(() => uow.Execute(db =>
        {
            db.Subjects.Clear();
            throw new InvalidOperationException("bug");
        }));

        Assert.Single(uow.Database.Subjects);
    }

    [Fact]
    public void Read_only_refuses_without_running_mutation()
    {
        var store = new InMemoryDataStore();
        var uow = new UnitOfWork(store, Db(), isReadOnly: true);
        var ran = false;

        var result = uow.Execute(_ =>
        {
            ran = true;
            return OperationResult.Ok();
        });

        Assert.False(ran);
        Assert.Equal(ErrorCodes.ReadOnlyDatabase, result.Error!.Code);
        Assert.Equal(0, store.SaveCount);
    }

    [Fact]
    public void Generic_execute_returns_value()
    {
        var uow = new UnitOfWork(new InMemoryDataStore(), Db());
        var result = uow.Execute(db => OperationResult<int>.Ok(db.Subjects.Count));
        Assert.Equal(1, result.Value);
    }

    [Fact]
    public void Snapshot_round_trip_is_lossless()
    {
        var db = Db();
        var id = Guid.NewGuid();
        db.SchoolName = "ПГ";
        db.BellSchedule.Add(new LessonSlot { LessonNumber = 1, StartTime = new TimeOnly(8, 0), EndTime = new TimeOnly(8, 40) });
        db.Grades.Add(new Grade { StudentId = id, Value = 5.25m, GradeType = GradeType.Homework, Date = new DateOnly(2026, 10, 1), Comment = "к", UpdatedAtUtc = DateTime.UtcNow });
        db.AttendanceRecords.Add(new AttendanceRecord { Status = AttendanceStatus.ExcusedAbsent });
        db.Users.Add(new User { Username = "u", Role = UserRole.Teacher, TeacherId = id });
        db.SchoolEvents.Add(new SchoolEvent { StartDateTime = new DateTime(2026, 12, 1, 9, 30, 0) });
        var before = JsonSerializer.Serialize(db, JsonOptions.Default);
        var uow = new UnitOfWork(new InMemoryDataStore(), db);

        uow.Execute(d =>
        {
            d.Grades.Clear();
            d.Users.Clear();
            d.SchoolName = "x";
            d.BellSchedule.Clear();
            d.SchoolEvents[0].StartDateTime = DateTime.MinValue;
            return OperationResult.Validation(ErrorCodes.InvalidInput, "rollback");
        });

        Assert.Equal(before, JsonSerializer.Serialize(uow.Database, JsonOptions.Default));
    }
}
