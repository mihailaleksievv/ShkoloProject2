// Owner: Shared
using Shkolo.Application.Results;

namespace Shkolo.Tests.Application;

public class OperationResultTests
{
    [Fact]
    public void Ok_is_success_without_error()
    {
        var result = OperationResult.Ok();
        Assert.True(result.Success);
        Assert.Null(result.Error);
    }

    [Fact]
    public void Validation_carries_kind_code_and_message()
    {
        var result = OperationResult.Validation("X", "m");
        Assert.False(result.Success);
        Assert.Equal(ErrorKind.Validation, result.Error!.Kind);
        Assert.Equal("X", result.Error.Code);
        Assert.Equal("m", result.Error.Message);
    }

    [Fact]
    public void Generic_ok_carries_value()
        => Assert.Equal(5, OperationResult<int>.Ok(5).Value);

    [Fact]
    public void Generic_fail_from_error_propagates()
    {
        var failed = OperationResult.Forbidden("нямате права");
        var typed = OperationResult<int>.Fail(failed.Error!);
        Assert.False(typed.Success);
        Assert.Equal(ErrorKind.Forbidden, typed.Error!.Kind);
        Assert.Equal(ErrorCodes.Forbidden, typed.Error.Code);
    }

    [Fact]
    public void Persistence_uses_persistence_code()
        => Assert.Equal(ErrorCodes.PersistenceFailed, OperationResult.Persistence("x").Error!.Code);
}
