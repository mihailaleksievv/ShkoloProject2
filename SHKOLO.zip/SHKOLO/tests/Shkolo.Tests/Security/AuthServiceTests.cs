// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Security;

public class AuthServiceTests
{
    private const string Pw = TestDatabaseBuilder.Password;

    [Fact]
    public void Correct_credentials_start_session()
    {
        var s = Scenario.Standard();
        var app = TestApp.Create(s.Db);

        var result = app.Services.Auth.Login("math", Pw);

        Assert.True(result.Success);
        Assert.True(app.Session.IsAuthenticated);
        Assert.Equal(UserRole.Teacher, app.Session.Role);
        Assert.Equal(s.MathTeacher, app.Session.TeacherId);
        Assert.Equal(app.Clock.UtcNow, s.Db.Users.Single(u => u.Id == s.MathTeacherUser).LastLoginAtUtc);
        Assert.Contains(s.Db.AuditLog, a => a.Action == "Auth.Login");
    }

    [Fact]
    public void Username_is_case_insensitive_and_trimmed()
    {
        var app = TestApp.Create(Scenario.Standard().Db);
        Assert.True(app.Services.Auth.Login("  MATH ", Pw).Success);
    }

    [Fact]
    public void All_failures_return_identical_message()
    {
        var s = Scenario.Standard();
        s.Db.Users.Single(u => u.Username == "bel").IsActive = false;
        s.Db.Students.Single(x => x.Id == s.Student1).IsActive = false;
        var app = TestApp.Create(s.Db);

        var failures = new[]
        {
            app.Services.Auth.Login("math", "wrong"),
            app.Services.Auth.Login("nobody", Pw),
            app.Services.Auth.Login("bel", Pw),
            app.Services.Auth.Login("s1001", Pw),
            app.Services.Auth.Login("", ""),
        };

        Assert.All(failures, f =>
        {
            Assert.False(f.Success);
            Assert.Equal(ErrorCodes.InvalidCredentials, f.Error!.Code);
            Assert.Equal("Невалидно потребителско име или парола.", f.Error.Message);
        });
        Assert.False(app.Session.IsAuthenticated);
    }

    [Fact]
    public void Failed_login_is_audited_without_password()
    {
        var s = Scenario.Standard();
        var app = TestApp.Create(s.Db);

        app.Services.Auth.Login("math", "Secret123!");
        app.Services.Auth.Login("math", Pw);

        Assert.Contains(s.Db.AuditLog, a => a.Action == "Auth.LoginFailed");
        Assert.DoesNotContain(s.Db.AuditLog, a => a.Summary.Contains("Secret123!") || a.Summary.Contains(Pw));
    }

    [Fact]
    public void Logout_clears_session()
    {
        var app = TestApp.Create(Scenario.Standard().Db);
        app.Services.Auth.Login("admin", Pw);

        app.Services.Auth.Logout();

        Assert.False(app.Session.IsAuthenticated);
        Assert.Null(app.Session.CurrentUser);
    }

    [Fact]
    public void Change_password_requires_correct_current_password()
    {
        var s = Scenario.Standard();
        var app = TestApp.Create(s.Db).LoginAs(s.Student1User);

        Assert.Equal(ErrorCodes.InvalidCredentials, app.Services.Auth.ChangePassword("bad", "NewPass123").Error!.Code);
        Assert.Equal(ErrorCodes.InvalidInput, app.Services.Auth.ChangePassword(Pw, "short1").Error!.Code);
        Assert.Equal(ErrorCodes.InvalidInput, app.Services.Auth.ChangePassword(Pw, "onlyletters").Error!.Code);
        Assert.True(app.Services.Auth.ChangePassword(Pw, "NewPass123").Success);

        app.Services.Auth.Logout();
        Assert.True(app.Services.Auth.Login("s1001", "NewPass123").Success);
    }

    [Fact]
    public void Create_account_requires_admin()
    {
        var s = Scenario.Standard();
        var app = TestApp.Create(s.Db).LoginAs(s.MathTeacherUser);

        var result = app.Services.Auth.CreateAccount(new AccountInput("new", "Нов", "Passw0rd!", UserRole.Administrator, null, null));

        Assert.Equal(ErrorKind.Forbidden, result.Error!.Kind);
    }

    [Fact]
    public void Create_account_rejects_duplicate_username_ignoring_case()
    {
        var s = Scenario.Standard();
        var app = TestApp.Create(s.Db).LoginAs(s.AdminUser);

        var result = app.Services.Auth.CreateAccount(new AccountInput("ADMIN", "Друг", "Passw0rd!", UserRole.Administrator, null, null));

        Assert.Equal(ErrorCodes.DuplicateUsername, result.Error!.Code);
    }

    [Fact]
    public void Create_account_requires_matching_profile_and_one_account_per_profile()
    {
        var s = Scenario.Standard();
        var app = TestApp.Create(s.Db).LoginAs(s.AdminUser);

        Assert.False(app.Services.Auth.CreateAccount(new AccountInput("x1", "X", "Passw0rd!", UserRole.Student, null, null)).Success);
        Assert.False(app.Services.Auth.CreateAccount(new AccountInput("x2", "X", "Passw0rd!", UserRole.Student, s.Student1, null)).Success);
        Assert.False(app.Services.Auth.CreateAccount(new AccountInput("x3", "X", "Passw0rd!", UserRole.Teacher, Guid.NewGuid(), null)).Success);
    }

    [Fact]
    public void Created_account_can_log_in_and_password_is_hashed()
    {
        var s = Scenario.Standard();
        var app = TestApp.Create(s.Db).LoginAs(s.AdminUser);

        var created = app.Services.Auth.CreateAccount(new AccountInput("admin2", "Втори админ", "Second123", UserRole.Administrator, null, null));

        Assert.True(created.Success);
        Assert.NotEqual("Second123", created.Value!.PasswordHash);
        app.Services.Auth.Logout();
        Assert.True(app.Services.Auth.Login("admin2", "Second123").Success);
    }

    [Fact]
    public void Admin_cannot_deactivate_self_but_can_deactivate_others()
    {
        var s = Scenario.Standard();
        var app = TestApp.Create(s.Db).LoginAs(s.AdminUser);

        Assert.False(app.Services.Auth.SetUserActive(s.AdminUser, false).Success);
        Assert.True(app.Services.Auth.SetUserActive(s.MathTeacherUser, false).Success);
        app.Services.Auth.Logout();
        Assert.False(app.Services.Auth.Login("math", Pw).Success);
    }

    [Fact]
    public void Admin_can_reset_password()
    {
        var s = Scenario.Standard();
        var app = TestApp.Create(s.Db).LoginAs(s.AdminUser);

        Assert.True(app.Services.Auth.ResetPassword(s.Student3User, "Reset1234").Success);
        app.Services.Auth.Logout();
        Assert.True(app.Services.Auth.Login("s1003", "Reset1234").Success);
    }
}
