// Owner: Shared
using Shkolo.Infrastructure.Security;

namespace Shkolo.Tests.Security;

public class PasswordHasherTests
{
    private readonly Pbkdf2PasswordHasher _hasher = new();

    [Fact]
    public void Verify_correct_password_true()
    {
        var (hash, salt) = _hasher.Hash("Passw0rd!");
        Assert.True(_hasher.Verify("Passw0rd!", hash, salt));
    }

    [Fact]
    public void Verify_wrong_password_false()
    {
        var (hash, salt) = _hasher.Hash("Passw0rd!");
        Assert.False(_hasher.Verify("passw0rd!", hash, salt));
    }

    [Fact]
    public void Same_password_gets_different_salt_and_hash()
    {
        var a = _hasher.Hash("Passw0rd!");
        var b = _hasher.Hash("Passw0rd!");
        Assert.NotEqual(a.Salt, b.Salt);
        Assert.NotEqual(a.Hash, b.Hash);
    }

    [Fact]
    public void Verify_with_malformed_hash_is_false_not_exception()
        => Assert.False(_hasher.Verify("x", "not-base64!", "also-not"));
}
