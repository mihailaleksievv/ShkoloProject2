// Owner: Shared
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Security;

/// <summary>
/// The access table of the specification (§5.2), enforced in the service layer.
/// Teacher = math teacher acting on 10А/Математика; Student = student1 of 10А.
/// Every row runs for all three roles against a fresh database.
/// </summary>
public class AccessMatrixTests
{
    private static readonly Dictionary<string, Func<TestApp, StandardScenario, OperationResult>> Actions = new()
    {
        ["ListAllStudents"] = (a, s) => a.Services.Students.GetAllStudents(),
        ["ChangeOwnPassword"] = (a, s) => a.Services.Auth.ChangePassword(TestDatabaseBuilder.Password, "NewPass123"),
        ["AddStudent"] = (a, s) => a.Services.Students.AddStudent(new StudentInput("9999", "Нов", "Ученик", s.Class10A, null)),
        ["ViewStudentOfOtherClass"] = (a, s) => a.Services.Students.GetStudentById(s.Student3),
        ["ManageTeachers"] = (a, s) => a.Services.Teachers.Add(new TeacherInput("T-NEW", "Нов", "Учител", "new@school.bg")),
        ["ManageClasses"] = (a, s) => a.Services.Classes.Create(new ClassInput(11, "А", s.YearId, null)),
        ["ManageSubjects"] = (a, s) => a.Services.Subjects.Add(new SubjectInput("Химия", null)),
        ["ManageAssignments"] = (a, s) => a.Services.Assignments.Assign(s.MathTeacher, s.Class10B, s.Math),
        ["TimetableAdd"] = (a, s) => a.Services.Timetable.AddEntry(new TimetableEntryInput(s.Class10A, s.Math, s.MathTeacher, DayOfWeek.Monday, 1, null)),
        ["CreateLesson"] = (a, s) => a.Services.Lessons.CreateLesson(new LessonInput(s.Class10A, s.Math, Scenario.Today, 1, "Тема", null)),
        ["AddGrade"] = (a, s) => a.Services.Grades.AddGrade(new GradeInput(s.Student1, s.Math, 5m, Scenario.Today, GradeType.Oral, null)),
        ["EditOthersGrade"] = (a, s) => a.Services.Grades.UpdateGrade(SeedForeignGrade(s), new GradeUpdate(3m, GradeType.Oral, null)),
        ["ViewAttendanceByPeriod"] = (a, s) => a.Services.Attendance.GetAttendanceByPeriod(Scenario.Today.AddDays(-30), Scenario.Today),
        ["ViewOwnAttendance"] = (a, s) => a.Services.Attendance.GetAttendanceForStudent(s.Student1),
        ["CreateHomework"] = (a, s) => a.Services.Homework.CreateHomework(new HomeworkInput(s.Class10A, s.Math, "Задачи", "", Scenario.Today, Scenario.Today.AddDays(3))),
        ["ViewClassHomework"] = (a, s) => a.Services.Homework.GetHomeworkForClass(s.Class10A),
        ["AddFeedback"] = (a, s) => a.Services.Feedback.AddPraise(s.Student1, "Браво", Scenario.Today),
        ["PublishClassAnnouncement"] = (a, s) => a.Services.Announcements.Publish(new AnnouncementInput("Съобщение", "Текст", s.Class10A)),
        ["SchoolStatistics"] = (a, s) => a.Services.Reports.GetSchoolStatistics(),
        ["Student1Report"] = (a, s) => a.Services.Reports.GenerateStudentReport(s.Student1),
        ["Student2Report"] = (a, s) => a.Services.Reports.GenerateStudentReport(s.Student2),
        ["ClassReport10A"] = (a, s) => a.Services.Reports.GenerateClassReport(s.Class10A),
        ["AuditLog"] = (a, s) => a.Services.Audit.GetRecent(10),
        ["StorageInfo"] = (a, s) => a.Services.System.GetStorageInfo(),
        ["ManageUsers"] = (a, s) => a.Services.Auth.GetUsers(),
    };

    public static TheoryData<string, UserRole, bool> Matrix()
    {
        var data = new TheoryData<string, UserRole, bool>();
        void Row(string action, bool admin, bool teacher, bool student)
        {
            data.Add(action, UserRole.Administrator, admin);
            data.Add(action, UserRole.Teacher, teacher);
            data.Add(action, UserRole.Student, student);
        }

        Row("ListAllStudents", true, true, false);
        Row("ChangeOwnPassword", true, true, true);
        Row("AddStudent", true, false, false);
        Row("ViewStudentOfOtherClass", true, false, false);
        Row("ManageTeachers", true, false, false);
        Row("ManageClasses", true, false, false);
        Row("ManageSubjects", true, false, false);
        Row("ManageAssignments", true, false, false);
        Row("TimetableAdd", true, false, false);
        Row("CreateLesson", false, true, false);
        Row("AddGrade", false, true, false);
        Row("EditOthersGrade", false, false, false);
        Row("ViewAttendanceByPeriod", true, true, false);
        Row("ViewOwnAttendance", true, true, true);
        Row("CreateHomework", false, true, false);
        Row("ViewClassHomework", true, true, true);
        Row("AddFeedback", false, true, false);
        Row("PublishClassAnnouncement", true, true, false);
        Row("SchoolStatistics", true, true, false);
        Row("Student1Report", true, true, true);
        Row("Student2Report", true, true, false);
        Row("ClassReport10A", true, true, false);
        Row("AuditLog", true, false, false);
        Row("StorageInfo", true, false, false);
        Row("ManageUsers", true, false, false);
        return data;
    }

    [Theory]
    [MemberData(nameof(Matrix))]
    public void Access_matches_specification(string action, UserRole role, bool allowed)
    {
        var s = Scenario.Standard();
        var user = role switch
        {
            UserRole.Administrator => s.AdminUser,
            UserRole.Teacher => s.MathTeacherUser,
            _ => s.Student1User,
        };
        var app = TestApp.Create(s.Db).LoginAs(user);

        var result = Actions[action](app, s);

        if (allowed)
        {
            Assert.True(result.Success, $"{action} as {role} should be allowed but failed: {result.Error?.Code} {result.Error?.Message}");
        }
        else
        {
            Assert.False(result.Success, $"{action} as {role} should be refused.");
            Assert.Equal(ErrorKind.Forbidden, result.Error!.Kind);
        }
    }

    [Fact]
    public void Every_action_is_covered_by_the_matrix()
        => Assert.Equal(Actions.Keys.OrderBy(k => k), Matrix().Select(r => (string)r[0]).Distinct().OrderBy(k => k));

    /// <summary>A grade given by the BEL teacher in 10А (so the math teacher is not its author).</summary>
    private static Guid SeedForeignGrade(StandardScenario s)
    {
        var grade = new Grade { StudentId = s.Student1, ClassId = s.Class10A, SubjectId = s.Math, TeacherId = s.BelTeacher, Value = 5m, Date = Scenario.Today };
        s.Db.Grades.Add(grade);
        return grade.Id;
    }
}
