// Owner: Shared
using Shkolo.Application.Results;
using Shkolo.Tests.TestSupport;

namespace Shkolo.Tests.Security;

public class AuthorizationServiceTests
{
    private readonly StandardScenario _s = Scenario.Standard();

    private TestApp As(Guid userId) => TestApp.Create(_s.Db).LoginAs(userId);

    [Fact]
    public void Teaching_assignment_is_required_for_class_and_subject()
    {
        var authz = As(_s.MathTeacherUser).Services.Authorization;

        Assert.True(authz.RequireTeachingAssignment(_s.Class10A, _s.Math).Success);
        Assert.Equal(ErrorCodes.NoAssignment, authz.RequireTeachingAssignment(_s.Class10A, _s.Bel).Error!.Code);
        Assert.Equal(ErrorKind.Forbidden, authz.RequireTeachingAssignment(_s.Class10B, _s.Math).Error!.Kind);
    }

    [Fact]
    public void Admin_has_no_teaching_assignment()
        => Assert.Equal(ErrorKind.Forbidden, As(_s.AdminUser).Services.Authorization.RequireTeachingAssignment(_s.Class10A, _s.Math).Error!.Kind);

    [Fact]
    public void Class_teacher_is_recognised_and_counts_as_teaching_the_class()
    {
        var authz = As(_s.BelTeacherUser).Services.Authorization;
        Assert.True(authz.IsClassTeacherOf(_s.Class10B));
        Assert.False(authz.IsClassTeacherOf(_s.Class10A));
        Assert.Equal(new[] { _s.Class10B }, authz.TaughtClassIds().ToArray());
    }

    [Fact]
    public void Student_can_view_only_self()
    {
        var authz = As(_s.Student1User).Services.Authorization;
        Assert.True(authz.RequireCanViewStudent(_s.Student1).Success);
        Assert.Equal(ErrorKind.Forbidden, authz.RequireCanViewStudent(_s.Student2).Error!.Kind);
        Assert.True(authz.RequireCanViewClass(_s.Class10A).Success);
        Assert.False(authz.RequireCanViewClass(_s.Class10B).Success);
    }

    [Fact]
    public void Teacher_can_view_only_students_of_taught_classes()
    {
        var authz = As(_s.MathTeacherUser).Services.Authorization;
        Assert.True(authz.RequireCanViewStudent(_s.Student1).Success);
        Assert.Equal(ErrorKind.Forbidden, authz.RequireCanViewStudent(_s.Student3).Error!.Kind);
    }

    [Fact]
    public void Admin_can_view_everything()
    {
        var authz = As(_s.AdminUser).Services.Authorization;
        Assert.True(authz.RequireAdmin().Success);
        Assert.True(authz.RequireCanViewStudent(_s.Student3).Success);
        Assert.True(authz.RequireCanViewClass(_s.Class10B).Success);
    }

    [Fact]
    public void Anonymous_is_not_authenticated()
    {
        var authz = TestApp.Create(_s.Db).Services.Authorization;
        Assert.Equal(ErrorCodes.NotAuthenticated, authz.RequireAuthenticated().Error!.Code);
        Assert.Equal(ErrorCodes.NotAuthenticated, authz.RequireAdmin().Error!.Code);
    }

    [Fact]
    public void Non_admin_fails_require_admin()
        => Assert.Equal(ErrorKind.Forbidden, As(_s.MathTeacherUser).Services.Authorization.RequireAdmin().Error!.Kind);
}
