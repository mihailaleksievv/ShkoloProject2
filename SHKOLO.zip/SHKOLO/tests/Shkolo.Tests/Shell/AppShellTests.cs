﻿// Owner: Shared
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Shell;
using Shkolo.Tests.TestSupport;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Tests.Shell;

public class AppShellTests
{
    private sealed class FakeSection(string title, params SectionAction[] actions) : ISection
    {
        public string Title => title;

        public string Icon => "◆";

        public int Loads { get; private set; }

        public IReadOnlyList<SectionAction> Actions => actions;

        public void Load(ScreenContext ctx) => Loads++;

        public IRenderable Render(ScreenContext ctx, ShellFrame frame) => new Markup($"{Markup.Escape(title)} съдържание {Loads}");
    }

    private sealed class FakeWorkspace(params ISection[] sections) : IWorkspace
    {
        public string Name => "Тест";

        public IReadOnlyList<ISection> Sections(ScreenContext ctx) => sections;
    }

    private sealed class LogoutScreen : IScreen
    {
        public string Title => "Вложен";

        public ScreenResult Show(ScreenContext ctx) => ScreenResult.Logout;
    }

    private readonly List<string> _runs = [];

    private SectionAction Act(string label, char? hotkey = null) => new(label, hotkey, _ =>
    {
        _runs.Add(label);
        return ShellOutcome.Stay;
    });

    private static UiApp Teacher()
    {
        var ui = new UiApp();
        ui.App.LoginAs(ui.Db.Users.Single(u => u.Username == "teacher1").Id);
        return ui;
    }

    private static ShellOutcome Run(UiApp ui, IWorkspace ws) => new AppShell().Run(ui.Context, ws);

    private static void Logout(UiApp ui) => ui.Console.Escape().Type("д");

    [Fact]
    public void Number_key_switches_section()
    {
        var ui = Teacher();
        var second = new FakeSection("Втори");
        ui.Console.Keys("2");
        Logout(ui);

        Assert.Equal(ShellOutcome.Logout, Run(ui, new FakeWorkspace(new FakeSection("Първи"), second)));
        Assert.Contains("Втори съдържание 1", ui.Console.Output);
        Assert.Equal(1, second.Loads);
    }

    [Fact]
    public void Tab_cycles_and_wraps()
    {
        var ui = Teacher();
        var first = new FakeSection("Първи");
        ui.Console.Tab().Tab().Tab();
        Logout(ui);

        Run(ui, new FakeWorkspace(first, new FakeSection("Втори"), new FakeSection("Трети")));

        Assert.Equal(2, first.Loads);
    }

    [Fact]
    public void Arrow_and_enter_runs_selected_action()
    {
        var ui = Teacher();
        ui.Console.Enter().Down().Enter().Escape();   // Enter focuses the actions, ↓ selects А2, Enter runs it, Esc back to the menu
        Logout(ui);

        Run(ui, new FakeWorkspace(new FakeSection("Първи", Act("А1"), Act("А2"))));

        Assert.Equal(["А2"], _runs);
    }

    [Fact]
    public void Right_and_left_move_between_menu_and_actions()
    {
        var ui = Teacher();
        var second = new FakeSection("Втори");
        ui.Console.Press(ConsoleKey.RightArrow)   // into the actions
            .Press(ConsoleKey.RightArrow)         // А2
            .Press(ConsoleKey.LeftArrow)          // А1
            .Press(ConsoleKey.LeftArrow)          // back to the menu
            .Down();                              // next section
        Logout(ui);

        Assert.Equal(ShellOutcome.Logout, Run(ui, new FakeWorkspace(new FakeSection("Първи", Act("А1"), Act("А2")), second)));
        Assert.Equal(1, second.Loads);
        Assert.Empty(_runs);
    }

    [Fact]
    public void Escape_in_actions_returns_to_the_menu_instead_of_logging_out()
    {
        var ui = Teacher();
        var second = new FakeSection("Втори");
        ui.Console.Enter().Escape().Down();
        Logout(ui);

        Assert.Equal(ShellOutcome.Logout, Run(ui, new FakeWorkspace(new FakeSection("Първи", Act("А1")), second)));
        Assert.Equal(1, second.Loads);
        Assert.Matches(@"→\S* \S*действия", ui.Console.Output);
    }

    [Fact]
    public void Down_in_the_menu_switches_section_even_when_it_has_actions()
    {
        var ui = Teacher();
        var second = new FakeSection("Втори");
        ui.Console.Down();
        Logout(ui);

        Run(ui, new FakeWorkspace(new FakeSection("Първи", Act("А1"), Act("А2")), second));

        Assert.Equal(1, second.Loads);
        Assert.Empty(_runs);
    }

    [Fact]
    public void Cyrillic_hotkey_runs_action()
    {
        var ui = Teacher();
        ui.Console.Keys("н");
        Logout(ui);

        Run(ui, new FakeWorkspace(new FakeSection("Първи", Act("Друго", 'Д'), Act("Нова оценка", 'Н'))));

        Assert.Equal(["Нова оценка"], _runs);
    }

    [Fact]
    public void Latin_phonetic_key_triggers_cyrillic_hotkey()
    {
        var ui = Teacher();
        ui.Console.Keys("p");
        Logout(ui);

        Run(ui, new FakeWorkspace(new FakeSection("Първи", Act("Провеждане на час", 'П'))));

        Assert.Equal(["Провеждане на час"], _runs);
    }

    [Fact]
    public void Escape_needs_confirmation()
    {
        var ui = Teacher();
        ui.Console.Escape().Type("н").Keys("2");
        Logout(ui);

        Assert.Equal(ShellOutcome.Logout, Run(ui, new FakeWorkspace(new FakeSection("Първи"), new FakeSection("Втори"))));
        Assert.Contains("Втори съдържание", ui.Console.Output);
    }

    [Fact]
    public void Arrows_switch_section_when_section_has_no_actions()
    {
        var ui = Teacher();
        var second = new FakeSection("Втори");
        ui.Console.Down();
        Logout(ui);

        Assert.Equal(ShellOutcome.Logout, Run(ui, new FakeWorkspace(new FakeSection("Първи"), second)));
        Assert.Equal(1, second.Loads);
        Assert.Matches(@"↑↓\S* \S*раздел", ui.Console.Output);
    }

    private sealed class ThrowingScreen : IScreen
    {
        public string Title => "Чупи се";

        public ScreenResult Show(ScreenContext ctx) => throw new InvalidOperationException("бум");
    }

    [Fact]
    public void Exception_in_nested_screen_returns_to_the_shell()
    {
        var ui = Teacher();
        ui.Console.Enter().Enter().Key().Escape();
        Logout(ui);

        var outcome = Run(ui, new FakeWorkspace(new FakeSection("Първи", SectionAction.Open("Вложен", null, () => new ThrowingScreen()))));

        Assert.Equal(ShellOutcome.Logout, outcome);
        Assert.Single(ui.Errors);
        Assert.Contains("неочаквана грешка", ui.Console.Output);
    }

    [Fact]
    public void Exception_in_form_action_is_shown_and_shell_continues()
    {
        var ui = Teacher();
        ui.Console.Enter().Enter().Key().Escape();
        Logout(ui);

        var outcome = Run(ui, new FakeWorkspace(new FakeSection("Първи", SectionAction.Form("Форма", null, _ => throw new InvalidOperationException("бум")))));

        Assert.Equal(ShellOutcome.Logout, outcome);
        Assert.Single(ui.Errors);
        Assert.Null(ui.Context.ShellSection);
    }

    [Fact]
    public void Logout_inside_nested_screen_ends_shell()
    {
        var ui = Teacher();
        ui.Console.Enter().Enter();

        var outcome = Run(ui, new FakeWorkspace(new FakeSection("Първи", SectionAction.Open("Вложен", null, () => new LogoutScreen()))));

        Assert.Equal(ShellOutcome.Logout, outcome);
        Assert.Equal(0, ui.Console.RemainingKeys);
    }

    [Fact]
    public void Section_is_reloaded_after_action()
    {
        var ui = Teacher();
        var section = new FakeSection("Първи", SectionAction.Form("Форма", 'Ф', c => c.Notifier.Success("записано")));
        ui.Console.Keys("ф");
        Logout(ui);

        Run(ui, new FakeWorkspace(section));

        Assert.Equal(2, section.Loads);
        Assert.Contains("записано", ui.Console.Output);
        Assert.Contains("Готово", ui.Console.Output);
    }

    [Fact]
    public void Shell_with_exhausted_script_fails_fast()
    {
        var ui = Teacher();
        Assert.Throws<ScriptExhaustedException>(() => Run(ui, new FakeWorkspace(new FakeSection("Първи"))));
    }

    [Fact]
    public void Small_window_shows_guard_and_continues_compact()
    {
        var ui = Teacher();
        ui.Console.Profile.Width = 100;
        ui.Console.Profile.Height = 30;
        ui.Console.Enter();
        Logout(ui);

        Assert.Equal(ShellOutcome.Logout, Run(ui, new FakeWorkspace(new FakeSection("Първи"))));
        Assert.Contains("120×34", ui.Console.Output);
        Assert.Contains("100×30", ui.Console.Output);
    }

    [Fact]
    public void Header_shows_role_name_and_clock()
    {
        var ui = Teacher();
        Logout(ui);

        Run(ui, new FakeWorkspace(new FakeSection("Първи")));

        Assert.Contains("Иван Иванов", ui.Console.Output);
        Assert.Contains("Учител", ui.Console.Output);
        Assert.Contains("10:00", ui.Console.Output);
        Assert.Contains("SHKOLO", ui.Console.Output.Replace("\u001b", ""));
    }

    [Fact]
    public void Key_map_normalizes_latin_and_case()
    {
        Assert.Equal('П', KeyMap.Normalize(new ConsoleKeyInfo('p', ConsoleKey.P, false, false, false)));
        Assert.Equal('Н', KeyMap.Normalize(new ConsoleKeyInfo('н', ConsoleKey.NoName, false, false, false)));
        Assert.Equal('В', KeyMap.Normalize(new ConsoleKeyInfo('W', ConsoleKey.W, true, false, false)));
        Assert.Null(KeyMap.Normalize(new ConsoleKeyInfo('5', ConsoleKey.D5, false, false, false)));
    }
}
