﻿// Owner: Shared
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Shell;
using Shkolo.Tests.TestSupport;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Tests.Shell;

public class PaletteTests
{
    private sealed class Section(string title, params SectionAction[] actions) : ISection
    {
        public string Title => title;

        public string Icon => "✎";

        public IReadOnlyList<SectionAction> Actions => actions;

        public void Load(ScreenContext ctx)
        {
        }

        public IRenderable Render(ScreenContext ctx, ShellFrame frame) => new Text(title);
    }

    private sealed class Workspace(params ISection[] sections) : IWorkspace
    {
        public string Name => "Тест";

        public IReadOnlyList<ISection> Sections(ScreenContext ctx) => sections;
    }

    private readonly List<string> _runs = [];

    private ISection Grades() => new Section("Оценки", new SectionAction("Нова оценка", 'Н', _ =>
    {
        _runs.Add("Нова оценка");
        return ShellOutcome.Stay;
    }));

    private static UiApp As(string username)
    {
        var ui = new UiApp();
        ui.App.LoginAs(ui.Db.Users.Single(u => u.Username == username).Id);
        return ui;
    }

    [Fact]
    public void Finds_students_by_name_for_staff()
    {
        var ui = As("admin");
        var results = PaletteIndex.Build(ui.Context, [Grades()]).Search("михаил");
        Assert.Contains(results, r => r.Group == "Хора" && r.Label.StartsWith("Михаил Алексиев"));
    }

    [Fact]
    public void Finds_student_by_exact_number()
    {
        var ui = As("admin");
        var result = PaletteIndex.Build(ui.Context, [Grades()]).Search("1001");
        Assert.StartsWith("Михаил Алексиев", Assert.Single(result).Label);
    }

    [Fact]
    public void Finds_actions_with_section_prefix()
    {
        var ui = As("teacher1");
        var results = PaletteIndex.Build(ui.Context, [Grades()]).Search("оценка");
        Assert.Contains(results, r => r.Group == "Действия" && r.Label == "Оценки › Нова оценка");
    }

    [Fact]
    public void Students_do_not_search_people()
    {
        var ui = As("student1");
        Assert.DoesNotContain(PaletteIndex.Build(ui.Context, [Grades()]).Search("а", 50), r => r.Group == "Хора");
    }

    [Fact]
    public void Empty_query_lists_actions()
    {
        var ui = As("teacher1");
        Assert.All(PaletteIndex.Build(ui.Context, [Grades()]).Search(""), r => Assert.Equal("Действия", r.Group));
    }

    [Fact]
    public void Palette_runs_the_chosen_action_from_the_shell()
    {
        var ui = As("teacher1");
        ui.Console.Keys("/").Keys("нова оц").Enter().Escape().Type("д");

        new AppShell().Run(ui.Context, new Workspace(Grades()));

        Assert.Equal(["Нова оценка"], _runs);
    }

    [Fact]
    public void Palette_shows_bracketed_names_literally_and_closes_on_escape()
    {
        var ui = As("admin");
        ui.Db.Students.First(s => s.StudentNumber == "1001").LastName = "[x] Алексиев";
        ui.Console.Keys("/").Keys("[x]").Escape().Escape().Type("д");

        new AppShell().Run(ui.Context, new Workspace(Grades()));

        Assert.Contains("Михаил [x] Алексиев", ui.Console.Output);
        Assert.Empty(_runs);
    }

    [Fact]
    public void Help_lists_keys_and_closes_on_any_key()
    {
        var ui = As("teacher1");
        ui.Console.Keys("?").Enter().Escape().Type("д");

        new AppShell().Run(ui.Context, new Workspace(Grades()));

        Assert.Contains("Командна палитра", ui.Console.Output);
        Assert.Contains("Нова оценка", ui.Console.Output);
    }
}
