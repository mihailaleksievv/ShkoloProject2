// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Models;

/// <summary>Съобщение от учител или администратор към клас или към цялото училище.</summary>
public sealed class Announcement
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Title { get; set; } = "";
    public string Body { get; set; } = "";
    public Guid AuthorUserId { get; set; }
    public Guid? TargetClassId { get; set; }
    public DateTime PublishedAtUtc { get; set; }
    public bool IsActive { get; set; } = true;
}
