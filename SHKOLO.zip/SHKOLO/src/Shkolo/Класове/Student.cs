// Owner: Participant 1 – Core Developer
using System.Text.Json.Serialization;

namespace Shkolo.Domain.Models;

/// <summary>Ученик: номер, име, клас, имейл. Не се изтрива, а се деактивира, за да се пази историята му.</summary>
public sealed class Student
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string StudentNumber { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public Guid ClassId { get; set; }
    public string? Email { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; }

    [JsonIgnore]
    public string FullName => $"{FirstName} {LastName}";
}
