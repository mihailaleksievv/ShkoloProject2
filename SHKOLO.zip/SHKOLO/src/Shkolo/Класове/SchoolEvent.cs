// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Models;

/// <summary>Училищно събитие с начало и край, например родителска среща.</summary>
public sealed class SchoolEvent
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public DateTime StartDateTime { get; set; }
    public DateTime EndDateTime { get; set; }
    public Guid? TargetClassId { get; set; }
    public Guid CreatedByUserId { get; set; }
}
