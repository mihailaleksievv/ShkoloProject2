// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Domain.Models;

/// <summary>Известие за потребител: нова оценка, отсъствие, съобщение и т.н.</summary>
public sealed class Notification
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid RecipientUserId { get; set; }
    public NotificationType Type { get; set; }
    public string Title { get; set; } = "";
    public string Message { get; set; } = "";
    public Guid? RelatedEntityId { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public bool IsRead { get; set; }
}
