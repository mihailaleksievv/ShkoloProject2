// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Models;

namespace Shkolo.Domain;

/// <summary>Цялата база данни на училището – всички списъци с данни. Записва се като един JSON файл.</summary>
public sealed class SchoolDatabase
{
    public const int CurrentSchemaVersion = 1;

    public int SchemaVersion { get; set; } = CurrentSchemaVersion;
    public DateTime LastSavedAtUtc { get; set; }
    public string SchoolName { get; set; } = "";

    public List<LessonSlot> BellSchedule { get; set; } = new();
    public List<User> Users { get; set; } = new();
    public List<Student> Students { get; set; } = new();
    public List<Teacher> Teachers { get; set; } = new();
    public List<SchoolClass> Classes { get; set; } = new();
    public List<Subject> Subjects { get; set; } = new();
    public List<AcademicYear> AcademicYears { get; set; } = new();
    public List<TeacherAssignment> TeacherAssignments { get; set; } = new();
    public List<TimetableEntry> Timetable { get; set; } = new();
    public List<Lesson> Lessons { get; set; } = new();
    public List<Grade> Grades { get; set; } = new();
    public List<TermGrade> TermGrades { get; set; } = new();
    public List<AttendanceRecord> AttendanceRecords { get; set; } = new();
    public List<Homework> Homework { get; set; } = new();
    public List<HomeworkSubmission> HomeworkSubmissions { get; set; } = new();
    public List<Feedback> Feedback { get; set; } = new();
    public List<Announcement> Announcements { get; set; } = new();
    public List<SchoolEvent> SchoolEvents { get; set; } = new();
    public List<AchievementBadge> AchievementBadges { get; set; } = new();
    public List<StudentAchievement> StudentAchievements { get; set; } = new();
    public List<Notification> Notifications { get; set; } = new();
    public List<AuditEntry> AuditLog { get; set; } = new();
}
