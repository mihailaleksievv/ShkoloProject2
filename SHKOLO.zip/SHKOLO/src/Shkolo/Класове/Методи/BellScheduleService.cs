// Owner: Participant 1 – Core Developer
using Shkolo.Application.Results;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>The bell schedule – the single source of lesson start and end times.</summary>
public sealed class BellScheduleService
{
    private readonly ServiceContext _ctx;

    public BellScheduleService(ServiceContext ctx) => _ctx = ctx;

    public IReadOnlyList<LessonSlot> GetSlots() => _ctx.Db.BellSchedule.OrderBy(s => s.LessonNumber).ToList();

    public LessonSlot? GetSlot(int lessonNumber) => _ctx.Db.BellSchedule.FirstOrDefault(s => s.LessonNumber == lessonNumber);

    public OperationResult UpdateSlot(int lessonNumber, TimeOnly start, TimeOnly end)
    {
        var auth = _ctx.Authorization.RequireAdmin();
        if (!auth.Success)
        {
            return auth;
        }

        if (GetSlot(lessonNumber) is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, $"Час №{lessonNumber} не съществува в звънеца.");
        }

        if (start >= end)
        {
            return OperationResult.Validation(ErrorCodes.InvalidDateRange, "Началото на часа трябва да е преди края му.");
        }

        var previous = GetSlots().LastOrDefault(s => s.LessonNumber < lessonNumber);
        var next = GetSlots().FirstOrDefault(s => s.LessonNumber > lessonNumber);
        if ((previous is not null && start < previous.EndTime) || (next is not null && end > next.StartTime))
        {
            return OperationResult.Validation(ErrorCodes.InvalidInput, "Часът се застъпва със съседен час от звънеца.");
        }

        return _ctx.Uow.Execute(db =>
        {
            var slot = db.BellSchedule.First(s => s.LessonNumber == lessonNumber);
            slot.StartTime = start;
            slot.EndTime = end;
            _ctx.Audit.Record(db, "BellSchedule.Updated", nameof(LessonSlot), null, $"Час №{lessonNumber}: {start:HH\\:mm}–{end:HH\\:mm}.");
            return OperationResult.Ok();
        });
    }
}
