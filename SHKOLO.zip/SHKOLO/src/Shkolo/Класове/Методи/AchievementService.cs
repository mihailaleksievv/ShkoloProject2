// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Achievement badges: an admin-managed catalog and awards given by teachers.</summary>
public sealed class AchievementService
{
    private const int MaxDescriptionLength = 200;
    private const int MaxSymbolLength = 4;
    private readonly ServiceContext _ctx;

    public AchievementService(ServiceContext ctx) => _ctx = ctx;

    public IReadOnlyList<AchievementBadge> GetCatalog(bool includeInactive = false)
        => _ctx.Db.AchievementBadges.Where(b => includeInactive || b.IsActive).OrderBy(b => b.Name, StringComparer.CurrentCulture).ToList();

    public OperationResult<AchievementBadge> AddBadge(string name, string description, string symbol)
    {
        var check = Check.All(
            _ctx.Authorization.RequireAdmin,
            () => Check.Name(name, "Наименование"),
            () => Check.Text(description, "Описание", MaxDescriptionLength),
            () => Check.Text(symbol, "Символ", MaxSymbolLength));
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var badge = new AchievementBadge { Name = name.Trim(), Description = description.Trim(), Symbol = symbol.Trim() };
            db.AchievementBadges.Add(badge);
            _ctx.Audit.Record(db, "Badge.Created", nameof(AchievementBadge), badge.Id, $"Ново отличие „{badge.Name}“.");
            return OperationResult<AchievementBadge>.Ok(badge);
        });
    }

    public OperationResult<StudentAchievement> Award(Guid studentId, Guid badgeId, string? note)
    {
        var badge = _ctx.Db.AchievementBadges.FirstOrDefault(b => b.Id == badgeId);
        var check = Check.All(
            () => _ctx.Authorization.RequireRole(UserRole.Teacher),
            () => _ctx.Authorization.RequireCanViewStudent(studentId),
            () => badge switch
            {
                null => OperationResult.NotFound(ErrorCodes.NotFound, "Отличието не е намерено."),
                { IsActive: false } => OperationResult.Validation(ErrorCodes.InactiveEntity, "Отличието е деактивирано."),
                _ => OperationResult.Ok(),
            },
            () => Check.Text(note, "Бележка", MaxDescriptionLength, required: false));
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var award = new StudentAchievement
            {
                BadgeId = badgeId,
                StudentId = studentId,
                AssignedByTeacherId = _ctx.Session.TeacherId!.Value,
                AssignedAtUtc = _ctx.Clock.UtcNow,
                Note = Check.Trimmed(note),
            };
            db.StudentAchievements.Add(award);
            _ctx.Audit.Record(db, "Achievement.Awarded", nameof(StudentAchievement), award.Id, $"„{badge!.Name}“ за {db.StudentName(studentId)}.");
            _ctx.Notifications.NotifyStudent(db, studentId, NotificationType.NewAchievement, "Ново отличие", $"{badge.Symbol} {badge.Name}", award.Id);
            return OperationResult<StudentAchievement>.Ok(award);
        });
    }

    public OperationResult<IReadOnlyList<AchievementView>> GetForStudent(Guid studentId)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        return auth.Success ? OperationResult<IReadOnlyList<AchievementView>>.Ok(Views(_ctx.Db, studentId)) : auth.Error!;
    }

    internal static IReadOnlyList<AchievementView> Views(SchoolDatabase db, Guid studentId)
        => db.StudentAchievements.Where(a => a.StudentId == studentId)
            .OrderByDescending(a => a.AssignedAtUtc)
            .Select(a =>
            {
                var badge = db.AchievementBadges.FirstOrDefault(b => b.Id == a.BadgeId);
                return new AchievementView(a.Id, badge?.Symbol ?? "?", badge?.Name ?? "—", badge?.Description ?? "", a.StudentId,
                    db.StudentName(a.StudentId), db.TeacherName(a.AssignedByTeacherId), a.AssignedAtUtc, a.Note);
            })
            .ToList();
}
