// Owner: Participant 1 – Core Developer
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Методи за учителите: списък, търсене, добавяне, редакция, деактивиране, какво преподава.</summary>
public sealed class TeacherService
{
    private const int MaxNumberLength = 20;
    private readonly ServiceContext _ctx;

    public TeacherService(ServiceContext ctx) => _ctx = ctx;

    public OperationResult<IReadOnlyList<Teacher>> GetAll(bool includeInactive = false)
    {
        var auth = _ctx.Authorization.RequireAdmin();
        if (!auth.Success)
        {
            return auth.Error!;
        }

        return OperationResult<IReadOnlyList<Teacher>>.Ok(_ctx.Db.Teachers
            .Where(t => includeInactive || t.IsActive)
            .OrderBy(t => t.LastName, StringComparer.CurrentCulture).ThenBy(t => t.FirstName, StringComparer.CurrentCulture)
            .ToList());
    }

    public OperationResult<Teacher> GetById(Guid id)
    {
        var auth = RequireAdminOrSelf(id);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        return _ctx.Db.FindTeacher(id) is { } teacher
            ? OperationResult<Teacher>.Ok(teacher)
            : new Error(ErrorKind.NotFound, ErrorCodes.NotFound, "Учителят не е намерен.");
    }

    public OperationResult<IReadOnlyList<Teacher>> Search(string query)
    {
        var all = GetAll(includeInactive: true);
        if (!all.Success)
        {
            return all;
        }

        var q = query?.Trim() ?? "";
        return OperationResult<IReadOnlyList<Teacher>>.Ok(all.Value!
            .Where(t => t.FullName.Contains(q, StringComparison.CurrentCultureIgnoreCase)
                        || t.EmployeeNumber.Equals(q, StringComparison.OrdinalIgnoreCase))
            .ToList());
    }

    public OperationResult<Teacher> Add(TeacherInput input)
    {
        var check = Validate(input, null);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var teacher = new Teacher { CreatedAtUtc = _ctx.Clock.UtcNow };
            Apply(teacher, input);
            db.Teachers.Add(teacher);
            _ctx.Audit.Record(db, "Teacher.Created", nameof(Teacher), teacher.Id, $"Добавен учител {teacher.FullName} ({teacher.EmployeeNumber}).");
            return OperationResult<Teacher>.Ok(teacher);
        });
    }

    public OperationResult Update(Guid id, TeacherInput input)
    {
        var check = Check.All(() => Validate(input, id), () => Exists(id));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var teacher = db.FindTeacher(id)!;
            Apply(teacher, input);
            _ctx.Audit.Record(db, "Teacher.Updated", nameof(Teacher), id, $"Редактиран учител {teacher.FullName}.");
            return OperationResult.Ok();
        });
    }

    /// <summary>Deactivates the teacher and the linked account. Returns how many timetable entries still use the teacher.</summary>
    public OperationResult<int> Deactivate(Guid id)
    {
        var check = Check.All(_ctx.Authorization.RequireAdmin, () => Exists(id));
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var teacher = db.FindTeacher(id)!;
            teacher.IsActive = false;
            if (db.UserOfTeacher(id) is { } user)
            {
                user.IsActive = false;
            }

            var timetableCount = db.Timetable.Count(t => t.TeacherId == id);
            _ctx.Audit.Record(db, "Teacher.Deactivated", nameof(Teacher), id, $"Деактивиран учител {teacher.FullName}.");
            return OperationResult<int>.Ok(timetableCount);
        });
    }

    public OperationResult<IReadOnlyList<SchoolClass>> GetTaughtClasses(Guid teacherId)
    {
        var check = Check.All(() => RequireAdminOrSelf(teacherId), () => Exists(teacherId));
        if (!check.Success)
        {
            return check.Error!;
        }

        var db = _ctx.Db;
        var ids = db.TeacherAssignments.Where(a => a.TeacherId == teacherId).Select(a => a.ClassId)
            .Concat(db.Classes.Where(c => c.ClassTeacherId == teacherId).Select(c => c.Id))
            .ToHashSet();
        return OperationResult<IReadOnlyList<SchoolClass>>.Ok(db.Classes.Where(c => ids.Contains(c.Id))
            .OrderBy(c => c.GradeLevel).ThenBy(c => c.Section, StringComparer.CurrentCulture).ToList());
    }

    public OperationResult<IReadOnlyList<Subject>> GetTaughtSubjects(Guid teacherId)
    {
        var check = Check.All(() => RequireAdminOrSelf(teacherId), () => Exists(teacherId));
        if (!check.Success)
        {
            return check.Error!;
        }

        var ids = _ctx.Db.TeacherAssignments.Where(a => a.TeacherId == teacherId).Select(a => a.SubjectId).ToHashSet();
        return OperationResult<IReadOnlyList<Subject>>.Ok(_ctx.Db.Subjects.Where(s => ids.Contains(s.Id))
            .OrderBy(s => s.Name, StringComparer.CurrentCulture).ToList());
    }

    private OperationResult RequireAdminOrSelf(Guid teacherId)
    {
        var auth = _ctx.Authorization.RequireAuthenticated();
        if (!auth.Success)
        {
            return auth;
        }

        return _ctx.Authorization.IsAdmin || _ctx.Session.TeacherId == teacherId
            ? OperationResult.Ok()
            : OperationResult.Forbidden("Нямате достъп до данните на този учител.");
    }

    private OperationResult Exists(Guid id)
        => _ctx.Db.FindTeacher(id) is null
            ? OperationResult.NotFound(ErrorCodes.NotFound, "Учителят не е намерен.")
            : OperationResult.Ok();

    private OperationResult Validate(TeacherInput input, Guid? existingId) => Check.All(
        _ctx.Authorization.RequireAdmin,
        () => Check.Text(input.EmployeeNumber, "Служебен номер", MaxNumberLength),
        () => Check.Name(input.FirstName, "Име"),
        () => Check.Name(input.LastName, "Фамилия"),
        () => Check.Email(input.Email, required: true),
        () => _ctx.Db.Teachers.Any(t => t.Id != existingId && string.Equals(t.EmployeeNumber, input.EmployeeNumber.Trim(), StringComparison.OrdinalIgnoreCase))
            ? OperationResult.Conflict(ErrorCodes.DuplicateEmployeeNumber, $"Служебен номер „{input.EmployeeNumber.Trim()}“ вече съществува.")
            : OperationResult.Ok());

    private static void Apply(Teacher teacher, TeacherInput input)
    {
        teacher.EmployeeNumber = input.EmployeeNumber.Trim();
        teacher.FirstName = input.FirstName.Trim();
        teacher.LastName = input.LastName.Trim();
        teacher.Email = input.Email.Trim();
    }
}
