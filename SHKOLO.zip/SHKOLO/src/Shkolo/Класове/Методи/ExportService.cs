// Owner: Participant 1 – Core Developer
using Shkolo.Application.Abstractions;
using Shkolo.Application.Results;

namespace Shkolo.Application.Services;

/// <summary>Exports reports to files (CSV). Same permissions as viewing the report.</summary>
public sealed class ExportService
{
    private static readonly string[] Headers = ["Раздел", "Показател", "Стойност"];
    private readonly ReportService _reports;
    private readonly IReportExporter _exporter;

    public ExportService(ReportService reports, IReportExporter exporter)
    {
        _reports = reports;
        _exporter = exporter;
    }

    public OperationResult<string> ExportStudentReport(Guid studentId)
    {
        var report = _reports.GenerateStudentReport(studentId);
        if (!report.Success)
        {
            return report.Error!;
        }

        var r = report.Value!;
        var rows = new List<string[]>
        {
            new[] { "Ученик", "Име", r.Student.FullName },
            new[] { "Ученик", "Клас", r.ClassName },
            new[] { "Ученик", "Номер", r.Student.StudentNumber },
            new[] { "Успех", "Общ среден успех", Number(r.OverallAverage) },
            new[] { "Успех", "Брой оценки", r.GradeCount.ToString(BulgarianNames.Culture) },
        };
        rows.AddRange(r.SubjectAverages.Select(s => new[] { "Предмет", s.SubjectName, $"{Number(s.Average)} ({s.GradeCount} оц.)" }));
        rows.AddRange(r.TermGrades.Select(t => new[] { "Срочни оценки", $"{BulgarianNames.Of(t.Period)}", t.Value.ToString(BulgarianNames.Culture) }));
        rows.Add(["Присъствия", "Присъствал", Count(r.Attendance.Present)]);
        rows.Add(["Присъствия", "Неизвинени отсъствия", Count(r.Attendance.Unexcused)]);
        rows.Add(["Присъствия", "Извинени отсъствия", Count(r.Attendance.Excused)]);
        rows.Add(["Присъствия", "Закъснения", Count(r.Attendance.Late)]);
        rows.AddRange(r.RecentGrades.Select(g => new[] { "Последни оценки", $"{g.Date:dd.MM.yyyy} {g.SubjectName}", BulgarianNames.Grade(g.Value) }));
        rows.AddRange(r.Achievements.Select(a => new[] { "Отличия", a.Name, a.AssignedAtUtc.ToString("dd.MM.yyyy", BulgarianNames.Culture) }));

        return Write($"Справка_{r.Student.LastName}_{r.Student.StudentNumber}", rows);
    }

    public OperationResult<string> ExportClassReport(Guid classId)
    {
        var report = _reports.GenerateClassReport(classId);
        if (!report.Success)
        {
            return report.Error!;
        }

        var r = report.Value!;
        var rows = new List<string[]>
        {
            new[] { "Клас", "Клас", r.Class.DisplayName },
            new[] { "Клас", "Класен ръководител", r.ClassTeacherName },
            new[] { "Клас", "Брой ученици", Count(r.StudentCount) },
            new[] { "Успех", "Среден успех на класа", Number(r.ClassAverage) },
            new[] { "Успех", "Брой оценки", Count(r.GradeCount) },
            new[] { "Разпределение", "Слаб", Count(r.Distribution.Poor) },
            new[] { "Разпределение", "Среден", Count(r.Distribution.Average) },
            new[] { "Разпределение", "Добър", Count(r.Distribution.Good) },
            new[] { "Разпределение", "Много добър", Count(r.Distribution.VeryGood) },
            new[] { "Разпределение", "Отличен", Count(r.Distribution.Excellent) },
            new[] { "Присъствия", "Неизвинени отсъствия", Count(r.Attendance.Unexcused) },
            new[] { "Присъствия", "Извинени отсъствия", Count(r.Attendance.Excused) },
            new[] { "Присъствия", "Закъснения", Count(r.Attendance.Late) },
        };
        rows.AddRange(r.SubjectAverages.Select(s => new[] { "Предмет", s.SubjectName, Number(s.Average) }));
        rows.AddRange(r.StudentAverages.Select(s => new[] { "Ученик", s.StudentName, Number(s.Average) }));

        return Write($"Справка_клас_{r.Class.DisplayName}", rows);
    }

    private OperationResult<string> Write(string stem, IEnumerable<string[]> rows)
    {
        try
        {
            return OperationResult<string>.Ok(_exporter.Export(stem, Headers, rows));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return new Error(ErrorKind.Persistence, ErrorCodes.PersistenceFailed, "Файлът не може да бъде записан: " + ex.Message);
        }
    }

    private static string Number(decimal? value) => value is { } v ? BulgarianNames.Grade(v) : "Няма данни";

    private static string Count(int value) => value.ToString(BulgarianNames.Culture);
}
