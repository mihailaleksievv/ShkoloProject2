// Owner: Participant 1 – Core Developer
using Shkolo.Application.Abstractions;
using Shkolo.Application.Reports;
using Shkolo.Application.Results;
using Shkolo.Application.Security;
using Shkolo.Domain;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>History of important actions. Entries are written inside the same unit of work as the change.</summary>
public sealed class AuditService
{
    private readonly IUnitOfWork _uow;
    private readonly SessionContext _session;
    private readonly IClock _clock;
    private readonly AuthorizationService _authorization;

    public AuditService(IUnitOfWork uow, SessionContext session, IClock clock, AuthorizationService authorization)
    {
        _uow = uow;
        _session = session;
        _clock = clock;
        _authorization = authorization;
    }

    /// <summary>Adds an entry for the current user. Must be called inside a mutation. Never pass secrets.</summary>
    public void Record(SchoolDatabase db, string action, string entityType, Guid? entityId, string summary)
        => db.AuditLog.Add(new AuditEntry
        {
            UserId = _session.UserId,
            Action = action,
            EntityType = entityType,
            EntityId = entityId,
            OccurredAtUtc = _clock.UtcNow,
            Summary = summary,
        });

    /// <summary>Most recent entries, newest first, optionally filtered by action prefix (e.g. "Grade.").</summary>
    public OperationResult<IReadOnlyList<AuditEntryView>> GetRecent(int count, string? actionPrefix = null)
    {
        var auth = _authorization.RequireAdmin();
        return auth.Success ? OperationResult<IReadOnlyList<AuditEntryView>>.Ok(GetRecentUnchecked(count, actionPrefix)) : auth.Error!;
    }

    /// <summary>For dashboards that already checked the admin role.</summary>
    internal IReadOnlyList<AuditEntryView> GetRecentUnchecked(int count, string? actionPrefix = null)
    {
        var db = _uow.Database;
        return db.AuditLog
            .Where(a => string.IsNullOrWhiteSpace(actionPrefix) || a.Action.StartsWith(actionPrefix, StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(a => a.OccurredAtUtc)
            .Take(count)
            .Select(a => new AuditEntryView(a.Id, a.OccurredAtUtc, a.UserId is null ? "—" : db.UserName(a.UserId), a.Action, a.EntityType, a.Summary))
            .ToList();
    }
}
