// Owner: Participant 1 – Core Developer
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Методи за предметите: добавяне, редакция и деактивиране.</summary>
public sealed class SubjectService
{
    private const int MaxCodeLength = 10;
    private readonly ServiceContext _ctx;

    public SubjectService(ServiceContext ctx) => _ctx = ctx;

    public IReadOnlyList<Subject> GetAll(bool includeInactive = false)
        => _ctx.Db.Subjects.Where(s => includeInactive || s.IsActive).OrderBy(s => s.Name, StringComparer.CurrentCulture).ToList();

    public OperationResult<Subject> GetById(Guid id)
        => _ctx.Db.FindSubject(id) is { } subject
            ? OperationResult<Subject>.Ok(subject)
            : new Error(ErrorKind.NotFound, ErrorCodes.NotFound, "Предметът не е намерен.");

    public IReadOnlyList<Subject> Search(string query)
    {
        var q = query?.Trim() ?? "";
        return GetAll(includeInactive: true)
            .Where(s => s.Name.Contains(q, StringComparison.CurrentCultureIgnoreCase)
                        || (s.Code?.Contains(q, StringComparison.CurrentCultureIgnoreCase) ?? false))
            .ToList();
    }

    public OperationResult<Subject> Add(SubjectInput input)
    {
        var check = Validate(input, null);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var subject = new Subject { Name = input.Name.Trim(), Code = Check.Trimmed(input.Code) };
            db.Subjects.Add(subject);
            _ctx.Audit.Record(db, "Subject.Created", nameof(Subject), subject.Id, $"Добавен предмет „{subject.Name}“.");
            return OperationResult<Subject>.Ok(subject);
        });
    }

    public OperationResult Update(Guid id, SubjectInput input)
    {
        var check = Check.All(() => Validate(input, id), () => GetById(id));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var subject = db.FindSubject(id)!;
            subject.Name = input.Name.Trim();
            subject.Code = Check.Trimmed(input.Code);
            _ctx.Audit.Record(db, "Subject.Updated", nameof(Subject), id, $"Редактиран предмет „{subject.Name}“.");
            return OperationResult.Ok();
        });
    }

    public OperationResult Deactivate(Guid id)
    {
        var check = Check.All(_ctx.Authorization.RequireAdmin, () => GetById(id));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var subject = db.FindSubject(id)!;
            subject.IsActive = false;
            _ctx.Audit.Record(db, "Subject.Deactivated", nameof(Subject), id, $"Деактивиран предмет „{subject.Name}“.");
            return OperationResult.Ok();
        });
    }

    private OperationResult Validate(SubjectInput input, Guid? existingId) => Check.All(
        _ctx.Authorization.RequireAdmin,
        () => Check.Name(input.Name, "Наименование"),
        () => Check.Text(input.Code, "Код", MaxCodeLength, required: false),
        () => _ctx.Db.Subjects.Any(s => s.Id != existingId && string.Equals(s.Name.Trim(), input.Name.Trim(), StringComparison.CurrentCultureIgnoreCase))
            ? OperationResult.Conflict(ErrorCodes.DuplicateSubject, $"Предмет „{input.Name.Trim()}“ вече съществува.")
            : OperationResult.Ok());
}
