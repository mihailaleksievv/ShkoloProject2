// Owner: Participant 1 – Core Developer
using Shkolo.Application.Results;
using Shkolo.Domain;

namespace Shkolo.Application.Services;

/// <summary>Reusable validation helpers that turn rules from <see cref="DomainRules"/> into results.</summary>
internal static class Check
{
    public static OperationResult Name(string? value, string label)
        => DomainRules.IsNameValid(value)
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.InvalidInput, $"{label}: задължително поле, до {DomainRules.MaxNameLength} символа.");

    public static OperationResult Text(string? value, string label, int maxLength, bool required = true)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return required
                ? OperationResult.Validation(ErrorCodes.InvalidInput, $"{label}: задължително поле.")
                : OperationResult.Ok();
        }

        return value.Trim().Length <= maxLength
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.InvalidInput, $"{label}: най-много {maxLength} символа.");
    }

    public static OperationResult Email(string? value, bool required)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return required
                ? OperationResult.Validation(ErrorCodes.InvalidInput, "Имейл: задължително поле.")
                : OperationResult.Ok();
        }

        return DomainRules.IsEmailValid(value)
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.InvalidInput, "Невалиден имейл адрес.");
    }

    /// <summary>Returns the first failed result, or OK when all succeeded. Checks are evaluated lazily in order.</summary>
    public static OperationResult All(params Func<OperationResult>[] checks)
    {
        foreach (var check in checks)
        {
            var result = check();
            if (!result.Success)
            {
                return result;
            }
        }

        return OperationResult.Ok();
    }

    public static string? Trimmed(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
