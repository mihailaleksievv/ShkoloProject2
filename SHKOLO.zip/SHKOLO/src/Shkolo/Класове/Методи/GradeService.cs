// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Методи за оценките: поставяне, редакция, изтриване и среден успех.</summary>
public sealed class GradeService
{
    private const int MaxCommentLength = 200;
    private readonly ServiceContext _ctx;

    public GradeService(ServiceContext ctx) => _ctx = ctx;

    public OperationResult<IReadOnlyList<GradeView>> GetGradesForStudent(Guid studentId, GradeFilter? filter = null)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        return auth.Success ? Views(Filter(InActiveYear(_ctx.Db.Grades.Where(g => g.StudentId == studentId)), filter)) : auth.Error!;
    }

    public OperationResult<IReadOnlyList<GradeView>> GetGradesBySubject(Guid studentId, Guid subjectId)
        => GetGradesForStudent(studentId, new GradeFilter(SubjectId: subjectId));

    /// <summary>Grades given in a class (by the class the student was in when graded). Admin or teachers of the class.</summary>
    public OperationResult<IReadOnlyList<GradeView>> GetGradesForClass(Guid classId, Guid? subjectId = null)
    {
        var auth = RequireStaffForClass(classId);
        return auth.Success
            ? Views(Filter(_ctx.Db.Grades.Where(g => g.ClassId == classId), new GradeFilter(SubjectId: subjectId)))
            : auth.Error!;
    }

    public OperationResult<Grade> AddGrade(GradeInput input)
    {
        var check = ValidateNewGrade(_ctx.Db, input);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var grade = BuildGrade(db, input);
            db.Grades.Add(grade);
            RecordAdded(db, grade);
            return OperationResult<Grade>.Ok(grade);
        });
    }

    public OperationResult UpdateGrade(Guid gradeId, GradeUpdate update)
    {
        var check = Check.All(
            () => RequireAuthor(gradeId),
            () => DomainRules.IsValidGrade(update.Value) ? OperationResult.Ok() : InvalidGrade(),
            () => Check.Text(update.Comment, "Коментар", MaxCommentLength, required: false));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var grade = db.Grades.First(g => g.Id == gradeId);
            var old = grade.Value;
            grade.Value = update.Value;
            grade.GradeType = update.Type;
            grade.Comment = Check.Trimmed(update.Comment);
            grade.UpdatedAtUtc = _ctx.Clock.UtcNow;
            _ctx.Audit.Record(db, "Grade.Updated", nameof(Grade), gradeId,
                $"{db.StudentName(grade.StudentId)}, {db.SubjectName(grade.SubjectId)}: {BulgarianNames.Grade(old)} → {BulgarianNames.Grade(update.Value)}.");
            return OperationResult.Ok();
        });
    }

    public OperationResult DeleteGrade(Guid gradeId)
    {
        var check = RequireAuthor(gradeId);
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var grade = db.Grades.First(g => g.Id == gradeId);
            db.Grades.Remove(grade);
            _ctx.Audit.Record(db, "Grade.Deleted", nameof(Grade), gradeId,
                $"Изтрита оценка {BulgarianNames.Grade(grade.Value)} на {db.StudentName(grade.StudentId)} по {db.SubjectName(grade.SubjectId)}.");
            return OperationResult.Ok();
        });
    }

    public OperationResult<decimal?> CalculateAverage(Guid studentId, Term? term = null)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        return auth.Success
            ? OperationResult<decimal?>.Ok(Average(Filter(InActiveYear(_ctx.Db.Grades.Where(g => g.StudentId == studentId)), new GradeFilter(Term: term))))
            : auth.Error!;
    }

    public OperationResult<decimal?> CalculateSubjectAverage(Guid studentId, Guid subjectId, Term? term = null)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        return auth.Success
            ? OperationResult<decimal?>.Ok(Average(Filter(InActiveYear(_ctx.Db.Grades.Where(g => g.StudentId == studentId)), new GradeFilter(SubjectId: subjectId, Term: term))))
            : auth.Error!;
    }

    /// <summary>Arithmetic mean with full precision; null when there are no grades (never 0).</summary>
    internal static decimal? Average(IEnumerable<Grade> grades)
    {
        var list = grades.ToList();
        return list.Count == 0 ? null : list.Sum(g => g.Value) / list.Count;
    }

    /// <summary>All rules for a new grade; reused by the atomic lesson workflow.</summary>
    internal OperationResult ValidateNewGrade(SchoolDatabase db, GradeInput input)
    {
        var student = db.FindStudent(input.StudentId);
        if (student is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Ученикът не е намерен.");
        }

        return Check.All(
            () => _ctx.Authorization.RequireTeachingAssignment(student.ClassId, input.SubjectId),
            () => student.IsActive ? OperationResult.Ok() : OperationResult.Validation(ErrorCodes.InactiveEntity, $"Ученикът {student.FullName} е деактивиран."),
            () => db.FindSubject(input.SubjectId)?.IsActive == true
                ? OperationResult.Ok()
                : OperationResult.Validation(ErrorCodes.InactiveEntity, "Предметът не съществува или е деактивиран."),
            () => DomainRules.IsValidGrade(input.Value) ? OperationResult.Ok() : InvalidGrade(),
            () => _ctx.RequireActiveYearContaining(input.Date),
            () => _ctx.RequireNotFuture(input.Date),
            () => Check.Text(input.Comment, "Коментар", MaxCommentLength, required: false),
            () => ValidateLessonLink(db, input, student.ClassId));
    }

    internal Grade BuildGrade(SchoolDatabase db, GradeInput input) => new()
    {
        StudentId = input.StudentId,
        ClassId = db.FindStudent(input.StudentId)!.ClassId,
        SubjectId = input.SubjectId,
        TeacherId = _ctx.Session.TeacherId!.Value,
        LessonId = input.LessonId,
        Value = input.Value,
        Date = input.Date,
        GradeType = input.Type,
        Comment = Check.Trimmed(input.Comment),
        CreatedAtUtc = _ctx.Clock.UtcNow,
    };

    /// <summary>Audit entry and student notification for a newly added grade.</summary>
    internal void RecordAdded(SchoolDatabase db, Grade grade)
    {
        var subject = db.SubjectName(grade.SubjectId);
        var text = $"{subject}: {BulgarianNames.Grade(grade.Value)} ({BulgarianNames.Of(grade.GradeType)})";
        _ctx.Audit.Record(db, "Grade.Created", nameof(Grade), grade.Id, $"{db.StudentName(grade.StudentId)} – {text}.");
        _ctx.Notifications.NotifyStudent(db, grade.StudentId, NotificationType.NewGrade, "Нова оценка", text, grade.Id);
    }

    /// <summary>A student's grades and averages describe the active academic year, never a mix of years.</summary>
    internal IEnumerable<Grade> InActiveYear(IEnumerable<Grade> grades)
    {
        var year = _ctx.ActiveYear;
        return year is null ? grades : grades.Where(g => year.Contains(g.Date));
    }

    internal IEnumerable<Grade> Filter(IEnumerable<Grade> grades, GradeFilter? filter)
    {
        if (filter is null)
        {
            return grades;
        }

        var year = _ctx.ActiveYear;
        return grades
            .Where(g => filter.SubjectId is null || g.SubjectId == filter.SubjectId)
            .Where(g => filter.Type is null || g.GradeType == filter.Type)
            .Where(g => filter.From is null || g.Date >= filter.From)
            .Where(g => filter.To is null || g.Date <= filter.To)
            .Where(g => filter.Term is null || (year is not null && year.Contains(g.Date) && year.GetTerm(g.Date) == filter.Term));
    }

    private static OperationResult ValidateLessonLink(SchoolDatabase db, GradeInput input, Guid classId)
    {
        if (input.LessonId is not { } lessonId)
        {
            return OperationResult.Ok();
        }

        var lesson = db.FindLesson(lessonId);
        return lesson is not null && lesson.Status == LessonStatus.Held && lesson.ClassId == classId
               && lesson.SubjectId == input.SubjectId && lesson.Date == input.Date
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.InvalidInput, "Оценката не съответства на избрания учебен час (клас, предмет или дата).");
    }

    private OperationResult RequireAuthor(Guid gradeId)
    {
        var grade = _ctx.Db.Grades.FirstOrDefault(g => g.Id == gradeId);
        if (grade is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Оценката не е намерена.");
        }

        var role = _ctx.Authorization.RequireRole(UserRole.Teacher);
        if (!role.Success)
        {
            return role;
        }

        return grade.TeacherId == _ctx.Session.TeacherId
            ? OperationResult.Ok()
            : OperationResult.Fail(new Error(ErrorKind.Forbidden, ErrorCodes.NotAuthor, "Можете да променяте само оценки, които сте поставили."));
    }

    private OperationResult RequireStaffForClass(Guid classId)
    {
        var role = _ctx.Authorization.RequireRole(UserRole.Administrator, UserRole.Teacher);
        if (!role.Success)
        {
            return role;
        }

        return _ctx.Authorization.IsAdmin ? _ctx.Authorization.RequireCanViewClass(classId) : _ctx.Authorization.RequireTeachesClass(classId);
    }

    private static OperationResult InvalidGrade()
        => OperationResult.Validation(ErrorCodes.InvalidGrade, "Оценката трябва да е между 2,00 и 6,00 с най-много два знака след запетаята.");

    private OperationResult<IReadOnlyList<GradeView>> Views(IEnumerable<Grade> grades)
    {
        var db = _ctx.Db;
        return OperationResult<IReadOnlyList<GradeView>>.Ok(grades
            .OrderByDescending(g => g.Date).ThenByDescending(g => g.CreatedAtUtc)
            .Select(g => new GradeView(g.Id, g.StudentId, db.StudentName(g.StudentId), g.SubjectId, db.SubjectName(g.SubjectId),
                g.Value, g.Date, g.GradeType, g.Comment, g.TeacherId, db.TeacherName(g.TeacherId)))
            .ToList());
    }
}
