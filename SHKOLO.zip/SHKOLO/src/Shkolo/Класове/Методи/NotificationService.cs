// Owner: Participant 1 – Core Developer
using Shkolo.Application.Abstractions;
using Shkolo.Application.Results;
using Shkolo.Application.Security;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>
/// Internal notifications. Write methods are called by other services inside the same
/// unit of work as the change that triggers them, so a failed change never leaves a stray notification.
/// </summary>
public sealed class NotificationService
{
    private readonly IUnitOfWork _uow;
    private readonly SessionContext _session;
    private readonly IClock _clock;

    public NotificationService(IUnitOfWork uow, SessionContext session, IClock clock)
    {
        _uow = uow;
        _session = session;
        _clock = clock;
    }

    /// <summary>Notifications of the logged-in user, newest first.</summary>
    public IReadOnlyList<Notification> GetForCurrentUser(bool unreadOnly = false)
        => _uow.Database.Notifications
            .Where(n => n.RecipientUserId == _session.UserId && (!unreadOnly || !n.IsRead))
            .OrderByDescending(n => n.CreatedAtUtc)
            .ToList();

    public int GetUnreadCount()
        => _session.UserId is { } id ? _uow.Database.Notifications.Count(n => n.RecipientUserId == id && !n.IsRead) : 0;

    public OperationResult MarkAsRead(Guid notificationId)
    {
        var notification = _uow.Database.Notifications.FirstOrDefault(n => n.Id == notificationId);
        if (notification is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Известието не е намерено.");
        }

        if (notification.RecipientUserId != _session.UserId)
        {
            return OperationResult.Forbidden("Това известие не е ваше.");
        }

        return _uow.Execute(db =>
        {
            db.Notifications.First(n => n.Id == notificationId).IsRead = true;
            return OperationResult.Ok();
        });
    }

    public OperationResult MarkAllAsRead()
    {
        if (_session.UserId is not { } userId)
        {
            return OperationResult.Fail(new Error(ErrorKind.Forbidden, ErrorCodes.NotAuthenticated, "Необходим е вход в системата."));
        }

        return _uow.Execute(db =>
        {
            foreach (var n in db.Notifications.Where(n => n.RecipientUserId == userId && !n.IsRead))
            {
                n.IsRead = true;
            }

            return OperationResult.Ok();
        });
    }

    public void Notify(SchoolDatabase db, Guid recipientUserId, NotificationType type, string title, string message, Guid? relatedId)
        => db.Notifications.Add(new Notification
        {
            RecipientUserId = recipientUserId,
            Type = type,
            Title = title,
            Message = message,
            RelatedEntityId = relatedId,
            CreatedAtUtc = _clock.UtcNow,
        });

    /// <summary>Notifies the account of a student; no-op when the student has no active account.</summary>
    public void NotifyStudent(SchoolDatabase db, Guid studentId, NotificationType type, string title, string message, Guid? relatedId)
    {
        var user = db.Users.FirstOrDefault(u => u.StudentId == studentId && u.IsActive);
        if (user is not null)
        {
            Notify(db, user.Id, type, title, message, relatedId);
        }
    }

    public void NotifyClass(SchoolDatabase db, Guid classId, NotificationType type, string title, string message, Guid? relatedId)
    {
        foreach (var student in db.ActiveStudentsOf(classId).ToList())
        {
            NotifyStudent(db, student.Id, type, title, message, relatedId);
        }
    }

    public void NotifyAll(SchoolDatabase db, Guid? exceptUserId, NotificationType type, string title, string message, Guid? relatedId)
    {
        foreach (var user in db.Users.Where(u => u.IsActive && u.Id != exceptUserId).ToList())
        {
            Notify(db, user.Id, type, title, message, relatedId);
        }
    }
}
