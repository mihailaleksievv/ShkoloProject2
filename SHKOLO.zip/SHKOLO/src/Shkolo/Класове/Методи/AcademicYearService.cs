// Owner: Participant 1 – Core Developer
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Academic years and terms. At most one year is active; school activity must fall inside it.</summary>
public sealed class AcademicYearService
{
    private readonly ServiceContext _ctx;

    public AcademicYearService(ServiceContext ctx) => _ctx = ctx;

    public IReadOnlyList<AcademicYear> GetAll() => _ctx.Db.AcademicYears.OrderByDescending(y => y.StartDate).ToList();

    public AcademicYear? GetActive() => _ctx.ActiveYear;

    /// <summary>Used by every service that records dated school activity.</summary>
    public OperationResult<AcademicYear> RequireActiveYearContaining(DateOnly date) => _ctx.RequireActiveYearContaining(date);

    public OperationResult<AcademicYear> Create(AcademicYearInput input)
    {
        var check = Validate(input);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var year = new AcademicYear();
            Apply(year, input);
            db.AcademicYears.Add(year);
            _ctx.Audit.Record(db, "AcademicYear.Created", nameof(AcademicYear), year.Id, $"Създадена учебна година {year.Name}.");
            return OperationResult<AcademicYear>.Ok(year);
        });
    }

    public OperationResult Update(Guid id, AcademicYearInput input)
    {
        var check = Check.All(() => Validate(input), () => Exists(id));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var year = db.AcademicYears.First(y => y.Id == id);
            Apply(year, input);
            _ctx.Audit.Record(db, "AcademicYear.Updated", nameof(AcademicYear), id, $"Редактирана учебна година {year.Name}.");
            return OperationResult.Ok();
        });
    }

    public OperationResult SetActive(Guid id)
    {
        var check = Check.All(_ctx.Authorization.RequireAdmin, () => Exists(id));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            foreach (var year in db.AcademicYears)
            {
                year.IsActive = year.Id == id;
            }

            _ctx.Audit.Record(db, "AcademicYear.Activated", nameof(AcademicYear), id, $"Активна учебна година: {db.AcademicYears.First(y => y.Id == id).Name}.");
            return OperationResult.Ok();
        });
    }

    private OperationResult Validate(AcademicYearInput input) => Check.All(
        _ctx.Authorization.RequireAdmin,
        () => Check.Text(input.Name, "Наименование", 20),
        () => input.StartDate < input.FirstTermEndDate && input.FirstTermEndDate < input.EndDate
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.InvalidDateRange, "Датите трябва да са подредени: начало < край на I срок < край на годината."));

    private OperationResult Exists(Guid id)
        => _ctx.Db.AcademicYears.Any(y => y.Id == id)
            ? OperationResult.Ok()
            : OperationResult.NotFound(ErrorCodes.NotFound, "Учебната година не е намерена.");

    private static void Apply(AcademicYear year, AcademicYearInput input)
    {
        year.Name = input.Name.Trim();
        year.StartDate = input.StartDate;
        year.FirstTermEndDate = input.FirstTermEndDate;
        year.EndDate = input.EndDate;
    }
}
