// Owner: Participant 1 – Core Developer
using Shkolo.Domain;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Small lookup helpers used by services to resolve ids into entities and display names.</summary>
internal static class DbLookups
{
    private const string Missing = "—";

    /// <summary>Bulgarian alphabetical order, independent of the machine culture.</summary>
    public static readonly StringComparer Bulgarian = StringComparer.Create(System.Globalization.CultureInfo.GetCultureInfo("bg-BG"), ignoreCase: true);

    public static IOrderedEnumerable<Student> SortedByName(this IEnumerable<Student> students)
        => students.OrderBy(s => s.LastName, Bulgarian).ThenBy(s => s.FirstName, Bulgarian);

    public static Student? FindStudent(this SchoolDatabase db, Guid id) => db.Students.FirstOrDefault(x => x.Id == id);

    public static Teacher? FindTeacher(this SchoolDatabase db, Guid id) => db.Teachers.FirstOrDefault(x => x.Id == id);

    public static SchoolClass? FindClass(this SchoolDatabase db, Guid id) => db.Classes.FirstOrDefault(x => x.Id == id);

    public static Subject? FindSubject(this SchoolDatabase db, Guid id) => db.Subjects.FirstOrDefault(x => x.Id == id);

    public static User? FindUser(this SchoolDatabase db, Guid id) => db.Users.FirstOrDefault(x => x.Id == id);

    public static Lesson? FindLesson(this SchoolDatabase db, Guid id) => db.Lessons.FirstOrDefault(x => x.Id == id);

    public static Homework? FindHomework(this SchoolDatabase db, Guid id) => db.Homework.FirstOrDefault(x => x.Id == id);

    public static User? UserOfStudent(this SchoolDatabase db, Guid studentId) => db.Users.FirstOrDefault(u => u.StudentId == studentId);

    public static User? UserOfTeacher(this SchoolDatabase db, Guid teacherId) => db.Users.FirstOrDefault(u => u.TeacherId == teacherId);

    public static string ClassName(this SchoolDatabase db, Guid id) => db.FindClass(id)?.DisplayName ?? Missing;

    public static string SubjectName(this SchoolDatabase db, Guid id) => db.FindSubject(id)?.Name ?? Missing;

    public static string TeacherName(this SchoolDatabase db, Guid id) => db.FindTeacher(id)?.FullName ?? Missing;

    public static string StudentName(this SchoolDatabase db, Guid id) => db.FindStudent(id)?.FullName ?? Missing;

    public static string UserName(this SchoolDatabase db, Guid? id) => id is { } v ? db.FindUser(v)?.DisplayName ?? Missing : Missing;

    public static IEnumerable<Student> ActiveStudentsOf(this SchoolDatabase db, Guid classId)
        => db.Students.Where(s => s.ClassId == classId && s.IsActive);
}
