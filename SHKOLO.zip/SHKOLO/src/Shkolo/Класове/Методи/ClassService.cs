// Owner: Participant 1 – Core Developer
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Classes (паралелки) and their class teachers.</summary>
/// <summary>Методи за класовете: създаване, редакция, деактивиране и класен ръководител.</summary>
public sealed class ClassService
{
    private const int MaxSectionLength = 3;
    private readonly ServiceContext _ctx;

    public ClassService(ServiceContext ctx) => _ctx = ctx;

    /// <summary>Admin: all classes. Teacher: taught classes. Student: own class.</summary>
    public IReadOnlyList<SchoolClass> GetAll(bool includeInactive = false)
    {
        var db = _ctx.Db;
        IEnumerable<SchoolClass> visible = _ctx.Session.Role switch
        {
            UserRole.Administrator => db.Classes,
            UserRole.Teacher => db.Classes.Where(c => _ctx.Authorization.TaughtClassIds().Contains(c.Id)),
            UserRole.Student => db.Classes.Where(c => db.FindStudent(_ctx.Session.StudentId!.Value)?.ClassId == c.Id),
            _ => [],
        };
        return visible.Where(c => includeInactive || c.IsActive)
            .OrderBy(c => c.GradeLevel).ThenBy(c => c.Section, StringComparer.CurrentCulture).ToList();
    }

    public OperationResult<SchoolClass> GetById(Guid id)
    {
        var auth = _ctx.Authorization.RequireCanViewClass(id);
        return auth.Success ? OperationResult<SchoolClass>.Ok(_ctx.Db.FindClass(id)!) : auth.Error!;
    }

    public OperationResult<SchoolClass> Create(ClassInput input)
    {
        var check = Validate(input, null);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var cls = new SchoolClass();
            Apply(cls, input);
            db.Classes.Add(cls);
            _ctx.Audit.Record(db, "Class.Created", nameof(SchoolClass), cls.Id, $"Създаден клас {cls.DisplayName}.");
            return OperationResult<SchoolClass>.Ok(cls);
        });
    }

    public OperationResult Update(Guid id, ClassInput input)
    {
        var check = Check.All(() => Validate(input, id), () => Exists(id));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var cls = db.FindClass(id)!;
            Apply(cls, input);
            _ctx.Audit.Record(db, "Class.Updated", nameof(SchoolClass), id, $"Редактиран клас {cls.DisplayName}.");
            return OperationResult.Ok();
        });
    }

    public OperationResult Deactivate(Guid id)
    {
        var check = Check.All(_ctx.Authorization.RequireAdmin, () => Exists(id));
        if (!check.Success)
        {
            return check;
        }

        if (_ctx.Db.ActiveStudentsOf(id).Any())
        {
            return OperationResult.Conflict(ErrorCodes.HasDependencies, "Класът има активни ученици. Преместете или деактивирайте учениците първо.");
        }

        return _ctx.Uow.Execute(db =>
        {
            var cls = db.FindClass(id)!;
            cls.IsActive = false;
            _ctx.Audit.Record(db, "Class.Deactivated", nameof(SchoolClass), id, $"Деактивиран клас {cls.DisplayName}.");
            return OperationResult.Ok();
        });
    }

    public OperationResult AssignClassTeacher(Guid classId, Guid? teacherId)
    {
        var check = Check.All(_ctx.Authorization.RequireAdmin, () => Exists(classId), () => ActiveTeacher(teacherId));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var cls = db.FindClass(classId)!;
            cls.ClassTeacherId = teacherId;
            var who = teacherId is { } t ? db.TeacherName(t) : "няма";
            _ctx.Audit.Record(db, "Class.ClassTeacherAssigned", nameof(SchoolClass), classId, $"Класен ръководител на {cls.DisplayName}: {who}.");
            return OperationResult.Ok();
        });
    }

    private OperationResult Exists(Guid id)
        => _ctx.Db.FindClass(id) is null ? OperationResult.NotFound(ErrorCodes.NotFound, "Класът не е намерен.") : OperationResult.Ok();

    private OperationResult ActiveTeacher(Guid? teacherId)
    {
        if (teacherId is not { } id)
        {
            return OperationResult.Ok();
        }

        return _ctx.Db.FindTeacher(id) switch
        {
            null => OperationResult.NotFound(ErrorCodes.NotFound, "Учителят не е намерен."),
            { IsActive: false } => OperationResult.Validation(ErrorCodes.InactiveEntity, "Учителят е деактивиран."),
            _ => OperationResult.Ok(),
        };
    }

    private OperationResult Validate(ClassInput input, Guid? existingId)
    {
        var section = Normalize(input.Section);
        return Check.All(
            _ctx.Authorization.RequireAdmin,
            () => input.GradeLevel is >= 1 and <= 12
                ? OperationResult.Ok()
                : OperationResult.Validation(ErrorCodes.InvalidInput, "Класът трябва да е между 1 и 12."),
            () => Check.Text(section, "Паралелка", MaxSectionLength),
            () => _ctx.Db.AcademicYears.Any(y => y.Id == input.AcademicYearId)
                ? OperationResult.Ok()
                : OperationResult.NotFound(ErrorCodes.NotFound, "Учебната година не е намерена."),
            () => ActiveTeacher(input.ClassTeacherId),
            () => _ctx.Db.Classes.Any(c => c.Id != existingId && c.AcademicYearId == input.AcademicYearId
                                           && c.GradeLevel == input.GradeLevel && Normalize(c.Section) == section)
                ? OperationResult.Conflict(ErrorCodes.DuplicateClass, $"Клас {input.GradeLevel}{section} вече съществува за тази учебна година.")
                : OperationResult.Ok());
    }

    private static string Normalize(string? section) => (section ?? "").Trim().ToUpperInvariant();

    private static void Apply(SchoolClass cls, ClassInput input)
    {
        cls.GradeLevel = input.GradeLevel;
        cls.Section = Normalize(input.Section);
        cls.AcademicYearId = input.AcademicYearId;
        cls.ClassTeacherId = input.ClassTeacherId;
    }
}
