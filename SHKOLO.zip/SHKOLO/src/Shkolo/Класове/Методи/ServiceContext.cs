// Owner: Participant 1 – Core Developer
using Shkolo.Application.Abstractions;
using Shkolo.Application.Results;
using Shkolo.Application.Security;
using Shkolo.Domain;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>
/// Dependencies shared by every service, bundled so constructors stay short and consistent.
/// </summary>
public sealed class ServiceContext
{
    public ServiceContext(IUnitOfWork uow, SessionContext session, IClock clock, AuthorizationService authorization, AuditService audit, NotificationService notifications)
    {
        Uow = uow;
        Session = session;
        Clock = clock;
        Authorization = authorization;
        Audit = audit;
        Notifications = notifications;
    }

    public IUnitOfWork Uow { get; }

    public SessionContext Session { get; }

    public IClock Clock { get; }

    public AuthorizationService Authorization { get; }

    public AuditService Audit { get; }

    public NotificationService Notifications { get; }

    /// <summary>Current state for reads. Changes go through <see cref="IUnitOfWork.Execute"/>.</summary>
    public SchoolDatabase Db => Uow.Database;

    public AcademicYear? ActiveYear => Db.AcademicYears.FirstOrDefault(y => y.IsActive);

    /// <summary>Dated school activity must fall inside the active academic year.</summary>
    public OperationResult<AcademicYear> RequireActiveYearContaining(DateOnly date)
    {
        var year = ActiveYear;
        if (year is null)
        {
            return new Error(ErrorKind.Validation, ErrorCodes.NoActiveYear, "Няма активна учебна година.");
        }

        return year.Contains(date)
            ? OperationResult<AcademicYear>.Ok(year)
            : new Error(ErrorKind.Validation, ErrorCodes.OutOfAcademicYear,
                $"Датата {date:dd.MM.yyyy} е извън учебната година {year.Name} ({year.StartDate:dd.MM.yyyy} – {year.EndDate:dd.MM.yyyy}).");
    }

    /// <summary>Records describe what happened – they cannot be dated in the future.</summary>
    public OperationResult RequireNotFuture(DateOnly date)
        => date <= Clock.Today
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.FutureDate, "Датата не може да бъде в бъдещето.");
}
