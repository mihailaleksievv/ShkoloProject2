// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Методи за учебните часове: записване, търсене, тема, бележки и отмяна.</summary>
public sealed class LessonService
{
    private const int MaxNotesLength = 500;
    private readonly ServiceContext _ctx;

    public LessonService(ServiceContext ctx) => _ctx = ctx;

    public OperationResult<Lesson> CreateLesson(LessonInput input, Guid? timetableEntryId = null)
    {
        var check = ValidateNewLesson(_ctx.Db, input, timetableEntryId);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var lesson = BuildLesson(input, timetableEntryId);
            db.Lessons.Add(lesson);
            _ctx.Audit.Record(db, "Lesson.Created", nameof(Lesson), lesson.Id, Describe(db, lesson));
            return OperationResult<Lesson>.Ok(lesson);
        });
    }

    /// <summary>Records the lesson planned by a timetable entry on a concrete date.</summary>
    public OperationResult<Lesson> OpenFromTimetable(Guid timetableEntryId, DateOnly date, string topic, string? notes)
    {
        var entry = _ctx.Db.Timetable.FirstOrDefault(t => t.Id == timetableEntryId);
        if (entry is null)
        {
            return new Error(ErrorKind.NotFound, ErrorCodes.NotFound, "Записът в разписанието не е намерен.");
        }

        return CreateLesson(new LessonInput(entry.ClassId, entry.SubjectId, date, entry.LessonNumber, topic, notes), timetableEntryId);
    }

    public OperationResult<LessonView> GetLessonById(Guid id)
    {
        var lesson = _ctx.Db.FindLesson(id);
        if (lesson is null)
        {
            return new Error(ErrorKind.NotFound, ErrorCodes.NotFound, "Учебният час не е намерен.");
        }

        var auth = _ctx.Authorization.RequireCanViewClass(lesson.ClassId);
        return auth.Success ? OperationResult<LessonView>.Ok(View(lesson)) : auth.Error!;
    }

    public OperationResult<IReadOnlyList<LessonView>> GetLessonsForClass(Guid classId) => Search(new LessonFilter(ClassId: classId));

    public OperationResult<IReadOnlyList<LessonView>> GetLessonsForTeacher(Guid teacherId) => Search(new LessonFilter(TeacherId: teacherId));

    /// <summary>Lessons visible to the current user that match the filter, newest first.</summary>
    public OperationResult<IReadOnlyList<LessonView>> Search(LessonFilter filter)
    {
        var auth = _ctx.Authorization.RequireAuthenticated();
        if (!auth.Success)
        {
            return auth.Error!;
        }

        if (filter.ClassId is { } classId)
        {
            var classAuth = _ctx.Authorization.RequireCanViewClass(classId);
            if (!classAuth.Success)
            {
                return classAuth.Error!;
            }
        }

        if (filter.TeacherId is { } teacherId && !_ctx.Authorization.IsAdmin && _ctx.Session.TeacherId != teacherId)
        {
            return new Error(ErrorKind.Forbidden, ErrorCodes.Forbidden, "Нямате достъп до часовете на този учител.");
        }

        var visible = VisibleClassIds();
        var lessons = _ctx.Db.Lessons
            .Where(l => visible is null || visible.Contains(l.ClassId) || l.TeacherId == _ctx.Session.TeacherId)
            .Where(l => filter.ClassId is null || l.ClassId == filter.ClassId)
            .Where(l => filter.SubjectId is null || l.SubjectId == filter.SubjectId)
            .Where(l => filter.TeacherId is null || l.TeacherId == filter.TeacherId)
            .Where(l => filter.From is null || l.Date >= filter.From)
            .Where(l => filter.To is null || l.Date <= filter.To)
            .OrderByDescending(l => l.Date).ThenByDescending(l => l.LessonNumber)
            .Select(View)
            .ToList();
        return OperationResult<IReadOnlyList<LessonView>>.Ok(lessons);
    }

    public OperationResult UpdateLessonTopic(Guid id, string topic)
    {
        var check = Check.All(() => RequireLessonTeacher(id), () => Check.Text(topic, "Тема", DomainRules.MaxTopicLength));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var lesson = db.FindLesson(id)!;
            lesson.Topic = topic.Trim();
            _ctx.Audit.Record(db, "Lesson.TopicUpdated", nameof(Lesson), id, $"Нова тема: „{lesson.Topic}“.");
            return OperationResult.Ok();
        });
    }

    public OperationResult UpdateNotes(Guid id, string? notes)
    {
        var check = Check.All(() => RequireLessonTeacher(id), () => Check.Text(notes, "Бележка", MaxNotesLength, required: false));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            db.FindLesson(id)!.Notes = Check.Trimmed(notes);
            _ctx.Audit.Record(db, "Lesson.NotesUpdated", nameof(Lesson), id, "Обновена бележка към час.");
            return OperationResult.Ok();
        });
    }

    /// <summary>Marks a lesson as cancelled – only while no attendance or grades depend on it.</summary>
    public OperationResult CancelLesson(Guid id)
    {
        var check = RequireLessonTeacher(id);
        if (!check.Success)
        {
            return check;
        }

        var db = _ctx.Db;
        if (db.AttendanceRecords.Any(a => a.LessonId == id) || db.Grades.Any(g => g.LessonId == id))
        {
            return OperationResult.Conflict(ErrorCodes.LessonHasRecords, "Часът има въведени присъствия или оценки и не може да бъде отменен.");
        }

        return _ctx.Uow.Execute(d =>
        {
            var lesson = d.FindLesson(id)!;
            lesson.Status = LessonStatus.Cancelled;
            _ctx.Audit.Record(d, "Lesson.Cancelled", nameof(Lesson), id, Describe(d, lesson));
            return OperationResult.Ok();
        });
    }

    public OperationResult<IReadOnlyList<RosterEntry>> GetLessonRoster(Guid lessonId)
    {
        var lesson = _ctx.Db.FindLesson(lessonId);
        if (lesson is null)
        {
            return new Error(ErrorKind.NotFound, ErrorCodes.NotFound, "Учебният час не е намерен.");
        }

        var auth = _ctx.Authorization.IsAdmin ? OperationResult.Ok() : _ctx.Authorization.RequireTeachesClass(lesson.ClassId);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var marks = _ctx.Db.AttendanceRecords.Where(a => a.LessonId == lessonId).ToDictionary(a => a.StudentId, a => a.Status);
        return OperationResult<IReadOnlyList<RosterEntry>>.Ok(_ctx.Db.ActiveStudentsOf(lesson.ClassId)
            .SortedByName()
            .Select(s => new RosterEntry(s.Id, s.StudentNumber, s.FullName, marks.TryGetValue(s.Id, out var st) ? st : null))
            .ToList());
    }

    /// <summary>All rules for a new held lesson; reused by the atomic lesson workflow.</summary>
    internal OperationResult ValidateNewLesson(SchoolDatabase db, LessonInput input, Guid? timetableEntryId) => Check.All(
        () => _ctx.Authorization.RequireTeachingAssignment(input.ClassId, input.SubjectId),
        () => db.FindClass(input.ClassId)?.IsActive == true
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.InactiveEntity, "Класът не съществува или е деактивиран."),
        () => _ctx.RequireActiveYearContaining(input.Date),
        () => _ctx.RequireNotFuture(input.Date),
        () => db.BellSchedule.Any(s => s.LessonNumber == input.LessonNumber)
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.InvalidInput, $"Час №{input.LessonNumber} не съществува в звънеца."),
        () => Check.Text(input.Topic, "Тема", DomainRules.MaxTopicLength),
        () => Check.Text(input.Notes, "Бележка", MaxNotesLength, required: false),
        () => ValidateTimetableLink(db, input, timetableEntryId),
        () => db.Lessons.Any(l => l.ClassId == input.ClassId && l.Date == input.Date && l.LessonNumber == input.LessonNumber && l.Status == LessonStatus.Held)
            ? OperationResult.Conflict(ErrorCodes.DuplicateLesson, $"За {db.ClassName(input.ClassId)} вече има записан {input.LessonNumber}. час на {input.Date:dd.MM.yyyy}.")
            : OperationResult.Ok());

    internal Lesson BuildLesson(LessonInput input, Guid? timetableEntryId) => new()
    {
        TimetableEntryId = timetableEntryId,
        ClassId = input.ClassId,
        SubjectId = input.SubjectId,
        TeacherId = _ctx.Session.TeacherId!.Value,
        Date = input.Date,
        LessonNumber = input.LessonNumber,
        Topic = input.Topic.Trim(),
        Notes = Check.Trimmed(input.Notes),
        Status = LessonStatus.Held,
        RecordedAtUtc = _ctx.Clock.UtcNow,
    };

    internal static string Describe(SchoolDatabase db, Lesson lesson)
        => $"{db.ClassName(lesson.ClassId)}, {db.SubjectName(lesson.SubjectId)}, {lesson.Date:dd.MM.yyyy}, {lesson.LessonNumber}. час: „{lesson.Topic}“.";

    private static OperationResult ValidateTimetableLink(SchoolDatabase db, LessonInput input, Guid? timetableEntryId)
    {
        if (timetableEntryId is not { } id)
        {
            return OperationResult.Ok();
        }

        var entry = db.Timetable.FirstOrDefault(t => t.Id == id);
        if (entry is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Записът в разписанието не е намерен.");
        }

        if (entry.ClassId != input.ClassId || entry.SubjectId != input.SubjectId || entry.LessonNumber != input.LessonNumber)
        {
            return OperationResult.Validation(ErrorCodes.InvalidInput, "Часът не съответства на записа в разписанието.");
        }

        return input.Date.DayOfWeek == entry.DayOfWeek
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.DayMismatch, "Датата не е в деня от седмицата, в който е часът по разписание.");
    }

    private OperationResult RequireLessonTeacher(Guid lessonId)
    {
        var lesson = _ctx.Db.FindLesson(lessonId);
        if (lesson is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Учебният час не е намерен.");
        }

        var role = _ctx.Authorization.RequireRole(UserRole.Teacher);
        if (!role.Success)
        {
            return role;
        }

        return lesson.TeacherId == _ctx.Session.TeacherId
            ? OperationResult.Ok()
            : OperationResult.Forbidden("Само учителят, провел часа, може да го променя.");
    }

    /// <summary>Null means "all classes" (administrator).</summary>
    private IReadOnlySet<Guid>? VisibleClassIds() => _ctx.Session.Role switch
    {
        UserRole.Administrator => null,
        UserRole.Teacher => _ctx.Authorization.TaughtClassIds(),
        _ => _ctx.Db.Students.Where(s => s.Id == _ctx.Session.StudentId).Select(s => s.ClassId).ToHashSet(),
    };

    private LessonView View(Lesson l)
    {
        var db = _ctx.Db;
        return new LessonView(l.Id, l.Date, l.LessonNumber, l.ClassId, db.ClassName(l.ClassId), l.SubjectId, db.SubjectName(l.SubjectId),
            l.TeacherId, db.TeacherName(l.TeacherId), l.Topic, l.Notes, l.Status,
            db.AttendanceRecords.Count(a => a.LessonId == l.Id), db.Grades.Count(g => g.LessonId == l.Id));
    }
}
