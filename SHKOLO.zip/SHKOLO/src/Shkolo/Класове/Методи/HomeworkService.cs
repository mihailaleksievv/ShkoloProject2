// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Методи за домашните: възлагане, редакция, предаване и преглед на отговорите.</summary>
public sealed class HomeworkService
{
    private const int MaxDescriptionLength = 1000;
    private const int MaxContentLength = 2000;
    private readonly ServiceContext _ctx;

    public HomeworkService(ServiceContext ctx) => _ctx = ctx;

    /// <summary>Pending/Overdue without a submission; Submitted/SubmittedLate depending on the submission date.</summary>
    public static HomeworkStatus ComputeStatus(Homework homework, HomeworkSubmission? submission, DateOnly today)
    {
        if (submission is null)
        {
            return today <= homework.DueDate ? HomeworkStatus.Pending : HomeworkStatus.Overdue;
        }

        return DateOnly.FromDateTime(submission.SubmittedAtUtc) <= homework.DueDate ? HomeworkStatus.Submitted : HomeworkStatus.SubmittedLate;
    }

    public OperationResult<Homework> CreateHomework(HomeworkInput input)
    {
        var check = Validate(input);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var homework = new Homework { TeacherId = _ctx.Session.TeacherId!.Value, CreatedAtUtc = _ctx.Clock.UtcNow };
            Apply(homework, input);
            db.Homework.Add(homework);
            var text = $"{db.SubjectName(homework.SubjectId)}: {homework.Title} (срок {homework.DueDate:dd.MM.yyyy})";
            _ctx.Audit.Record(db, "Homework.Created", nameof(Homework), homework.Id, $"{db.ClassName(homework.ClassId)} – {text}.");
            _ctx.Notifications.NotifyClass(db, homework.ClassId, NotificationType.NewHomework, "Ново домашно", text, homework.Id);
            return OperationResult<Homework>.Ok(homework);
        });
    }

    public OperationResult UpdateHomework(Guid id, HomeworkInput input)
    {
        var check = Check.All(() => RequireAuthor(id), () => Validate(input));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var homework = db.FindHomework(id)!;
            Apply(homework, input);
            _ctx.Audit.Record(db, "Homework.Updated", nameof(Homework), id, $"Редактирано домашно „{homework.Title}“.");
            return OperationResult.Ok();
        });
    }

    public OperationResult ArchiveHomework(Guid id)
    {
        var check = _ctx.Authorization.IsAdmin
            ? (_ctx.Db.FindHomework(id) is null ? OperationResult.NotFound(ErrorCodes.NotFound, "Домашното не е намерено.") : OperationResult.Ok())
            : RequireAuthor(id);
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var homework = db.FindHomework(id)!;
            homework.IsActive = false;
            _ctx.Audit.Record(db, "Homework.Archived", nameof(Homework), id, $"Архивирано домашно „{homework.Title}“.");
            return OperationResult.Ok();
        });
    }

    public OperationResult<IReadOnlyList<HomeworkView>> GetHomeworkForClass(Guid classId, Guid? subjectId = null, bool includeArchived = false)
    {
        var auth = _ctx.Authorization.RequireCanViewClass(classId);
        return auth.Success
            ? OperationResult<IReadOnlyList<HomeworkView>>.Ok(Views(_ctx.Db.Homework.Where(h => h.ClassId == classId
                && (subjectId is null || h.SubjectId == subjectId) && (includeArchived || h.IsActive)), _ctx.Session.StudentId))
            : auth.Error!;
    }

    public OperationResult<IReadOnlyList<HomeworkView>> GetHomeworkForStudent(Guid studentId)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var classId = _ctx.Db.FindStudent(studentId)!.ClassId;
        return OperationResult<IReadOnlyList<HomeworkView>>.Ok(Views(_ctx.Db.Homework.Where(h => h.ClassId == classId && h.IsActive), studentId));
    }

    /// <summary>Active homework with a due date today or later, in the current user's scope.</summary>
    public IReadOnlyList<HomeworkView> GetUpcomingHomework()
        => Views(Scope().Where(h => h.IsActive && h.DueDate >= _ctx.Clock.Today), _ctx.Session.StudentId);

    /// <summary>Active homework past its due date; for a student only the ones without a submission.</summary>
    public IReadOnlyList<HomeworkView> GetOverdueHomework()
    {
        var studentId = _ctx.Session.StudentId;
        return Views(Scope().Where(h => h.IsActive && h.DueDate < _ctx.Clock.Today
                                        && (studentId is null || !_ctx.Db.HomeworkSubmissions.Any(s => s.HomeworkId == h.Id && s.StudentId == studentId))), studentId);
    }

    public OperationResult<HomeworkSubmission> Submit(Guid homeworkId, string content)
    {
        var homework = _ctx.Db.FindHomework(homeworkId);
        var studentId = _ctx.Session.StudentId;
        var existing = _ctx.Db.HomeworkSubmissions.FirstOrDefault(s => s.HomeworkId == homeworkId && s.StudentId == studentId);
        var check = Check.All(
            () => _ctx.Authorization.RequireRole(UserRole.Student),
            () => homework is null ? OperationResult.NotFound(ErrorCodes.NotFound, "Домашното не е намерено.") : OperationResult.Ok(),
            () => _ctx.Db.FindStudent(studentId!.Value)?.ClassId == homework!.ClassId
                ? OperationResult.Ok()
                : OperationResult.Forbidden("Домашното не е за вашия клас."),
            () => homework!.IsActive ? OperationResult.Ok() : OperationResult.Validation(ErrorCodes.InactiveEntity, "Домашното е архивирано."),
            () => Check.Text(content, "Отговор", MaxContentLength),
            () => existing is not null && _ctx.Clock.Today > homework!.DueDate
                ? OperationResult.Validation(ErrorCodes.InvalidInput, "Срокът е изтекъл – предаденият отговор вече не може да се променя.")
                : OperationResult.Ok());
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var submission = db.HomeworkSubmissions.FirstOrDefault(s => s.HomeworkId == homeworkId && s.StudentId == studentId);
            if (submission is null)
            {
                submission = new HomeworkSubmission { HomeworkId = homeworkId, StudentId = studentId!.Value };
                db.HomeworkSubmissions.Add(submission);
            }

            submission.Content = content.Trim();
            submission.SubmittedAtUtc = _ctx.Clock.UtcNow;
            _ctx.Audit.Record(db, "Homework.Submitted", nameof(HomeworkSubmission), submission.Id, $"{db.StudentName(studentId!.Value)} предаде „{homework!.Title}“.");
            return OperationResult<HomeworkSubmission>.Ok(submission);
        });
    }

    /// <summary>Every active student of the class with their submission state (admin or teachers of the class).</summary>
    public OperationResult<IReadOnlyList<SubmissionView>> GetSubmissions(Guid homeworkId)
    {
        var homework = _ctx.Db.FindHomework(homeworkId);
        if (homework is null)
        {
            return new Error(ErrorKind.NotFound, ErrorCodes.NotFound, "Домашното не е намерено.");
        }

        var auth = _ctx.Authorization.IsAdmin ? OperationResult.Ok() : _ctx.Authorization.RequireTeachesClass(homework.ClassId);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var db = _ctx.Db;
        var today = _ctx.Clock.Today;
        return OperationResult<IReadOnlyList<SubmissionView>>.Ok(db.ActiveStudentsOf(homework.ClassId).SortedByName()
            .Select(s =>
            {
                var sub = db.HomeworkSubmissions.FirstOrDefault(x => x.HomeworkId == homeworkId && x.StudentId == s.Id);
                return new SubmissionView(s.Id, s.FullName, ComputeStatus(homework, sub, today), sub?.SubmittedAtUtc, sub?.Content);
            })
            .ToList());
    }

    private IEnumerable<Homework> Scope()
    {
        var db = _ctx.Db;
        return _ctx.Session.Role switch
        {
            UserRole.Administrator => db.Homework,
            UserRole.Teacher => db.Homework.Where(h => h.TeacherId == _ctx.Session.TeacherId),
            UserRole.Student => db.Homework.Where(h => h.ClassId == db.FindStudent(_ctx.Session.StudentId!.Value)?.ClassId),
            _ => [],
        };
    }

    private OperationResult Validate(HomeworkInput input) => Check.All(
        () => _ctx.Authorization.RequireTeachingAssignment(input.ClassId, input.SubjectId),
        () => _ctx.Db.FindClass(input.ClassId)?.IsActive == true
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.InactiveEntity, "Класът не съществува или е деактивиран."),
        () => Check.Text(input.Title, "Заглавие", DomainRules.MaxTitleLength),
        () => Check.Text(input.Description, "Описание", MaxDescriptionLength, required: false),
        () => input.DueDate >= input.AssignedDate
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.InvalidDateRange, "Срокът трябва да е след или на датата на възлагане."),
        () => _ctx.RequireActiveYearContaining(input.AssignedDate));

    private OperationResult RequireAuthor(Guid id)
    {
        var homework = _ctx.Db.FindHomework(id);
        if (homework is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Домашното не е намерено.");
        }

        var role = _ctx.Authorization.RequireRole(UserRole.Teacher);
        if (!role.Success)
        {
            return role;
        }

        return homework.TeacherId == _ctx.Session.TeacherId
            ? OperationResult.Ok()
            : OperationResult.Fail(new Error(ErrorKind.Forbidden, ErrorCodes.NotAuthor, "Можете да променяте само домашни, които сте създали."));
    }

    private static void Apply(Homework homework, HomeworkInput input)
    {
        homework.ClassId = input.ClassId;
        homework.SubjectId = input.SubjectId;
        homework.Title = input.Title.Trim();
        homework.Description = input.Description?.Trim() ?? "";
        homework.AssignedDate = input.AssignedDate;
        homework.DueDate = input.DueDate;
    }

    private IReadOnlyList<HomeworkView> Views(IEnumerable<Homework> items, Guid? forStudentId)
    {
        var db = _ctx.Db;
        var today = _ctx.Clock.Today;
        return items
            .OrderBy(h => h.DueDate).ThenBy(h => h.Title, StringComparer.CurrentCulture)
            .Select(h =>
            {
                HomeworkStatus? status = forStudentId is { } sid
                    ? ComputeStatus(h, db.HomeworkSubmissions.FirstOrDefault(s => s.HomeworkId == h.Id && s.StudentId == sid), today)
                    : null;
                return new HomeworkView(h.Id, h.ClassId, db.ClassName(h.ClassId), h.SubjectId, db.SubjectName(h.SubjectId), h.TeacherId,
                    db.TeacherName(h.TeacherId), h.Title, h.Description, h.AssignedDate, h.DueDate, h.IsActive, status,
                    db.HomeworkSubmissions.Count(s => s.HomeworkId == h.Id), db.ActiveStudentsOf(h.ClassId).Count());
            })
            .ToList();
    }
}
