// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>
/// Performance intelligence: reports, statistics and role dashboards.
/// Every number is computed from the stored data at the moment of the request – nothing is hard-coded.
/// </summary>
public sealed partial class ReportService
{
    private const int RecentCount = 5;
    private readonly ServiceContext _ctx;
    private readonly HomeworkService _homework;
    private readonly AnnouncementService _announcements;
    private readonly SchoolEventService _events;
    private readonly TimetableService _timetable;

    public ReportService(ServiceContext ctx, HomeworkService homework, AnnouncementService announcements, SchoolEventService events, TimetableService timetable)
    {
        _ctx = ctx;
        _homework = homework;
        _announcements = announcements;
        _events = events;
        _timetable = timetable;
    }

    public OperationResult<StudentReport> GenerateStudentReport(Guid studentId, Term? term = null)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        return auth.Success ? OperationResult<StudentReport>.Ok(BuildStudentReport(studentId, term)) : auth.Error!;
    }

    public OperationResult<ClassReport> GenerateClassReport(Guid classId, Term? term = null)
    {
        var auth = RequireStaffForClass(classId);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var db = _ctx.Db;
        var cls = db.FindClass(classId)!;
        var grades = InTerm(db.Grades.Where(g => g.ClassId == classId), g => g.Date, term, ClassYear(db, cls)).ToList();
        var students = db.ActiveStudentsOf(classId).SortedByName().ToList();
        var subjectAverages = SubjectAverages(db, grades);
        var lessonIds = db.Lessons.Where(l => l.ClassId == classId).Select(l => l.Id).ToHashSet();
        var attendance = InTerm(db.AttendanceRecords.Where(a => lessonIds.Contains(a.LessonId)), a => db.FindLesson(a.LessonId)!.Date, term, ClassYear(db, cls));

        return OperationResult<ClassReport>.Ok(new ClassReport(
            cls,
            cls.ClassTeacherId is { } t ? db.TeacherName(t) : "—",
            students.Count,
            GradeService.Average(grades),
            subjectAverages,
            grades.Count,
            AttendanceService.Summarize(attendance),
            GradeDistribution.From(grades.Select(g => g.Value)),
            subjectAverages.OrderByDescending(s => s.GradeCount).Take(3).ToList(),
            UpcomingHomework(db.Homework.Where(h => h.ClassId == classId)),
            students.Select(s => new StudentAverage(s.Id, s.FullName, GradeService.Average(grades.Where(g => g.StudentId == s.Id)))).ToList()));
    }

    public OperationResult<TeacherReport> GenerateTeacherReport(Guid teacherId)
    {
        var auth = _ctx.Authorization.RequireAuthenticated();
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var db = _ctx.Db;
        var teacher = db.FindTeacher(teacherId);
        if (teacher is null)
        {
            return new Error(ErrorKind.NotFound, ErrorCodes.NotFound, "Учителят не е намерен.");
        }

        if (!_ctx.Authorization.IsAdmin && _ctx.Session.TeacherId != teacherId)
        {
            return new Error(ErrorKind.Forbidden, ErrorCodes.Forbidden, "Нямате достъп до тази справка.");
        }

        var assignments = db.TeacherAssignments.Where(a => a.TeacherId == teacherId).ToList();
        return OperationResult<TeacherReport>.Ok(new TeacherReport(
            teacher,
            assignments.Select(a => db.ClassName(a.ClassId)).Distinct().OrderBy(n => n, StringComparer.CurrentCulture).ToList(),
            assignments.Select(a => db.SubjectName(a.SubjectId)).Distinct().OrderBy(n => n, StringComparer.CurrentCulture).ToList(),
            db.Lessons.Count(l => l.TeacherId == teacherId && l.Status == LessonStatus.Held),
            db.Grades.Count(g => g.TeacherId == teacherId),
            db.Homework.Count(h => h.TeacherId == teacherId && h.IsActive)));
    }

    /// <summary>Admin: whole school. Teacher: restricted to the classes they teach. Students: not allowed.</summary>
    public OperationResult<SchoolStatistics> GetSchoolStatistics()
    {
        var auth = _ctx.Authorization.RequireRole(UserRole.Administrator, UserRole.Teacher);
        return auth.Success ? OperationResult<SchoolStatistics>.Ok(BuildStatistics(ScopeClassIds())) : auth.Error!;
    }

    public OperationResult<SubjectPerformance> GetSubjectPerformance(Guid subjectId)
    {
        var auth = _ctx.Authorization.RequireRole(UserRole.Administrator, UserRole.Teacher);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var db = _ctx.Db;
        if (db.FindSubject(subjectId) is not { } subject)
        {
            return new Error(ErrorKind.NotFound, ErrorCodes.NotFound, "Предметът не е намерен.");
        }

        var scope = ScopeClassIds();
        var grades = InTerm(db.Grades.Where(g => g.SubjectId == subjectId && (scope is null || scope.Contains(g.ClassId))), g => g.Date, null).ToList();
        return OperationResult<SubjectPerformance>.Ok(new SubjectPerformance(subject.Name, GradeService.Average(grades), grades.Count, GradeDistribution.From(grades.Select(g => g.Value))));
    }

    public OperationResult<AttendanceSummary> GetAttendanceStatistics(Guid? classId = null)
    {
        var auth = classId is { } id ? RequireStaffForClass(id) : _ctx.Authorization.RequireRole(UserRole.Administrator, UserRole.Teacher);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var scope = classId is { } c ? new HashSet<Guid> { c } : ScopeClassIds();
        return OperationResult<AttendanceSummary>.Ok(AttendanceInScope(scope));
    }

    public OperationResult<AdminDashboard> GetAdminDashboard()
    {
        var auth = _ctx.Authorization.RequireAdmin();
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var year = _ctx.ActiveYear;
        var today = _ctx.Clock.Today;
        return OperationResult<AdminDashboard>.Ok(new AdminDashboard(
            BuildStatistics(null),
            _ctx.Audit.GetRecentUnchecked(8),
            _events.GetUpcoming().Take(RecentCount).ToList(),
            year?.Name,
            year is not null && year.Contains(today) ? year.GetTerm(today) : null));
    }

    public OperationResult<TeacherDashboard> GetTeacherDashboard()
    {
        var auth = _ctx.Authorization.RequireRole(UserRole.Teacher);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var db = _ctx.Db;
        var teacherId = _ctx.Session.TeacherId!.Value;
        var today = _ctx.Clock.Today;
        var todayRows = _timetable.GetTodayForCurrentUser();
        var recorded = db.Lessons
            .Where(l => l.Date == today && l.Status == LessonStatus.Held && l.TimetableEntryId is not null)
            .Select(l => l.TimetableEntryId!.Value)
            .ToHashSet();

        var recentGrades = db.Grades.Where(g => g.TeacherId == teacherId)
            .OrderByDescending(g => g.CreatedAtUtc).ThenByDescending(g => g.Date).Take(RecentCount)
            .Select(g => new GradeView(g.Id, g.StudentId, db.StudentName(g.StudentId), g.SubjectId, db.SubjectName(g.SubjectId), g.Value, g.Date, g.GradeType, g.Comment, g.TeacherId, db.TeacherName(g.TeacherId)))
            .ToList();

        var recentAbsences = db.AttendanceRecords
            .Where(a => a.RecordedByTeacherId == teacherId && a.Status != AttendanceStatus.Present)
            .OrderByDescending(a => a.RecordedAtUtc).Take(RecentCount)
            .Select(a =>
            {
                var lesson = db.FindLesson(a.LessonId)!;
                return new AttendanceView(a.Id, a.StudentId, db.StudentName(a.StudentId), lesson.Id, lesson.Date, lesson.LessonNumber,
                    db.ClassName(lesson.ClassId), db.SubjectName(lesson.SubjectId), a.Status, a.Note);
            })
            .ToList();

        return OperationResult<TeacherDashboard>.Ok(new TeacherDashboard(
            db.FindTeacher(teacherId)!,
            todayRows,
            todayRows.Where(r => recorded.Contains(r.EntryId)).Select(r => r.EntryId).ToHashSet(),
            _ctx.Authorization.TaughtClassIds()
                .Select(id => new ClassSize(id, db.ClassName(id), db.ActiveStudentsOf(id).Count()))
                .OrderBy(c => c.ClassName, StringComparer.CurrentCulture).ToList(),
            recentGrades,
            recentAbsences,
            _homework.GetUpcomingHomework(),
            _announcements.GetActiveForCurrentUser().Take(3).ToList(),
            _ctx.Notifications.GetUnreadCount()));
    }

    public OperationResult<StudentDashboard> GetStudentDashboard()
    {
        var auth = _ctx.Authorization.RequireRole(UserRole.Student);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        return OperationResult<StudentDashboard>.Ok(new StudentDashboard(
            BuildStudentReport(_ctx.Session.StudentId!.Value, null),
            _ctx.Notifications.GetForCurrentUser(unreadOnly: true),
            _events.GetUpcoming(days: 7),
            _announcements.GetActiveForCurrentUser().Take(3).ToList()));
    }

    private StudentReport BuildStudentReport(Guid studentId, Term? term)
    {
        var db = _ctx.Db;
        var student = db.FindStudent(studentId)!;
        var grades = InTerm(db.Grades.Where(g => g.StudentId == studentId), g => g.Date, term).ToList();
        var attendance = InTerm(db.AttendanceRecords.Where(a => a.StudentId == studentId), a => db.FindLesson(a.LessonId)?.Date ?? default, term);
        var isStudent = _ctx.Authorization.IsStudent;
        var today = _ctx.Clock.Today;

        var upcoming = db.Homework.Where(h => h.ClassId == student.ClassId && h.IsActive && h.DueDate >= today)
            .OrderBy(h => h.DueDate)
            .Select(h => new HomeworkView(h.Id, h.ClassId, db.ClassName(h.ClassId), h.SubjectId, db.SubjectName(h.SubjectId), h.TeacherId,
                db.TeacherName(h.TeacherId), h.Title, h.Description, h.AssignedDate, h.DueDate, h.IsActive,
                HomeworkService.ComputeStatus(h, db.HomeworkSubmissions.FirstOrDefault(s => s.HomeworkId == h.Id && s.StudentId == studentId), today),
                db.HomeworkSubmissions.Count(s => s.HomeworkId == h.Id), db.ActiveStudentsOf(h.ClassId).Count()))
            .ToList();

        var feedback = db.Feedback.Where(f => f.StudentId == studentId && (!isStudent || f.IsVisibleToStudent))
            .OrderByDescending(f => f.Date).ThenByDescending(f => f.CreatedAtUtc).Take(RecentCount)
            .Select(f => new FeedbackView(f.Id, f.StudentId, student.FullName, db.TeacherName(f.TeacherId), f.Type, f.Description, f.Date, f.IsVisibleToStudent))
            .ToList();

        return new StudentReport(
            student,
            db.ClassName(student.ClassId),
            GradeService.Average(grades),
            SubjectAverages(db, grades),
            grades.Count,
            grades.OrderByDescending(g => g.Date).ThenByDescending(g => g.CreatedAtUtc).Take(RecentCount)
                .Select(g => new GradeView(g.Id, g.StudentId, student.FullName, g.SubjectId, db.SubjectName(g.SubjectId), g.Value, g.Date, g.GradeType, g.Comment, g.TeacherId, db.TeacherName(g.TeacherId)))
                .ToList(),
            AttendanceService.Summarize(attendance),
            db.TermGrades.Where(t => t.StudentId == studentId && t.AcademicYearId == _ctx.ActiveYear?.Id).OrderBy(t => t.Period).ToList(),
            upcoming,
            feedback,
            AchievementService.Views(db, studentId));
    }

    private SchoolStatistics BuildStatistics(IReadOnlySet<Guid>? scope)
    {
        var db = _ctx.Db;
        bool InScope(Guid classId) => scope is null || scope.Contains(classId);

        var classes = db.Classes.Where(c => c.IsActive && InScope(c.Id))
            .OrderBy(c => c.GradeLevel).ThenBy(c => c.Section, StringComparer.CurrentCulture).ToList();
        var grades = InTerm(db.Grades.Where(g => InScope(g.ClassId)), g => g.Date, null).ToList();
        return new SchoolStatistics(
            db.Students.Count(s => s.IsActive && InScope(s.ClassId)),
            db.Teachers.Count(t => t.IsActive),
            classes.Count,
            db.Subjects.Count(s => s.IsActive),
            db.Homework.Count(h => h.IsActive && h.DueDate >= _ctx.Clock.Today && InScope(h.ClassId)),
            grades.Count,
            GradeService.Average(grades),
            AttendanceInScope(scope),
            classes.Select(c => new ClassAverage(c.Id, c.DisplayName, GradeService.Average(grades.Where(g => g.ClassId == c.Id)))).ToList(),
            GradeDistribution.From(grades.Select(g => g.Value)));
    }

    private AttendanceSummary AttendanceInScope(IReadOnlySet<Guid>? scope)
    {
        var db = _ctx.Db;
        var lessons = db.Lessons.Where(l => scope is null || scope.Contains(l.ClassId)).Select(l => l.Id).ToHashSet();
        return AttendanceService.Summarize(InTerm(db.AttendanceRecords.Where(a => lessons.Contains(a.LessonId)), a => db.FindLesson(a.LessonId)!.Date, null));
    }

    private static IReadOnlyList<SubjectAverage> SubjectAverages(SchoolDatabase db, IEnumerable<Grade> grades)
        => grades.GroupBy(g => g.SubjectId)
            .Select(g => new SubjectAverage(g.Key, db.SubjectName(g.Key), GradeService.Average(g), g.Count()))
            .OrderBy(s => s.SubjectName, StringComparer.CurrentCulture)
            .ToList();

    private IReadOnlyList<HomeworkView> UpcomingHomework(IEnumerable<Homework> homework)
    {
        var db = _ctx.Db;
        var today = _ctx.Clock.Today;
        return homework.Where(h => h.IsActive && h.DueDate >= today).OrderBy(h => h.DueDate)
            .Select(h => new HomeworkView(h.Id, h.ClassId, db.ClassName(h.ClassId), h.SubjectId, db.SubjectName(h.SubjectId), h.TeacherId,
                db.TeacherName(h.TeacherId), h.Title, h.Description, h.AssignedDate, h.DueDate, h.IsActive, null,
                db.HomeworkSubmissions.Count(s => s.HomeworkId == h.Id), db.ActiveStudentsOf(h.ClassId).Count()))
            .ToList();
    }

    /// <summary>
    /// Limits items to one academic year (the active one unless given) and optionally one term.
    /// "Whole year" figures therefore never mix data from different academic years.
    /// </summary>
    private IEnumerable<T> InTerm<T>(IEnumerable<T> items, Func<T, DateOnly> date, Term? term, AcademicYear? year = null)
    {
        year ??= _ctx.ActiveYear;
        if (year is null)
        {
            return term is null ? items : [];
        }

        return items.Where(x => year.Contains(date(x)) && (term is null || year.GetTerm(date(x)) == term));
    }

    /// <summary>A class report covers the academic year the class belongs to (not necessarily the active one).</summary>
    private static AcademicYear? ClassYear(SchoolDatabase db, SchoolClass cls) => db.AcademicYears.FirstOrDefault(y => y.Id == cls.AcademicYearId);

    /// <summary>Null = whole school (administrator); teacher = taught classes.</summary>
    private IReadOnlySet<Guid>? ScopeClassIds() => _ctx.Authorization.IsAdmin ? null : _ctx.Authorization.TaughtClassIds();

    private OperationResult RequireStaffForClass(Guid classId)
    {
        var role = _ctx.Authorization.RequireRole(UserRole.Administrator, UserRole.Teacher);
        if (!role.Success)
        {
            return role;
        }

        return _ctx.Authorization.IsAdmin ? _ctx.Authorization.RequireCanViewClass(classId) : _ctx.Authorization.RequireTeachesClass(classId);
    }
}
