// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Assignments of teachers to classes and subjects – the source of every teacher permission.</summary>
public sealed class TeacherAssignmentService
{
    private readonly ServiceContext _ctx;

    public TeacherAssignmentService(ServiceContext ctx) => _ctx = ctx;

    public OperationResult<IReadOnlyList<AssignmentView>> GetAll()
    {
        var auth = _ctx.Authorization.RequireAdmin();
        return auth.Success ? Views(_ctx.Db.TeacherAssignments) : auth.Error!;
    }

    public OperationResult<IReadOnlyList<AssignmentView>> GetForTeacher(Guid teacherId)
    {
        var auth = _ctx.Authorization.RequireAuthenticated();
        if (!auth.Success)
        {
            return auth.Error!;
        }

        if (!_ctx.Authorization.IsAdmin && _ctx.Session.TeacherId != teacherId)
        {
            return new Error(ErrorKind.Forbidden, ErrorCodes.Forbidden, "Нямате достъп до назначенията на този учител.");
        }

        return Views(_ctx.Db.TeacherAssignments.Where(a => a.TeacherId == teacherId));
    }

    public OperationResult<IReadOnlyList<AssignmentView>> GetForClass(Guid classId)
    {
        var auth = _ctx.Authorization.RequireCanViewClass(classId);
        return auth.Success ? Views(_ctx.Db.TeacherAssignments.Where(a => a.ClassId == classId)) : auth.Error!;
    }

    public OperationResult<TeacherAssignment> Assign(Guid teacherId, Guid classId, Guid subjectId)
    {
        var db = _ctx.Db;
        var check = Check.All(
            _ctx.Authorization.RequireAdmin,
            () => Active(db.FindTeacher(teacherId)?.IsActive, "Учителят"),
            () => Active(db.FindClass(classId)?.IsActive, "Класът"),
            () => Active(db.FindSubject(subjectId)?.IsActive, "Предметът"),
            () => db.TeacherAssignments.Any(a => a.TeacherId == teacherId && a.ClassId == classId && a.SubjectId == subjectId)
                ? OperationResult.Conflict(ErrorCodes.DuplicateAssignment, "Това назначение вече съществува.")
                : OperationResult.Ok());
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(d =>
        {
            var assignment = new TeacherAssignment { TeacherId = teacherId, ClassId = classId, SubjectId = subjectId };
            d.TeacherAssignments.Add(assignment);
            _ctx.Audit.Record(d, "Assignment.Created", nameof(TeacherAssignment), assignment.Id,
                $"{d.TeacherName(teacherId)} преподава {d.SubjectName(subjectId)} в {d.ClassName(classId)}.");
            return OperationResult<TeacherAssignment>.Ok(assignment);
        });
    }

    /// <summary>Removes an assignment only when no timetable entry, lesson, grade or homework depends on it.</summary>
    public OperationResult Remove(Guid assignmentId)
    {
        var auth = _ctx.Authorization.RequireAdmin();
        if (!auth.Success)
        {
            return auth;
        }

        var db = _ctx.Db;
        var a = db.TeacherAssignments.FirstOrDefault(x => x.Id == assignmentId);
        if (a is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Назначението не е намерено.");
        }

        if (HasDependencies(db, a))
        {
            return OperationResult.Conflict(ErrorCodes.HasDependencies,
                "Назначението се използва от разписание, учебни часове, оценки или домашни и не може да бъде премахнато.");
        }

        return _ctx.Uow.Execute(d =>
        {
            d.TeacherAssignments.RemoveAll(x => x.Id == assignmentId);
            _ctx.Audit.Record(d, "Assignment.Removed", nameof(TeacherAssignment), assignmentId,
                $"Премахнато: {d.TeacherName(a.TeacherId)} – {d.SubjectName(a.SubjectId)} в {d.ClassName(a.ClassId)}.");
            return OperationResult.Ok();
        });
    }

    private static bool HasDependencies(SchoolDatabase db, TeacherAssignment a)
        => db.Timetable.Any(x => x.TeacherId == a.TeacherId && x.ClassId == a.ClassId && x.SubjectId == a.SubjectId)
           || db.Lessons.Any(x => x.TeacherId == a.TeacherId && x.ClassId == a.ClassId && x.SubjectId == a.SubjectId)
           || db.Grades.Any(x => x.TeacherId == a.TeacherId && x.ClassId == a.ClassId && x.SubjectId == a.SubjectId)
           || db.Homework.Any(x => x.TeacherId == a.TeacherId && x.ClassId == a.ClassId && x.SubjectId == a.SubjectId);

    private static OperationResult Active(bool? isActive, string what) => isActive switch
    {
        null => OperationResult.NotFound(ErrorCodes.NotFound, $"{what} не е намерен."),
        false => OperationResult.Validation(ErrorCodes.InactiveEntity, $"{what} е деактивиран."),
        true => OperationResult.Ok(),
    };

    private OperationResult<IReadOnlyList<AssignmentView>> Views(IEnumerable<TeacherAssignment> assignments)
    {
        var db = _ctx.Db;
        return OperationResult<IReadOnlyList<AssignmentView>>.Ok(assignments
            .Select(a => new AssignmentView(a.Id, a.TeacherId, db.TeacherName(a.TeacherId), a.ClassId, db.ClassName(a.ClassId), a.SubjectId, db.SubjectName(a.SubjectId)))
            .OrderBy(v => v.ClassName, StringComparer.CurrentCulture).ThenBy(v => v.SubjectName, StringComparer.CurrentCulture)
            .ToList());
    }
}
