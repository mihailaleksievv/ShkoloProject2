// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>School calendar: tests, parent meetings, competitions and other events.</summary>
public sealed class SchoolEventService
{
    private const int MaxDescriptionLength = 1000;
    private readonly ServiceContext _ctx;
    private readonly AnnouncementService _announcements;

    public SchoolEventService(ServiceContext ctx, AnnouncementService announcements)
    {
        _ctx = ctx;
        _announcements = announcements;
    }

    public OperationResult<SchoolEvent> Create(SchoolEventInput input)
    {
        var check = Validate(input);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var ev = new SchoolEvent { CreatedByUserId = _ctx.Session.UserId!.Value };
            Apply(ev, input);
            db.SchoolEvents.Add(ev);
            _ctx.Audit.Record(db, "Event.Created", nameof(SchoolEvent), ev.Id, $"„{ev.Title}“ на {ev.StartDateTime:dd.MM.yyyy HH:mm} ({AnnouncementService.Target(db, ev.TargetClassId)}).");
            return OperationResult<SchoolEvent>.Ok(ev);
        });
    }

    public OperationResult Update(Guid id, SchoolEventInput input)
    {
        var check = Check.All(() => RequireCreatorOrAdmin(id), () => Validate(input));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var ev = db.SchoolEvents.First(e => e.Id == id);
            Apply(ev, input);
            _ctx.Audit.Record(db, "Event.Updated", nameof(SchoolEvent), id, $"Редактирано събитие „{ev.Title}“.");
            return OperationResult.Ok();
        });
    }

    public OperationResult Delete(Guid id)
    {
        var check = RequireCreatorOrAdmin(id);
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var ev = db.SchoolEvents.First(e => e.Id == id);
            db.SchoolEvents.Remove(ev);
            _ctx.Audit.Record(db, "Event.Deleted", nameof(SchoolEvent), id, $"Изтрито събитие „{ev.Title}“.");
            return OperationResult.Ok();
        });
    }

    /// <summary>Events in the current user's scope that have not ended and start within the next <paramref name="days"/> days.</summary>
    public IReadOnlyList<EventView> GetUpcoming(int days = 30)
    {
        var now = _ctx.Clock.LocalNow;
        return Views(Scope().Where(e => e.EndDateTime >= now && e.StartDateTime <= now.AddDays(days)));
    }

    /// <summary>Events overlapping the inclusive date range, in the current user's scope.</summary>
    public IReadOnlyList<EventView> GetByDateRange(DateOnly from, DateOnly to)
    {
        var start = from.ToDateTime(TimeOnly.MinValue);
        var end = to.ToDateTime(TimeOnly.MaxValue);
        return Views(Scope().Where(e => e.StartDateTime <= end && e.EndDateTime >= start));
    }

    public OperationResult<IReadOnlyList<EventView>> GetForClass(Guid classId)
    {
        var auth = _ctx.Authorization.RequireCanViewClass(classId);
        return auth.Success ? OperationResult<IReadOnlyList<EventView>>.Ok(Views(_ctx.Db.SchoolEvents.Where(e => e.TargetClassId == classId))) : auth.Error!;
    }

    private IEnumerable<SchoolEvent> Scope()
    {
        if (!_ctx.Session.IsAuthenticated)
        {
            return [];
        }

        var classes = _announcements.VisibleClassIds(_ctx.Db);
        return _ctx.Db.SchoolEvents.Where(e => classes is null || e.TargetClassId is null || classes.Contains(e.TargetClassId.Value));
    }

    private OperationResult Validate(SchoolEventInput input) => Check.All(
        () => _ctx.Authorization.RequireRole(UserRole.Administrator, UserRole.Teacher),
        () => Check.Text(input.Title, "Заглавие", DomainRules.MaxTitleLength),
        () => Check.Text(input.Description, "Описание", MaxDescriptionLength, required: false),
        () => input.Start < input.End
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.InvalidDateRange, "Началото трябва да е преди края на събитието."),
        () => (_ctx.Authorization.IsAdmin, input.TargetClassId) switch
        {
            (true, { } classId) => _ctx.Authorization.RequireCanViewClass(classId),
            (true, null) => OperationResult.Ok(),
            (false, { } classId) => _ctx.Authorization.RequireTeachesClass(classId),
            (false, null) => OperationResult.Forbidden("Учителите създават събития само за класовете, в които преподават."),
        });

    private OperationResult RequireCreatorOrAdmin(Guid id)
    {
        var ev = _ctx.Db.SchoolEvents.FirstOrDefault(e => e.Id == id);
        if (ev is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Събитието не е намерено.");
        }

        var auth = _ctx.Authorization.RequireAuthenticated();
        if (!auth.Success)
        {
            return auth;
        }

        return _ctx.Authorization.IsAdmin || ev.CreatedByUserId == _ctx.Session.UserId
            ? OperationResult.Ok()
            : OperationResult.Fail(new Error(ErrorKind.Forbidden, ErrorCodes.NotAuthor, "Можете да променяте само събития, които сте създали."));
    }

    private static void Apply(SchoolEvent ev, SchoolEventInput input)
    {
        ev.Title = input.Title.Trim();
        ev.Description = input.Description?.Trim() ?? "";
        ev.StartDateTime = input.Start;
        ev.EndDateTime = input.End;
        ev.TargetClassId = input.TargetClassId;
    }

    private IReadOnlyList<EventView> Views(IEnumerable<SchoolEvent> items)
    {
        var db = _ctx.Db;
        return items.OrderBy(e => e.StartDateTime)
            .Select(e => new EventView(e.Id, e.Title, e.Description, e.StartDateTime, e.EndDateTime, e.TargetClassId,
                AnnouncementService.Target(db, e.TargetClassId), e.CreatedByUserId, db.UserName(e.CreatedByUserId)))
            .ToList();
    }
}
