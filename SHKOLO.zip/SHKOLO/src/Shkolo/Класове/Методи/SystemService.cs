// Owner: Participant 1 – Core Developer
using Shkolo.Application.Abstractions;
using Shkolo.Application.Reports;
using Shkolo.Application.Results;

namespace Shkolo.Application.Services;

/// <summary>Technical information and backup restore (administrators only).</summary>
public sealed class SystemService
{
    private readonly ServiceContext _ctx;
    private readonly IBackupProvider _backups;
    private readonly string _dataFilePath;

    public SystemService(ServiceContext ctx, IBackupProvider backups, string dataFilePath)
    {
        _ctx = ctx;
        _backups = backups;
        _dataFilePath = dataFilePath;
    }

    /// <summary>True after a successful restore: the data in memory is outdated and the application must reload it.</summary>
    public bool RestartRequired { get; private set; }

    public OperationResult<StorageInfo> GetStorageInfo()
    {
        var auth = _ctx.Authorization.RequireAdmin();
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var size = File.Exists(_dataFilePath) ? new FileInfo(_dataFilePath).Length : 0;
        return OperationResult<StorageInfo>.Ok(new StorageInfo(_dataFilePath, size, _ctx.Db.LastSavedAtUtc, _backups.GetBackups(), _ctx.Uow.IsReadOnly));
    }

    /// <summary>
    /// Replaces the data file with a backup. Nothing is written from memory afterwards –
    /// the caller must reload the application (see <see cref="RestartRequired"/>).
    /// </summary>
    public OperationResult RestoreBackup(string backupFileName)
    {
        var auth = _ctx.Authorization.RequireAdmin();
        if (!auth.Success)
        {
            return auth;
        }

        try
        {
            _backups.RestoreBackup(backupFileName);
            RestartRequired = true;
            return OperationResult.Ok();
        }
        catch (DataStoreException ex)
        {
            return OperationResult.Persistence(ex.Message);
        }
    }
}
