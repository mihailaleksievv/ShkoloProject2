﻿// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>
/// Data behind the SHKOLO infographics: attendance per day, attendance pulse, weekly grade trends
/// and the teacher's "needs attention" list. Same permissions as the other reports; active year only.
/// </summary>
public sealed partial class ReportService
{
    private const int AttentionUnexcusedThreshold = 3;
    private const int AttentionWeakGradeDays = 7;
    private const decimal WeakGrade = 3.00m;

    /// <summary>
    /// Counts shown on the start screen before anyone signs in. Deliberately contains no names, grades
    /// or attendance, so it needs no permission check.
    /// </summary>
    public SchoolOverview GetPublicOverview()
    {
        var db = _ctx.Db;
        return new SchoolOverview(
            db.Students.Count(s => s.IsActive),
            db.Teachers.Count(t => t.IsActive),
            db.Classes.Count(c => c.IsActive),
            db.Subjects.Count(s => s.IsActive));
    }

    public OperationResult<IReadOnlyList<DayAttendance>> GetStudentAttendanceDays(Guid studentId, DateOnly from, DateOnly to)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        return auth.Success
            ? OperationResult<IReadOnlyList<DayAttendance>>.Ok(Days(_ctx.Db.AttendanceRecords.Where(a => a.StudentId == studentId), from, to))
            : auth.Error!;
    }

    public OperationResult<IReadOnlyList<DayAttendance>> GetClassAttendanceDays(Guid classId, DateOnly from, DateOnly to)
    {
        var auth = RequireStaffForClass(classId);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var lessons = _ctx.Db.Lessons.Where(l => l.ClassId == classId).Select(l => l.Id).ToHashSet();
        return OperationResult<IReadOnlyList<DayAttendance>>.Ok(Days(_ctx.Db.AttendanceRecords.Where(a => lessons.Contains(a.LessonId)), from, to));
    }

    /// <summary>Share of present-or-late marks on each of the last <paramref name="schoolDays"/> school days (admin: school, teacher: own classes).</summary>
    public OperationResult<IReadOnlyList<DayPresence>> GetAttendancePulse(int schoolDays = 10)
    {
        var auth = _ctx.Authorization.RequireRole(UserRole.Administrator, UserRole.Teacher);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var db = _ctx.Db;
        var scope = ScopeClassIds();
        var lessonDates = db.Lessons.Where(l => scope is null || scope.Contains(l.ClassId)).ToDictionary(l => l.Id, l => l.Date);
        var byDate = db.AttendanceRecords.Where(a => lessonDates.ContainsKey(a.LessonId)).ToLookup(a => lessonDates[a.LessonId]);

        return OperationResult<IReadOnlyList<DayPresence>>.Ok(RecentSchoolDays(schoolDays)
            .Select(d =>
            {
                var records = byDate[d].ToList();
                decimal? share = records.Count == 0
                    ? null
                    : (decimal)records.Count(r => r.Status is AttendanceStatus.Present or AttendanceStatus.Late) / records.Count;
                return new DayPresence(d, share);
            })
            .ToList());
    }

    public OperationResult<IReadOnlyList<WeekAverage>> GetStudentGradeTrend(Guid studentId, int weeks = 6)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        return auth.Success ? OperationResult<IReadOnlyList<WeekAverage>>.Ok(Weekly(_ctx.Db.Grades.Where(g => g.StudentId == studentId), weeks)) : auth.Error!;
    }

    public OperationResult<IReadOnlyList<WeekAverage>> GetClassGradeTrend(Guid classId, int weeks = 6)
    {
        var auth = RequireStaffForClass(classId);
        return auth.Success ? OperationResult<IReadOnlyList<WeekAverage>>.Ok(Weekly(_ctx.Db.Grades.Where(g => g.ClassId == classId), weeks)) : auth.Error!;
    }

    /// <summary>
    /// Students of the teacher's classes with ≥ 3 unexcused absences this year, or a weak grade (&lt; 3,00) in the last 7 days.
    /// Reasons are facts from the gradebook – never judgements about the student.
    /// </summary>
    public OperationResult<IReadOnlyList<AttentionItem>> GetAttentionList()
    {
        var auth = _ctx.Authorization.RequireRole(UserRole.Teacher);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var db = _ctx.Db;
        var year = _ctx.ActiveYear;
        var today = _ctx.Clock.Today;
        var items = new List<AttentionItem>();
        if (year is null)
        {
            return OperationResult<IReadOnlyList<AttentionItem>>.Ok(items);
        }

        var lessonDates = db.Lessons.ToDictionary(l => l.Id, l => l.Date);
        foreach (var classId in _ctx.Authorization.TaughtClassIds())
        {
            foreach (var student in db.ActiveStudentsOf(classId).SortedByName())
            {
                var unexcused = db.AttendanceRecords.Count(a => a.StudentId == student.Id && a.Status == AttendanceStatus.Absent
                    && lessonDates.TryGetValue(a.LessonId, out var d) && year.Contains(d));
                if (unexcused >= AttentionUnexcusedThreshold)
                {
                    items.Add(new AttentionItem(student.Id, student.FullName, db.ClassName(classId), $"{unexcused} неизвинени отсъствия"));
                }

                var weak = db.Grades
                    .Where(g => g.StudentId == student.Id && g.Value < WeakGrade && year.Contains(g.Date)
                                && g.Date >= today.AddDays(-AttentionWeakGradeDays) && g.Date <= today)
                    .OrderByDescending(g => g.Date)
                    .FirstOrDefault();
                if (weak is not null)
                {
                    items.Add(new AttentionItem(student.Id, student.FullName, db.ClassName(classId),
                        $"Слаб {BulgarianNames.Grade(weak.Value)} по {db.SubjectName(weak.SubjectId)} на {weak.Date:dd.MM}"));
                }
            }
        }

        return OperationResult<IReadOnlyList<AttentionItem>>.Ok(items);
    }

    private static DateOnly WeekStartOf(DateOnly date) => date.AddDays(-(((int)date.DayOfWeek + 6) % 7));

    private static bool IsSchoolDay(DateOnly d) => d.DayOfWeek is not DayOfWeek.Saturday and not DayOfWeek.Sunday;

    private IReadOnlyList<DayAttendance> Days(IEnumerable<AttendanceRecord> records, DateOnly from, DateOnly to)
    {
        var lessonDates = _ctx.Db.Lessons.ToDictionary(l => l.Id, l => l.Date);
        var byDate = records.Where(r => lessonDates.ContainsKey(r.LessonId)).ToLookup(r => lessonDates[r.LessonId]);
        var result = new List<DayAttendance>();
        for (var d = from; d <= to; d = d.AddDays(1))
        {
            if (!IsSchoolDay(d))
            {
                continue;
            }

            var day = byDate[d].ToList();
            result.Add(new DayAttendance(d, day.Count == 0 ? null : day.Max(r => Severity(r.Status)) switch
            {
                3 => AttendanceStatus.Absent,
                2 => AttendanceStatus.ExcusedAbsent,
                1 => AttendanceStatus.Late,
                _ => AttendanceStatus.Present,
            }, day.Count));
        }

        return result;
    }

    private static int Severity(AttendanceStatus status) => status switch
    {
        AttendanceStatus.Absent => 3,
        AttendanceStatus.ExcusedAbsent => 2,
        AttendanceStatus.Late => 1,
        _ => 0,
    };

    /// <summary>The last N school days ending today, inside the active year (oldest first).</summary>
    private List<DateOnly> RecentSchoolDays(int count)
    {
        var year = _ctx.ActiveYear;
        var days = new List<DateOnly>();
        if (year is null)
        {
            return days;
        }

        for (var d = _ctx.Clock.Today; days.Count < count && d >= year.StartDate; d = d.AddDays(-1))
        {
            if (IsSchoolDay(d) && year.Contains(d))
            {
                days.Add(d);
            }
        }

        days.Reverse();
        return days;
    }

    private IReadOnlyList<WeekAverage> Weekly(IEnumerable<Grade> grades, int weeks)
    {
        var inYear = InTerm(grades, g => g.Date, null).ToList();
        var lastWeek = WeekStartOf(_ctx.Clock.Today);
        return Enumerable.Range(0, weeks)
            .Select(i => lastWeek.AddDays(-7 * (weeks - 1 - i)))
            .Select(start =>
            {
                var week = inYear.Where(g => g.Date >= start && g.Date < start.AddDays(7)).ToList();
                return new WeekAverage(start, GradeService.Average(week), week.Count);
            })
            .ToList();
    }
}
