// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>
/// The core teacher workflow: open a lesson, take attendance, give grades – stored as ONE unit of work.
/// If any part is invalid nothing is saved, so the gradebook never contains a half-recorded lesson.
/// </summary>
public sealed class LessonWorkflowService
{
    private readonly ServiceContext _ctx;
    private readonly LessonService _lessons;
    private readonly AttendanceService _attendance;
    private readonly GradeService _grades;

    public LessonWorkflowService(ServiceContext ctx, LessonService lessons, AttendanceService attendance, GradeService grades)
    {
        _ctx = ctx;
        _lessons = lessons;
        _attendance = attendance;
        _grades = grades;
    }

    public OperationResult<LessonRecordSummary> RecordLesson(LessonRecordRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);
        var check = _lessons.ValidateNewLesson(_ctx.Db, request.Lesson, request.TimetableEntryId);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var lesson = _lessons.BuildLesson(request.Lesson, request.TimetableEntryId);
            db.Lessons.Add(lesson);

            var marks = request.Attendance.ToList();
            var marked = marks.Select(m => m.StudentId).ToHashSet();
            marks.AddRange(db.ActiveStudentsOf(lesson.ClassId)
                .Where(s => !marked.Contains(s.Id))
                .Select(s => new AttendanceMark(s.Id, AttendanceStatus.Present, null)));

            foreach (var mark in marks)
            {
                var valid = _attendance.ValidateMark(db, lesson, mark);
                if (!valid.Success)
                {
                    return ForStudent(db, mark.StudentId, valid.Error!);
                }

                db.AttendanceRecords.Add(_attendance.BuildRecord(lesson, mark));
            }

            foreach (var g in request.Grades)
            {
                var input = new GradeInput(g.StudentId, lesson.SubjectId, g.Value, lesson.Date, g.Type, g.Comment, lesson.Id);
                var valid = _grades.ValidateNewGrade(db, input);
                if (!valid.Success)
                {
                    return ForStudent(db, g.StudentId, valid.Error!);
                }

                var grade = _grades.BuildGrade(db, input);
                db.Grades.Add(grade);
                _grades.RecordAdded(db, grade);
            }

            var summary = new LessonRecordSummary(
                lesson.Id,
                marks.Count(m => m.Status == AttendanceStatus.Present),
                marks.Count(m => m.Status is AttendanceStatus.Absent or AttendanceStatus.ExcusedAbsent),
                marks.Count(m => m.Status == AttendanceStatus.Late),
                request.Grades.Count);
            _ctx.Audit.Record(db, "Lesson.Recorded", nameof(Lesson), lesson.Id,
                $"{LessonService.Describe(db, lesson)} Отсъстващи: {summary.Absent}, закъснели: {summary.Late}, оценки: {summary.GradesAdded}.");
            return OperationResult<LessonRecordSummary>.Ok(summary);
        });
    }

    /// <summary>Prefixes the error with the student's name so the teacher knows which row to fix.</summary>
    private static OperationResult<LessonRecordSummary> ForStudent(SchoolDatabase db, Guid studentId, Error error)
        => error with { Message = $"{db.StudentName(studentId)}: {error.Message}" };
}
