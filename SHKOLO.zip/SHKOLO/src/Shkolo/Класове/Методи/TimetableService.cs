// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Weekly timetable with conflict detection for classes, teachers and rooms.</summary>
public sealed class TimetableService
{
    private readonly ServiceContext _ctx;

    public TimetableService(ServiceContext ctx) => _ctx = ctx;

    public OperationResult<IReadOnlyList<TimetableRow>> GetForClass(Guid classId)
    {
        var auth = _ctx.Authorization.RequireCanViewClass(classId);
        return auth.Success ? Rows(_ctx.Db.Timetable.Where(t => t.ClassId == classId)) : auth.Error!;
    }

    public OperationResult<IReadOnlyList<TimetableRow>> GetForTeacher(Guid teacherId)
    {
        var auth = _ctx.Authorization.RequireAuthenticated();
        if (!auth.Success)
        {
            return auth.Error!;
        }

        return _ctx.Authorization.IsAdmin || _ctx.Session.TeacherId == teacherId
            ? Rows(_ctx.Db.Timetable.Where(t => t.TeacherId == teacherId))
            : new Error(ErrorKind.Forbidden, ErrorCodes.Forbidden, "Нямате достъп до разписанието на този учител.");
    }

    /// <summary>Admin: whole school. Teacher: own lessons. Student: own class.</summary>
    public IReadOnlyList<TimetableRow> GetForCurrentUser()
    {
        var db = _ctx.Db;
        IEnumerable<TimetableEntry> entries = _ctx.Session.Role switch
        {
            UserRole.Administrator => db.Timetable,
            UserRole.Teacher => db.Timetable.Where(t => t.TeacherId == _ctx.Session.TeacherId),
            UserRole.Student => db.Timetable.Where(t => t.ClassId == db.FindStudent(_ctx.Session.StudentId!.Value)?.ClassId),
            _ => [],
        };
        return Rows(entries).Value!;
    }

    /// <summary>Today's lessons; empty on weekends, outside the active academic year or when there is no active year.</summary>
    public IReadOnlyList<TimetableRow> GetTodayForCurrentUser()
    {
        var today = _ctx.Clock.Today;
        if (_ctx.ActiveYear?.Contains(today) != true)
        {
            return [];
        }

        return GetForCurrentUser().Where(r => r.Day == today.DayOfWeek).ToList();
    }

    public OperationResult<TimetableEntry> AddEntry(TimetableEntryInput input)
    {
        var check = Validate(input, null);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var entry = new TimetableEntry();
            Apply(entry, input);
            db.Timetable.Add(entry);
            _ctx.Audit.Record(db, "Timetable.Created", nameof(TimetableEntry), entry.Id, Describe(input));
            return OperationResult<TimetableEntry>.Ok(entry);
        });
    }

    public OperationResult UpdateEntry(Guid id, TimetableEntryInput input)
    {
        if (_ctx.Db.Timetable.All(t => t.Id != id))
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Записът в разписанието не е намерен.");
        }

        var check = Validate(input, id);
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            Apply(db.Timetable.First(t => t.Id == id), input);
            _ctx.Audit.Record(db, "Timetable.Updated", nameof(TimetableEntry), id, Describe(input));
            return OperationResult.Ok();
        });
    }

    /// <summary>Removes a planned entry. Lessons already held keep their data (their link becomes historical).</summary>
    public OperationResult DeleteEntry(Guid id)
    {
        var auth = _ctx.Authorization.RequireAdmin();
        if (!auth.Success)
        {
            return auth;
        }

        var entry = _ctx.Db.Timetable.FirstOrDefault(t => t.Id == id);
        if (entry is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Записът в разписанието не е намерен.");
        }

        var description = Describe(new TimetableEntryInput(entry.ClassId, entry.SubjectId, entry.TeacherId, entry.DayOfWeek, entry.LessonNumber, entry.Room));
        return _ctx.Uow.Execute(db =>
        {
            db.Timetable.RemoveAll(t => t.Id == id);
            foreach (var lesson in db.Lessons.Where(l => l.TimetableEntryId == id))
            {
                lesson.TimetableEntryId = null;
            }

            _ctx.Audit.Record(db, "Timetable.Deleted", nameof(TimetableEntry), id, description);
            return OperationResult.Ok();
        });
    }

    private OperationResult Validate(TimetableEntryInput input, Guid? existingId)
    {
        var db = _ctx.Db;
        var room = Check.Trimmed(input.Room);
        var others = db.Timetable.Where(t => t.Id != existingId && t.DayOfWeek == input.Day && t.LessonNumber == input.LessonNumber).ToList();
        return Check.All(
            _ctx.Authorization.RequireAdmin,
            () => input.Day is >= DayOfWeek.Monday and <= DayOfWeek.Friday
                ? OperationResult.Ok()
                : OperationResult.Validation(ErrorCodes.InvalidInput, "Разписанието е само за делничните дни."),
            () => db.BellSchedule.Any(s => s.LessonNumber == input.LessonNumber)
                ? OperationResult.Ok()
                : OperationResult.Validation(ErrorCodes.InvalidInput, $"Час №{input.LessonNumber} не съществува в звънеца."),
            () => Check.Text(room, "Стая", 10, required: false),
            () => db.FindClass(input.ClassId)?.IsActive == true && db.FindSubject(input.SubjectId)?.IsActive == true && db.FindTeacher(input.TeacherId)?.IsActive == true
                ? OperationResult.Ok()
                : OperationResult.Validation(ErrorCodes.InactiveEntity, "Класът, предметът и учителят трябва да съществуват и да са активни."),
            () => db.TeacherAssignments.Any(a => a.TeacherId == input.TeacherId && a.ClassId == input.ClassId && a.SubjectId == input.SubjectId)
                ? OperationResult.Ok()
                : OperationResult.Validation(ErrorCodes.NoAssignment, "Учителят няма назначение за този клас и предмет."),
            () => others.Any(t => t.ClassId == input.ClassId)
                ? OperationResult.Conflict(ErrorCodes.TimetableClassConflict, $"Класът {db.ClassName(input.ClassId)} вече има час в този ден и час.")
                : OperationResult.Ok(),
            () => others.Any(t => t.TeacherId == input.TeacherId)
                ? OperationResult.Conflict(ErrorCodes.TimetableTeacherConflict, $"{db.TeacherName(input.TeacherId)} вече преподава в този ден и час.")
                : OperationResult.Ok(),
            () => room is not null && others.Any(t => string.Equals(Check.Trimmed(t.Room), room, StringComparison.OrdinalIgnoreCase))
                ? OperationResult.Conflict(ErrorCodes.TimetableRoomConflict, $"Стая {room} е заета в този ден и час.")
                : OperationResult.Ok());
    }

    private static void Apply(TimetableEntry entry, TimetableEntryInput input)
    {
        entry.ClassId = input.ClassId;
        entry.SubjectId = input.SubjectId;
        entry.TeacherId = input.TeacherId;
        entry.DayOfWeek = input.Day;
        entry.LessonNumber = input.LessonNumber;
        entry.Room = Check.Trimmed(input.Room);
    }

    private string Describe(TimetableEntryInput i)
        => $"{_ctx.Db.ClassName(i.ClassId)}, {i.Day}, час {i.LessonNumber}: {_ctx.Db.SubjectName(i.SubjectId)} – {_ctx.Db.TeacherName(i.TeacherId)}.";

    private OperationResult<IReadOnlyList<TimetableRow>> Rows(IEnumerable<TimetableEntry> entries)
    {
        var db = _ctx.Db;
        var slots = db.BellSchedule.ToDictionary(s => s.LessonNumber);
        return OperationResult<IReadOnlyList<TimetableRow>>.Ok(entries
            .Select(t =>
            {
                slots.TryGetValue(t.LessonNumber, out var slot);
                return new TimetableRow(t.Id, t.DayOfWeek, t.LessonNumber, slot?.StartTime ?? default, slot?.EndTime ?? default,
                    t.ClassId, db.ClassName(t.ClassId), t.SubjectId, db.SubjectName(t.SubjectId), t.TeacherId, db.TeacherName(t.TeacherId), t.Room);
            })
            .OrderBy(r => r.Day).ThenBy(r => r.LessonNumber).ThenBy(r => r.ClassName, StringComparer.CurrentCulture)
            .ToList());
    }
}
