// Owner: Participant 1 – Core Developer
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Методи за учениците: списък, търсене, добавяне, редакция, деактивиране и активиране.</summary>
public sealed class StudentService
{
    private const int MaxNumberLength = 20;
    private readonly ServiceContext _ctx;

    public StudentService(ServiceContext ctx) => _ctx = ctx;

    /// <summary>Admin: all students. Teacher: students of taught classes. Students are not allowed.</summary>
    public OperationResult<IReadOnlyList<Student>> GetAllStudents(bool includeInactive = false)
    {
        var auth = _ctx.Authorization.RequireRole(UserRole.Administrator, UserRole.Teacher);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var taught = _ctx.Authorization.TaughtClassIds();
        return OperationResult<IReadOnlyList<Student>>.Ok(_ctx.Db.Students
            .Where(s => includeInactive || s.IsActive)
            .Where(s => _ctx.Authorization.IsAdmin || taught.Contains(s.ClassId))
            .SortedByName()
            .ToList());
    }

    public OperationResult<Student> GetStudentById(Guid id)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(id);
        return auth.Success ? OperationResult<Student>.Ok(_ctx.Db.FindStudent(id)!) : auth.Error!;
    }

    /// <summary>Matches first, last or full name (case-insensitive) or the exact student number.</summary>
    public OperationResult<IReadOnlyList<Student>> SearchStudents(string query)
    {
        var all = GetAllStudents(includeInactive: true);
        if (!all.Success)
        {
            return all;
        }

        var q = query?.Trim() ?? "";
        return OperationResult<IReadOnlyList<Student>>.Ok(all.Value!
            .Where(s => s.StudentNumber.Equals(q, StringComparison.OrdinalIgnoreCase)
                        || s.FullName.Contains(q, StringComparison.CurrentCultureIgnoreCase)
                        || $"{s.LastName} {s.FirstName}".Contains(q, StringComparison.CurrentCultureIgnoreCase))
            .ToList());
    }

    /// <summary>Class list (admin, or teachers of the class). Students may not list classmates and their e-mails.</summary>
    public OperationResult<IReadOnlyList<Student>> GetStudentsByClass(Guid classId, bool includeInactive = false)
    {
        var auth = _ctx.Authorization.IsAdmin
            ? _ctx.Authorization.RequireCanViewClass(classId)
            : _ctx.Authorization.RequireTeachesClass(classId);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        return OperationResult<IReadOnlyList<Student>>.Ok(_ctx.Db.Students
            .Where(s => s.ClassId == classId && (includeInactive || s.IsActive))
            .SortedByName()
            .ToList());
    }

    public OperationResult<Student> AddStudent(StudentInput input)
    {
        var check = Validate(input, null);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var student = new Student { CreatedAtUtc = _ctx.Clock.UtcNow };
            Apply(student, input);
            db.Students.Add(student);
            _ctx.Audit.Record(db, "Student.Created", nameof(Student), student.Id,
                $"Добавен ученик {student.FullName} (№{student.StudentNumber}) в {db.ClassName(student.ClassId)}.");
            return OperationResult<Student>.Ok(student);
        });
    }

    /// <summary>Edits the profile. Moving to another class keeps old grades attached to the old class.</summary>
    public OperationResult UpdateStudent(Guid id, StudentInput input)
    {
        var check = Check.All(() => Validate(input, id), () => Exists(id));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var student = db.FindStudent(id)!;
            Apply(student, input);
            _ctx.Audit.Record(db, "Student.Updated", nameof(Student), id, $"Редактиран профил на {student.FullName}.");
            return OperationResult.Ok();
        });
    }

    public OperationResult DeactivateStudent(Guid id) => SetActive(id, false);

    public OperationResult ReactivateStudent(Guid id) => SetActive(id, true);

    private OperationResult SetActive(Guid id, bool active)
    {
        var check = Check.All(_ctx.Authorization.RequireAdmin, () => Exists(id));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var student = db.FindStudent(id)!;
            student.IsActive = active;
            if (db.UserOfStudent(id) is { } user)
            {
                user.IsActive = active;
            }

            _ctx.Audit.Record(db, active ? "Student.Reactivated" : "Student.Deactivated", nameof(Student), id,
                $"{(active ? "Активиран" : "Деактивиран")} ученик {student.FullName}.");
            return OperationResult.Ok();
        });
    }

    private OperationResult Exists(Guid id)
        => _ctx.Db.FindStudent(id) is null ? OperationResult.NotFound(ErrorCodes.NotFound, "Ученикът не е намерен.") : OperationResult.Ok();

    private OperationResult Validate(StudentInput input, Guid? existingId) => Check.All(
        _ctx.Authorization.RequireAdmin,
        () => Check.Text(input.StudentNumber, "Ученически номер", MaxNumberLength),
        () => Check.Name(input.FirstName, "Име"),
        () => Check.Name(input.LastName, "Фамилия"),
        () => Check.Email(input.Email, required: false),
        () => _ctx.Db.FindClass(input.ClassId) switch
        {
            null => OperationResult.NotFound(ErrorCodes.NotFound, "Класът не е намерен."),
            { IsActive: false } => OperationResult.Validation(ErrorCodes.InactiveEntity, "Класът е деактивиран."),
            _ => OperationResult.Ok(),
        },
        () => _ctx.Db.Students.Any(s => s.Id != existingId && string.Equals(s.StudentNumber, input.StudentNumber.Trim(), StringComparison.OrdinalIgnoreCase))
            ? OperationResult.Conflict(ErrorCodes.DuplicateStudentNumber, $"Ученически номер „{input.StudentNumber.Trim()}“ вече съществува.")
            : OperationResult.Ok());

    private static void Apply(Student student, StudentInput input)
    {
        student.StudentNumber = input.StudentNumber.Trim();
        student.FirstName = input.FirstName.Trim();
        student.LastName = input.LastName.Trim();
        student.ClassId = input.ClassId;
        student.Email = Check.Trimmed(input.Email);
    }
}
