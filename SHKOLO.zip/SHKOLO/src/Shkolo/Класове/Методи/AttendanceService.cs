// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Методи за присъствията: отбелязване, промяна, справка и обобщение.</summary>
public sealed class AttendanceService
{
    private const int MaxNoteLength = 200;
    private readonly ServiceContext _ctx;

    public AttendanceService(ServiceContext ctx) => _ctx = ctx;

    public OperationResult<AttendanceRecord> RecordAttendance(Guid lessonId, AttendanceMark mark)
    {
        var lesson = _ctx.Db.FindLesson(lessonId);
        if (lesson is null)
        {
            return new Error(ErrorKind.NotFound, ErrorCodes.NotFound, "Учебният час не е намерен.");
        }

        var check = Check.All(() => RequireLessonTeacher(lesson), () => ValidateMark(_ctx.Db, lesson, mark));
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var record = BuildRecord(db.FindLesson(lessonId)!, mark);
            db.AttendanceRecords.Add(record);
            _ctx.Audit.Record(db, "Attendance.Recorded", nameof(AttendanceRecord), record.Id, Describe(db, record));
            return OperationResult<AttendanceRecord>.Ok(record);
        });
    }

    /// <summary>The lesson teacher may set any status; the class teacher may only excuse an unexcused absence.</summary>
    public OperationResult UpdateAttendanceStatus(Guid recordId, AttendanceStatus status, string? note)
    {
        var db = _ctx.Db;
        var record = db.AttendanceRecords.FirstOrDefault(a => a.Id == recordId);
        if (record is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Записът не е намерен.");
        }

        var lesson = db.FindLesson(record.LessonId)!;
        var role = _ctx.Authorization.RequireRole(UserRole.Teacher);
        if (!role.Success)
        {
            return role;
        }

        var isLessonTeacher = lesson.TeacherId == _ctx.Session.TeacherId;
        var isExcuseByClassTeacher = _ctx.Authorization.IsClassTeacherOf(lesson.ClassId)
                                     && record.Status == AttendanceStatus.Absent && status == AttendanceStatus.ExcusedAbsent;
        if (!isLessonTeacher && !isExcuseByClassTeacher)
        {
            return OperationResult.Forbidden("Само учителят на часа може да променя записа; класният ръководител може само да извинява отсъствия.");
        }

        var noteCheck = Check.Text(note, "Бележка", MaxNoteLength, required: false);
        if (!noteCheck.Success)
        {
            return noteCheck;
        }

        return _ctx.Uow.Execute(d =>
        {
            var stored = d.AttendanceRecords.First(a => a.Id == recordId);
            var old = stored.Status;
            stored.Status = status;
            stored.Note = Check.Trimmed(note) ?? stored.Note;
            stored.UpdatedAtUtc = _ctx.Clock.UtcNow;
            _ctx.Audit.Record(d, "Attendance.Updated", nameof(AttendanceRecord), recordId,
                $"{d.StudentName(stored.StudentId)}: {BulgarianNames.Of(old)} → {BulgarianNames.Of(status)}.");
            return OperationResult.Ok();
        });
    }

    public OperationResult<IReadOnlyList<AttendanceView>> GetAttendanceForStudent(Guid studentId, AttendanceFilter? filter = null)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        return auth.Success ? Views(_ctx.Db.AttendanceRecords.Where(a => a.StudentId == studentId), filter) : auth.Error!;
    }

    public OperationResult<IReadOnlyList<AttendanceView>> GetAttendanceForClass(Guid classId, AttendanceFilter? filter = null)
    {
        var auth = RequireStaffForClass(classId);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var lessons = _ctx.Db.Lessons.Where(l => l.ClassId == classId).Select(l => l.Id).ToHashSet();
        return Views(_ctx.Db.AttendanceRecords.Where(a => lessons.Contains(a.LessonId)), filter);
    }

    public OperationResult<AttendanceSummary> GetAttendanceSummary(Guid studentId, Term? term = null)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        return OperationResult<AttendanceSummary>.Ok(Summarize(Filter(_ctx.Db.AttendanceRecords.Where(a => a.StudentId == studentId), new AttendanceFilter(Term: term))));
    }

    /// <summary>Admin: the whole school. Teacher: taught classes. Students use their own attendance instead.</summary>
    public OperationResult<IReadOnlyList<AttendanceView>> GetAttendanceByPeriod(DateOnly from, DateOnly to)
    {
        var role = _ctx.Authorization.RequireRole(UserRole.Administrator, UserRole.Teacher);
        if (!role.Success)
        {
            return role.Error!;
        }

        var taught = _ctx.Authorization.TaughtClassIds();
        var lessons = _ctx.Db.Lessons.Where(l => _ctx.Authorization.IsAdmin || taught.Contains(l.ClassId)).Select(l => l.Id).ToHashSet();
        return Views(_ctx.Db.AttendanceRecords.Where(a => lessons.Contains(a.LessonId)), new AttendanceFilter(From: from, To: to));
    }

    internal static AttendanceSummary Summarize(IEnumerable<AttendanceRecord> records)
    {
        var list = records.ToList();
        return new AttendanceSummary(
            list.Count(a => a.Status == AttendanceStatus.Present),
            list.Count(a => a.Status == AttendanceStatus.Absent),
            list.Count(a => a.Status == AttendanceStatus.ExcusedAbsent),
            list.Count(a => a.Status == AttendanceStatus.Late));
    }

    internal IEnumerable<AttendanceRecord> Filter(IEnumerable<AttendanceRecord> records, AttendanceFilter? filter)
    {
        if (filter is null)
        {
            return records;
        }

        var db = _ctx.Db;
        var year = _ctx.ActiveYear;
        return records.Where(a =>
        {
            var lesson = db.FindLesson(a.LessonId);
            return lesson is not null
                   && (filter.SubjectId is null || lesson.SubjectId == filter.SubjectId)
                   && (filter.From is null || lesson.Date >= filter.From)
                   && (filter.To is null || lesson.Date <= filter.To)
                   && (filter.Term is null || (year is not null && year.Contains(lesson.Date) && year.GetTerm(lesson.Date) == filter.Term));
        });
    }

    /// <summary>Rules for one mark in a lesson; reused by the atomic lesson workflow.</summary>
    internal OperationResult ValidateMark(SchoolDatabase db, Lesson lesson, AttendanceMark mark)
    {
        var student = db.FindStudent(mark.StudentId);
        return Check.All(
            () => lesson.Status == LessonStatus.Held
                ? OperationResult.Ok()
                : OperationResult.Validation(ErrorCodes.LessonCancelled, "Часът е отменен и не приема присъствия."),
            () => student is null
                ? OperationResult.NotFound(ErrorCodes.NotFound, "Ученикът не е намерен.")
                : OperationResult.Ok(),
            () => student!.ClassId == lesson.ClassId && student.IsActive
                ? OperationResult.Ok()
                : OperationResult.Validation(ErrorCodes.StudentNotInClass, $"{student.FullName} не е активен ученик от {db.ClassName(lesson.ClassId)}."),
            () => Check.Text(mark.Note, "Бележка", MaxNoteLength, required: false),
            () => db.AttendanceRecords.Any(a => a.StudentId == mark.StudentId && a.LessonId == lesson.Id)
                ? OperationResult.Conflict(ErrorCodes.DuplicateAttendance, $"За {student!.FullName} вече има запис за този час.")
                : OperationResult.Ok());
    }

    internal AttendanceRecord BuildRecord(Lesson lesson, AttendanceMark mark) => new()
    {
        StudentId = mark.StudentId,
        LessonId = lesson.Id,
        Status = mark.Status,
        Note = Check.Trimmed(mark.Note),
        RecordedByTeacherId = _ctx.Session.TeacherId!.Value,
        RecordedAtUtc = _ctx.Clock.UtcNow,
    };

    private static string Describe(SchoolDatabase db, AttendanceRecord r)
        => $"{db.StudentName(r.StudentId)}: {BulgarianNames.Of(r.Status)}.";

    private OperationResult RequireLessonTeacher(Lesson lesson)
    {
        var role = _ctx.Authorization.RequireRole(UserRole.Teacher);
        if (!role.Success)
        {
            return role;
        }

        return lesson.TeacherId == _ctx.Session.TeacherId
            ? OperationResult.Ok()
            : OperationResult.Forbidden("Присъствия записва само учителят, провел часа.");
    }

    private OperationResult RequireStaffForClass(Guid classId)
    {
        var role = _ctx.Authorization.RequireRole(UserRole.Administrator, UserRole.Teacher);
        if (!role.Success)
        {
            return role;
        }

        return _ctx.Authorization.IsAdmin ? _ctx.Authorization.RequireCanViewClass(classId) : _ctx.Authorization.RequireTeachesClass(classId);
    }

    private OperationResult<IReadOnlyList<AttendanceView>> Views(IEnumerable<AttendanceRecord> records, AttendanceFilter? filter)
    {
        var db = _ctx.Db;
        return OperationResult<IReadOnlyList<AttendanceView>>.Ok(Filter(records, filter)
            .Select(a => (Record: a, Lesson: db.FindLesson(a.LessonId)!))
            .OrderByDescending(x => x.Lesson.Date).ThenByDescending(x => x.Lesson.LessonNumber)
            .Select(x => new AttendanceView(x.Record.Id, x.Record.StudentId, db.StudentName(x.Record.StudentId), x.Lesson.Id, x.Lesson.Date,
                x.Lesson.LessonNumber, db.ClassName(x.Lesson.ClassId), db.SubjectName(x.Lesson.SubjectId), x.Record.Status, x.Record.Note))
            .ToList());
    }
}
