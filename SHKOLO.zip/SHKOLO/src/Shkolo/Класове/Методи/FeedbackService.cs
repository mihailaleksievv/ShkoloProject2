// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>Методи за похвалите и забележките.</summary>
public sealed class FeedbackService
{
    private readonly ServiceContext _ctx;

    public FeedbackService(ServiceContext ctx) => _ctx = ctx;

    public OperationResult<Feedback> AddPraise(Guid studentId, string description, DateOnly date, bool visibleToStudent = true)
        => Add(FeedbackType.Praise, studentId, description, date, visibleToStudent);

    public OperationResult<Feedback> AddRemark(Guid studentId, string description, DateOnly date, bool visibleToStudent = true)
        => Add(FeedbackType.Remark, studentId, description, date, visibleToStudent);

    /// <summary>Students see only feedback marked visible to them; staff see everything they may view.</summary>
    public OperationResult<IReadOnlyList<FeedbackView>> GetForStudent(Guid studentId, FeedbackType? type = null)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        return Views(_ctx.Db.Feedback.Where(f => f.StudentId == studentId
                                                 && (type is null || f.Type == type)
                                                 && (!_ctx.Authorization.IsStudent || f.IsVisibleToStudent)));
    }

    public OperationResult<IReadOnlyList<FeedbackView>> GetByTeacher(Guid teacherId)
    {
        var auth = _ctx.Authorization.RequireAuthenticated();
        if (!auth.Success)
        {
            return auth.Error!;
        }

        return _ctx.Authorization.IsAdmin || _ctx.Session.TeacherId == teacherId
            ? Views(_ctx.Db.Feedback.Where(f => f.TeacherId == teacherId))
            : new Error(ErrorKind.Forbidden, ErrorCodes.Forbidden, "Нямате достъп до тези записи.");
    }

    private OperationResult<Feedback> Add(FeedbackType type, Guid studentId, string description, DateOnly date, bool visibleToStudent)
    {
        var check = Check.All(
            () => _ctx.Authorization.RequireRole(UserRole.Teacher),
            () => _ctx.Authorization.RequireCanViewStudent(studentId),
            () => _ctx.Db.FindStudent(studentId)!.IsActive
                ? OperationResult.Ok()
                : OperationResult.Validation(ErrorCodes.InactiveEntity, "Ученикът е деактивиран."),
            () => Check.Text(description, "Текст", DomainRules.MaxFeedbackLength),
            () => _ctx.RequireActiveYearContaining(date),
            () => _ctx.RequireNotFuture(date));
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var feedback = new Feedback
            {
                StudentId = studentId,
                TeacherId = _ctx.Session.TeacherId!.Value,
                Type = type,
                Description = description.Trim(),
                Date = date,
                IsVisibleToStudent = visibleToStudent,
                CreatedAtUtc = _ctx.Clock.UtcNow,
            };
            db.Feedback.Add(feedback);
            var title = BulgarianNames.Of(type);
            _ctx.Audit.Record(db, "Feedback.Created", nameof(Feedback), feedback.Id, $"{title} за {db.StudentName(studentId)}.");
            if (visibleToStudent)
            {
                _ctx.Notifications.NotifyStudent(db, studentId, NotificationType.NewFeedback, $"Нова {title.ToLowerInvariant()}",
                    $"{db.TeacherName(feedback.TeacherId)}: {feedback.Description}", feedback.Id);
            }

            return OperationResult<Feedback>.Ok(feedback);
        });
    }

    private OperationResult<IReadOnlyList<FeedbackView>> Views(IEnumerable<Feedback> items)
    {
        var db = _ctx.Db;
        return OperationResult<IReadOnlyList<FeedbackView>>.Ok(items
            .OrderByDescending(f => f.Date).ThenByDescending(f => f.CreatedAtUtc)
            .Select(f => new FeedbackView(f.Id, f.StudentId, db.StudentName(f.StudentId), db.TeacherName(f.TeacherId), f.Type, f.Description, f.Date, f.IsVisibleToStudent))
            .ToList());
    }
}
