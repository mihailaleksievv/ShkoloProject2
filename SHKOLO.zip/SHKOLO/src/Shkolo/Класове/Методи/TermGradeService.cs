// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>
/// Official term and annual grades. The system suggests a value from current grades; the teacher decides.
/// </summary>
public sealed class TermGradeService
{
    private readonly ServiceContext _ctx;

    public TermGradeService(ServiceContext ctx) => _ctx = ctx;

    public OperationResult<int?> GetSuggestedValue(Guid studentId, Guid subjectId, TermPeriod period)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var year = _ctx.ActiveYear;
        if (year is null)
        {
            return new Error(ErrorKind.Validation, ErrorCodes.NoActiveYear, "Няма активна учебна година.");
        }

        return OperationResult<int?>.Ok(Suggest(_ctx.Db, year, studentId, subjectId, period));
    }

    public OperationResult<TermGrade> SetTermGrade(Guid studentId, Guid subjectId, TermPeriod period, int value)
    {
        var db = _ctx.Db;
        var student = db.FindStudent(studentId);
        if (student is null)
        {
            return new Error(ErrorKind.NotFound, ErrorCodes.NotFound, "Ученикът не е намерен.");
        }

        var year = _ctx.ActiveYear;
        var check = Check.All(
            () => _ctx.Authorization.RequireTeachingAssignment(student.ClassId, subjectId),
            () => DomainRules.IsValidTermGrade(value)
                ? OperationResult.Ok()
                : OperationResult.Validation(ErrorCodes.InvalidGrade, "Срочната и годишната оценка е цяло число от 2 до 6."),
            () => year is null ? OperationResult.Validation(ErrorCodes.NoActiveYear, "Няма активна учебна година.") : OperationResult.Ok(),
            () => PeriodGrades(db, year!, studentId, subjectId, period).Any()
                ? OperationResult.Ok()
                : OperationResult.Validation(ErrorCodes.NoGradesForPeriod, $"Няма текущи оценки за периода ({BulgarianNames.Of(period)})."));
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(d =>
        {
            var record = d.TermGrades.FirstOrDefault(t => t.StudentId == studentId && t.SubjectId == subjectId && t.AcademicYearId == year!.Id && t.Period == period);
            if (record is null)
            {
                record = new TermGrade { StudentId = studentId, SubjectId = subjectId, AcademicYearId = year!.Id, Period = period };
                d.TermGrades.Add(record);
            }

            record.ClassId = student.ClassId;
            record.Value = value;
            record.TeacherId = _ctx.Session.TeacherId!.Value;
            record.RecordedAtUtc = _ctx.Clock.UtcNow;

            var text = $"{d.SubjectName(subjectId)} – {BulgarianNames.Of(period)}: {value}";
            _ctx.Audit.Record(d, "TermGrade.Set", nameof(TermGrade), record.Id, $"{d.StudentName(studentId)}, {text}.");
            _ctx.Notifications.NotifyStudent(d, studentId, NotificationType.NewTermGrade, "Срочна/годишна оценка", text, record.Id);
            return OperationResult<TermGrade>.Ok(record);
        });
    }

    public OperationResult<IReadOnlyList<TermGrade>> GetTermGradesForStudent(Guid studentId)
    {
        var auth = _ctx.Authorization.RequireCanViewStudent(studentId);
        return auth.Success
            ? OperationResult<IReadOnlyList<TermGrade>>.Ok(_ctx.Db.TermGrades.Where(t => t.StudentId == studentId).OrderBy(t => t.Period).ToList())
            : auth.Error!;
    }

    /// <summary>Every active student of the class with current average, suggestion and the assigned grade.</summary>
    public OperationResult<IReadOnlyList<TermGradeRow>> GetTermGradeSheet(Guid classId, Guid subjectId, TermPeriod period)
    {
        var auth = _ctx.Authorization.IsAdmin ? _ctx.Authorization.RequireCanViewClass(classId) : _ctx.Authorization.RequireTeachesClass(classId);
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var year = _ctx.ActiveYear;
        if (year is null)
        {
            return new Error(ErrorKind.Validation, ErrorCodes.NoActiveYear, "Няма активна учебна година.");
        }

        var db = _ctx.Db;
        return OperationResult<IReadOnlyList<TermGradeRow>>.Ok(db.ActiveStudentsOf(classId).SortedByName()
            .Select(s => new TermGradeRow(
                s.Id,
                s.FullName,
                GradeService.Average(PeriodGrades(db, year, s.Id, subjectId, period)),
                Suggest(db, year, s.Id, subjectId, period),
                db.TermGrades.FirstOrDefault(t => t.StudentId == s.Id && t.SubjectId == subjectId && t.AcademicYearId == year.Id && t.Period == period)?.Value))
            .ToList());
    }

    private static IEnumerable<Grade> PeriodGrades(SchoolDatabase db, AcademicYear year, Guid studentId, Guid subjectId, TermPeriod period)
        => db.Grades.Where(g => g.StudentId == studentId && g.SubjectId == subjectId && year.Contains(g.Date)
                                && period switch
                                {
                                    TermPeriod.FirstTerm => year.GetTerm(g.Date) == Term.First,
                                    TermPeriod.SecondTerm => year.GetTerm(g.Date) == Term.Second,
                                    _ => true,
                                });

    private static int? Suggest(SchoolDatabase db, AcademicYear year, Guid studentId, Guid subjectId, TermPeriod period)
    {
        if (period == TermPeriod.Annual)
        {
            var terms = db.TermGrades
                .Where(t => t.StudentId == studentId && t.SubjectId == subjectId && t.AcademicYearId == year.Id && t.Period != TermPeriod.Annual)
                .ToList();
            if (terms.Count == 2)
            {
                return DomainRules.RoundToTermGrade(terms.Sum(t => t.Value) / 2m);
            }
        }

        var average = GradeService.Average(PeriodGrades(db, year, studentId, subjectId, period));
        return average is { } a ? DomainRules.RoundToTermGrade(a) : null;
    }
}
