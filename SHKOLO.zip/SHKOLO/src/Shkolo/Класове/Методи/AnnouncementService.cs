// Owner: Participant 1 – Core Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Services;

/// <summary>School-wide and class announcements.</summary>
public sealed class AnnouncementService
{
    internal const string WholeSchool = "Цялото училище";
    private const int MaxBodyLength = 2000;
    private readonly ServiceContext _ctx;

    public AnnouncementService(ServiceContext ctx) => _ctx = ctx;

    public OperationResult<Announcement> Publish(AnnouncementInput input)
    {
        var check = Validate(input);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var announcement = new Announcement
            {
                Title = input.Title.Trim(),
                Body = input.Body.Trim(),
                AuthorUserId = _ctx.Session.UserId!.Value,
                TargetClassId = input.TargetClassId,
                PublishedAtUtc = _ctx.Clock.UtcNow,
            };
            db.Announcements.Add(announcement);
            _ctx.Audit.Record(db, "Announcement.Published", nameof(Announcement), announcement.Id, $"„{announcement.Title}“ → {Target(db, announcement.TargetClassId)}.");
            if (input.TargetClassId is { } classId)
            {
                _ctx.Notifications.NotifyClass(db, classId, NotificationType.NewAnnouncement, "Ново съобщение", announcement.Title, announcement.Id);
            }
            else
            {
                _ctx.Notifications.NotifyAll(db, announcement.AuthorUserId, NotificationType.NewAnnouncement, "Ново съобщение", announcement.Title, announcement.Id);
            }

            return OperationResult<Announcement>.Ok(announcement);
        });
    }

    public OperationResult Update(Guid id, AnnouncementInput input)
    {
        var check = Check.All(() => RequireAuthorOrAdmin(id), () => Validate(input));
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var a = db.Announcements.First(x => x.Id == id);
            a.Title = input.Title.Trim();
            a.Body = input.Body.Trim();
            a.TargetClassId = input.TargetClassId;
            _ctx.Audit.Record(db, "Announcement.Updated", nameof(Announcement), id, $"Редактирано съобщение „{a.Title}“.");
            return OperationResult.Ok();
        });
    }

    public OperationResult Archive(Guid id)
    {
        var check = RequireAuthorOrAdmin(id);
        if (!check.Success)
        {
            return check;
        }

        return _ctx.Uow.Execute(db =>
        {
            var a = db.Announcements.First(x => x.Id == id);
            a.IsActive = false;
            _ctx.Audit.Record(db, "Announcement.Archived", nameof(Announcement), id, $"Архивирано съобщение „{a.Title}“.");
            return OperationResult.Ok();
        });
    }

    /// <summary>Student: school-wide + own class. Teacher: school-wide + taught classes + own. Admin: all. Newest first.</summary>
    public IReadOnlyList<AnnouncementView> GetActiveForCurrentUser()
    {
        var db = _ctx.Db;
        var classes = VisibleClassIds(db);
        return Views(db, db.Announcements.Where(a => a.IsActive
            && (classes is null || a.TargetClassId is null || classes.Contains(a.TargetClassId.Value) || a.AuthorUserId == _ctx.Session.UserId)));
    }

    public OperationResult<IReadOnlyList<AnnouncementView>> GetForClass(Guid classId)
    {
        var auth = _ctx.Authorization.RequireCanViewClass(classId);
        return auth.Success
            ? OperationResult<IReadOnlyList<AnnouncementView>>.Ok(Views(_ctx.Db, _ctx.Db.Announcements.Where(a => a.IsActive && a.TargetClassId == classId)))
            : auth.Error!;
    }

    internal static string Target(SchoolDatabase db, Guid? classId) => classId is { } id ? db.ClassName(id) : WholeSchool;

    /// <summary>Null means "every class" (administrator); not authenticated sees school-wide only.</summary>
    internal IReadOnlySet<Guid>? VisibleClassIds(SchoolDatabase db) => _ctx.Session.Role switch
    {
        UserRole.Administrator => null,
        UserRole.Teacher => _ctx.Authorization.TaughtClassIds(),
        UserRole.Student => db.Students.Where(s => s.Id == _ctx.Session.StudentId).Select(s => s.ClassId).ToHashSet(),
        _ => new HashSet<Guid>(),
    };

    internal static IReadOnlyList<AnnouncementView> Views(SchoolDatabase db, IEnumerable<Announcement> items)
        => items.OrderByDescending(a => a.PublishedAtUtc)
            .Select(a => new AnnouncementView(a.Id, a.Title, a.Body, a.AuthorUserId, db.UserName(a.AuthorUserId), a.TargetClassId,
                Target(db, a.TargetClassId), a.PublishedAtUtc, a.IsActive))
            .ToList();

    private OperationResult Validate(AnnouncementInput input) => Check.All(
        () => _ctx.Authorization.RequireRole(UserRole.Administrator, UserRole.Teacher),
        () => Check.Text(input.Title, "Заглавие", DomainRules.MaxTitleLength),
        () => Check.Text(input.Body, "Текст", MaxBodyLength),
        () => input.TargetClassId is { } classId
            ? (_ctx.Authorization.IsAdmin ? _ctx.Authorization.RequireCanViewClass(classId) : _ctx.Authorization.RequireTeachesClass(classId))
            : OperationResult.Ok());

    private OperationResult RequireAuthorOrAdmin(Guid id)
    {
        var a = _ctx.Db.Announcements.FirstOrDefault(x => x.Id == id);
        if (a is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Съобщението не е намерено.");
        }

        var auth = _ctx.Authorization.RequireAuthenticated();
        if (!auth.Success)
        {
            return auth;
        }

        return _ctx.Authorization.IsAdmin || a.AuthorUserId == _ctx.Session.UserId
            ? OperationResult.Ok()
            : OperationResult.Fail(new Error(ErrorKind.Forbidden, ErrorCodes.NotAuthor, "Можете да променяте само собствените си съобщения."));
    }
}
