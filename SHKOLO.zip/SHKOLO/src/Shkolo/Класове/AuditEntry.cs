// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Models;

/// <summary>Запис в историята на действията: кой, какво и кога е направил.</summary>
public sealed class AuditEntry
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid? UserId { get; set; }
    public string Action { get; set; } = "";
    public string EntityType { get; set; } = "";
    public Guid? EntityId { get; set; }
    public DateTime OccurredAtUtc { get; set; }
    public string Summary { get; set; } = "";
}
