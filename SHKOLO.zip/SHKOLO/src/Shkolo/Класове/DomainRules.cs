// Owner: Participant 1 – Core Developer
using System.Net.Mail;

namespace Shkolo.Domain;

/// <summary>
/// Pure, reusable business rules. Kept in one place so services never duplicate the same check.
/// </summary>
public static class DomainRules
{
    public const decimal MinGrade = 2.00m;
    public const decimal MaxGrade = 6.00m;
    public const int MinTermGrade = 2;
    public const int MaxTermGrade = 6;
    public const int MaxNameLength = 50;
    public const int MaxTopicLength = 200;
    public const int MaxTitleLength = 120;
    public const int MaxFeedbackLength = 500;

    /// <summary>Grade must be within 2.00–6.00 inclusive and have at most two decimals.</summary>
    public static bool IsValidGrade(decimal value)
        => value >= MinGrade && value <= MaxGrade && decimal.Round(value, 2) == value;

    public static bool IsValidTermGrade(int value) => value >= MinTermGrade && value <= MaxTermGrade;

    public static bool IsNameValid(string? name)
        => !string.IsNullOrWhiteSpace(name) && name.Trim().Length <= MaxNameLength;

    /// <summary>Accepts a plain address only (no display name), surrounding whitespace is ignored.</summary>
    public static bool IsEmailValid(string? email)
    {
        if (string.IsNullOrWhiteSpace(email))
        {
            return false;
        }

        var trimmed = email.Trim();
        return MailAddress.TryCreate(trimmed, out var address) && address.Address == trimmed;
    }

    /// <summary>Rounding used only for display – calculations keep full precision.</summary>
    public static decimal RoundForDisplay(decimal value) => decimal.Round(value, 2, MidpointRounding.AwayFromZero);

    /// <summary>Converts an average to the suggested integer term grade (4.50 → 5, 4.49 → 4).</summary>
    public static int RoundToTermGrade(decimal average)
    {
        var rounded = (int)decimal.Round(average, 0, MidpointRounding.AwayFromZero);
        return Math.Clamp(rounded, MinTermGrade, MaxTermGrade);
    }

    /// <summary>Bulgarian verbal grade for a numeric grade or average.</summary>
    public static string GradeWord(decimal value) => value switch
    {
        < 3.00m => "Слаб",
        < 3.50m => "Среден",
        < 4.50m => "Добър",
        < 5.50m => "Много добър",
        _ => "Отличен",
    };
}
