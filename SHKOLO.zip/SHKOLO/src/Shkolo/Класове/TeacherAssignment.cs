// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Models;

/// <summary>Кой учител кой предмет в кой клас преподава.</summary>
public sealed class TeacherAssignment
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid TeacherId { get; set; }
    public Guid ClassId { get; set; }
    public Guid SubjectId { get; set; }
}
