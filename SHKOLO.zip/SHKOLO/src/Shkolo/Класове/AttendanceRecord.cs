// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Domain.Models;

/// <summary>Присъствие на ученик в конкретен час: присъства, отсъства, извинен или закъснял.</summary>
public sealed class AttendanceRecord
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid StudentId { get; set; }
    public Guid LessonId { get; set; }
    public AttendanceStatus Status { get; set; }
    public string? Note { get; set; }
    public Guid RecordedByTeacherId { get; set; }
    public DateTime RecordedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }
}
