// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Models;

/// <summary>Предаден отговор на ученик по домашна работа.</summary>
public sealed class HomeworkSubmission
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid HomeworkId { get; set; }
    public Guid StudentId { get; set; }
    public string Content { get; set; } = "";
    public DateTime SubmittedAtUtc { get; set; }
}
