// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Domain.Models;

/// <summary>Похвала или забележка от учител към ученик.</summary>
public sealed class Feedback
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid StudentId { get; set; }
    public Guid TeacherId { get; set; }
    public FeedbackType Type { get; set; }
    public string Description { get; set; } = "";
    public DateOnly Date { get; set; }
    public bool IsVisibleToStudent { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; }
}
