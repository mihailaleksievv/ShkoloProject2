// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Domain.Models;

/// <summary>Срочна или годишна оценка (цяло число от 2 до 6).</summary>
public sealed class TermGrade
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid StudentId { get; set; }
    public Guid ClassId { get; set; }
    public Guid SubjectId { get; set; }
    public Guid AcademicYearId { get; set; }
    public TermPeriod Period { get; set; }
    public int Value { get; set; }
    public Guid TeacherId { get; set; }
    public DateTime RecordedAtUtc { get; set; }
}
