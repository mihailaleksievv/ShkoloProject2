// Owner: Participant 1 – Core Developer
using System.Text.Json.Serialization;

namespace Shkolo.Domain.Models;

/// <summary>Учител: име, имейл и дали е активен.</summary>
public sealed class Teacher
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string EmployeeNumber { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string Email { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; }

    [JsonIgnore]
    public string FullName => $"{FirstName} {LastName}";
}
