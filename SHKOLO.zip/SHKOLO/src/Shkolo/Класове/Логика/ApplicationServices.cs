// Owner: Participant 1 – Core Developer
using Shkolo.Application.Abstractions;
using Shkolo.Application.Security;
using Shkolo.Application.Services;

namespace Shkolo.Application;

/// <summary>
/// Creates and exposes every application service. The presentation layer depends only on this facade
/// and never touches the collections or the storage directly.
/// </summary>
public sealed class ApplicationServices
{
    public ApplicationServices(
        IUnitOfWork uow,
        SessionContext session,
        IClock clock,
        IPasswordHasher hasher,
        IReportExporter exporter,
        IBackupProvider backups,
        string dataFilePath)
    {
        Session = session;
        Clock = clock;
        Authorization = new AuthorizationService(uow, session);
        Audit = new AuditService(uow, session, clock, Authorization);
        Notifications = new NotificationService(uow, session, clock);
        var ctx = new ServiceContext(uow, session, clock, Authorization, Audit, Notifications);

        Auth = new AuthService(ctx, hasher);
        AcademicYears = new AcademicYearService(ctx);
        BellSchedule = new BellScheduleService(ctx);
        Subjects = new SubjectService(ctx);
        Teachers = new TeacherService(ctx);
        Classes = new ClassService(ctx);
        Assignments = new TeacherAssignmentService(ctx);
        Students = new StudentService(ctx);
        Timetable = new TimetableService(ctx);
        Lessons = new LessonService(ctx);
        Grades = new GradeService(ctx);
        TermGrades = new TermGradeService(ctx);
        Attendance = new AttendanceService(ctx);
        LessonWorkflow = new LessonWorkflowService(ctx, Lessons, Attendance, Grades);
        Feedback = new FeedbackService(ctx);
        Achievements = new AchievementService(ctx);
        Homework = new HomeworkService(ctx);
        Announcements = new AnnouncementService(ctx);
        Events = new SchoolEventService(ctx, Announcements);
        Reports = new ReportService(ctx, Homework, Announcements, Events, Timetable);
        Export = new ExportService(Reports, exporter);
        System = new SystemService(ctx, backups, dataFilePath);
    }

    public ExportService Export { get; }

    public SystemService System { get; }

    public ReportService Reports { get; }

    public AnnouncementService Announcements { get; }

    public SchoolEventService Events { get; }

    public HomeworkService Homework { get; }

    public FeedbackService Feedback { get; }

    public AchievementService Achievements { get; }

    public LessonWorkflowService LessonWorkflow { get; }

    public AttendanceService Attendance { get; }

    public TermGradeService TermGrades { get; }

    public GradeService Grades { get; }

    public LessonService Lessons { get; }

    public TimetableService Timetable { get; }

    public StudentService Students { get; }

    public TeacherService Teachers { get; }

    public ClassService Classes { get; }

    public TeacherAssignmentService Assignments { get; }

    public AcademicYearService AcademicYears { get; }

    public BellScheduleService BellSchedule { get; }

    public SubjectService Subjects { get; }

    public SessionContext Session { get; }

    public IClock Clock { get; }

    public AuthorizationService Authorization { get; }

    public AuditService Audit { get; }

    public NotificationService Notifications { get; }

    public AuthService Auth { get; }
}
