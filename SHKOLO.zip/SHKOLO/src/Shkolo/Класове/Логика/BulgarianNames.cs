// Owner: Participant 1 – Core Developer
using System.Globalization;
using Shkolo.Domain.Enums;

namespace Shkolo.Application;

/// <summary>
/// Bulgarian names of domain values and Bulgarian number/date formatting.
/// Shared by service messages (notifications, audit) and the console UI, so every label exists once.
/// </summary>
public static class BulgarianNames
{
    public static readonly CultureInfo Culture = CultureInfo.GetCultureInfo("bg-BG");

    public static string Of(GradeType type) => type switch
    {
        GradeType.Oral => "Устно изпитване",
        GradeType.WrittenTest => "Писмено изпитване",
        GradeType.Test => "Контролна работа",
        GradeType.Homework => "Домашна работа",
        GradeType.Project => "Проект",
        _ => "Друго",
    };

    public static string Of(AttendanceStatus status) => status switch
    {
        AttendanceStatus.Present => "Присъства",
        AttendanceStatus.Absent => "Неизвинено отсъствие",
        AttendanceStatus.ExcusedAbsent => "Извинено отсъствие",
        _ => "Закъснение",
    };

    public static string Of(UserRole role) => role switch
    {
        UserRole.Administrator => "Администратор",
        UserRole.Teacher => "Учител",
        _ => "Ученик",
    };

    public static string Of(FeedbackType type) => type == FeedbackType.Praise ? "Похвала" : "Забележка";

    public static string Of(LessonStatus status) => status == LessonStatus.Held ? "Проведен" : "Отменен";

    public static string Of(TermPeriod period) => period switch
    {
        TermPeriod.FirstTerm => "I срок",
        TermPeriod.SecondTerm => "II срок",
        _ => "Годишна",
    };

    public static string Of(Term term) => term == Term.First ? "I срок" : "II срок";

    public static string Of(HomeworkStatus status) => status switch
    {
        HomeworkStatus.Pending => "Предстои",
        HomeworkStatus.Submitted => "Предадено",
        HomeworkStatus.SubmittedLate => "Предадено със закъснение",
        _ => "Просрочено",
    };

    public static string Of(DayOfWeek day) => Culture.DateTimeFormat.GetDayName(day) is { Length: > 0 } name
        ? char.ToUpper(name[0], Culture) + name[1..]
        : day.ToString();

    /// <summary>Grade with two decimals and a decimal comma, e.g. 5,50.</summary>
    public static string Grade(decimal value) => value.ToString("0.00", Culture);
}
