// Owner: Participant 1 – Core Developer
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Serialization;
using Shkolo.Application.Abstractions;
using Shkolo.Application.Results;
using Shkolo.Domain;

namespace Shkolo.Application;

/// <summary>
/// Executes every change as a unit: snapshot → mutate → save. When the mutation fails, throws,
/// or the save fails, the in-memory database is restored from the snapshot, so memory and
/// the data file never diverge and a failed operation never leaves half-written data behind.
/// </summary>
public sealed class UnitOfWork : IUnitOfWork
{
    private static readonly JsonSerializerOptions SnapshotOptions = CreateSnapshotOptions();

    private static readonly PropertyInfo[] StateProperties = typeof(SchoolDatabase)
        .GetProperties(BindingFlags.Public | BindingFlags.Instance)
        .Where(p => p.CanRead && p.CanWrite)
        .ToArray();

    private readonly IDataStore _store;

    public UnitOfWork(IDataStore store, SchoolDatabase database, bool isReadOnly = false)
    {
        _store = store;
        Database = database;
        IsReadOnly = isReadOnly;
    }

    public SchoolDatabase Database { get; }

    public bool IsReadOnly { get; }

    public OperationResult Execute(Func<SchoolDatabase, OperationResult> mutation)
        => Run(mutation, r => r, e => OperationResult.Fail(e));

    public OperationResult<T> Execute<T>(Func<SchoolDatabase, OperationResult<T>> mutation)
        => Run(mutation, r => r, e => OperationResult<T>.Fail(e));

    private TResult Run<TResult>(Func<SchoolDatabase, TResult> mutation, Func<TResult, OperationResult> view, Func<Error, TResult> fail)
    {
        ArgumentNullException.ThrowIfNull(mutation);
        if (IsReadOnly)
        {
            return fail(new Error(ErrorKind.Persistence, ErrorCodes.ReadOnlyDatabase,
                "Базата е в режим само за четене поради проблеми в целостта на данните."));
        }

        var snapshot = JsonSerializer.SerializeToUtf8Bytes(Database, SnapshotOptions);
        TResult result;
        try
        {
            result = mutation(Database);
        }
        catch
        {
            // A bug inside a mutation must not leave the database half-changed.
            Restore(snapshot);
            throw;
        }

        if (!view(result).Success)
        {
            Restore(snapshot);
            return result;
        }

        try
        {
            _store.Save(Database);
        }
        catch (DataStoreException ex)
        {
            Restore(snapshot);
            return fail(new Error(ErrorKind.Persistence, ErrorCodes.PersistenceFailed,
                "Промяната не е записана: " + ex.Message));
        }

        return result;
    }

    /// <summary>Copies the snapshot back into the same instance – services keep their reference to it.</summary>
    private void Restore(byte[] snapshot)
    {
        var copy = JsonSerializer.Deserialize<SchoolDatabase>(snapshot, SnapshotOptions)!;
        foreach (var property in StateProperties)
        {
            property.SetValue(Database, property.GetValue(copy));
        }
    }

    private static JsonSerializerOptions CreateSnapshotOptions()
    {
        var options = new JsonSerializerOptions();
        options.Converters.Add(new JsonStringEnumConverter());
        return options;
    }
}
