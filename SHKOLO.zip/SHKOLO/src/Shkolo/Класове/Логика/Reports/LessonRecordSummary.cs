// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Reports;

/// <summary>Result of recording a lesson. Present includes the students marked present by default.</summary>
public sealed record LessonRecordSummary(Guid LessonId, int Present, int Absent, int Late, int GradesAdded);
