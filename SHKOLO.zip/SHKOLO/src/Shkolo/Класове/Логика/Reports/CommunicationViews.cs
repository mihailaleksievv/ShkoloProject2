// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Reports;

/// <summary>Announcement with author name and readable target ("Цялото училище" or a class).</summary>
public sealed record AnnouncementView(
    Guid Id,
    string Title,
    string Body,
    Guid AuthorUserId,
    string AuthorName,
    Guid? TargetClassId,
    string Target,
    DateTime PublishedAtUtc,
    bool IsActive);

/// <summary>School event with creator name and readable target.</summary>
public sealed record EventView(
    Guid Id,
    string Title,
    string Description,
    DateTime Start,
    DateTime End,
    Guid? TargetClassId,
    string Target,
    Guid CreatedByUserId,
    string CreatedByName);
