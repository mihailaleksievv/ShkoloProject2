﻿// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Application.Reports;

/// <summary>Attendance of one school day. Worst: Absent &gt; ExcusedAbsent &gt; Late &gt; Present; null = no lessons that day.</summary>
public sealed record DayAttendance(DateOnly Date, AttendanceStatus? Worst, int Lessons);

/// <summary>Share of present (or late) marks on a school day; null when nothing was recorded.</summary>
public sealed record DayPresence(DateOnly Date, decimal? PresentShare);

/// <summary>Average grade of one week (WeekStart is a Monday); null when there are no grades.</summary>
public sealed record WeekAverage(DateOnly WeekStart, decimal? Average, int GradeCount);

/// <summary>A factual reason a teacher may want to look at a student – never a judgement about the person.</summary>
public sealed record AttentionItem(Guid StudentId, string StudentName, string ClassName, string Reason);

/// <summary>Anonymous school summary for the start screen: only counts, no personal data.</summary>
public sealed record SchoolOverview(int Students, int Teachers, int Classes, int Subjects);
