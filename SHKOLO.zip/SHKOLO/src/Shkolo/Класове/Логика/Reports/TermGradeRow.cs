// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Reports;

/// <summary>One student in the term-grade sheet of a class and subject.</summary>
public sealed record TermGradeRow(Guid StudentId, string StudentName, decimal? CurrentAverage, int? Suggested, int? Assigned);
