// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Reports;

/// <summary>Complete performance report of one student, computed from stored data.</summary>
public sealed record StudentReport(
    Student Student,
    string ClassName,
    decimal? OverallAverage,
    IReadOnlyList<SubjectAverage> SubjectAverages,
    int GradeCount,
    IReadOnlyList<GradeView> RecentGrades,
    AttendanceSummary Attendance,
    IReadOnlyList<TermGrade> TermGrades,
    IReadOnlyList<HomeworkView> UpcomingHomework,
    IReadOnlyList<FeedbackView> RecentFeedback,
    IReadOnlyList<AchievementView> Achievements);

/// <summary>Performance report of one class. Grades are counted by the class they were given in.</summary>
public sealed record ClassReport(
    SchoolClass Class,
    string ClassTeacherName,
    int StudentCount,
    decimal? ClassAverage,
    IReadOnlyList<SubjectAverage> SubjectAverages,
    int GradeCount,
    AttendanceSummary Attendance,
    GradeDistribution Distribution,
    IReadOnlyList<SubjectAverage> MostActiveSubjects,
    IReadOnlyList<HomeworkView> UpcomingHomework,
    IReadOnlyList<StudentAverage> StudentAverages);

/// <summary>Teaching summary of one teacher.</summary>
public sealed record TeacherReport(
    Teacher Teacher,
    IReadOnlyList<string> Classes,
    IReadOnlyList<string> Subjects,
    int LessonsHeld,
    int GradesGiven,
    int ActiveHomework);

/// <summary>School-wide (or, for a teacher, taught-classes) statistics.</summary>
public sealed record SchoolStatistics(
    int ActiveStudents,
    int ActiveTeachers,
    int Classes,
    int Subjects,
    int ActiveHomework,
    int TotalGrades,
    decimal? SchoolAverage,
    AttendanceSummary Attendance,
    IReadOnlyList<ClassAverage> ClassAverages,
    GradeDistribution Distribution);

/// <summary>Performance of one subject across the visible classes.</summary>
public sealed record SubjectPerformance(string SubjectName, decimal? Average, int GradeCount, GradeDistribution Distribution);

public sealed record AdminDashboard(
    SchoolStatistics Stats,
    IReadOnlyList<AuditEntryView> RecentActions,
    IReadOnlyList<EventView> UpcomingEvents,
    string? ActiveYearName,
    Term? CurrentTerm);

public sealed record TeacherDashboard(
    Teacher Teacher,
    IReadOnlyList<TimetableRow> Today,
    IReadOnlySet<Guid> TodayRecordedEntryIds,
    IReadOnlyList<ClassSize> Classes,
    IReadOnlyList<GradeView> RecentGrades,
    IReadOnlyList<AttendanceView> RecentAbsences,
    IReadOnlyList<HomeworkView> ActiveHomework,
    IReadOnlyList<AnnouncementView> RecentAnnouncements,
    int UnreadNotifications);

public sealed record StudentDashboard(
    StudentReport Report,
    IReadOnlyList<Notification> Unread,
    IReadOnlyList<EventView> UpcomingEvents,
    IReadOnlyList<AnnouncementView> RecentAnnouncements);
