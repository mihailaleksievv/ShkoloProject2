// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Application.Reports;

/// <summary>Praise or remark with resolved names.</summary>
public sealed record FeedbackView(
    Guid Id,
    Guid StudentId,
    string StudentName,
    string TeacherName,
    FeedbackType Type,
    string Description,
    DateOnly Date,
    bool IsVisibleToStudent);
