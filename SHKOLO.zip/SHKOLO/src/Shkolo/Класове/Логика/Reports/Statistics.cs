// Owner: Participant 1 – Core Developer
using Shkolo.Domain;

namespace Shkolo.Application.Reports;

/// <summary>Average of one subject. Average is null when there are no grades.</summary>
public sealed record SubjectAverage(Guid SubjectId, string SubjectName, decimal? Average, int GradeCount);

/// <summary>Average of one class (null when the class has no grades).</summary>
public sealed record ClassAverage(Guid ClassId, string ClassName, decimal? Average);

/// <summary>Average of one student within a report scope.</summary>
public sealed record StudentAverage(Guid StudentId, string StudentName, decimal? Average);

/// <summary>Number of active students in a class.</summary>
public sealed record ClassSize(Guid ClassId, string ClassName, int StudentCount);

/// <summary>Count of grades by the Bulgarian verbal scale (Слаб … Отличен).</summary>
public sealed record GradeDistribution(int Poor, int Average, int Good, int VeryGood, int Excellent)
{
    public int Total => Poor + Average + Good + VeryGood + Excellent;

    public static GradeDistribution From(IEnumerable<decimal> values)
    {
        int poor = 0, average = 0, good = 0, veryGood = 0, excellent = 0;
        foreach (var value in values)
        {
            switch (DomainRules.GradeWord(value))
            {
                case "Слаб": poor++; break;
                case "Среден": average++; break;
                case "Добър": good++; break;
                case "Много добър": veryGood++; break;
                default: excellent++; break;
            }
        }

        return new GradeDistribution(poor, average, good, veryGood, excellent);
    }
}

/// <summary>History entry with the user's display name.</summary>
public sealed record AuditEntryView(Guid Id, DateTime OccurredAtUtc, string UserName, string Action, string EntityType, string Summary);
