// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Reports;

/// <summary>Timetable entry with names resolved and times taken from the bell schedule.</summary>
public sealed record TimetableRow(
    Guid EntryId,
    DayOfWeek Day,
    int LessonNumber,
    TimeOnly Start,
    TimeOnly End,
    Guid ClassId,
    string ClassName,
    Guid SubjectId,
    string SubjectName,
    Guid TeacherId,
    string TeacherName,
    string? Room);
