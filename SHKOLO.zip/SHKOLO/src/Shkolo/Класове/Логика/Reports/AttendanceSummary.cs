// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Reports;

/// <summary>
/// Attendance counts kept apart: unexcused and excused absences are never mixed,
/// and late arrivals are not counted as absences.
/// </summary>
public sealed record AttendanceSummary(int Present, int Unexcused, int Excused, int Late)
{
    public static AttendanceSummary Empty { get; } = new(0, 0, 0, 0);

    public int TotalAbsences => Unexcused + Excused;

    public int TotalRecords => Present + Unexcused + Excused + Late;
}
