// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Application.Reports;

/// <summary>Current grade with resolved names, ready for display.</summary>
public sealed record GradeView(
    Guid Id,
    Guid StudentId,
    string StudentName,
    Guid SubjectId,
    string SubjectName,
    decimal Value,
    DateOnly Date,
    GradeType Type,
    string? Comment,
    Guid TeacherId,
    string TeacherName);
