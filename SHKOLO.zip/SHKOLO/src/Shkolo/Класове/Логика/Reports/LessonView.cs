// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Application.Reports;

/// <summary>Held or cancelled lesson with resolved names and record counts.</summary>
public sealed record LessonView(
    Guid Id,
    DateOnly Date,
    int LessonNumber,
    Guid ClassId,
    string ClassName,
    Guid SubjectId,
    string SubjectName,
    Guid TeacherId,
    string TeacherName,
    string Topic,
    string? Notes,
    LessonStatus Status,
    int AttendanceCount,
    int GradeCount);

/// <summary>One student of the lesson's class with the attendance recorded so far (null = not recorded).</summary>
public sealed record RosterEntry(Guid StudentId, string StudentNumber, string FullName, AttendanceStatus? Status);
