// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Reports;

/// <summary>Teacher assignment with resolved names, ready for display.</summary>
public sealed record AssignmentView(Guid Id, Guid TeacherId, string TeacherName, Guid ClassId, string ClassName, Guid SubjectId, string SubjectName);
