// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Reports;

/// <summary>Awarded achievement with badge details and names.</summary>
public sealed record AchievementView(
    Guid Id,
    string Symbol,
    string Name,
    string Description,
    Guid StudentId,
    string StudentName,
    string TeacherName,
    DateTime AssignedAtUtc,
    string? Note);
