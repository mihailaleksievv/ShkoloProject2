// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Application.Reports;

/// <summary>Homework with names, submission counts and – for a student – that student's status.</summary>
public sealed record HomeworkView(
    Guid Id,
    Guid ClassId,
    string ClassName,
    Guid SubjectId,
    string SubjectName,
    Guid TeacherId,
    string TeacherName,
    string Title,
    string Description,
    DateOnly AssignedDate,
    DateOnly DueDate,
    bool IsActive,
    HomeworkStatus? StatusForStudent,
    int SubmissionCount,
    int ClassSize);

/// <summary>One student of the class and the state of their submission.</summary>
public sealed record SubmissionView(Guid StudentId, string StudentName, HomeworkStatus Status, DateTime? SubmittedAtUtc, string? Content);
