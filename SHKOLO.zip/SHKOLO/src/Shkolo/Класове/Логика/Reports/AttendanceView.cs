// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Application.Reports;

/// <summary>Attendance record joined with its lesson, ready for display.</summary>
public sealed record AttendanceView(
    Guid Id,
    Guid StudentId,
    string StudentName,
    Guid LessonId,
    DateOnly Date,
    int LessonNumber,
    string ClassName,
    string SubjectName,
    AttendanceStatus Status,
    string? Note);
