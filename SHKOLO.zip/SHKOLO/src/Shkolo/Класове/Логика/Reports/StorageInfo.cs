// Owner: Participant 1 – Core Developer
using Shkolo.Application.Abstractions;

namespace Shkolo.Application.Reports;

/// <summary>Technical information about the data file shown to administrators.</summary>
public sealed record StorageInfo(string DataFilePath, long SizeBytes, DateTime LastSavedAtUtc, IReadOnlyList<BackupInfo> Backups, bool IsReadOnly);
