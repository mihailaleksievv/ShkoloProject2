// Owner: Participant 1 – Core Developer
using Shkolo.Application.Abstractions;
using Shkolo.Application.Results;
using Shkolo.Domain.Enums;

namespace Shkolo.Application.Security;

/// <summary>
/// The single place where permissions are decided. Every service method calls it first,
/// so hiding a menu option is never the only protection.
/// </summary>
public sealed class AuthorizationService
{
    private static readonly Error NotAuthenticated =
        new(ErrorKind.Forbidden, ErrorCodes.NotAuthenticated, "Необходим е вход в системата.");

    private readonly IUnitOfWork _uow;
    private readonly SessionContext _session;

    public AuthorizationService(IUnitOfWork uow, SessionContext session)
    {
        _uow = uow;
        _session = session;
    }

    public bool IsAdmin => _session.Role == UserRole.Administrator;

    public bool IsTeacher => _session.Role == UserRole.Teacher;

    public bool IsStudent => _session.Role == UserRole.Student;

    public OperationResult RequireAuthenticated()
        => _session.IsAuthenticated ? OperationResult.Ok() : OperationResult.Fail(NotAuthenticated);

    public OperationResult RequireRole(params UserRole[] roles)
    {
        var auth = RequireAuthenticated();
        if (!auth.Success)
        {
            return auth;
        }

        return roles.Contains(_session.Role!.Value)
            ? OperationResult.Ok()
            : OperationResult.Forbidden("Нямате права за това действие.");
    }

    public OperationResult RequireAdmin() => RequireRole(UserRole.Administrator);

    /// <summary>The current user must be a teacher assigned to teach the subject in the class.</summary>
    public OperationResult RequireTeachingAssignment(Guid classId, Guid subjectId)
    {
        var role = RequireRole(UserRole.Teacher);
        if (!role.Success)
        {
            return role;
        }

        var assigned = _uow.Database.TeacherAssignments.Any(a =>
            a.TeacherId == _session.TeacherId && a.ClassId == classId && a.SubjectId == subjectId);
        return assigned
            ? OperationResult.Ok()
            : OperationResult.Fail(new Error(ErrorKind.Forbidden, ErrorCodes.NoAssignment, "Нямате назначение за този клас и предмет."));
    }

    /// <summary>The current user must be a teacher who teaches in (or is class teacher of) the class.</summary>
    public OperationResult RequireTeachesClass(Guid classId)
    {
        var role = RequireRole(UserRole.Teacher);
        if (!role.Success)
        {
            return role;
        }

        return TaughtClassIds().Contains(classId)
            ? OperationResult.Ok()
            : OperationResult.Forbidden("Не преподавате в този клас.");
    }

    public bool IsClassTeacherOf(Guid classId)
        => _session.TeacherId is { } teacherId
           && _uow.Database.Classes.Any(c => c.Id == classId && c.ClassTeacherId == teacherId);

    /// <summary>Classes where the current teacher has an assignment or is the class teacher.</summary>
    public IReadOnlySet<Guid> TaughtClassIds()
    {
        if (_session.TeacherId is not { } teacherId)
        {
            return new HashSet<Guid>();
        }

        var db = _uow.Database;
        return db.TeacherAssignments.Where(a => a.TeacherId == teacherId).Select(a => a.ClassId)
            .Concat(db.Classes.Where(c => c.ClassTeacherId == teacherId).Select(c => c.Id))
            .ToHashSet();
    }

    /// <summary>Admin: any student. Teacher: students of taught classes. Student: only self.</summary>
    public OperationResult RequireCanViewStudent(Guid studentId)
    {
        var auth = RequireAuthenticated();
        if (!auth.Success)
        {
            return auth;
        }

        var student = _uow.Database.Students.FirstOrDefault(s => s.Id == studentId);
        if (student is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Ученикът не е намерен.");
        }

        var allowed = _session.Role switch
        {
            UserRole.Administrator => true,
            UserRole.Teacher => TaughtClassIds().Contains(student.ClassId),
            UserRole.Student => _session.StudentId == studentId,
            _ => false,
        };
        return allowed ? OperationResult.Ok() : OperationResult.Forbidden("Нямате достъп до данните на този ученик.");
    }

    /// <summary>Admin: any class. Teacher: taught classes. Student: own class.</summary>
    public OperationResult RequireCanViewClass(Guid classId)
    {
        var auth = RequireAuthenticated();
        if (!auth.Success)
        {
            return auth;
        }

        if (_uow.Database.Classes.All(c => c.Id != classId))
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Класът не е намерен.");
        }

        var allowed = _session.Role switch
        {
            UserRole.Administrator => true,
            UserRole.Teacher => TaughtClassIds().Contains(classId),
            UserRole.Student => _uow.Database.Students.Any(s => s.Id == _session.StudentId && s.ClassId == classId),
            _ => false,
        };
        return allowed ? OperationResult.Ok() : OperationResult.Forbidden("Нямате достъп до този клас.");
    }
}
