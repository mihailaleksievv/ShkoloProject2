// Owner: Participant 1 – Core Developer
using Shkolo.Application.Results;

namespace Shkolo.Application.Security;

/// <summary>Minimum password strength: at least 8 characters with a letter and a digit.</summary>
internal static class PasswordPolicy
{
    public const int MinLength = 8;

    public static OperationResult Validate(string? password)
        => password is { Length: >= MinLength } && password.Any(char.IsLetter) && password.Any(char.IsDigit)
            ? OperationResult.Ok()
            : OperationResult.Validation(ErrorCodes.InvalidInput, "Паролата трябва да е поне 8 символа и да съдържа буква и цифра.");
}
