// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Security;

/// <summary>
/// The logged-in user of this application process. One instance is created by the composition root
/// and passed to every service through its constructor (no static/global state).
/// </summary>
public sealed class SessionContext
{
    public User? CurrentUser { get; private set; }

    public bool IsAuthenticated => CurrentUser is not null;

    public Guid? UserId => CurrentUser?.Id;

    public UserRole? Role => CurrentUser?.Role;

    public Guid? StudentId => CurrentUser?.StudentId;

    public Guid? TeacherId => CurrentUser?.TeacherId;

    public void Begin(User user) => CurrentUser = user ?? throw new ArgumentNullException(nameof(user));

    public void End() => CurrentUser = null;
}
