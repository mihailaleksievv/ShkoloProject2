// Owner: Participant 1 – Core Developer
using System.Text.RegularExpressions;
using Shkolo.Application.Abstractions;
using Shkolo.Application.Requests;
using Shkolo.Application.Results;
using Shkolo.Application.Services;
using Shkolo.Domain;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;

namespace Shkolo.Application.Security;

/// <summary>Login, logout and account management.</summary>
public sealed partial class AuthService
{
    private const string InvalidCredentialsMessage = "Невалидно потребителско име или парола.";

    private readonly ServiceContext _ctx;
    private readonly IPasswordHasher _hasher;

    // Used when the username does not exist, so a failed login always costs one hash verification
    // and response time does not reveal which usernames exist.
    private readonly Lazy<(string Hash, string Salt)> _dummy;

    public AuthService(ServiceContext ctx, IPasswordHasher hasher)
    {
        _ctx = ctx;
        _hasher = hasher;
        _dummy = new Lazy<(string, string)>(() => hasher.Hash("educore-dummy-password-1"));
    }

    public OperationResult<User> Login(string username, string password)
    {
        var name = (username ?? "").Trim();
        var user = _ctx.Db.Users.FirstOrDefault(u => string.Equals(u.Username, name, StringComparison.OrdinalIgnoreCase));
        var (hash, salt) = user is null ? _dummy.Value : (user.PasswordHash, user.PasswordSalt);
        var passwordMatches = _hasher.Verify(password ?? "", hash, salt);

        if (user is null || !passwordMatches || !IsAccountUsable(_ctx.Db, user))
        {
            var shownName = name.Length > 30 ? name[..30] + "…" : name;
            var failedUserId = user?.Id;
            _ctx.Uow.Execute(db =>
            {
                _ctx.Audit.Record(db, "Auth.LoginFailed", nameof(User), failedUserId, $"Неуспешен опит за вход с потребител „{shownName}“.");
                return OperationResult.Ok();
            });
            return new Error(ErrorKind.Validation, ErrorCodes.InvalidCredentials, InvalidCredentialsMessage);
        }

        var userId = user.Id;
        _ctx.Session.Begin(user);

        // A failed save (e.g. read-only database) must not prevent viewing data, so the result is ignored.
        _ctx.Uow.Execute(db =>
        {
            var stored = db.FindUser(userId)!;
            stored.LastLoginAtUtc = _ctx.Clock.UtcNow;
            _ctx.Audit.Record(db, "Auth.Login", nameof(User), userId, $"Вход на „{stored.Username}“.");
            return OperationResult.Ok();
        });

        var current = _ctx.Db.FindUser(userId)!;
        _ctx.Session.Begin(current);
        return OperationResult<User>.Ok(current);
    }

    public void Logout() => _ctx.Session.End();

    public OperationResult ChangePassword(string currentPassword, string newPassword)
    {
        var auth = _ctx.Authorization.RequireAuthenticated();
        if (!auth.Success)
        {
            return auth;
        }

        var user = _ctx.Db.FindUser(_ctx.Session.UserId!.Value)!;
        if (!_hasher.Verify(currentPassword ?? "", user.PasswordHash, user.PasswordSalt))
        {
            return OperationResult.Validation(ErrorCodes.InvalidCredentials, "Текущата парола е грешна.");
        }

        return SetPassword(user.Id, newPassword, "User.PasswordChanged", "Сменена парола.");
    }

    public OperationResult<IReadOnlyList<User>> GetUsers()
    {
        var auth = _ctx.Authorization.RequireAdmin();
        return auth.Success
            ? OperationResult<IReadOnlyList<User>>.Ok(_ctx.Db.Users.OrderBy(u => u.Role).ThenBy(u => u.Username).ToList())
            : auth.Error!;
    }

    public OperationResult<User> CreateAccount(AccountInput input)
    {
        var auth = _ctx.Authorization.RequireAdmin();
        if (!auth.Success)
        {
            return auth.Error!;
        }

        var check = ValidateAccount(_ctx.Db, input);
        if (!check.Success)
        {
            return check.Error!;
        }

        return _ctx.Uow.Execute(db =>
        {
            var (hash, salt) = _hasher.Hash(input.Password);
            var user = new User
            {
                Username = input.Username.Trim(),
                DisplayName = input.DisplayName.Trim(),
                Role = input.Role,
                StudentId = input.StudentId,
                TeacherId = input.TeacherId,
                PasswordHash = hash,
                PasswordSalt = salt,
                CreatedAtUtc = _ctx.Clock.UtcNow,
            };
            db.Users.Add(user);
            _ctx.Audit.Record(db, "User.Created", nameof(User), user.Id, $"Създаден акаунт „{user.Username}“ ({input.Role}).");
            return OperationResult<User>.Ok(user);
        });
    }

    public OperationResult SetUserActive(Guid userId, bool active)
    {
        var auth = _ctx.Authorization.RequireAdmin();
        if (!auth.Success)
        {
            return auth;
        }

        if (_ctx.Db.FindUser(userId) is null)
        {
            return OperationResult.NotFound(ErrorCodes.NotFound, "Потребителят не е намерен.");
        }

        if (!active && userId == _ctx.Session.UserId)
        {
            return OperationResult.Validation(ErrorCodes.InvalidInput, "Не можете да деактивирате собствения си акаунт.");
        }

        return _ctx.Uow.Execute(db =>
        {
            var user = db.FindUser(userId)!;
            user.IsActive = active;
            _ctx.Audit.Record(db, active ? "User.Activated" : "User.Deactivated", nameof(User), userId,
                $"{(active ? "Активиран" : "Деактивиран")} акаунт „{user.Username}“.");
            return OperationResult.Ok();
        });
    }

    public OperationResult ResetPassword(Guid userId, string newPassword)
    {
        var auth = _ctx.Authorization.RequireAdmin();
        if (!auth.Success)
        {
            return auth;
        }

        return _ctx.Db.FindUser(userId) is null
            ? OperationResult.NotFound(ErrorCodes.NotFound, "Потребителят не е намерен.")
            : SetPassword(userId, newPassword, "User.PasswordReset", "Нулирана парола от администратор.");
    }

    /// <summary>A user can sign in only while the account and its linked profile are active.</summary>
    internal static bool IsAccountUsable(SchoolDatabase db, User user) => user.IsActive && user.Role switch
    {
        UserRole.Student => user.StudentId is { } s && db.FindStudent(s)?.IsActive == true,
        UserRole.Teacher => user.TeacherId is { } t && db.FindTeacher(t)?.IsActive == true,
        _ => true,
    };

    private OperationResult SetPassword(Guid userId, string newPassword, string action, string summary)
    {
        var policy = PasswordPolicy.Validate(newPassword);
        if (!policy.Success)
        {
            return policy;
        }

        return _ctx.Uow.Execute(db =>
        {
            var user = db.FindUser(userId)!;
            (user.PasswordHash, user.PasswordSalt) = _hasher.Hash(newPassword);
            _ctx.Audit.Record(db, action, nameof(User), userId, $"{summary} Потребител „{user.Username}“.");
            return OperationResult.Ok();
        });
    }

    private static OperationResult ValidateAccount(SchoolDatabase db, AccountInput input)
    {
        var username = input.Username?.Trim() ?? "";
        if (!UsernamePattern().IsMatch(username))
        {
            return OperationResult.Validation(ErrorCodes.InvalidInput, "Потребителското име трябва да е 3–30 латински букви, цифри, „.“, „_“ или „-“.");
        }

        if (db.Users.Any(u => string.Equals(u.Username, username, StringComparison.OrdinalIgnoreCase)))
        {
            return OperationResult.Conflict(ErrorCodes.DuplicateUsername, $"Потребителското име „{username}“ вече е заето.");
        }

        if (string.IsNullOrWhiteSpace(input.DisplayName) || input.DisplayName.Trim().Length > 100)
        {
            return OperationResult.Validation(ErrorCodes.InvalidInput, "Въведете име за показване (до 100 символа).");
        }

        var policy = PasswordPolicy.Validate(input.Password);
        if (!policy.Success)
        {
            return policy;
        }

        return input.Role switch
        {
            UserRole.Student when input.StudentId is { } s && input.TeacherId is null =>
                db.FindStudent(s) is null ? OperationResult.NotFound(ErrorCodes.NotFound, "Ученикът не е намерен.")
                : db.Users.Any(u => u.StudentId == s) ? OperationResult.Conflict(ErrorCodes.ProfileHasAccount, "Ученикът вече има акаунт.")
                : OperationResult.Ok(),
            UserRole.Teacher when input.TeacherId is { } t && input.StudentId is null =>
                db.FindTeacher(t) is null ? OperationResult.NotFound(ErrorCodes.NotFound, "Учителят не е намерен.")
                : db.Users.Any(u => u.TeacherId == t) ? OperationResult.Conflict(ErrorCodes.ProfileHasAccount, "Учителят вече има акаунт.")
                : OperationResult.Ok(),
            UserRole.Administrator when input.StudentId is null && input.TeacherId is null => OperationResult.Ok(),
            _ => OperationResult.Validation(ErrorCodes.InvalidInput, "Профилът на акаунта не съответства на ролята."),
        };
    }

    [GeneratedRegex("^[A-Za-z0-9._-]{3,30}$")]
    private static partial Regex UsernamePattern();
}
