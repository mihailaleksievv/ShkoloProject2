// Owner: Participant 1 – Core Developer (contract) / implemented by Participant 3
using Shkolo.Domain;

namespace Shkolo.Application.Abstractions;

/// <summary>Physical storage of the whole <see cref="SchoolDatabase"/>. The rest of the app never sees the JSON.</summary>
public interface IDataStore
{
    /// <summary>Full path of the main data file (shown in the technical information screen).</summary>
    string DataFilePath { get; }

    /// <summary>Loads the database. Never throws for expected problems – they are described by the result.</summary>
    LoadResult Load();

    /// <summary>Stores the database atomically. Throws <see cref="DataStoreException"/> on failure.</summary>
    void Save(SchoolDatabase database);
}
