// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Abstractions;

/// <summary>Description of one backup file.</summary>
public sealed record BackupInfo(string FileName, DateTime CreatedAtUtc, long SizeBytes);
