// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Abstractions;

/// <summary>State of the data file found at start-up.</summary>
public enum LoadStatus
{
    /// <summary>Existing valid file was loaded.</summary>
    Loaded,

    /// <summary>No file existed; a new database with demo data was created.</summary>
    CreatedNew,

    /// <summary>File is empty or not valid JSON. It was left untouched.</summary>
    Corrupted,

    /// <summary>File was written by a newer version of the application.</summary>
    UnsupportedVersion,

    /// <summary>Valid JSON, but references between objects are broken. App runs read-only.</summary>
    IntegrityProblems,
}
