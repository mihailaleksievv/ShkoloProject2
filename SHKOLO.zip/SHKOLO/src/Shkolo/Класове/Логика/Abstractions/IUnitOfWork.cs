// Owner: Participant 1 – Core Developer
using Shkolo.Application.Results;
using Shkolo.Domain;

namespace Shkolo.Application.Abstractions;

/// <summary>
/// Gateway for every change: snapshot → mutate → save → rollback on any failure,
/// so memory and the data file never diverge.
/// </summary>
public interface IUnitOfWork
{
    /// <summary>Current in-memory state. Services read from it; they change it only inside <see cref="Execute"/>.</summary>
    SchoolDatabase Database { get; }

    /// <summary>True when the data has integrity problems – every change is refused.</summary>
    bool IsReadOnly { get; }

    OperationResult Execute(Func<SchoolDatabase, OperationResult> mutation);

    OperationResult<T> Execute<T>(Func<SchoolDatabase, OperationResult<T>> mutation);
}
