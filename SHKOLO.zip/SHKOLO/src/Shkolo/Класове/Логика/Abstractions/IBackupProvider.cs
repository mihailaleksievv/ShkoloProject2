// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Abstractions;

/// <summary>Access to the automatic backups of the data file.</summary>
public interface IBackupProvider
{
    /// <summary>Available backups, newest first.</summary>
    IReadOnlyList<BackupInfo> GetBackups();

    /// <summary>Copies the backup over the main data file (the current file is backed up first).</summary>
    void RestoreBackup(string backupFileName);
}
