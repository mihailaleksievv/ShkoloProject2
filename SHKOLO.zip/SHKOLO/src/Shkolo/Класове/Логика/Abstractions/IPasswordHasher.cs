// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Abstractions;

/// <summary>One-way password hashing with a per-user salt.</summary>
public interface IPasswordHasher
{
    (string Hash, string Salt) Hash(string password);

    bool Verify(string password, string hash, string salt);
}
