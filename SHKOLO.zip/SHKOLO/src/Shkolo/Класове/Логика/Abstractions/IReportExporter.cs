// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Abstractions;

/// <summary>Writes tabular report data to a file and returns the file's full path.</summary>
public interface IReportExporter
{
    string Export(string fileNameStem, IReadOnlyList<string> headers, IEnumerable<IReadOnlyList<string>> rows);
}
