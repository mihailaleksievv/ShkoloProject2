// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Abstractions;

/// <summary>Source of "now" and "today" – abstracted so rules about dates are testable.</summary>
public interface IClock
{
    DateTime UtcNow { get; }

    /// <summary>Today's local calendar date.</summary>
    DateOnly Today { get; }

    /// <summary>Current local date and time.</summary>
    DateTime LocalNow { get; }
}
