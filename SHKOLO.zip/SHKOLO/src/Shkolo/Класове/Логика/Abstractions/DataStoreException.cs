// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Abstractions;

/// <summary>Raised by a data store when the database cannot be stored or restored.</summary>
public sealed class DataStoreException(string message, Exception? inner = null) : Exception(message, inner);
