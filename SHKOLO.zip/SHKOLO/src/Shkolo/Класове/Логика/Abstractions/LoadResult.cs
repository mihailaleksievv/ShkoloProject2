// Owner: Participant 1 – Core Developer
using Shkolo.Domain;

namespace Shkolo.Application.Abstractions;

/// <summary>Outcome of loading the data file.</summary>
public sealed record LoadResult(
    LoadStatus Status,
    SchoolDatabase? Database,
    string? Message,
    IReadOnlyList<string> IntegrityIssues);
