// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Requests;

/// <summary>Data for creating or editing a homework assignment.</summary>
public sealed record HomeworkInput(Guid ClassId, Guid SubjectId, string Title, string Description, DateOnly AssignedDate, DateOnly DueDate);
