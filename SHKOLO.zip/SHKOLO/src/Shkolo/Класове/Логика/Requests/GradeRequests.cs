// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Application.Requests;

/// <summary>Data for a new current grade. The class and teacher are set by the service.</summary>
public sealed record GradeInput(Guid StudentId, Guid SubjectId, decimal Value, DateOnly Date, GradeType Type, string? Comment, Guid? LessonId = null);

/// <summary>Editable fields of an existing grade.</summary>
public sealed record GradeUpdate(decimal Value, GradeType Type, string? Comment);

/// <summary>Optional filters for grade lists (all conditions are combined).</summary>
public sealed record GradeFilter(Guid? SubjectId = null, Term? Term = null, GradeType? Type = null, DateOnly? From = null, DateOnly? To = null);
