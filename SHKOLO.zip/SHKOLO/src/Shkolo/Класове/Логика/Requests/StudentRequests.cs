// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Requests;

/// <summary>Data for creating or editing a student.</summary>
public sealed record StudentInput(string StudentNumber, string FirstName, string LastName, Guid ClassId, string? Email);
