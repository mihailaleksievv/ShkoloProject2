// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Requests;

/// <summary>Announcement data. TargetClassId = null means the whole school.</summary>
public sealed record AnnouncementInput(string Title, string Body, Guid? TargetClassId);

/// <summary>Calendar event data (local times). TargetClassId = null means the whole school.</summary>
public sealed record SchoolEventInput(string Title, string Description, DateTime Start, DateTime End, Guid? TargetClassId);
