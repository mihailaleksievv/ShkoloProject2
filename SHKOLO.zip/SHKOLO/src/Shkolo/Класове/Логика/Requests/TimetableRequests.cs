// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Requests;

/// <summary>Data for creating or editing a weekly timetable entry.</summary>
public sealed record TimetableEntryInput(Guid ClassId, Guid SubjectId, Guid TeacherId, DayOfWeek Day, int LessonNumber, string? Room);
