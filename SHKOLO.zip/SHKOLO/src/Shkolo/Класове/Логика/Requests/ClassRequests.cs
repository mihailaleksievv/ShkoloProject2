// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Requests;

/// <summary>Data for creating or editing a class.</summary>
public sealed record ClassInput(int GradeLevel, string Section, Guid AcademicYearId, Guid? ClassTeacherId);
