// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Application.Requests;

/// <summary>Data for creating a login account (administrators only).</summary>
public sealed record AccountInput(string Username, string DisplayName, string Password, UserRole Role, Guid? StudentId, Guid? TeacherId);
