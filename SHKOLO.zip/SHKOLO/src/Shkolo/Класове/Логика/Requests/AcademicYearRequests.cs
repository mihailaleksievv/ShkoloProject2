// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Requests;

/// <summary>Data for creating or editing an academic year.</summary>
public sealed record AcademicYearInput(string Name, DateOnly StartDate, DateOnly FirstTermEndDate, DateOnly EndDate);
