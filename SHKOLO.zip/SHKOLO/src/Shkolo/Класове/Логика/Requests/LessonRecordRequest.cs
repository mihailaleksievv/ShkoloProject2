// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Application.Requests;

/// <summary>A grade given during the lesson being recorded (subject, date and lesson come from the lesson).</summary>
public sealed record LessonGradeInput(Guid StudentId, decimal Value, GradeType Type, string? Comment);

/// <summary>
/// Everything a teacher enters for one lesson: the lesson itself, attendance exceptions and grades.
/// Students without a mark are recorded as present.
/// </summary>
public sealed record LessonRecordRequest(
    LessonInput Lesson,
    Guid? TimetableEntryId,
    IReadOnlyList<AttendanceMark> Attendance,
    IReadOnlyList<LessonGradeInput> Grades);
