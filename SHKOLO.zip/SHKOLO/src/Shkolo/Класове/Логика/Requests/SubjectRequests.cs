// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Requests;

/// <summary>Data for creating or editing a subject.</summary>
public sealed record SubjectInput(string Name, string? Code);
