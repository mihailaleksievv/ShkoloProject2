// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Requests;

/// <summary>Data for recording a held lesson.</summary>
public sealed record LessonInput(Guid ClassId, Guid SubjectId, DateOnly Date, int LessonNumber, string Topic, string? Notes);

/// <summary>Optional filters for searching lessons (all conditions are combined).</summary>
public sealed record LessonFilter(Guid? ClassId = null, Guid? SubjectId = null, Guid? TeacherId = null, DateOnly? From = null, DateOnly? To = null);
