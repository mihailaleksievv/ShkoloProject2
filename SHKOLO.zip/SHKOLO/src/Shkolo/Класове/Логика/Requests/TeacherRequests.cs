// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Requests;

/// <summary>Data for creating or editing a teacher.</summary>
public sealed record TeacherInput(string EmployeeNumber, string FirstName, string LastName, string Email);
