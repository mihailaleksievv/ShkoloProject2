// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Application.Requests;

/// <summary>Attendance mark of one student for a lesson.</summary>
public sealed record AttendanceMark(Guid StudentId, AttendanceStatus Status, string? Note);

/// <summary>Optional filters for attendance lists (all conditions are combined).</summary>
public sealed record AttendanceFilter(Guid? SubjectId = null, Term? Term = null, DateOnly? From = null, DateOnly? To = null);
