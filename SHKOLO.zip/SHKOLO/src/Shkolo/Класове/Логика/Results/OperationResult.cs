// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Results;

/// <summary>
/// The single way services report the outcome of an operation.
/// Expected failures are values, not exceptions and never <c>null</c>.
/// </summary>
public class OperationResult
{
    protected OperationResult(bool success, Error? error)
    {
        Success = success;
        Error = error;
    }

    public bool Success { get; }

    public Error? Error { get; }

    public static OperationResult Ok() => new(true, null);

    public static OperationResult Fail(Error error) => new(false, error);

    public static OperationResult Validation(string code, string message) => Fail(new Error(ErrorKind.Validation, code, message));

    public static OperationResult NotFound(string code, string message) => Fail(new Error(ErrorKind.NotFound, code, message));

    public static OperationResult Forbidden(string message) => Fail(new Error(ErrorKind.Forbidden, ErrorCodes.Forbidden, message));

    public static OperationResult Conflict(string code, string message) => Fail(new Error(ErrorKind.Conflict, code, message));

    public static OperationResult Persistence(string message) => Fail(new Error(ErrorKind.Persistence, ErrorCodes.PersistenceFailed, message));
}
