// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Results;

/// <summary>Category of an expected failure returned by a service.</summary>
public enum ErrorKind
{
    /// <summary>Input breaks a business rule.</summary>
    Validation,

    /// <summary>A referenced entity does not exist.</summary>
    NotFound,

    /// <summary>The current user is not allowed to perform the operation.</summary>
    Forbidden,

    /// <summary>The operation conflicts with the current state (duplicates, dependencies).</summary>
    Conflict,

    /// <summary>The change could not be stored; nothing was changed.</summary>
    Persistence,
}
