// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Results;

/// <summary>Stable error codes shared by services, UI and tests.</summary>
public static class ErrorCodes
{
    public const string NotAuthenticated = nameof(NotAuthenticated);
    public const string Forbidden = nameof(Forbidden);
    public const string NotFound = nameof(NotFound);
    public const string InvalidInput = nameof(InvalidInput);
    public const string InvalidCredentials = nameof(InvalidCredentials);
    public const string NoActiveYear = nameof(NoActiveYear);
    public const string OutOfAcademicYear = nameof(OutOfAcademicYear);
    public const string FutureDate = nameof(FutureDate);
    public const string DuplicateStudentNumber = nameof(DuplicateStudentNumber);
    public const string DuplicateEmployeeNumber = nameof(DuplicateEmployeeNumber);
    public const string DuplicateUsername = nameof(DuplicateUsername);
    public const string ProfileHasAccount = nameof(ProfileHasAccount);
    public const string DuplicateClass = nameof(DuplicateClass);
    public const string DuplicateSubject = nameof(DuplicateSubject);
    public const string DuplicateAssignment = nameof(DuplicateAssignment);
    public const string NoAssignment = nameof(NoAssignment);
    public const string InactiveEntity = nameof(InactiveEntity);
    public const string InvalidGrade = nameof(InvalidGrade);
    public const string TimetableClassConflict = nameof(TimetableClassConflict);
    public const string TimetableTeacherConflict = nameof(TimetableTeacherConflict);
    public const string TimetableRoomConflict = nameof(TimetableRoomConflict);
    public const string DayMismatch = nameof(DayMismatch);
    public const string DuplicateLesson = nameof(DuplicateLesson);
    public const string LessonCancelled = nameof(LessonCancelled);
    public const string LessonHasRecords = nameof(LessonHasRecords);
    public const string DuplicateAttendance = nameof(DuplicateAttendance);
    public const string StudentNotInClass = nameof(StudentNotInClass);
    public const string NotAuthor = nameof(NotAuthor);
    public const string NoGradesForPeriod = nameof(NoGradesForPeriod);
    public const string InvalidDateRange = nameof(InvalidDateRange);
    public const string HasDependencies = nameof(HasDependencies);
    public const string ReadOnlyDatabase = nameof(ReadOnlyDatabase);
    public const string PersistenceFailed = nameof(PersistenceFailed);
}
