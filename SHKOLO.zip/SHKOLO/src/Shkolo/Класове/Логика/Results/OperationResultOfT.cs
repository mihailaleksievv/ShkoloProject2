// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Results;

/// <summary>Operation result that carries a value on success.</summary>
public sealed class OperationResult<T> : OperationResult
{
    private OperationResult(bool success, T? value, Error? error)
        : base(success, error)
    {
        Value = value;
    }

    public T? Value { get; }

    public static OperationResult<T> Ok(T value) => new(true, value, null);

    public static new OperationResult<T> Fail(Error error) => new(false, default, error);

    /// <summary>Lets a service write <c>return result.Error!;</c> to propagate a failure.</summary>
    public static implicit operator OperationResult<T>(Error error) => Fail(error);
}
