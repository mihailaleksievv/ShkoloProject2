// Owner: Participant 1 – Core Developer
namespace Shkolo.Application.Results;

/// <summary>Expected failure. <see cref="Code"/> is stable for tests, <see cref="Message"/> is Bulgarian UI text.</summary>
public sealed record Error(ErrorKind Kind, string Code, string Message);
