// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Models;

/// <summary>Вид отличие, например „Отлично представяне“.</summary>
public sealed class AchievementBadge
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public string Symbol { get; set; } = "";
    public bool IsActive { get; set; } = true;
}
