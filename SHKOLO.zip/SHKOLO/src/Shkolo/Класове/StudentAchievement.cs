// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Models;

/// <summary>Отличие, дадено на ученик от учител.</summary>
public sealed class StudentAchievement
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid BadgeId { get; set; }
    public Guid StudentId { get; set; }
    public Guid AssignedByTeacherId { get; set; }
    public DateTime AssignedAtUtc { get; set; }
    public string? Note { get; set; }
}
