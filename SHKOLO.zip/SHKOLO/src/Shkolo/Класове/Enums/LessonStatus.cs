// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Enums;

/// <summary>Lifecycle of a recorded lesson.</summary>
public enum LessonStatus
{
    Held,
    Cancelled,
}
