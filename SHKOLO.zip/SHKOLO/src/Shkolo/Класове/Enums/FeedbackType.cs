// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Enums;

/// <summary>Kind of teacher feedback.</summary>
public enum FeedbackType
{
    Praise,
    Remark,
}
