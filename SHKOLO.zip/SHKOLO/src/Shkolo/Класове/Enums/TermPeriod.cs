// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Enums;

/// <summary>Period an official term or annual grade is given for.</summary>
public enum TermPeriod
{
    FirstTerm,
    SecondTerm,
    Annual,
}
