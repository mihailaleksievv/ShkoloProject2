// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Enums;

/// <summary>Kind of assessment a current grade comes from.</summary>
public enum GradeType
{
    Oral,
    WrittenTest,
    Test,
    Homework,
    Project,
    Other,
}
