// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Enums;

/// <summary>Term a date falls into; computed from the academic year.</summary>
public enum Term
{
    First,
    Second,
}
