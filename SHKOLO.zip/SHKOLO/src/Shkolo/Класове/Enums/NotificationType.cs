// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Enums;

/// <summary>Event that produced an internal notification.</summary>
public enum NotificationType
{
    NewGrade,
    NewTermGrade,
    NewHomework,
    NewAnnouncement,
    NewFeedback,
    NewAchievement,
    UpcomingEvent,
}
