// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Enums;

/// <summary>Role of a system account.</summary>
public enum UserRole
{
    Administrator,
    Teacher,
    Student,
}
