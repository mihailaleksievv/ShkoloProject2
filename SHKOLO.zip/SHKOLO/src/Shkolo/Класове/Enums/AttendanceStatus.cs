// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Enums;

/// <summary>Attendance mark of a student for one held lesson.</summary>
public enum AttendanceStatus
{
    Present,
    Absent,
    ExcusedAbsent,
    Late,
}
