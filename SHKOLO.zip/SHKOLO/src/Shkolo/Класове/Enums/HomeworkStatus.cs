// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Enums;

/// <summary>Status of a homework for one student. Always computed, never stored.</summary>
public enum HomeworkStatus
{
    Pending,
    Submitted,
    SubmittedLate,
    Overdue,
}
