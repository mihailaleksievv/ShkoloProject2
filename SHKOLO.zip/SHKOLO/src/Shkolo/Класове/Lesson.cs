// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Domain.Models;

/// <summary>Проведен учебен час: дата, клас, предмет и тема.</summary>
public sealed class Lesson
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid? TimetableEntryId { get; set; }
    public Guid ClassId { get; set; }
    public Guid SubjectId { get; set; }
    public Guid TeacherId { get; set; }
    public DateOnly Date { get; set; }
    public int LessonNumber { get; set; }
    public string Topic { get; set; } = "";
    public string? Notes { get; set; }
    public LessonStatus Status { get; set; } = LessonStatus.Held;
    public DateTime RecordedAtUtc { get; set; }
}
