// Owner: Participant 1 – Core Developer
using System.Text.Json.Serialization;

namespace Shkolo.Domain.Models;

/// <summary>Клас (паралелка), например 10А, със стая и класен ръководител.</summary>
public sealed class SchoolClass
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public int GradeLevel { get; set; }
    public string Section { get; set; } = "";
    public Guid AcademicYearId { get; set; }
    public Guid? ClassTeacherId { get; set; }
    public bool IsActive { get; set; } = true;

    [JsonIgnore]
    public string DisplayName => $"{GradeLevel}{Section}";
}
