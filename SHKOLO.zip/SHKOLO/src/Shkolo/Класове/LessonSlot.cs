// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Models;

/// <summary>Час от звънеца: номер, начало и край.</summary>
public sealed class LessonSlot
{
    public int LessonNumber { get; set; }
    public TimeOnly StartTime { get; set; }
    public TimeOnly EndTime { get; set; }
}
