// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Models;

/// <summary>Домашна работа за клас по предмет, с краен срок.</summary>
public sealed class Homework
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ClassId { get; set; }
    public Guid SubjectId { get; set; }
    public Guid TeacherId { get; set; }
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public DateOnly AssignedDate { get; set; }
    public DateOnly DueDate { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; }
}
