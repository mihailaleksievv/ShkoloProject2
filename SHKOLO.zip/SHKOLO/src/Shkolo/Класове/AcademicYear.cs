// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Domain.Models;

/// <summary>Учебна година: начало, край и краят на първия срок.</summary>
public sealed class AcademicYear
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";
    public DateOnly StartDate { get; set; }
    public DateOnly FirstTermEndDate { get; set; }
    public DateOnly EndDate { get; set; }
    public bool IsActive { get; set; }

    /// <summary>В кой срок е датата: след края на първия срок започва вторият.</summary>
    public Term GetTerm(DateOnly date) => date <= FirstTermEndDate ? Term.First : Term.Second;

    /// <summary>Дали датата е в рамките на учебната година.</summary>
    public bool Contains(DateOnly date) => date >= StartDate && date <= EndDate;
}
