// Owner: Participant 1 – Core Developer
using Shkolo.Domain.Enums;

namespace Shkolo.Domain.Models;

/// <summary>Акаунт за вход: потребителско име, роля и хеш на паролата (самата парола не се пази).</summary>
public sealed class User
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Username { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string PasswordSalt { get; set; } = "";
    public UserRole Role { get; set; }
    public Guid? StudentId { get; set; }
    public Guid? TeacherId { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? LastLoginAtUtc { get; set; }
}
