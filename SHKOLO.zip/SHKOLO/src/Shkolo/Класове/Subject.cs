// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Models;

/// <summary>Учебен предмет, например Математика.</summary>
public sealed class Subject
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";
    public string? Code { get; set; }
    public bool IsActive { get; set; } = true;
}
