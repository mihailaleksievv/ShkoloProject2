// Owner: Participant 1 – Core Developer
namespace Shkolo.Domain.Models;

/// <summary>Час от седмичното разписание: ден, номер на часа, клас, предмет и учител.</summary>
public sealed class TimetableEntry
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ClassId { get; set; }
    public Guid SubjectId { get; set; }
    public Guid TeacherId { get; set; }
    public DayOfWeek DayOfWeek { get; set; }
    public int LessonNumber { get; set; }
    public string? Room { get; set; }
}
