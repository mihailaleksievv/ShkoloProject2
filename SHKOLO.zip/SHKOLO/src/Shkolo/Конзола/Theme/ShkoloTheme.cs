﻿// Owner: Participant 2 – Presentation Developer
using Spectre.Console;

namespace Shkolo.Presentation.Theme;

/// <summary>Shkolo visual identity: the colour palette from the specification and shared styles.</summary>
public static class ShkoloTheme
{
    // Soft palette in the spirit of Catppuccin Mocha: calm pastel tones that stay readable on dark terminals.
    public const string BackgroundHex = "#1E1E2E";
    public const string PrimaryHex = "#89B4FA";
    public const string AccentHex = "#74C7EC";
    public const string SuccessHex = "#A6E3A1";
    public const string WarningHex = "#F9E2AF";
    public const string PeachHex = "#FAB387";
    public const string ErrorHex = "#F38BA8";
    public const string LavenderHex = "#B4BEFE";
    public const string TextHex = "#CDD6F4";
    public const string MutedHex = "#7F849C";
    public const string SurfaceHex = "#45475A";

    public static readonly Color Background = Color.FromHex(BackgroundHex.TrimStart('#'));
    public static readonly Color Primary = Color.FromHex(PrimaryHex.TrimStart('#'));
    public static readonly Color Accent = Color.FromHex(AccentHex.TrimStart('#'));
    public static readonly Color Success = Color.FromHex(SuccessHex.TrimStart('#'));
    public static readonly Color Warning = Color.FromHex(WarningHex.TrimStart('#'));
    public static readonly Color Peach = Color.FromHex(PeachHex.TrimStart('#'));
    public static readonly Color Error = Color.FromHex(ErrorHex.TrimStart('#'));
    public static readonly Color Lavender = Color.FromHex(LavenderHex.TrimStart('#'));
    public static readonly Color Text = Color.FromHex(TextHex.TrimStart('#'));
    public static readonly Color Muted = Color.FromHex(MutedHex.TrimStart('#'));
    public static readonly Color Surface = Color.FromHex(SurfaceHex.TrimStart('#'));

    /// <summary>The one frame colour of the command centre, the same for every role.</summary>
    public static readonly Color Frame = Primary;

    public static readonly Style Title = new(Primary, decoration: Decoration.Bold);
    public static readonly Style Band = new(Text, Background);

    public const string Brand = "SHKOLO";
    public const string FullName = "SHKOLO – School Management & Intelligence System";
    public const string Slogan = "A smarter way to manage the school day.";
    public const string SloganBg = "Училищният ден – под контрол.";
    public const string Version = "1.0.0";

    public const string BackLabel = "← Назад";
    public const string LogoutLabel = "⏻ Изход от профила";
}
