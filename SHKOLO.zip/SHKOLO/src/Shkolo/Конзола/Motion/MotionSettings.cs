// Owner: Participant 2 – Presentation Developer
namespace Shkolo.Presentation.Motion;

/// <summary>Whether animations run, and how fast. Disabled for redirected output, --no-motion and tests.</summary>
public sealed record MotionSettings(bool Enabled, double Speed = 1.0)
{
    public static MotionSettings Disabled { get; } = new(false);

    public static MotionSettings Default { get; } = new(true);
}
