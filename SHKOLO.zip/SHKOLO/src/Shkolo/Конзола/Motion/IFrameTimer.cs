// Owner: Participant 2 – Presentation Developer
using System.Diagnostics;

namespace Shkolo.Presentation.Motion;

/// <summary>Time source of an animation (replaced by a manual timer in tests).</summary>
public interface IFrameTimer
{
    TimeSpan Elapsed { get; }

    void Restart();
}

/// <summary>Real-time frame timer.</summary>
public sealed class StopwatchFrameTimer : IFrameTimer
{
    private readonly Stopwatch _watch = new();

    public TimeSpan Elapsed => _watch.Elapsed;

    public void Restart() => _watch.Restart();
}
