// Owner: Participant 2 – Presentation Developer
namespace Shkolo.Presentation.Motion;

/// <summary>Easing curves on [0,1]: they shape how an animation accelerates and settles.</summary>
public static class Easing
{
    public static readonly Func<double, double> Linear = t => Math.Clamp(t, 0, 1);

    /// <summary>Fast start, gentle stop – used for counters and reveals.</summary>
    public static readonly Func<double, double> EaseOutCubic = t => 1 - Math.Pow(1 - Math.Clamp(t, 0, 1), 3);

    /// <summary>Slow start and stop – used for transitions.</summary>
    public static readonly Func<double, double> EaseInOutQuad = t =>
    {
        t = Math.Clamp(t, 0, 1);
        return t < 0.5 ? 2 * t * t : 1 - (Math.Pow(-2 * t + 2, 2) / 2);
    };
}
