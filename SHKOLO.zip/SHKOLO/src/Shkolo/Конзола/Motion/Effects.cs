// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Motion;

/// <summary>Ready-made frame functions for <see cref="Animator.Play"/>.</summary>
public static class Effects
{
    /// <summary>The logo builds up column by column.</summary>
    public static Func<double, IRenderable> LogoReveal() => p => Logo.Render(Easing.EaseOutCubic(p));

    /// <summary>Text appears letter by letter.</summary>
    public static Func<double, IRenderable> Typewriter(string text, Color color) => p =>
    {
        var count = (int)Math.Round(text.Length * Math.Clamp(p, 0, 1));
        var cursor = p < 1 ? "▌" : "";
        return new Markup($"[{Gradient.Hex(color)}]{Ui.Escape(text[..count])}{cursor}[/]");
    };

    /// <summary>A number counting up from zero.</summary>
    public static Func<double, IRenderable> CountUp(int to, Func<int, string> format)
        => p => new Markup(format(Tween.Value(0, to, Easing.EaseOutCubic(p))));

    /// <summary>
    /// Transition to new content: an accent sweep line runs across the top while the new content
    /// is already in place (clipping arbitrary renderables is not possible, so the sweep carries the motion).
    /// </summary>
    public static Func<double, IRenderable> Wipe(IRenderable from, IRenderable to, int width = 80) => p =>
    {
        if (p >= 1)
        {
            return to;
        }

        var eased = Easing.EaseInOutQuad(p);
        var sweep = Meter.Markup((decimal)eased, 1m, width, ShkoloTheme.Primary, ShkoloTheme.Accent);
        return new Rows(new Markup(sweep), eased < 0.35 ? from : to);
    };

    /// <summary>A short highlight: inverted for the first half, normal afterwards.</summary>
    public static Func<double, IRenderable> Flash(string message, Color color) => p =>
    {
        var hex = Gradient.Hex(color);
        return new Markup(p < 0.5
            ? $"[bold {ShkoloTheme.BackgroundHex} on {hex}] {Ui.Escape(message)} [/]"
            : $"[bold {hex}] {Ui.Escape(message)} [/]");
    };
}
