// Owner: Participant 2 – Presentation Developer
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Motion;

/// <summary>
/// Plays an animation in place (Spectre live display). Any key skips straight to the final frame,
/// and with motion disabled only the final frame is drawn – animations never slow the user down.
/// </summary>
public sealed class Animator
{
    private readonly MotionSettings _settings;
    private readonly IFrameTimer _timer;

    public Animator(MotionSettings settings, IFrameTimer timer)
    {
        _settings = settings;
        _timer = timer;
    }

    public bool Enabled => _settings.Enabled;

    /// <summary>Pause between frames (~30 fps).</summary>
    public TimeSpan FrameDelay { get; set; } = TimeSpan.FromMilliseconds(33);

    /// <summary>Called after every frame (tests advance a manual timer here).</summary>
    public Action? OnFrame { get; set; }

    /// <param name="frame">Renders the animation at progress p ∈ [0,1].</param>
    public void Play(IAnsiConsole console, TimeSpan duration, Func<double, IRenderable> frame)
    {
        if (!_settings.Enabled)
        {
            console.Write(frame(1.0));
            return;
        }

        var scaled = TimeSpan.FromMilliseconds(duration.TotalMilliseconds / Math.Max(0.01, _settings.Speed));
        console.Live(frame(0)).AutoClear(false).Start(ctx =>
        {
            _timer.Restart();
            while (true)
            {
                var p = Tween.Progress(_timer.Elapsed, scaled, Easing.Linear);
                if (p < 1 && console.Input.IsKeyAvailable())
                {
                    console.Input.ReadKey(intercept: true);
                    p = 1;
                }

                ctx.UpdateTarget(frame(p));
                ctx.Refresh();
                if (p >= 1)
                {
                    return;
                }

                OnFrame?.Invoke();
                if (FrameDelay > TimeSpan.Zero)
                {
                    Thread.Sleep(FrameDelay);
                }
            }
        });
    }
}
