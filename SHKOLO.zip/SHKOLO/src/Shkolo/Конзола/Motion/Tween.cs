// Owner: Participant 2 – Presentation Developer
namespace Shkolo.Presentation.Motion;

/// <summary>Interpolation between two values over time.</summary>
public static class Tween
{
    /// <summary>Eased progress in [0,1]; a non-positive duration is already finished.</summary>
    public static double Progress(TimeSpan elapsed, TimeSpan duration, Func<double, double> easing)
        => duration <= TimeSpan.Zero ? 1 : easing(Math.Clamp(elapsed.TotalMilliseconds / duration.TotalMilliseconds, 0, 1));

    public static decimal Value(decimal from, decimal to, double progress)
        => from + ((to - from) * (decimal)Math.Clamp(progress, 0, 1));

    public static int Value(int from, int to, double progress)
        => (int)Math.Round(from + ((to - from) * Math.Clamp(progress, 0, 1)), MidpointRounding.AwayFromZero);
}
