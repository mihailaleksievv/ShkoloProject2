// Owner: Participant 2 – Presentation Developer
using System.Globalization;

namespace Shkolo.Presentation.Input;

/// <summary>Превръща въведения текст в число, оценка или дата и казва какво е грешно.</summary>
public static class InputParsers
{
    private static readonly string[] DateFormats = ["d.M.yyyy", "dd.MM.yyyy"];
    private static readonly string[] TimeFormats = ["H:mm", "HH:mm"];

    /// <summary>Accepts both "5,50" and "5.50".</summary>
    public static bool TryParseDecimal(string? input, out decimal value)
    {
        value = 0;
        if (string.IsNullOrWhiteSpace(input))
        {
            return false;
        }

        var normalized = input.Trim().Replace(',', '.');
        return normalized.Count(c => c == '.') <= 1
               && decimal.TryParse(normalized, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out value);
    }

    /// <summary>Accepts dd.MM.yyyy (or d.M.yyyy) and the words "днес", "вчера", "утре".</summary>
    public static bool TryParseDate(string? input, DateOnly today, out DateOnly value)
    {
        value = default;
        var text = input?.Trim().ToLowerInvariant() ?? "";
        switch (text)
        {
            case "днес":
                value = today;
                return true;
            case "вчера":
                value = today.AddDays(-1);
                return true;
            case "утре":
                value = today.AddDays(1);
                return true;
        }

        return DateOnly.TryParseExact(text, DateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out value);
    }

    /// <summary>Accepts H:mm / HH:mm (24-hour).</summary>
    public static bool TryParseTime(string? input, out TimeOnly value)
        => TimeOnly.TryParseExact(input?.Trim(), TimeFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out value);

    public static bool TryParseInt(string? input, int min, int max, out int value)
        => int.TryParse(input?.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out value) && value >= min && value <= max;
}
