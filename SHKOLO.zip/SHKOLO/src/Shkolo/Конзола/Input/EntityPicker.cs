// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Input;

/// <summary>
/// Picks an entity from a searchable list by readable name – the user never has to type a GUID.
/// Returns null when the user chooses "← Назад" or the list is empty.
/// </summary>
public sealed class EntityPicker
{
    private readonly IAnsiConsole _console;
    private readonly Notifier _notifier;

    public EntityPicker(IAnsiConsole console, Notifier notifier)
    {
        _console = console;
        _notifier = notifier;
    }

    public T? Pick<T>(string title, IReadOnlyList<T> items, Func<T, string> label)
        where T : class
    {
        if (items.Count == 0)
        {
            _notifier.Warning("Няма налични записи за избор.");
            return null;
        }

        var back = new Choice<T>(null, ShkoloTheme.BackLabel);
        var choices = items.Select(i => new Choice<T>(i, label(i))).Append(back).ToList();
        var prompt = new SelectionPrompt<Choice<T>>()
            .Title($"[bold]{Ui.Escape(title)}[/] {Ui.Muted("(стрелки, Enter; пишете за търсене)")}")
            .PageSize(12)
            .HighlightStyle(new Style(ShkoloTheme.Background, ShkoloTheme.Accent))
            .EnableSearch()
            .SearchPlaceholderText(Ui.Muted("Търсене…"))
            .UseConverter(c => Ui.Escape(c.Label))
            .AddChoices(choices);
        return _console.Prompt(prompt).Value;
    }

    /// <summary>Picks a value type (enum etc.) from labelled options.</summary>
    public T? PickValue<T>(string title, IReadOnlyList<(T Value, string Label)> options)
        where T : struct
    {
        var prompt = new SelectionPrompt<int>()
            .Title($"[bold]{Ui.Escape(title)}[/]")
            .PageSize(12)
            .HighlightStyle(new Style(ShkoloTheme.Background, ShkoloTheme.Accent))
            .UseConverter(i => i < options.Count ? Ui.Escape(options[i].Label) : ShkoloTheme.BackLabel)
            .AddChoices(Enumerable.Range(0, options.Count + 1));
        var index = _console.Prompt(prompt);
        return index < options.Count ? options[index].Value : null;
    }

    private sealed record Choice<T>(T? Value, string Label);
}
