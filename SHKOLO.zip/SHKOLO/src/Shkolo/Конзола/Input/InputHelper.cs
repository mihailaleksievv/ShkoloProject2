// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Abstractions;
using Shkolo.Domain;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Input;

/// <summary>Чете входа от клавиатурата и го проверява: текст, числа, оценки, дати.</summary>
public sealed class InputHelper
{
    private readonly IAnsiConsole _console;
    private readonly IClock _clock;

    public InputHelper(IAnsiConsole console, IClock clock)
    {
        _console = console;
        _clock = clock;
    }

    public static string CancelHint => Ui.Muted("(празен вход = отказ)");

    /// <summary>Required text. With <paramref name="current"/>, empty input keeps the current value.</summary>
    public string? ReadRequiredString(string label, int maxLength = 200, string? current = null)
    {
        while (true)
        {
            var hint = current is null ? CancelHint : Ui.Muted($"(Enter = „{current}“)");
            var text = Ask($"{Ui.Escape(label)} {hint}");
            if (string.IsNullOrWhiteSpace(text))
            {
                return current;
            }

            if (text.Trim().Length <= maxLength)
            {
                return text.Trim();
            }

            Invalid($"Най-много {maxLength} символа.");
        }
    }

    /// <summary>
    /// Optional text: empty input means "no value". Never cancels.
    /// With <paramref name="current"/>, empty input keeps the current value and "-" clears it.
    /// </summary>
    public string? ReadOptionalString(string label, int maxLength = 500, string? current = null)
    {
        while (true)
        {
            var hint = current is null ? Ui.Muted("(по желание)") : Ui.Muted($"(Enter = „{current}“ · „-“ = изтриване)");
            var text = Ask($"{Ui.Escape(label)} {hint}");
            if (string.IsNullOrWhiteSpace(text))
            {
                return current;
            }

            if (current is not null && text.Trim() == "-")
            {
                return null;
            }

            if (text.Trim().Length <= maxLength)
            {
                return text.Trim();
            }

            Invalid($"Най-много {maxLength} символа.");
        }
    }

    public int? ReadInt(string label, int min, int max, int? current = null)
    {
        while (true)
        {
            var text = Ask($"{Ui.Escape(label)} {Ui.Muted($"({min}–{max})")} {(current is null ? CancelHint : Ui.Muted($"(Enter = {current})"))}");
            if (string.IsNullOrWhiteSpace(text))
            {
                return current;
            }

            if (InputParsers.TryParseInt(text, min, max, out var value))
            {
                return value;
            }

            Invalid($"Въведете цяло число от {min} до {max}.");
        }
    }

    public decimal? ReadDecimal(string label, decimal min, decimal max)
    {
        while (true)
        {
            var text = Ask($"{Ui.Escape(label)} {Ui.Muted($"({min:0.00}–{max:0.00}, напр. 5,50)")} {CancelHint}");
            if (string.IsNullOrWhiteSpace(text))
            {
                return null;
            }

            if (InputParsers.TryParseDecimal(text, out var value) && value >= min && value <= max)
            {
                return value;
            }

            Invalid($"Въведете число от {min:0.00} до {max:0.00}.");
        }
    }

    /// <summary>Date as dd.MM.yyyy or "днес"/"вчера"/"утре". With a default, empty input returns it.</summary>
    public DateOnly? ReadDate(string label, DateOnly? defaultValue = null)
    {
        while (true)
        {
            var hint = defaultValue is { } d ? Ui.Muted($"(дд.мм.гггг · Enter = {Ui.Date(d)})") : $"{Ui.Muted("(дд.мм.гггг, „днес“)")} {CancelHint}";
            var text = Ask($"{Ui.Escape(label)} {hint}");
            if (string.IsNullOrWhiteSpace(text))
            {
                return defaultValue;
            }

            if (InputParsers.TryParseDate(text, _clock.Today, out var value))
            {
                return value;
            }

            Invalid("Невалидна дата. Пример: 05.11.2026.");
        }
    }

    public TimeOnly? ReadTime(string label, TimeOnly? defaultValue = null)
    {
        while (true)
        {
            var hint = defaultValue is { } t ? Ui.Muted($"(чч:мм · Enter = {Ui.Time(t)})") : $"{Ui.Muted("(чч:мм)")} {CancelHint}";
            var text = Ask($"{Ui.Escape(label)} {hint}");
            if (string.IsNullOrWhiteSpace(text))
            {
                return defaultValue;
            }

            if (InputParsers.TryParseTime(text, out var value))
            {
                return value;
            }

            Invalid("Невалиден час. Пример: 08:30.");
        }
    }

    /// <summary>E-mail. When optional, empty input means "no e-mail" (returns empty string); when required, empty input cancels (null).</summary>
    public string? ReadEmail(string label, bool optional, string? current = null)
    {
        while (true)
        {
            var hint = current is not null ? Ui.Muted($"(Enter = „{current}“)") : optional ? Ui.Muted("(по желание)") : CancelHint;
            var text = Ask($"{Ui.Escape(label)} {hint}");
            if (string.IsNullOrWhiteSpace(text))
            {
                return current ?? (optional ? "" : null);
            }

            if (DomainRules.IsEmailValid(text))
            {
                return text.Trim();
            }

            Invalid("Невалиден имейл адрес. Пример: ivan.petrov@school.bg.");
        }
    }

    public Guid? ReadGuid(string label)
    {
        while (true)
        {
            var text = Ask($"{Ui.Escape(label)} {CancelHint}");
            if (string.IsNullOrWhiteSpace(text))
            {
                return null;
            }

            if (Guid.TryParse(text.Trim(), out var value))
            {
                return value;
            }

            Invalid("Невалиден идентификатор (GUID).");
        }
    }

    /// <summary>Menu choice by arrow keys; invalid input is impossible by construction.</summary>
    public int ReadMenuChoice(string title, IReadOnlyList<string> options)
        => _console.Prompt(new SelectionPrompt<int>()
            .Title(Ui.Escape(title))
            .PageSize(15)
            .HighlightStyle(new Style(ShkoloTheme.Background, ShkoloTheme.Accent))
            .UseConverter(i => Ui.Escape(options[i]))
            .AddChoices(Enumerable.Range(0, options.Count)));

    public bool ReadConfirmation(string question, bool defaultValue = true)
        => _console.Prompt(new ConfirmationPrompt(Ui.Escape(question)) { DefaultValue = defaultValue, Yes = 'д', No = 'н' }.ShowChoices());

    public string? ReadPassword(string label)
    {
        var text = _console.Prompt(new TextPrompt<string>($"{Ui.Escape(label)}:").Secret('•').AllowEmpty());
        return string.IsNullOrEmpty(text) ? null : text;
    }

    private string Ask(string promptMarkup)
        => _console.Prompt(new TextPrompt<string>($"[{ShkoloTheme.TextHex}]{promptMarkup}[/]:").AllowEmpty());

    private void Invalid(string message) => _console.MarkupLine($"[{ShkoloTheme.ErrorHex}]  ✖ {Ui.Escape(message)}[/]");
}
