﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces;

/// <summary>Helpers shared by the role workspaces.</summary>
public static class WorkspaceKit
{
    /// <summary>„Добро утро“ / „Добър ден“ / „Добър вечер“ by the local hour.</summary>
    public static string Greeting(DateTime localNow) => localNow.Hour switch
    {
        < 12 => "Добро утро",
        < 18 => "Добър ден",
        _ => "Добър вечер",
    };

    /// <summary>First name of the logged-in user's display name.</summary>
    public static string FirstName(ScreenContext ctx) => (ctx.Services.Session.CurrentUser?.DisplayName ?? "").Split(' ')[0];

    /// <summary>The current term of the active year as a date range ending today (null outside the year).</summary>
    public static (DateOnly From, DateOnly To, string Name)? CurrentTerm(ScreenContext ctx)
    {
        var year = ctx.Services.AcademicYears.GetActive();
        var today = ctx.Services.Clock.Today;
        if (year is null || !year.Contains(today))
        {
            return null;
        }

        var term = year.GetTerm(today);
        var from = term == Domain.Enums.Term.First ? year.StartDate : year.FirstTermEndDate.AddDays(1);
        return (from, today, BulgarianNames.Of(term));
    }

    /// <summary>Total school days and the ones already passed in the current term.</summary>
    public static (int Passed, int Total)? TermProgress(ScreenContext ctx)
    {
        var year = ctx.Services.AcademicYears.GetActive();
        var today = ctx.Services.Clock.Today;
        if (year is null || !year.Contains(today))
        {
            return null;
        }

        var first = year.GetTerm(today) == Domain.Enums.Term.First;
        var from = first ? year.StartDate : year.FirstTermEndDate.AddDays(1);
        var to = first ? year.FirstTermEndDate : year.EndDate;
        int Count(DateOnly a, DateOnly b) => Enumerable.Range(0, b.DayNumber - a.DayNumber + 1).Select(a.AddDays)
            .Count(d => d.DayOfWeek is not DayOfWeek.Saturday and not DayOfWeek.Sunday);
        return (Count(from, today), Count(from, to));
    }

    /// <summary>A titled box used for dashboard blocks.</summary>
    public static IRenderable Box(string title, IRenderable content, Color accent)
        => new Panel(content).Header($" {Ui.Escape(title)} ").Border(BoxBorder.Rounded).BorderColor(accent);

    /// <summary>
    /// The next day (after today, within two weeks and the active school year) on which the signed-in teacher
    /// has lessons, with those lessons in order. Null when there is none.
    /// </summary>
    public static (DateOnly Date, IReadOnlyList<Application.Reports.TimetableRow> Lessons)? NextSchoolDay(ScreenContext ctx)
    {
        if (ctx.Services.Session.TeacherId is not { } teacherId || ctx.Services.Timetable.GetForTeacher(teacherId).Value is not { } rows)
        {
            return null;
        }

        var year = ctx.Services.AcademicYears.GetActive();
        var today = ctx.Services.Clock.Today;
        for (var date = today.AddDays(1); date <= today.AddDays(14); date = date.AddDays(1))
        {
            if (year is not null && !year.Contains(date))
            {
                break;
            }

            var lessons = rows.Where(r => r.Day == date.DayOfWeek).OrderBy(r => r.LessonNumber).ToList();
            if (lessons.Count > 0)
            {
                return (date, lessons);
            }
        }

        return null;
    }

    /// <summary>"понеделник, 23.11".</summary>
    public static string DayLabel(DateOnly date)
        => $"{BulgarianNames.Of(date.DayOfWeek).ToLower(BulgarianNames.Culture)}, {date:dd.MM}";

    public static IRenderable Empty(string text) => new Markup(Ui.Muted(text));

    public static string Number(int value) => $"[bold {ShkoloTheme.TextHex}]{Ui.Count(value)}[/]";

    public static Color Accent(ScreenContext ctx) => RoleAccent.For(ctx.Services.Session.Role);
}
