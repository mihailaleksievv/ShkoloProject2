﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Shell;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Learning;

/// <summary>Month calendar with school events and homework deadlines; ← / → change the month.</summary>
public sealed class StudentCalendarSection : ISection
{
    private DateOnly _month;
    private IReadOnlyList<(DateOnly Date, string Label)> _marks = [];

    public string Title => "Календар";

    public string Icon => Glyphs.Flag;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Училищни събития", 'Б', () => new EventsScreen(canManage: false)),
    ];

    public void Load(ScreenContext ctx)
    {
        if (_month == default)
        {
            var today = ctx.Services.Clock.Today;
            _month = new DateOnly(today.Year, today.Month, 1);
        }

        LoadMarks(ctx);
    }

    public bool HandleKey(ScreenContext ctx, ConsoleKeyInfo key)
    {
        if (key.Key is not (ConsoleKey.LeftArrow or ConsoleKey.RightArrow))
        {
            return false;
        }

        _month = _month.AddMonths(key.Key == ConsoleKey.RightArrow ? 1 : -1);
        LoadMarks(ctx);
        return true;
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
        => new Rows(CalendarView.Render(_month.Year, _month.Month, _marks), new Markup(Ui.Muted("← → предишен / следващ месец")));

    private void LoadMarks(ScreenContext ctx)
    {
        var end = _month.AddMonths(1).AddDays(-1);
        var events = ctx.Services.Events.GetByDateRange(_month, end)
            .Select(e => (DateOnly.FromDateTime(e.Start), $"{e.Title} · {Ui.Time(TimeOnly.FromDateTime(e.Start))}"));
        var homework = (ctx.Services.Homework.GetHomeworkForStudent(ctx.Services.Session.StudentId!.Value).Value ?? [])
            .Where(h => h.DueDate >= _month && h.DueDate <= end)
            .Select(h => (h.DueDate, $"Срок: {h.Title} ({h.SubjectName})"));
        _marks = events.Concat(homework).OrderBy(m => m.Item1).ToList();
    }
}
