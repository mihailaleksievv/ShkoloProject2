// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Screens.StudentArea;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Learning;

/// <summary>Homework cards with a countdown to the due date and the student's status.</summary>
public sealed class StudentHomeworkSection : ISection
{
    private IReadOnlyList<HomeworkView> _homework = [];

    public string Title => "Домашни";

    public string Icon => Glyphs.Mail;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Предаване и описание", 'П', () => new MyHomeworkScreen()),
    ];

    public void Load(ScreenContext ctx)
        => _homework = ctx.Services.Homework.GetHomeworkForStudent(ctx.Services.Session.StudentId!.Value).Value ?? [];

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_homework.Count == 0)
        {
            return WorkspaceKit.Empty("Нямате домашни.");
        }

        var today = ctx.Services.Clock.Today;
        var accent = WorkspaceKit.Accent(ctx);
        return new Columns(_homework.Select(h => Card.Render(
            h.SubjectName,
            $"[bold]{Ui.Escape(h.Title)}[/]\n{Countdown(h.DueDate, today)} {Ui.Muted("· " + Ui.Date(h.DueDate))}\n{StudentReportScreen.HomeworkStatusMarkup(h.StatusForStudent)}",
            null,
            h.DueDate < today ? ShkoloTheme.Error : accent)));
    }

    public static string Countdown(DateOnly due, DateOnly today)
    {
        var days = due.DayNumber - today.DayNumber;
        return days switch
        {
            < 0 => $"[bold {ShkoloTheme.ErrorHex}]просрочено[/]",
            0 => $"[bold {ShkoloTheme.WarningHex}]срок днес[/]",
            1 => $"[bold {ShkoloTheme.WarningHex}]остава 1 ден[/]",
            _ => $"[bold {ShkoloTheme.AccentHex}]остават {days} дни[/]",
        };
    }
}
