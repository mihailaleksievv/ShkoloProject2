// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Shell;

namespace Shkolo.Presentation.Workspaces.Learning;

/// <summary>Student command centre: "Моят напредък".</summary>
public sealed class StudentWorkspace : IWorkspace
{
    public string Name => "Ученик";

    public IReadOnlyList<ISection> Sections(ScreenContext ctx) =>
    [
        new StudentDashboardSection(),
        new StudentGradesSection(),
        new StudentTimetableSection(),
        new StudentHomeworkSection(),
        new StudentCalendarSection(),
        new StudentMessagesSection(),
        new StudentAchievementsSection(),
    ];
}
