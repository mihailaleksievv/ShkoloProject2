// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.StudentArea;
using Shkolo.Presentation.Shell;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Learning;

/// <summary>The gradebook: one row per subject with every grade as a coloured badge and the average.</summary>
public sealed class StudentGradesSection : ISection
{
    private IReadOnlyList<IGrouping<string, GradeView>> _bySubject = [];

    public string Title => "Оценки";

    public string Icon => Glyphs.Pencil;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Филтри и подробен списък", 'Ф', () => new MyGradesScreen()),
        SectionAction.Open("Справка за успеха и CSV", 'С', () => new MyPerformanceScreen()),
    ];

    public void Load(ScreenContext ctx)
        => _bySubject = (ctx.Services.Grades.GetGradesForStudent(ctx.Services.Session.StudentId!.Value).Value ?? [])
            .OrderBy(g => g.Date)
            .GroupBy(g => g.SubjectName)
            .OrderBy(g => g.Key, StringComparer.CurrentCulture)
            .ToList();

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_bySubject.Count == 0)
        {
            return WorkspaceKit.Empty("Все още нямате оценки тази учебна година.");
        }

        var table = new Table().Border(TableBorder.Simple).BorderColor(WorkspaceKit.Accent(ctx))
            .AddColumn("Предмет").AddColumn("Оценки").AddColumn("Среден успех");
        foreach (var subject in _bySubject)
        {
            table.AddRow(
                new Markup($"[bold]{Ui.Escape(subject.Key)}[/]"),
                new Markup(string.Join(" ", subject.Select(g => GradeBadge.Markup(g.Value)))),
                new Markup(GradeFormatter.WithWord(subject.Average(g => g.Value))));
        }

        return table;
    }
}
