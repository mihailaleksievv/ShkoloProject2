// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Learning;

/// <summary>Achievements and the praises and remarks visible to the student.</summary>
public sealed class StudentAchievementsSection : ISection
{
    private IReadOnlyList<AchievementView> _achievements = [];
    private IReadOnlyList<FeedbackView> _feedback = [];

    public string Title => "Отличия";

    public string Icon => Glyphs.Star;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Смяна на парола", 'П', () => new ChangePasswordScreen()),
    ];

    public void Load(ScreenContext ctx)
    {
        var id = ctx.Services.Session.StudentId!.Value;
        _achievements = ctx.Services.Achievements.GetForStudent(id).Value ?? [];
        _feedback = ctx.Services.Feedback.GetForStudent(id).Value ?? [];
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        var accent = WorkspaceKit.Accent(ctx);
        IRenderable badges = _achievements.Count == 0
            ? WorkspaceKit.Empty("Все още нямате отличия.")
            : new Columns(_achievements.Select(a => Card.Render(a.Name, $"[bold {ShkoloTheme.WarningHex}]{Ui.Escape(a.Symbol)}[/]  {Ui.Escape(a.Description)}", $"{a.TeacherName} · {Ui.FromUtc(a.AssignedAtUtc)}", accent)));
        var feedback = _feedback.Count == 0
            ? WorkspaceKit.Empty("Няма похвали и забележки.")
            : new Markup(string.Join("\n", _feedback.Take(8).Select(f =>
                $"{(f.Type == FeedbackType.Praise ? $"[{ShkoloTheme.SuccessHex}]{Glyphs.Up} Похвала[/]" : $"[{ShkoloTheme.WarningHex}]{Glyphs.Warn} Забележка[/]")} {Ui.Muted(Ui.Date(f.Date))} {Ui.Escape(f.Description)} {Ui.Muted("· " + f.TeacherName)}")));
        return new Rows(badges, WorkspaceKit.Box("Похвали и забележки", feedback, accent));
    }
}
