// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Learning;

/// <summary>Unread notifications and the latest announcements.</summary>
public sealed class StudentMessagesSection : ISection
{
    private IReadOnlyList<Notification> _unread = [];
    private IReadOnlyList<AnnouncementView> _announcements = [];

    public string Title => "Съобщения";

    public string Icon => Glyphs.Mail;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Известия", 'И', () => new NotificationsScreen()),
        SectionAction.Open("Съобщения", 'С', () => new AnnouncementsScreen(canPublish: false)),
    ];

    public void Load(ScreenContext ctx)
    {
        _unread = ctx.Services.Notifications.GetForCurrentUser(unreadOnly: true);
        _announcements = ctx.Services.Announcements.GetActiveForCurrentUser().Take(5).ToList();
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        var accent = WorkspaceKit.Accent(ctx);
        var unread = _unread.Count == 0
            ? WorkspaceKit.Empty("Нямате нови известия.")
            : new Markup(string.Join("\n", _unread.Take(8).Select(n => $"[{ShkoloTheme.WarningHex}]{Glyphs.Now}[/] [bold]{Ui.Escape(n.Title)}[/] {Ui.Muted(n.Message)}")));
        var news = _announcements.Count == 0
            ? WorkspaceKit.Empty("Няма активни съобщения.")
            : new Markup(string.Join("\n", _announcements.Select(a => $"[{ShkoloTheme.AccentHex}]{Glyphs.Mail}[/] [bold]{Ui.Escape(a.Title)}[/] {Ui.Muted("· " + a.AuthorName)}")));
        return new Rows(WorkspaceKit.Box($"Нови известия ({_unread.Count})", unread, accent), WorkspaceKit.Box("Съобщения", news, accent));
    }
}
