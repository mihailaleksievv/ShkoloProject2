// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Shell;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Learning;

/// <summary>Weekly timetable with today and the current lesson highlighted.</summary>
public sealed class StudentTimetableSection : ISection
{
    private IReadOnlyList<TimetableRow> _rows = [];
    private IReadOnlyList<LessonSlot> _slots = [];

    public string Title => "Разписание";

    public string Icon => Glyphs.Clock;

    public IReadOnlyList<SectionAction> Actions => [];

    public void Load(ScreenContext ctx)
    {
        _rows = ctx.Services.Timetable.GetForCurrentUser();
        _slots = ctx.Services.BellSchedule.GetSlots();
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        var now = TimeOnly.FromDateTime(frame.LocalNow);
        var current = _slots.FirstOrDefault(s => now >= s.StartTime && now < s.EndTime)?.LessonNumber;
        return TimetableGrid.Build("Седмично разписание", _rows, _slots, r => r.TeacherName, frame.LocalNow.DayOfWeek, current);
    }
}
