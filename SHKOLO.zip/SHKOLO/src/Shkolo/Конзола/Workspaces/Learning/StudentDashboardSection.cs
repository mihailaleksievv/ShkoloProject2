﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Learning;

/// <summary>
/// The student's progress in the layout of the v1.0 class report: a row of tiles, then full-width pages
/// switched with ← →: subject averages, attendance (split and heatmap), and the trend (weekly columns, latest grades, term).
/// </summary>
public sealed class StudentDashboardSection : ISection
{
    private StudentDashboard? _dashboard;
    private IReadOnlyList<DayAttendance> _days = [];
    private IReadOnlyList<decimal?> _weeks = [];
    private (int Passed, int Total)? _term;
    private string _termName = "";
    private int _page;

    private static readonly string[] Pages = ["Успех", "Присъствия", "Тенденция"];

    public string Title => "Табло";

    public string Icon => Glyphs.Home;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Form("Моите отсъствия", 'О', MyAbsences),
    ];

    private static void MyAbsences(ScreenContext ctx)
    {
        if (ctx.Services.Session.StudentId is { } studentId)
        {
            var records = (ctx.Services.Attendance.GetAttendanceForStudent(studentId).Value ?? [])
                .Where(a => a.Status != AttendanceStatus.Present)
                .ToList();
            GradeTables.Attendance(ctx.Console, records, "Отсъствия и закъснения");
        }

        ctx.Notifier.Pause();
    }

    public bool HandleKey(ScreenContext ctx, ConsoleKeyInfo key)
    {
        if (PageTabs.Step(key, Pages.Length, _page) is not { } next)
        {
            return false;
        }

        _page = next;
        return true;
    }

    public void Load(ScreenContext ctx)
    {
        var reports = ctx.Services.Reports;
        var studentId = ctx.Services.Session.StudentId!.Value;
        _dashboard = reports.GetStudentDashboard().Value;
        var term = WorkspaceKit.CurrentTerm(ctx);
        _termName = term?.Name ?? "Извън учебната година";
        _days = term is null ? [] : reports.GetStudentAttendanceDays(studentId, term.Value.From, term.Value.To).Value ?? [];
        _weeks = (reports.GetStudentGradeTrend(studentId).Value ?? []).Select(w => w.Average).ToList();
        _term = WorkspaceKit.TermProgress(ctx);
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_dashboard is not { } d)
        {
            return WorkspaceKit.Empty("Таблото не може да бъде заредено.");
        }

        var r = d.Report;
        var identity = new Markup($"[bold]{Ui.Escape(r.Student.FullName.ToUpper(BulgarianNames.Culture))}[/]  {Ui.Muted($"{r.ClassName} клас · №{r.Student.StudentNumber}")}  " +
                                  $"{Ui.Muted(WorkspaceKit.Greeting(frame.LocalNow) + "!")}");
        var tiles = StatPanel.Tiles(1,
            ("Среден успех", GradeFormatter.WithWord(r.OverallAverage)),
            ("Оценки", StatPanel.Number(r.GradeCount)),
            ("Неизвинени", $"[bold {ShkoloTheme.ErrorHex}]{r.Attendance.Unexcused}[/]"),
            ("Извинени", $"[bold {ShkoloTheme.WarningHex}]{r.Attendance.Excused}[/]"),
            ("Закъснения", StatPanel.Number(r.Attendance.Late)));

        var roomy = ctx.Console.Profile.Height >= 40;
        IRenderable page = _page switch
        {
            0 => new Rows(
                PageTabs.Heading("Успех по предмети"),
                new Text(""),
                r.SubjectAverages.Count == 0
                    ? WorkspaceKit.Empty("Все още няма оценки.")
                    : GradeBars.Render(r.SubjectAverages.OrderByDescending(x => x.Average).Select(x => new GradeBar(x.SubjectName, x.Average)).ToList(),
                        r.OverallAverage, 36, spacing: roomy)),
            1 => new Rows(
                PageTabs.Heading($"Присъствия · {_termName}"),
                new Text(""),
                SegmentBar.Attendance(r.Attendance, 90),
                new Text(""),
                PageTabs.Heading("По дни"),
                new Text(""),
                Heatmap.Render(_days)),
            _ when !roomy => TrendPage(r, compact: true),
            _ => TrendPage(r, compact: false),
        };

        return new Rows(identity, tiles, new Text(""), PageTabs.Render(Pages, _page), new Text(""), page);
    }

    private static string Short(string subject) => subject.Length <= 16 ? subject : subject[..15] + "…";

    private IRenderable TrendPage(StudentReport r, bool compact)
    {
        var weeks = new Rows(
            new Markup($"{Trend.Of(_weeks)} {Ui.Muted("среден успех за последните 6 седмици")}"),
            new Text(""),
            WeekColumns.Render(_weeks, compact ? 3 : 5));
        var recent = r.RecentGrades.Count == 0
            ? Ui.Muted("Няма оценки.")
            : string.Join("   ", r.RecentGrades.Take(4).Select(g => $"{GradeBadge.Markup(g.Value)} {Ui.Muted(Short(g.SubjectName))}"));
        var termLine = _term is { } t
            ? $"{Meter.Markup(t.Passed, Math.Max(1, t.Total), 40, ShkoloTheme.Primary, ShkoloTheme.Accent)}  {Ui.Muted($"{_termName} · ден {t.Passed} от {t.Total}")}"
            : Ui.Muted(_termName);
        var achievements = r.Achievements.Count == 0
            ? Ui.Muted("Все още няма отличия.")
            : string.Join("   ", r.Achievements.Select(a => $"[bold {ShkoloTheme.WarningHex}]{Ui.Escape(a.Symbol)}[/] {Ui.Escape(a.Name)}"));

        var left = new Rows(PageTabs.Heading("Тенденция · 6 седмици"), new Text(""), weeks);
        var right = new Rows(PageTabs.Heading("Среден успех"), new Text(""), GradeGauge.Render(r.OverallAverage));
        var top = new Grid().AddColumn(new GridColumn().PadRight(6)).AddColumn();
        top.AddRow(left, right);

        return new Rows(
            top,
            new Text(""),
            PageTabs.Heading("Последни оценки"),
            new Markup(recent),
            new Text(""),
            PageTabs.Heading("Срок и отличия"),
            new Markup(termLine),
            new Markup(achievements));
    }
}
