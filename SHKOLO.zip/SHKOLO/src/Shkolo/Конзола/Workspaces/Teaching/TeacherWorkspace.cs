// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Shell;

namespace Shkolo.Presentation.Workspaces.Teaching;

/// <summary>Teacher command centre: "Моят учебен ден".</summary>
public sealed class TeacherWorkspace : IWorkspace
{
    public string Name => "Учител";

    public IReadOnlyList<ISection> Sections(ScreenContext ctx) =>
    [
        new TeacherDashboardSection(),
        new TodaySection(),
        new ClassesSection(),
        new GradesSection(),
        new TermGradesSection(),
        new AttendanceSection(),
        new HomeworkSection(),
        new CommunicationSection(),
        new ReportsSection(),
    ];
}
