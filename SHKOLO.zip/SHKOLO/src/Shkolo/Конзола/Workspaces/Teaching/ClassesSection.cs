// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.TeacherArea;
using Shkolo.Presentation.Shell;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Teaching;

/// <summary>A card per taught class: size, average, 6-week trend and class-teacher badge.</summary>
public sealed class ClassesSection : ISection
{
    private sealed record ClassCard(string Name, int Students, decimal? Average, IReadOnlyList<decimal?> Weeks, bool IsClassTeacher);

    private IReadOnlyList<ClassCard> _cards = [];

    public string Title => "Класове";

    public string Icon => Glyphs.Diamond;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Ученици и справки", 'У', () => new MyClassesScreen()),
    ];

    public void Load(ScreenContext ctx)
    {
        var services = ctx.Services;
        _cards = (services.Reports.GetTeacherDashboard().Value?.Classes ?? [])
            .Select(c => new ClassCard(
                c.ClassName,
                c.StudentCount,
                services.Reports.GenerateClassReport(c.ClassId).Value?.ClassAverage,
                (services.Reports.GetClassGradeTrend(c.ClassId).Value ?? []).Select(w => w.Average).ToList(),
                services.Authorization.IsClassTeacherOf(c.ClassId)))
            .ToList();
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_cards.Count == 0)
        {
            return WorkspaceKit.Empty("Нямате назначени класове.");
        }

        var accent = WorkspaceKit.Accent(ctx);
        return new Columns(_cards.Select(c => Card.Render(
            $"{c.Name} клас{(c.IsClassTeacher ? " · класен ръководител" : "")}",
            $"{(c.Average is { } a ? GradeBadge.Markup(a) : Ui.Muted("няма оценки"))}  {Trend.Of(c.Weeks)}\n[{Gradient.Hex(accent)}]{Sparkline.Grades(c.Weeks)}[/] {Ui.Muted("6 седмици")}\n{WorkspaceKit.Number(c.Students)} {Ui.Muted("ученици")}",
            null,
            accent)));
    }
}
