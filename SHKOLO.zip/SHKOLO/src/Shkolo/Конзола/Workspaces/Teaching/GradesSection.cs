// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.TeacherArea;
using Shkolo.Presentation.Shell;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Teaching;

/// <summary>The teacher's ten most recent grades with quick access to grading.</summary>
public sealed class GradesSection : ISection
{
    private IReadOnlyList<GradeView> _recent = [];

    public string Title => "Оценки";

    public string Icon => Glyphs.Pencil;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Form("Нова оценка", 'Н', GradesScreen.Add),
        SectionAction.Open("Редакция, изтриване и преглед", 'Е', () => new GradesScreen()),
    ];

    public void Load(ScreenContext ctx)
    {
        var services = ctx.Services;
        var me = services.Session.TeacherId;
        _recent = services.Authorization.TaughtClassIds()
            .SelectMany(id => services.Grades.GetGradesForClass(id).Value ?? [])
            .Where(g => g.TeacherId == me)
            .OrderByDescending(g => g.Date)
            .Take(10)
            .ToList();
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_recent.Count == 0)
        {
            return WorkspaceKit.Empty("Все още не сте поставяли оценки.");
        }

        var table = new Table().Border(TableBorder.Simple).BorderColor(WorkspaceKit.Accent(ctx))
            .AddColumn("Дата").AddColumn("Ученик").AddColumn("Предмет").AddColumn("Оценка").AddColumn("Вид");
        foreach (var g in _recent)
        {
            table.AddRow(
                new Markup(Ui.Muted(Ui.Date(g.Date))),
                new Markup(Ui.Escape(g.StudentName)),
                new Markup(Ui.Escape(g.SubjectName)),
                new Markup(GradeBadge.Markup(g.Value)),
                new Markup(Ui.Muted(BulgarianNames.Of(g.Type))));
        }

        return table;
    }
}
