// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.TeacherArea;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Teaching;

/// <summary>Upcoming and overdue homework with a submission meter.</summary>
public sealed class HomeworkSection : ISection
{
    private IReadOnlyList<HomeworkView> _upcoming = [];
    private IReadOnlyList<HomeworkView> _overdue = [];

    public string Title => "Домашни";

    public string Icon => Glyphs.Mail;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Ново, редакция, предадени, архив", 'Н', () => new HomeworkScreen()),
    ];

    public void Load(ScreenContext ctx)
    {
        _upcoming = ctx.Services.Homework.GetUpcomingHomework();
        _overdue = ctx.Services.Homework.GetOverdueHomework();
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_upcoming.Count + _overdue.Count == 0)
        {
            return WorkspaceKit.Empty("Нямате активни домашни.");
        }

        var table = new Table().Border(TableBorder.Simple).BorderColor(WorkspaceKit.Accent(ctx))
            .AddColumn("Срок").AddColumn("Клас").AddColumn("Заглавие").AddColumn("Предадени").AddColumn("");
        foreach (var h in _upcoming.Concat(_overdue))
        {
            var overdue = h.DueDate < ctx.Services.Clock.Today;
            table.AddRow(
                new Markup(overdue ? $"[{ShkoloTheme.ErrorHex}]{Ui.Date(h.DueDate)}[/]" : Ui.Date(h.DueDate)),
                new Markup(Ui.Escape(h.ClassName)),
                new Markup(Ui.Escape(h.Title)),
                new Markup(Meter.Markup(h.SubmissionCount, Math.Max(1, h.ClassSize), 16, ShkoloTheme.Primary, ShkoloTheme.Success)),
                new Markup($"{h.SubmissionCount}/{h.ClassSize}"));
        }

        return table;
    }
}
