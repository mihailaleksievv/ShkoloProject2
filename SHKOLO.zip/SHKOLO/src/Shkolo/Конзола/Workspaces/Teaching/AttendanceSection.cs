// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.TeacherArea;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Teaching;

/// <summary>Attendance heatmap of one taught class for the current term; ← / → switch the class.</summary>
public sealed class AttendanceSection : ISection
{
    private IReadOnlyList<ClassSize> _classes = [];
    private int _index;
    private IReadOnlyList<DayAttendance> _days = [];
    private string _termName = "";

    public string Title => "Отсъствия";

    public string Icon => Glyphs.List;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Отсъствия, извиняване и обобщение", 'О', () => new AttendanceScreen()),
    ];

    public void Load(ScreenContext ctx)
    {
        _classes = ctx.Services.Reports.GetTeacherDashboard().Value?.Classes ?? [];
        _index = Math.Clamp(_index, 0, Math.Max(0, _classes.Count - 1));
        LoadDays(ctx);
    }

    public bool HandleKey(ScreenContext ctx, ConsoleKeyInfo key)
    {
        if (_classes.Count < 2 || key.Key is not (ConsoleKey.LeftArrow or ConsoleKey.RightArrow))
        {
            return false;
        }

        _index = (_index + (key.Key == ConsoleKey.RightArrow ? 1 : _classes.Count - 1)) % _classes.Count;
        LoadDays(ctx);
        return true;
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_classes.Count == 0)
        {
            return WorkspaceKit.Empty("Нямате назначени класове.");
        }

        var tabs = string.Join("  ", _classes.Select((c, i) => i == _index
            ? $"[bold {ShkoloTheme.BackgroundHex} on {Gradient.Hex(WorkspaceKit.Accent(ctx))}] {Ui.Escape(c.ClassName)} [/]"
            : Ui.Muted(c.ClassName)));
        var withLessons = _days.Where(d => d.Worst is not null).ToList();
        var summary = $"Учебни дни: {withLessons.Count} · с неизвинено: [{ShkoloTheme.ErrorHex}]{withLessons.Count(d => d.Worst == AttendanceStatus.Absent)}[/] · с извинено: [{ShkoloTheme.WarningHex}]{withLessons.Count(d => d.Worst == AttendanceStatus.ExcusedAbsent)}[/]";
        return new Rows(
            new Markup($"{tabs}   {Ui.Muted("← → смяна на класа")}"),
            new Markup(Ui.Muted($"{_termName} · най-лошият статус в класа за всеки ден")),
            Heatmap.Render(_days),
            new Markup(summary));
    }

    private void LoadDays(ScreenContext ctx)
    {
        var term = WorkspaceKit.CurrentTerm(ctx);
        _termName = term?.Name ?? "Извън учебната година";
        _days = _classes.Count == 0 || term is null
            ? []
            : ctx.Services.Reports.GetClassAttendanceDays(_classes[_index].ClassId, term.Value.From, term.Value.To).Value ?? [];
    }
}
