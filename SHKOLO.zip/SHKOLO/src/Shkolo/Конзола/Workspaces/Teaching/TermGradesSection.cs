// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.TeacherArea;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Teaching;

/// <summary>Progress of the term grades for every class and subject the teacher teaches.</summary>
public sealed class TermGradesSection : ISection
{
    private sealed record Row(string ClassName, string Subject, int Assigned, int Total);

    private IReadOnlyList<Row> _rows = [];
    private TermPeriod _period = TermPeriod.FirstTerm;

    public string Title => "Срочни";

    public string Icon => Glyphs.Star;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Поставяне на срочни оценки", 'С', () => new TermGradesScreen()),
    ];

    public void Load(ScreenContext ctx)
    {
        var services = ctx.Services;
        var year = services.AcademicYears.GetActive();
        _period = year is not null && year.GetTerm(services.Clock.Today) == Term.Second ? TermPeriod.SecondTerm : TermPeriod.FirstTerm;
        _rows = (services.Assignments.GetForTeacher(services.Session.TeacherId!.Value).Value ?? [])
            .Select(a =>
            {
                var sheet = services.TermGrades.GetTermGradeSheet(a.ClassId, a.SubjectId, _period).Value ?? [];
                return new Row(a.ClassName, a.SubjectName, sheet.Count(r => r.Assigned is not null), sheet.Count);
            })
            .ToList();
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_rows.Count == 0)
        {
            return WorkspaceKit.Empty("Нямате назначения.");
        }

        var table = new Table().Border(TableBorder.Simple).BorderColor(WorkspaceKit.Accent(ctx))
            .Title($"[bold]{Ui.Escape(BulgarianNames.Of(_period))}[/]")
            .AddColumn("Клас").AddColumn("Предмет").AddColumn("Напредък").AddColumn(new TableColumn("Поставени").RightAligned());
        foreach (var r in _rows)
        {
            table.AddRow(
                new Markup(Ui.Escape(r.ClassName)),
                new Markup(Ui.Escape(r.Subject)),
                new Markup(Meter.Markup(r.Assigned, Math.Max(1, r.Total), 24, ShkoloTheme.Warning, ShkoloTheme.Success)),
                new Markup($"{r.Assigned}/{r.Total}"));
        }

        return table;
    }
}
