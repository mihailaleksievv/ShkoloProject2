﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.TeacherArea;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Teaching;

/// <summary>Today's lessons as cards with their status.</summary>
public sealed class TodaySection : ISection
{
    private TeacherDashboard? _dashboard;

    public string Title => "Днес";

    public string Icon => Glyphs.Clock;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Провеждане на час", 'П', () => new RecordLessonScreen()),
        SectionAction.Open("История на часовете", 'И', () => new LessonHistoryScreen()),
        SectionAction.Form("Седмично разписание", 'Р', WeeklyTimetable),
    ];

    private static void WeeklyTimetable(ScreenContext ctx)
    {
        if (ctx.Services.Session.TeacherId is { } teacherId && ctx.Services.Timetable.GetForTeacher(teacherId).Value is { } rows)
        {
            TimetableGrid.Render(ctx.Console, "Моето седмично разписание", rows, ctx.Services.BellSchedule.GetSlots(), r => r.ClassName, ctx.Services.Clock.Today.DayOfWeek);
        }

        ctx.Notifier.Pause();
    }

    private (DateOnly Date, IReadOnlyList<TimetableRow> Lessons)? _next;

    public void Load(ScreenContext ctx)
    {
        _dashboard = ctx.Services.Reports.GetTeacherDashboard().Value;
        _next = _dashboard is { Today.Count: 0 } ? WorkspaceKit.NextSchoolDay(ctx) : null;
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        var rows = _dashboard?.Today ?? [];
        if (rows.Count == 0)
        {
            return _next is { } next ? NextDay(ctx, next.Date, next.Lessons) : WorkspaceKit.Empty("Днес нямате часове по разписание.");
        }

        var accent = WorkspaceKit.Accent(ctx);
        var now = TimeOnly.FromDateTime(frame.LocalNow);
        var cards = rows.Select(r =>
        {
            var recorded = _dashboard!.TodayRecordedEntryIds.Contains(r.EntryId);
            var isNow = now >= r.Start && now < r.End;
            var status = recorded ? $"[bold {ShkoloTheme.SuccessHex}]{Glyphs.Done} записан[/]"
                : isNow ? $"[bold {ShkoloTheme.AccentHex}]{Glyphs.Now} сега[/]"
                : now >= r.End ? $"[{ShkoloTheme.WarningHex}]{Glyphs.Pending} незаписан[/]"
                : Ui.Muted($"{Glyphs.Pending} предстои");
            return Card.Render($"{r.LessonNumber}. час · {Ui.Time(r.Start)}–{Ui.Time(r.End)}",
                $"[bold]{Ui.Escape(r.SubjectName)}[/]\n{Ui.Escape(r.ClassName)}{(r.Room is null ? "" : $" · стая {Ui.Escape(r.Room)}")}\n{status}", null, isNow ? ShkoloTheme.Accent : accent);
        }).ToList();

        return new Columns(cards);
    }

    /// <summary>No lessons today: the programme of the next school day, every lesson marked as upcoming.</summary>
    private static IRenderable NextDay(ScreenContext ctx, DateOnly date, IReadOnlyList<TimetableRow> lessons)
    {
        var accent = WorkspaceKit.Accent(ctx);
        var cards = lessons.Select(r => Card.Render($"{r.LessonNumber}. час · {Ui.Time(r.Start)}–{Ui.Time(r.End)}",
            $"[bold]{Ui.Escape(r.SubjectName)}[/]\n{Ui.Escape(r.ClassName)}{(r.Room is null ? "" : $" · стая {Ui.Escape(r.Room)}")}\n{Ui.Muted($"{Glyphs.Pending} предстои")}", null, accent)).ToList();
        return new Rows(
            new Markup($"{Ui.Muted("Днес нямате часове по разписание.")} [bold]Следващ учебен ден: {Ui.Escape(WorkspaceKit.DayLabel(date))}[/] {Ui.Muted($"· {lessons.Count} часа")}"),
            new Text(""),
            new Columns(cards));
    }
}
