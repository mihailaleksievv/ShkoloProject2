﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.TeacherArea;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Teaching;

/// <summary>Greeting, the day timeline, key numbers, class trends and the "needs attention" list.</summary>
public sealed class TeacherDashboardSection : ISection
{
    private TeacherDashboard? _dashboard;
    private IReadOnlyList<(string ClassName, IReadOnlyList<decimal?> Weeks)> _trends = [];
    private IReadOnlyList<AttentionItem> _attention = [];
    private IReadOnlyList<Domain.Models.LessonSlot> _slots = [];
    private (DateOnly Date, IReadOnlyList<Application.Reports.TimetableRow> Lessons)? _next;

    public string Title => "Табло";

    public string Icon => Glyphs.Home;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Провеждане на час", 'П', () => new RecordLessonScreen()),
    ];

    public void Load(ScreenContext ctx)
    {
        var reports = ctx.Services.Reports;
        _dashboard = reports.GetTeacherDashboard().Value;
        _slots = ctx.Services.BellSchedule.GetSlots();
        _next = _dashboard is { Today.Count: 0 } ? WorkspaceKit.NextSchoolDay(ctx) : null;
        _attention = reports.GetAttentionList().Value ?? [];
        _trends = (_dashboard?.Classes ?? [])
            .Select(c => (c.ClassName, (IReadOnlyList<decimal?>)(reports.GetClassGradeTrend(c.ClassId).Value ?? []).Select(w => w.Average).ToList()))
            .ToList();
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_dashboard is not { } d)
        {
            return WorkspaceKit.Empty("Таблото не може да бъде заредено.");
        }

        var accent = WorkspaceKit.Accent(ctx);
        var dayNote = d.Today.Count > 0
            ? $"Днес имате {d.Today.Count} часа."
            : _next is { } n ? $"Днес нямате часове. Следващ учебен ден: {WorkspaceKit.DayLabel(n.Date)} – {n.Lessons.Count} часа." : "Днес нямате часове.";
        var greeting = new Markup($"[bold]{WorkspaceKit.Greeting(frame.LocalNow)}, {Ui.Escape(WorkspaceKit.FirstName(ctx))}![/] {Ui.Muted(dayNote)}");
        var timeline = d.Today.Count == 0 && _next is { } next
            ? WorkspaceKit.Box($"Следващ учебен ден · {WorkspaceKit.DayLabel(next.Date)}",
                DayTimeline.Render(_slots, next.Lessons, new HashSet<Guid>(), TimeOnly.MinValue), accent)
            : WorkspaceKit.Box("Денят", DayTimeline.Render(_slots, d.Today, d.TodayRecordedEntryIds, TimeOnly.FromDateTime(frame.LocalNow)), accent);

        var cards = Card.Row(
            Card.Render("Часове днес", WorkspaceKit.Number(d.Today.Count), null, accent),
            Card.Render("Записани", $"[bold {ShkoloTheme.SuccessHex}]{d.TodayRecordedEntryIds.Count}[/]", null, accent),
            Card.Render("Ученици", WorkspaceKit.Number(d.Classes.Sum(c => c.StudentCount)), $"{d.Classes.Count} класа", accent),
            Card.Render("Активни домашни", WorkspaceKit.Number(d.ActiveHomework.Count), null, accent),
            Card.Render("Известия", WorkspaceKit.Number(d.UnreadNotifications), null, accent));

        var trends = new Table().Border(TableBorder.None).HideHeaders().AddColumn("").AddColumn("").AddColumn("").AddColumn("");
        foreach (var (className, weeks) in _trends)
        {
            var last = weeks.LastOrDefault(w => w is not null);
            trends.AddRow(
                new Markup($"[bold]{Ui.Escape(className)}[/]"),
                new Markup($"[{Gradient.Hex(accent)}]{Sparkline.Grades(weeks)}[/]"),
                new Markup(last is { } v ? GradeBadge.Markup(v) : Ui.Muted("—")),
                new Markup(Trend.Of(weeks)));
        }

        var attention = _attention.Count == 0
            ? WorkspaceKit.Empty("Няма ученици, които изискват внимание.")
            : new Markup(string.Join("\n", _attention.Take(6).Select(a => $"[{ShkoloTheme.WarningHex}]{Glyphs.Warn}[/] [bold]{Ui.Escape(a.StudentName)}[/] {Ui.Muted(a.ClassName)} · {Ui.Escape(a.Reason)}")));

        var bottom = new Grid().AddColumn().AddColumn();
        bottom.AddRow(
            WorkspaceKit.Box("Успех · 6 седмици", trends, accent),
            WorkspaceKit.Box("Нужда от внимание", attention, accent));

        return new Rows(greeting, timeline, cards, bottom);
    }
}
