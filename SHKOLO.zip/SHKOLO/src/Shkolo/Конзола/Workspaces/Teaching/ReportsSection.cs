// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Screens.TeacherArea;
using Shkolo.Presentation.Shell;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Teaching;

/// <summary>The teacher's own teaching summary and access to all reports.</summary>
public sealed class ReportsSection : ISection
{
    private TeacherReport? _report;

    public string Title => "Справки";

    public string Icon => Glyphs.List;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Справки и CSV", 'С', () => new TeacherReportsScreen()),
        SectionAction.Open("Смяна на парола", 'П', () => new ChangePasswordScreen()),
    ];

    public void Load(ScreenContext ctx)
        => _report = ctx.Services.Reports.GenerateTeacherReport(ctx.Services.Session.TeacherId!.Value).Value;

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_report is not { } r)
        {
            return WorkspaceKit.Empty("Справката не може да бъде заредена.");
        }

        var accent = WorkspaceKit.Accent(ctx);
        return new Rows(
            Card.Row(
                Card.Render("Проведени часове", WorkspaceKit.Number(r.LessonsHeld), null, accent),
                Card.Render("Поставени оценки", WorkspaceKit.Number(r.GradesGiven), null, accent),
                Card.Render("Активни домашни", WorkspaceKit.Number(r.ActiveHomework), null, accent)),
            new Markup($"{Ui.Muted("Класове:")} {Ui.Escape(string.Join(", ", r.Classes))}\n{Ui.Muted("Предмети:")} {Ui.Escape(string.Join(", ", r.Subjects))}"));
    }
}
