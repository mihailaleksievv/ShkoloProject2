﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces;

/// <summary>
/// Pages inside a section, switched with ← →: a tab strip and the index arithmetic.
/// Used by the dashboards and the statistics section so every paged view looks and behaves the same.
/// </summary>
public static class PageTabs
{
    public static IRenderable Render(IReadOnlyList<string> pages, int active)
    {
        var tabs = pages.Select((p, i) => i == active
            ? $"[bold {ShkoloTheme.BackgroundHex} on {ShkoloTheme.PrimaryHex}] {Ui.Escape(p)} [/]"
            : $" [{ShkoloTheme.MutedHex}]{Ui.Escape(p)}[/] ");
        return new Markup($"[{ShkoloTheme.MutedHex}]◀[/] {string.Join("  ", tabs)} [{ShkoloTheme.MutedHex}]▶[/]   {Ui.Muted("← →")}");
    }

    /// <summary>The page after a ← / → key, or null when the key is not a page key.</summary>
    public static int? Step(ConsoleKeyInfo key, int count, int current) => key.Key switch
    {
        ConsoleKey.RightArrow => (current + 1) % count,
        ConsoleKey.LeftArrow => (current - 1 + count) % count,
        _ => null,
    };

    /// <summary>A section heading inside a page, the same as in the v1.0 reports.</summary>
    public static IRenderable Heading(string title)
        => new Rule($"[bold {ShkoloTheme.AccentHex}]{Ui.Escape(title)}[/]").LeftJustified().RuleStyle(new Style(ShkoloTheme.Surface));
}
