// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Screens.TeacherArea;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces;

/// <summary>Latest announcements and upcoming events, shared by teachers and administrators.</summary>
public sealed class CommunicationSection : ISection
{
    private IReadOnlyList<AnnouncementView> _announcements = [];
    private IReadOnlyList<EventView> _events = [];

    public CommunicationSection(bool includeTeacherActions = true, IEnumerable<SectionAction>? extra = null)
    {
        var actions = new List<SectionAction>
        {
            SectionAction.Open("Съобщения", 'С', () => new AnnouncementsScreen(canPublish: true)),
            SectionAction.Open("Събития", 'Б', () => new EventsScreen(canManage: true)),
        };
        if (includeTeacherActions)
        {
            actions.Add(SectionAction.Open("Похвали и забележки", 'Х', () => new FeedbackScreen()));
            actions.Add(SectionAction.Open("Отличия", 'О', () => new AwardAchievementScreen()));
        }

        actions.AddRange(extra ?? []);
        actions.Add(SectionAction.Open("Известия", 'И', () => new NotificationsScreen()));
        Actions = actions;
    }

    public string Title => "Комуникация";

    public string Icon => Glyphs.Flag;

    public IReadOnlyList<SectionAction> Actions { get; }

    public void Load(ScreenContext ctx)
    {
        _announcements = ctx.Services.Announcements.GetActiveForCurrentUser().Take(5).ToList();
        _events = ctx.Services.Events.GetUpcoming().Take(5).ToList();
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        var accent = WorkspaceKit.Accent(ctx);
        var news = _announcements.Count == 0
            ? WorkspaceKit.Empty("Няма активни съобщения.")
            : new Markup(string.Join("\n", _announcements.Select(a => $"[{ShkoloTheme.AccentHex}]{Glyphs.Mail}[/] [bold]{Ui.Escape(a.Title)}[/] {Ui.Muted($"· {a.Target} · {a.AuthorName}")}")));
        var events = _events.Count == 0
            ? WorkspaceKit.Empty("Няма предстоящи събития.")
            : new Markup(string.Join("\n", _events.Select(e => $"[{ShkoloTheme.WarningHex}]{Glyphs.Flag}[/] {Ui.Escape(Ui.DateTime(e.Start))} [bold]{Ui.Escape(e.Title)}[/] {Ui.Muted("· " + e.Target)}")));

        var grid = new Grid().AddColumn().AddColumn();
        grid.AddRow(WorkspaceKit.Box("Съобщения", news, accent), WorkspaceKit.Box("Предстоящи събития", events, accent));
        return grid;
    }
}
