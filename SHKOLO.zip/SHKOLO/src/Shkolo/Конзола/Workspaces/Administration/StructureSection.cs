// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.AdminArea;
using Shkolo.Presentation.Shell;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Administration;

/// <summary>School structure: classes with size and class teacher, plus the structure screens.</summary>
public sealed class StructureSection : ISection
{
    private IReadOnlyList<(string Name, int Students, string ClassTeacher, decimal? Average)> _classes = [];
    private int _subjects;

    public string Title => "Структура";

    public string Icon => Glyphs.Diamond;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Класове", 'К', () => new ClassesScreen()),
        SectionAction.Open("Предмети", 'П', () => new SubjectsScreen()),
        SectionAction.Open("Учебни години и звънец", 'Г', () => new AcademicYearsScreen()),
        SectionAction.Open("Назначения", 'Н', () => new AssignmentsScreen()),
    ];

    public void Load(ScreenContext ctx)
    {
        var reports = ctx.Services.Reports;
        _classes = ctx.Services.Classes.GetAll()
            .Select(c => reports.GenerateClassReport(c.Id).Value)
            .Where(r => r is not null)
            .Select(r => (r!.Class.DisplayName, r.StudentCount, r.ClassTeacherName, r.ClassAverage))
            .ToList();
        _subjects = ctx.Services.Subjects.GetAll().Count;
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        var table = new Table().Border(TableBorder.Simple).BorderColor(WorkspaceKit.Accent(ctx))
            .AddColumn("Клас").AddColumn(new TableColumn("Ученици").RightAligned()).AddColumn("Класен ръководител").AddColumn("Среден успех");
        foreach (var c in _classes)
        {
            table.AddRow(new Markup($"[bold]{Ui.Escape(c.Name)}[/]"), new Markup(Ui.Count(c.Students)), new Markup(Ui.Escape(c.ClassTeacher)),
                new Markup(c.Average is { } a ? GradeBadge.Markup(a) : Ui.Muted("—")));
        }

        return new Rows(table, new Markup(Ui.Muted($"Активни предмети: {_subjects}")));
    }
}
