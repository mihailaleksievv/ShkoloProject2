// Owner: Participant 2 – Presentation Developer
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.AdminArea;
using Shkolo.Presentation.Shell;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Administration;

/// <summary>Students, teachers and accounts in numbers, with their management screens.</summary>
public sealed class PeopleSection : ISection
{
    private (int Active, int Inactive) _students;
    private (int Active, int Inactive) _teachers;
    private (int Active, int Suspended, int Admins) _accounts;

    public string Title => "Хора";

    public string Icon => Glyphs.List;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Ученици", 'У', () => new StudentsScreen()),
        SectionAction.Open("Учители", 'Т', () => new TeachersScreen()),
        SectionAction.Open("Акаунти", 'А', () => new UsersScreen()),
    ];

    public void Load(ScreenContext ctx)
    {
        var students = ctx.Services.Students.GetAllStudents(includeInactive: true).Value ?? [];
        var teachers = ctx.Services.Teachers.GetAll(includeInactive: true).Value ?? [];
        var users = ctx.Services.Auth.GetUsers().Value ?? [];
        _students = (students.Count(s => s.IsActive), students.Count(s => !s.IsActive));
        _teachers = (teachers.Count(t => t.IsActive), teachers.Count(t => !t.IsActive));
        _accounts = (users.Count(u => u.IsActive), users.Count(u => !u.IsActive), users.Count(u => u.Role == UserRole.Administrator));
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        var accent = WorkspaceKit.Accent(ctx);
        return Card.Row(
            Card.Render("Ученици", WorkspaceKit.Number(_students.Active), $"неактивни: {_students.Inactive}", accent),
            Card.Render("Учители", WorkspaceKit.Number(_teachers.Active), $"неактивни: {_teachers.Inactive}", accent),
            Card.Render("Акаунти", WorkspaceKit.Number(_accounts.Active), $"спрени: {_accounts.Suspended} · администратори: {_accounts.Admins}", accent));
    }
}
