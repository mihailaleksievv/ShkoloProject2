﻿// Owner: Participant 2 – Presentation Developer
using System.Diagnostics;
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Domain;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Motion;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.AdminArea;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Administration;

/// <summary>
/// School performance in three views switched with ← →: averages by subject, averages by class,
/// and the grade distribution with the attendance split. Bars grow in when the view changes.
/// </summary>
public sealed class StatisticsSection : ISection
{
    private static readonly string[] Views = ["По предмети", "По класове", "Разпределение"];
    private static readonly TimeSpan GrowDuration = TimeSpan.FromMilliseconds(450);

    private readonly Stopwatch _sinceSwitch = new();
    private IReadOnlyList<SubjectPerformance> _subjects = [];
    private SchoolStatistics? _stats;
    private int _view;
    private bool _motion;

    public string Title => "Статистики";

    public string Icon => Glyphs.Up;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Статистики и справки за класове", 'С', () => new SchoolStatisticsScreen()),
    ];

    public bool IsAnimating => _motion && _sinceSwitch.IsRunning && _sinceSwitch.Elapsed < GrowDuration;

    public void Load(ScreenContext ctx)
    {
        _subjects = ctx.Services.Subjects.GetAll()
            .Select(s => ctx.Services.Reports.GetSubjectPerformance(s.Id).Value)
            .Where(p => p is not null && p.GradeCount > 0)
            .Select(p => p!)
            .OrderByDescending(p => p.Average)
            .ToList();
        _stats = ctx.Services.Reports.GetSchoolStatistics().Value;
        _motion = ctx.Motion.Enabled;
        _sinceSwitch.Restart();
    }

    public bool HandleKey(ScreenContext ctx, ConsoleKeyInfo key)
    {
        if (PageTabs.Step(key, Views.Length, _view) is not { } next)
        {
            return false;
        }

        _view = next;
        _sinceSwitch.Restart();
        return true;
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_stats is not { } s || s.TotalGrades == 0)
        {
            return WorkspaceKit.Empty("Все още няма оценки тази учебна година.");
        }

        var progress = _motion ? Tween.Progress(_sinceSwitch.Elapsed, GrowDuration, Easing.EaseOutCubic) : 1.0;
        var summary = new Markup(
            $"{Ui.Muted("Училищен успех")} {(s.SchoolAverage is { } avg ? GradeBadge.Markup(avg) : Ui.Muted("—"))}   " +
            $"{Ui.Muted("Оценки")} [bold]{s.TotalGrades}[/]   {Ui.Muted("Ученици")} [bold]{s.ActiveStudents}[/]   {Ui.Muted("Класове")} [bold]{s.Classes}[/]");

        IRenderable body = _view switch
        {
            0 => GradeBars.Render(_subjects.Select(p => new GradeBar(p.SubjectName, p.Average)).ToList(), s.SchoolAverage, 34, progress),
            1 => GradeBars.Render(s.ClassAverages.Select(c => new GradeBar(c.ClassName, c.Average)).ToList(), s.SchoolAverage, 34, progress),
            _ => new Rows(
                GradeHistogram.Render(s.Distribution, 7, progress),
                new Text(""),
                new Markup($"[bold]Присъствия[/] {Ui.Muted("в класовете")}"),
                SegmentBar.Attendance(s.Attendance, 90)),
        };

        return new Rows(PageTabs.Render(Views, _view), new Text(""), summary, new Text(""), body);
    }
}
