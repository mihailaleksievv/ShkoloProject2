// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.AdminArea;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Administration;

/// <summary>The gradebook of the last week: recorded lessons and absences.</summary>
public sealed class GradebookSection : ISection
{
    private IReadOnlyList<LessonView> _lessons = [];
    private int _absences;
    private int _late;

    public string Title => "Дневник";

    public string Icon => Glyphs.Pencil;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Оценки, отсъствия и часове", 'Д', () => new GradebookOverviewScreen()),
    ];

    public void Load(ScreenContext ctx)
    {
        var today = ctx.Services.Clock.Today;
        _lessons = ctx.Services.Lessons.Search(new LessonFilter(From: today.AddDays(-7))).Value ?? [];
        var records = ctx.Services.Attendance.GetAttendanceByPeriod(today.AddDays(-7), today).Value ?? [];
        _absences = records.Count(r => r.Status is AttendanceStatus.Absent or AttendanceStatus.ExcusedAbsent);
        _late = records.Count(r => r.Status == AttendanceStatus.Late);
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        var accent = WorkspaceKit.Accent(ctx);
        var table = new Table().Border(TableBorder.Simple).BorderColor(accent)
            .AddColumn("Дата").AddColumn("Час").AddColumn("Клас").AddColumn("Предмет").AddColumn("Тема").AddColumn("Учител");
        foreach (var l in _lessons.Take(10))
        {
            table.AddRow(Ui.Muted(Ui.Date(l.Date)), $"{l.LessonNumber}.", Ui.Escape(l.ClassName), Ui.Escape(l.SubjectName), Ui.Escape(l.Topic), Ui.Muted(l.TeacherName));
        }

        return new Rows(
            Card.Row(
                Card.Render("Часове · 7 дни", WorkspaceKit.Number(_lessons.Count), null, accent),
                Card.Render("Отсъствия · 7 дни", $"[bold {ShkoloTheme.ErrorHex}]{_absences}[/]", null, accent),
                Card.Render("Закъснения · 7 дни", WorkspaceKit.Number(_late), null, accent)),
            table);
    }
}
