// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.AdminArea;
using Shkolo.Presentation.Shell;

namespace Shkolo.Presentation.Workspaces.Administration;

/// <summary>Administrator command centre: "Училището в един поглед".</summary>
public sealed class AdminWorkspace : IWorkspace
{
    public string Name => "Администратор";

    public IReadOnlyList<ISection> Sections(ScreenContext ctx) =>
    [
        new AdminDashboardSection(),
        new PeopleSection(),
        new StructureSection(),
        new SchoolTimetableSection(),
        new GradebookSection(),
        new StatisticsSection(),
        new CommunicationSection(includeTeacherActions: false, extra: [SectionAction.Open("Отличия", 'О', () => new BadgeCatalogScreen())]),
        new SystemSection(),
    ];
}
