// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.AdminArea;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Administration;

/// <summary>Today's programme of the whole school, grouped by lesson period.</summary>
public sealed class SchoolTimetableSection : ISection
{
    private IReadOnlyList<TimetableRow> _today = [];

    public string Title => "Разписание";

    public string Icon => Glyphs.Clock;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("Управление на разписанието", 'Р', () => new TimetableAdminScreen()),
    ];

    public void Load(ScreenContext ctx) => _today = ctx.Services.Timetable.GetTodayForCurrentUser();

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_today.Count == 0)
        {
            return WorkspaceKit.Empty("Днес няма учебни часове.");
        }

        var now = TimeOnly.FromDateTime(frame.LocalNow);
        var classes = _today.Select(r => r.ClassName).Distinct().Order(StringComparer.CurrentCulture).ToList();
        var table = new Table().Border(TableBorder.Simple).BorderColor(WorkspaceKit.Accent(ctx)).AddColumn("Час");
        foreach (var c in classes)
        {
            table.AddColumn(Ui.Escape(c));
        }

        foreach (var period in _today.GroupBy(r => r.LessonNumber).OrderBy(g => g.Key))
        {
            var first = period.First();
            var isNow = now >= first.Start && now < first.End;
            var cells = new List<IRenderable> { new Markup(isNow ? $"[bold {ShkoloTheme.AccentHex}]{Glyphs.Now} {period.Key}. {Ui.Time(first.Start)}[/]" : Ui.Muted($"{period.Key}. {Ui.Time(first.Start)}")) };
            cells.AddRange(classes.Select(c => period.FirstOrDefault(r => r.ClassName == c) is { } r
                ? (IRenderable)new Markup($"{Ui.Escape(r.SubjectName)}\n{Ui.Muted(r.TeacherName)}")
                : new Markup(Ui.Muted("·"))));
            table.AddRow(cells.ToArray());
        }

        return table;
    }
}
