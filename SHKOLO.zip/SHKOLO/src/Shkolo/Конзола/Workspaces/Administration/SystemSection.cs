// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.AdminArea;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Administration;

/// <summary>Storage health: data file, last save, mode and backups.</summary>
public sealed class SystemSection : ISection
{
    private StorageInfo? _info;

    public string Title => "Система";

    public string Icon => Glyphs.Warn;

    public IReadOnlyList<SectionAction> Actions { get; } =
    [
        SectionAction.Open("История на действията", 'И', () => new AuditLogScreen()),
        SectionAction.Open("Системна информация и възстановяване", 'С', () => new SystemScreen()),
        SectionAction.Open("Смяна на парола", 'П', () => new ChangePasswordScreen()),
    ];

    public void Load(ScreenContext ctx) => _info = ctx.Services.System.GetStorageInfo().Value;

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_info is not { } i)
        {
            return WorkspaceKit.Empty("Няма достъп до системната информация.");
        }

        var accent = WorkspaceKit.Accent(ctx);
        var grid = new Grid().AddColumn(new GridColumn().NoWrap()).AddColumn();
        grid.AddRow(new Markup(Ui.Muted("Файл с данни")), new Markup(Ui.Escape(i.DataFilePath)));
        grid.AddRow(new Markup(Ui.Muted("Размер")), new Markup(Ui.Escape($"{i.SizeBytes / 1024.0:0.0} KB")));
        grid.AddRow(new Markup(Ui.Muted("Последен запис")), new Markup(Ui.Escape(Ui.FromUtc(i.LastSavedAtUtc))));
        grid.AddRow(new Markup(Ui.Muted("Режим")), new Markup(i.IsReadOnly ? $"[{ShkoloTheme.WarningHex}]само за четене[/]" : $"[{ShkoloTheme.SuccessHex}]{Glyphs.Done} нормален[/]"));
        grid.AddRow(new Markup(Ui.Muted("Архиви")), new Markup(i.Backups.Count == 0
            ? Ui.Muted("няма")
            : string.Join("\n", i.Backups.Select(b => $"{Ui.Escape(Ui.FromUtc(b.CreatedAtUtc))} {Ui.Muted($"· {b.SizeBytes / 1024.0:0} KB")}"))));
        return WorkspaceKit.Box("Съхранение", grid, accent);
    }
}
