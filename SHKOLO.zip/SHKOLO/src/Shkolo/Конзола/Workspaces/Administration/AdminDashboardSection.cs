﻿// Owner: Participant 2 – Presentation Developer
using System.Diagnostics;
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Domain;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Motion;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Workspaces.Administration;

/// <summary>
/// The whole school in the layout of the v1.0 class report: a row of tiles (numbers count up), then full-width pages
/// switched with ← →: class averages, grade distribution, attendance pulse, events and recent actions.
/// </summary>
public sealed class AdminDashboardSection : ISection
{
    private static readonly TimeSpan CountDuration = TimeSpan.FromMilliseconds(700);

    private readonly Stopwatch _sinceLoad = new();
    private AdminDashboard? _dashboard;
    private IReadOnlyList<DayPresence> _pulse = [];
    private bool _motion;
    private int _page;

    private static readonly string[] Pages = ["Успех по класове", "Разпределение", "Присъствия", "Събития и действия"];

    public string Title => "Табло";

    public string Icon => Glyphs.Home;

    public IReadOnlyList<SectionAction> Actions => [];

    public bool IsAnimating => _motion && _sinceLoad.IsRunning && _sinceLoad.Elapsed < CountDuration;

    public bool HandleKey(ScreenContext ctx, ConsoleKeyInfo key)
    {
        if (PageTabs.Step(key, Pages.Length, _page) is not { } next)
        {
            return false;
        }

        _page = next;
        _sinceLoad.Restart(); // charts of the new page grow in
        return true;
    }

    public void Load(ScreenContext ctx)
    {
        _dashboard = ctx.Services.Reports.GetAdminDashboard().Value;
        _pulse = ctx.Services.Reports.GetAttendancePulse().Value ?? [];
        _motion = ctx.Motion.Enabled;
        _sinceLoad.Restart();
    }

    public IRenderable Render(ScreenContext ctx, ShellFrame frame)
    {
        if (_dashboard is not { } d)
        {
            return WorkspaceKit.Empty("Таблото не може да бъде заредено.");
        }

        var p = _motion ? Tween.Progress(_sinceLoad.Elapsed, CountDuration, Easing.EaseOutCubic) : 1.0;
        string Count(int value) => StatPanel.Number(Tween.Value(0, value, p));
        var s = d.Stats;

        var term = d.ActiveYearName is null ? "няма активна учебна година" : $"{d.ActiveYearName}{(d.CurrentTerm is { } t ? " · " + BulgarianNames.Of(t) : "")}";
        var greeting = new Markup($"[bold]{WorkspaceKit.Greeting(frame.LocalNow)}![/] {Ui.Muted(term)}");
        var roomy = ctx.Console.Profile.Height >= 40;
        var tiles = StatPanel.Tiles(1,
            ("Ученици", Count(s.ActiveStudents)),
            ("Учители", Count(s.ActiveTeachers)),
            ("Класове", Count(s.Classes)),
            ("Предмети", Count(s.Subjects)),
            ("Домашни", Count(s.ActiveHomework)),
            ("Оценки", Count(s.TotalGrades)),
            ("Среден успех", GradeFormatter.WithWord(s.SchoolAverage)));

        IRenderable page = _page switch
        {
            0 => new Rows(
                PageTabs.Heading("Успех по класове"),
                new Text(""),
                GradeBars.Render(s.ClassAverages.Select(c => new GradeBar(c.ClassName, c.Average)).ToList(), s.SchoolAverage, 44, p)),
            1 => new Rows(
                PageTabs.Heading("Разпределение на оценките"),
                new Text(""),
                GradeHistogram.Render(s.Distribution, roomy ? 7 : 4, p)),
            2 => new Rows(
                PageTabs.Heading("Пулс на присъствията"),
                new Markup(Ui.Muted($"Присъстващи и закъснели · последни {_pulse.Count} учебни дни")),
                new Text(""),
                DayColumns.Render(_pulse, roomy ? 5 : 3),
                new Text(""),
                PageTabs.Heading("Присъствия в училището"),
                new Text(""),
                SegmentBar.Attendance(s.Attendance, 90)),
            _ => EventsAndActions(d, roomy ? 6 : 3),
        };

        return new Rows(greeting, tiles, new Text(""), PageTabs.Render(Pages, _page), new Text(""), page);
    }

    private static IRenderable EventsAndActions(AdminDashboard d, int actionCount)
    {
        IRenderable events = d.UpcomingEvents.Count == 0
            ? WorkspaceKit.Empty("Няма предстоящи събития.")
            : Table(["Начало", "Събитие"], d.UpcomingEvents.Select(e => new[]
                { Ui.Escape(Ui.DateTime(e.Start)), $"[{ShkoloTheme.WarningHex}]{Glyphs.Flag}[/] [bold]{Ui.Escape(e.Title)}[/]" }));
        IRenderable actions = d.RecentActions.Count == 0
            ? WorkspaceKit.Empty("Няма действия.")
            : Table(["Време", "Потребител", "Действие"], d.RecentActions.Take(actionCount).Select(a => new[]
                { Ui.Muted(Ui.FromUtc(a.OccurredAtUtc)), Ui.Escape(a.UserName), Ui.Escape(a.Summary) }));

        return new Rows(
            PageTabs.Heading("Предстоящи събития"),
            events,
            new Text(""),
            PageTabs.Heading("Последни действия"),
            actions);
    }

    private static Table Table(string[] headers, IEnumerable<string[]> rows)
    {
        var table = new Table().Border(TableBorder.Simple).BorderColor(ShkoloTheme.Surface);
        foreach (var h in headers)
        {
            table.AddColumn(new TableColumn($"[{ShkoloTheme.MutedHex}]{Ui.Escape(h)}[/]"));
        }

        foreach (var row in rows)
        {
            table.AddRow(row.Select(c => (IRenderable)new Markup(c)).ToArray());
        }

        return table;
    }
}
