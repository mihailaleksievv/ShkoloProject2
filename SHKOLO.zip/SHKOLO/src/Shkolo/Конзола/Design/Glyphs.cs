// Owner: Participant 2 – Presentation Developer
namespace Shkolo.Presentation.Design;

/// <summary>
/// The SHKOLO symbol language. Only width-1 Unicode symbols (no emoji), so tables and frames
/// stay aligned in Windows Terminal with Cascadia Mono or Consolas.
/// </summary>
public static class Glyphs
{
    public const string Selected = "▸";
    public const string Now = "●";
    public const string Pending = "○";
    public const string Done = "✔";
    public const string Fail = "✖";
    public const string Warn = "⚠";
    public const string Up = "▲";
    public const string Down = "▼";
    public const string Flat = "▬";
    public const string Star = "★";
    public const string Mail = "✉";
    public const string Clock = "◷";
    public const string Home = "⌂";
    public const string Pencil = "✎";
    public const string List = "≡";
    public const string Flag = "⚑";
    public const string Diamond = "◆";
    public const string Cell = "■";
    public const string Empty = "·";
    public const string SparkBlocks = "▁▂▃▄▅▆▇█";
    public const string BarFull = "━";
    public const string BarEmpty = "─";
}
