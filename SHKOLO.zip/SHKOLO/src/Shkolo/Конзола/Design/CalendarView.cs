// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>Month calendar in Bulgarian with highlighted dates and the list of what happens on them.</summary>
public static class CalendarView
{
    public static IRenderable Render(int year, int month, IReadOnlyList<(DateOnly Date, string Label)> marks)
    {
        var calendar = new Calendar(year, month)
            .Culture(BulgarianNames.Culture)
            .Border(TableBorder.Rounded)
            .BorderColor(ShkoloTheme.Primary)
            .HeaderStyle(new Style(ShkoloTheme.Accent, decoration: Decoration.Bold))
            .HighlightStyle(new Style(ShkoloTheme.Background, ShkoloTheme.Warning, Decoration.Bold));

        var inMonth = marks.Where(m => m.Date.Year == year && m.Date.Month == month).OrderBy(m => m.Date).ToList();
        foreach (var mark in inMonth)
        {
            calendar.AddCalendarEvent(mark.Date.Year, mark.Date.Month, mark.Date.Day);
        }

        var title = new DateOnly(year, month, 1).ToString("MMMM yyyy", BulgarianNames.Culture);
        var list = inMonth.Count == 0
            ? Ui.Muted("Няма събития и срокове този месец.")
            : string.Join("\n", inMonth.Select(m => $"[{ShkoloTheme.WarningHex}]{m.Date:dd.MM}[/] {Ui.Escape(m.Label)}"));

        return new Rows(new Markup($"[bold]{Ui.Escape(title)}[/]"), calendar, new Markup(list));
    }
}
