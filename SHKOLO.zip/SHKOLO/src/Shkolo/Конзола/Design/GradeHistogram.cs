﻿// Owner: Participant 2 – Presentation Developer
using System.Text;
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>
/// Grade distribution as a vertical histogram: one coloured column per band (6 → 2), the count above it,
/// the band name and its share below. Partial heights use the ▁▂▃▄▅▆▇ blocks.
/// </summary>
public static class GradeHistogram
{
    private static readonly string Blocks = " ▁▂▃▄▅▆▇█";

    /// <param name="compact">Narrow columns with grade digits instead of names (for dashboard boxes).</param>
    public static IRenderable Render(GradeDistribution d, int height = 6, double progress = 1, bool compact = false)
    {
        var columnWidth = compact ? 7 : 11;
        var barWidth = compact ? 4 : 5;
        if (d.Total == 0)
        {
            return new Markup(Ui.Muted("Няма оценки."));
        }

        int[] counts = [d.Excellent, d.VeryGood, d.Good, d.Average, d.Poor];
        var max = counts.Max();
        var heights = counts.Select(c => (double)c / max * height * Math.Clamp(progress, 0, 1)).ToArray();
        var lines = new List<string>();

        for (var level = height + 1; level >= 1; level--)
        {
            var line = new StringBuilder();
            for (var i = 0; i < counts.Length; i++)
            {
                var hex = GradeScale.Bands[i].Hex;
                var top = (int)Math.Ceiling(heights[i]);
                string cell;
                if (level <= top)
                {
                    var fill = Math.Clamp(heights[i] - (level - 1), 0, 1);
                    var block = Blocks[(int)Math.Round(fill * 8, MidpointRounding.AwayFromZero)];
                    cell = $"[{hex}]{new string(block, barWidth)}[/]";
                }
                else if (level == top + 1)
                {
                    cell = $"[bold {hex}]{Center(counts[i].ToString(), barWidth)}[/]";
                }
                else
                {
                    cell = new string(' ', barWidth);
                }

                line.Append(Center(cell, barWidth, columnWidth));
            }

            lines.Add(line.ToString());
        }

        lines.Add(string.Concat(GradeScale.Bands.Select(_ => $"[{ShkoloTheme.SurfaceHex}]{new string('─', columnWidth - 1)}[/] ")));
        lines.Add(string.Concat(GradeScale.Bands.Select(b => $"[bold {b.Hex}]{Center(compact ? b.Grade.ToString() : b.Name, columnWidth)}[/]")));
        lines.Add(string.Concat(counts.Select(c => Ui.Muted(Center($"{(double)c / d.Total:P0}".Replace(" ", ""), columnWidth)))));
        return new Markup(string.Join("\n", lines));
    }

    private static string Center(string text, int width) => Center(text, text.Length, width);

    /// <summary>Centres markup whose visible length is known.</summary>
    private static string Center(string markup, int visible, int width)
    {
        var left = Math.Max(0, (width - visible) / 2);
        var right = Math.Max(0, width - visible - left);
        return new string(' ', left) + markup + new string(' ', right);
    }
}
