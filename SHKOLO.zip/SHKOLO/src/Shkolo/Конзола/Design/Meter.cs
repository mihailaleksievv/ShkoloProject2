// Owner: Participant 2 – Presentation Developer
using System.Text;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Design;

/// <summary>Horizontal progress bar filled with a gradient (━) on a muted track (─).</summary>
public static class Meter
{
    public static string Markup(decimal value, decimal max, int width, Color from, Color to)
    {
        var filled = max <= 0 ? 0 : (int)Math.Round(Math.Clamp(value / max, 0m, 1m) * width, MidpointRounding.AwayFromZero);
        var builder = new StringBuilder();
        for (var i = 0; i < filled; i++)
        {
            var color = Gradient.Lerp(from, to, width <= 1 ? 1 : (double)i / (width - 1));
            builder.Append('[').Append(Gradient.Hex(color)).Append(']').Append(Glyphs.BarFull).Append("[/]");
        }

        if (width > filled)
        {
            builder.Append('[').Append(ShkoloTheme.MutedHex).Append(']').Append(string.Concat(Enumerable.Repeat(Glyphs.BarEmpty, width - filled))).Append("[/]");
        }

        return builder.ToString();
    }
}
