// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Domain;
using Shkolo.Presentation.Components;

namespace Shkolo.Presentation.Design;

/// <summary>A grade as a coloured "chip": ▌5,50▐.</summary>
public static class GradeBadge
{
    public static string Markup(decimal value)
    {
        var rounded = DomainRules.RoundForDisplay(value);
        var color = GradeFormatter.Color(rounded);
        return $"[{color}]▌[/][bold black on {color}]{BulgarianNames.Grade(rounded)}[/][{color}]▐[/]";
    }
}
