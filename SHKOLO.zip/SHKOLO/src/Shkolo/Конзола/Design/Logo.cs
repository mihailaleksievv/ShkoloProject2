// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>The SHKOLO logo: FIGlet letters coloured with a blue → cyan gradient, optionally partially revealed.</summary>
public static class Logo
{
    private static readonly Lazy<IReadOnlyList<string>> CachedLines = new(BuildLines);

    /// <summary>Logo rows, right-padded to equal width.</summary>
    public static IReadOnlyList<string> Lines => CachedLines.Value;

    public static int Width => Lines.Count == 0 ? 0 : Lines[0].Length;

    /// <summary>Renders the first <c>reveal × width</c> columns (1.0 = whole logo) – used by the intro animation.</summary>
    public static IRenderable Render(double reveal = 1.0)
    {
        var columns = (int)Math.Ceiling(Math.Clamp(reveal, 0, 1) * Width);
        var visible = Lines.Select(l => l[..columns]).ToList();
        return Gradient.Lines(visible, ShkoloTheme.Primary, ShkoloTheme.Accent, Width);
    }

    private static IReadOnlyList<string> BuildLines()
    {
        var writer = new StringWriter();
        var console = AnsiConsole.Create(new AnsiConsoleSettings
        {
            Out = new AnsiConsoleOutput(writer),
            Ansi = AnsiSupport.No,
            ColorSystem = ColorSystemSupport.NoColors,
            Interactive = InteractionSupport.No,
        });
        console.Profile.Width = 200;
        console.Write(new FigletText(ShkoloTheme.Brand));

        var lines = writer.ToString().Replace("\r", "").Split('\n').Select(l => l.TrimEnd()).ToList();
        while (lines.Count > 0 && lines[0].Length == 0)
        {
            lines.RemoveAt(0);
        }

        while (lines.Count > 0 && lines[^1].Length == 0)
        {
            lines.RemoveAt(lines.Count - 1);
        }

        var width = lines.Count == 0 ? 0 : lines.Max(l => l.Length);
        return lines.Select(l => l.PadRight(width)).ToList();
    }
}
