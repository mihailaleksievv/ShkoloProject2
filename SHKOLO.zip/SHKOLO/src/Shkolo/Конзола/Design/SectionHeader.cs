// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>Title of the main area: icon, bold title and a thin accent rule.</summary>
public static class SectionHeader
{
    public static IRenderable Render(string icon, string title, Color accent)
        => new Rule($"[bold {Gradient.Hex(accent)}]{Ui.Escape(icon)} {Ui.Escape(title)}[/]").LeftJustified().RuleStyle(new Style(accent));
}
