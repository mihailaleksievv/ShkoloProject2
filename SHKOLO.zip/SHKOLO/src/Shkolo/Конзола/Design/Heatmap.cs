// Owner: Participant 2 – Presentation Developer
using System.Text;
using Shkolo.Application.Reports;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>
/// Attendance calendar in the style of a contribution graph: rows Mon–Fri, one column per week,
/// each cell coloured by the worst mark of the day.
/// </summary>
public static class Heatmap
{
    private static readonly (DayOfWeek Day, string Label)[] Days =
    [
        (DayOfWeek.Monday, "Пн"), (DayOfWeek.Tuesday, "Вт"), (DayOfWeek.Wednesday, "Ср"), (DayOfWeek.Thursday, "Чт"), (DayOfWeek.Friday, "Пт"),
    ];

    public static IRenderable Render(IReadOnlyList<DayAttendance> days)
    {
        // Leading weeks without any lessons (e.g. before records started) only add empty columns.
        var firstWithLessons = days.Where(d => d.Worst is not null).Select(d => (DateOnly?)WeekStart(d.Date)).Min();
        if (firstWithLessons is { } first)
        {
            days = days.Where(d => d.Date >= first).ToList();
        }

        var byDate = days.ToDictionary(d => d.Date);
        var weeks = days.Select(d => WeekStart(d.Date)).Distinct().Order().ToList();
        var lines = new List<string>();

        foreach (var (day, label) in Days)
        {
            var row = new StringBuilder($"[{ShkoloTheme.MutedHex}]{label}[/] ");
            foreach (var week in weeks)
            {
                var date = week.AddDays((int)day - 1);
                row.Append(byDate.TryGetValue(date, out var item) ? Cell(item.Worst) : " ").Append(' ');
            }

            lines.Add(row.ToString());
        }

        lines.Add("");
        lines.Add(string.Join("  ", new[]
        {
            Legend(AttendanceStatus.Present, "Присъства"),
            Legend(AttendanceStatus.Late, "Закъснение"),
            Legend(AttendanceStatus.ExcusedAbsent, "Извинено"),
            Legend(AttendanceStatus.Absent, "Неизвинено"),
        }));
        return new Markup(string.Join("\n", lines));
    }

    public static string Cell(AttendanceStatus? worst) => worst is { } s
        ? $"[{Hex(s)}]{Glyphs.Cell}[/]"
        : $"[{ShkoloTheme.MutedHex}]{Glyphs.Empty}[/]";

    public static string Hex(AttendanceStatus status) => status switch
    {
        AttendanceStatus.Present => ShkoloTheme.SuccessHex,
        AttendanceStatus.Late => ShkoloTheme.AccentHex,
        AttendanceStatus.ExcusedAbsent => ShkoloTheme.WarningHex,
        _ => ShkoloTheme.ErrorHex,
    };

    private static string Legend(AttendanceStatus status, string label) => $"{Cell(status)} [{ShkoloTheme.MutedHex}]{label}[/]";

    private static DateOnly WeekStart(DateOnly date) => date.AddDays(-(((int)date.DayOfWeek + 6) % 7));
}
