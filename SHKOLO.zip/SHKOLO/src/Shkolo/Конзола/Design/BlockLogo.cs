// Owner: Participant 2 – Presentation Developer
using Spectre.Console;

namespace Shkolo.Presentation.Design;

/// <summary>
/// The SHKOLO wordmark as a pixel font of our own: wide, rounded letters eight pixels tall, drawn straight into
/// a sky picture with a soft shadow. Four terminal rows high at two pixels per row.
/// </summary>
public static class BlockLogo
{
    private const int Gap = 3;

    private static readonly Dictionary<char, string[]> Glyphs = new()
    {
        ['S'] =
        [
            ".#########",
            "##........",
            "##........",
            ".########.",
            "........##",
            "........##",
            "........##",
            "#########.",
        ],
        ['H'] =
        [
            "##......##",
            "##......##",
            "##......##",
            "##########",
            "##......##",
            "##......##",
            "##......##",
            "##......##",
        ],
        ['K'] =
        [
            "##.....##.",
            "##....##..",
            "##...##...",
            "#######...",
            "##....##..",
            "##.....##.",
            "##......##",
            "##......##",
        ],
        ['O'] =
        [
            ".########.",
            "##......##",
            "##......##",
            "##......##",
            "##......##",
            "##......##",
            "##......##",
            ".########.",
        ],
        ['L'] =
        [
            "##........",
            "##........",
            "##........",
            "##........",
            "##........",
            "##........",
            "##........",
            ".#########",
        ],
    };

    private const string Word = "SHKOLO";

    public static int Height => 8;

    public static int Width => Word.Length * 10 + (Word.Length - 1) * Gap;

    /// <summary>Draws the wordmark centred on <paramref name="centerX"/> with its top at pixel row <paramref name="top"/>.</summary>
    public static void Draw(Color[,] pixels, int centerX, int top, Color color)
    {
        var left = centerX - Width / 2;
        var shadow = new Color(20, 60, 120);
        Paint(pixels, left + 1, top + 1, (x, y) => Mix(pixels[x, y], shadow, 0.35));
        Paint(pixels, left, top, (_, _) => color);
    }

    private static void Paint(Color[,] pixels, int left, int top, Func<int, int, Color> colorAt)
    {
        var w = pixels.GetLength(0);
        var h = pixels.GetLength(1);
        for (var i = 0; i < Word.Length; i++)
        {
            var glyph = Glyphs[Word[i]];
            var gx = left + i * (10 + Gap);
            for (var y = 0; y < glyph.Length; y++)
            {
                for (var x = 0; x < glyph[y].Length; x++)
                {
                    var px = gx + x;
                    var py = top + y;
                    if (glyph[y][x] == '#' && px >= 0 && px < w && py >= 0 && py < h)
                    {
                        pixels[px, py] = colorAt(px, py);
                    }
                }
            }
        }
    }

    private static Color Mix(Color a, Color b, double t)
        => new((byte)(a.R + (b.R - a.R) * t), (byte)(a.G + (b.G - a.G) * t), (byte)(a.B + (b.B - a.B) * t));
}
