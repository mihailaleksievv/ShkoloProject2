﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Design;

/// <summary>
/// Role colours. The frame is one soft blue for every role (a single, calm product look);
/// the role itself shows only as a small coloured badge in the header.
/// </summary>
public static class RoleAccent
{
    /// <summary>Frame colour: one soft blue for everyone, so the interface feels like one product.</summary>
    public static Color For(UserRole? role) => ShkoloTheme.Frame;

    public static string HexFor(UserRole? role) => ShkoloTheme.PrimaryHex;

    /// <summary>Small role badge in the header: lavender for administrators, sapphire for teachers, green for students.</summary>
    public static Color BadgeFor(UserRole? role) => Color.FromHex(BadgeHexFor(role).TrimStart('#'));

    public static string BadgeHexFor(UserRole? role) => role switch
    {
        UserRole.Teacher => ShkoloTheme.AccentHex,
        UserRole.Student => ShkoloTheme.SuccessHex,
        _ => ShkoloTheme.LavenderHex,
    };
}
