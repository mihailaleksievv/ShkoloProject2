﻿// Owner: Participant 2 – Presentation Developer
using Spectre.Console;

namespace Shkolo.Presentation.Design;

/// <summary>
/// Paints a sunny sky procedurally (no image files): a blue gradient, a sun glare with soft rays in the
/// upper left, and fluffy clouds along the bottom and the sides built from fractal value noise.
/// The centre stays clear so a logo and buttons can sit on top. Deterministic: the same size gives the same picture.
/// </summary>
public static class SkyPainter
{
    private static readonly (double R, double G, double B) Top = (28, 104, 190);
    private static readonly (double R, double G, double B) Bottom = (126, 190, 238);

    /// <param name="width">Pixels across (one per terminal column).</param>
    /// <param name="height">Pixels down (two per terminal row).</param>
    /// <param name="darken">0 = full daylight, 1 = deep blue; the login uses a calmer, darker sky.</param>
    /// <param name="reveal">0–1 fade-in from deep blue (start-up animation).</param>
    public static Color[,] Paint(int width, int height, double darken = 0, double reveal = 1)
    {
        var pixels = new Color[width, height];
        var sunX = width * 0.15;
        var sunY = height * 0.26;
        var scale = Math.Max(width, height * 2.0);

        for (var y = 0; y < height; y++)
        {
            var t = height <= 1 ? 0 : (double)y / (height - 1);
            for (var x = 0; x < width; x++)
            {
                var r = Lerp(Top.R, Bottom.R, t);
                var g = Lerp(Top.G, Bottom.G, t);
                var b = Lerp(Top.B, Bottom.B, t);

                // Sun: a bright core, a wide glow and four soft rays.
                var dx = x - sunX;
                var dy = (y - sunY) * 1.0;
                var d = Math.Sqrt(dx * dx + dy * dy);
                var angle = Math.Atan2(dy, dx);
                var glow = Math.Exp(-d / (scale * 0.07)) * 0.75 + Math.Exp(-d / (scale * 0.018)) * 0.7;
                var rays = (Math.Pow(Math.Abs(Math.Cos(angle * 3 + 0.4)), 140) * 0.45 + Math.Pow(Math.Abs(Math.Cos(angle * 2 + 1.2)), 220) * 0.3)
                           * Math.Exp(-d / (scale * 0.12));
                var sun = Math.Clamp(glow + rays, 0, 1);
                (r, g, b) = (Lerp(r, 255, sun), Lerp(g, 255, sun), Lerp(b, 255, sun));

                // Clouds: noise pushed up near the bottom and the sides, held back in the centre.
                var nx = (double)x / width;
                var side = Math.Pow(Math.Abs(nx - 0.5) * 2, 3);
                var low = Math.Pow(t, 2.2);
                var centre = Math.Exp(-Math.Pow((nx - 0.5) / 0.28, 2) - Math.Pow((t - 0.5) / 0.25, 2));
                var noise = Fbm(x / 26.0, y / 16.0);
                var density = noise + low * 0.62 + side * 0.48 - 0.70 - centre * 0.6 - (1 - t) * 0.12;
                var alpha = SmoothStep(0.0, 0.12, density);
                if (alpha > 0)
                {
                    var shade = 0.82 + 0.18 * Fbm(x / 9.0 + 40, y / 6.0 + 40) - (1 - t) * 0.04;
                    var cr = 255 * Math.Clamp(shade + 0.02, 0, 1);
                    var cg = 255 * Math.Clamp(shade + 0.04, 0, 1);
                    var cb = 255 * Math.Clamp(shade + 0.09, 0, 1);
                    (r, g, b) = (Lerp(r, cr, alpha), Lerp(g, cg, alpha), Lerp(b, cb, alpha));
                }

                var dim = Math.Clamp(darken + (1 - reveal) * 0.85, 0, 1);
                (r, g, b) = (Lerp(r, 52, dim * 0.6), Lerp(g, 98, dim * 0.6), Lerp(b, 150, dim * 0.6));
                pixels[x, y] = new Color(ToByte(r), ToByte(g), ToByte(b));
            }
        }

        return pixels;
    }

    private static double Lerp(double a, double b, double t) => a + (b - a) * t;

    private static byte ToByte(double v) => (byte)Math.Clamp(Math.Round(v), 0, 255);

    private static double SmoothStep(double edge0, double edge1, double x)
    {
        var t = Math.Clamp((x - edge0) / (edge1 - edge0), 0, 1);
        return t * t * (3 - 2 * t);
    }

    /// <summary>Fractal value noise in 0–1: four octaves of smoothly interpolated lattice values.</summary>
    private static double Fbm(double x, double y)
    {
        double sum = 0, amplitude = 0.5, total = 0;
        for (var octave = 0; octave < 4; octave++)
        {
            sum += amplitude * ValueNoise(x, y);
            total += amplitude;
            x *= 2.03;
            y *= 2.03;
            amplitude *= 0.5;
        }

        return sum / total;
    }

    private static double ValueNoise(double x, double y)
    {
        var x0 = (int)Math.Floor(x);
        var y0 = (int)Math.Floor(y);
        var fx = x - x0;
        var fy = y - y0;
        var sx = fx * fx * (3 - 2 * fx);
        var sy = fy * fy * (3 - 2 * fy);
        var top = Lerp(Hash(x0, y0), Hash(x0 + 1, y0), sx);
        var bottom = Lerp(Hash(x0, y0 + 1), Hash(x0 + 1, y0 + 1), sx);
        return Lerp(top, bottom, sy);
    }

    private static double Hash(int x, int y)
    {
        unchecked
        {
            var h = (uint)(x * 374761393 + y * 668265263);
            h = (h ^ (h >> 13)) * 1274126177;
            h ^= h >> 16;
            return (h & 0xFFFFFF) / (double)0xFFFFFF;
        }
    }
}
