// Owner: Participant 2 – Presentation Developer
using System.Text;
using Spectre.Console;
using Spectre.Console.Rendering;
using TextSegment = Spectre.Console.Rendering.Segment;

namespace Shkolo.Presentation.Design;

/// <summary>
/// A picture in the terminal: every cell shows two pixels with "▀" (upper pixel as foreground, lower as background).
/// Text and solid boxes can be laid over it; a text cell takes the blended colour of its two pixels as background,
/// so words sit directly on the picture. Text is written as plain characters – never parsed as markup.
/// </summary>
public sealed class PixelCanvas : Renderable
{
    private readonly Color[,] _pixels;
    private readonly Cell?[,] _overlay;

    private readonly record struct Cell(char Char, Color Foreground, Color? Background, bool Bold);

    public PixelCanvas(Color[,] pixels)
    {
        _pixels = pixels;
        Width = pixels.GetLength(0);
        Rows = pixels.GetLength(1) / 2;
        _overlay = new Cell?[Width, Rows];
    }

    public int Width { get; }

    public int Rows { get; }

    /// <summary>Writes text at a cell position (clipped to the canvas).</summary>
    public PixelCanvas Text(int x, int row, string text, Color foreground, Color? background = null, bool bold = false)
    {
        // Text on the picture gets one averaged backdrop for the whole run, so words read as a unit.
        background ??= Average(x, row, text.Length);
        for (var i = 0; i < text.Length; i++)
        {
            var cx = x + i;
            if (cx >= 0 && cx < Width && row >= 0 && row < Rows)
            {
                _overlay[cx, row] = new Cell(text[i], foreground, background, bold);
            }
        }

        return this;
    }

    /// <summary>Text centred horizontally on the canvas.</summary>
    public PixelCanvas Centered(int row, string text, Color foreground, Color? background = null, bool bold = false)
        => Text((Width - text.Length) / 2, row, text, foreground, background, bold);

    /// <summary>A solid box of one colour (buttons, cards, input fields).</summary>
    public PixelCanvas Fill(int x, int row, int width, int height, Color background)
    {
        for (var r = row; r < row + height; r++)
        {
            Text(x, r, new string(' ', Math.Max(0, width)), background, background);
        }

        return this;
    }

    protected override Measurement Measure(RenderOptions options, int maxWidth) => new(Math.Min(Width, maxWidth), Math.Min(Width, maxWidth));

    protected override IEnumerable<TextSegment> Render(RenderOptions options, int maxWidth)
    {
        var width = Math.Min(Width, maxWidth);
        for (var row = 0; row < Rows; row++)
        {
            var run = new StringBuilder();
            Style? runStyle = null;
            for (var x = 0; x < width; x++)
            {
                var top = _pixels[x, row * 2];
                var bottom = _pixels[x, row * 2 + 1];
                char ch;
                Style style;
                if (_overlay[x, row] is { } cell)
                {
                    ch = cell.Char;
                    style = new Style(cell.Foreground, cell.Background ?? Blend(top, bottom), cell.Bold ? Decoration.Bold : Decoration.None);
                }
                else
                {
                    ch = '▀';
                    style = new Style(top, bottom);
                }

                if (runStyle is { } current && !current.Equals(style))
                {
                    yield return new TextSegment(run.ToString(), runStyle.Value);
                    run.Clear();
                }

                runStyle = style;
                run.Append(ch);
            }

            if (run.Length > 0 && runStyle is { } last)
            {
                yield return new TextSegment(run.ToString(), last);
            }

            yield return TextSegment.LineBreak;
        }
    }

    private Color Average(int x, int row, int length)
    {
        int r = 0, g = 0, b = 0, n = 0;
        for (var cx = Math.Max(0, x); cx < Math.Min(Width, x + length); cx++)
        {
            var c = AverageAt(cx, row);
            r += c.R;
            g += c.G;
            b += c.B;
            n++;
        }

        return n == 0 ? Color.Black : new Color((byte)(r / n), (byte)(g / n), (byte)(b / n));
    }

    public static Color Blend(Color a, Color b) => new((byte)((a.R + b.R) / 2), (byte)((a.G + b.G) / 2), (byte)((a.B + b.B) / 2));

    /// <summary>Average colour of a rectangle of cells (for text placed on the picture).</summary>
    public Color AverageAt(int x, int row) => Blend(_pixels[Math.Clamp(x, 0, Width - 1), Math.Clamp(row * 2, 0, Rows * 2 - 1)],
        _pixels[Math.Clamp(x, 0, Width - 1), Math.Clamp(row * 2 + 1, 0, Rows * 2 - 1)]);
}
