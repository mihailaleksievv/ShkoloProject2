// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>Dashboard card: escaped title, a big value (trusted markup) and an optional escaped caption.</summary>
public static class Card
{
    public static IRenderable Render(string title, string valueMarkup, string? caption, Color accent)
    {
        // A card is at least as wide as its title, otherwise Spectre truncates the header ("Ча…").
        var visible = Markup.Remove(valueMarkup).Split('\n').Max(l => l.Length);
        var pad = Math.Max(0, title.Length - visible - 1);
        var body = (pad > 0 ? valueMarkup + new string(' ', pad) : valueMarkup) + (caption is null ? "" : $"\n{Ui.Muted(caption)}");
        return new Panel(new Markup(body))
            .Header($" {Ui.Escape(title)} ")
            .Border(BoxBorder.Rounded)
            .BorderColor(accent)
            .Padding(2, 0);
    }

    /// <summary>Cards laid out in equal columns.</summary>
    public static IRenderable Row(params IRenderable[] cards)
    {
        var grid = new Grid();
        foreach (var _ in cards)
        {
            grid.AddColumn(new GridColumn().PadRight(1));
        }

        grid.AddRow(cards);
        return grid;
    }
}
