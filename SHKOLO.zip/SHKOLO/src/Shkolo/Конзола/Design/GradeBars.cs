﻿// Owner: Participant 2 – Presentation Developer
using System.Text;
using Shkolo.Application;
using Shkolo.Domain;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>One bar of <see cref="GradeBars"/>: a label and an average on the 2–6 scale.</summary>
public sealed record GradeBar(string Label, decimal? Value);

/// <summary>
/// Averages as separate horizontal bars: an empty line between rows, the colour of each bar's grade band,
/// a dotted track up to 6,00, an optional ┊ marker for the school average, ★ for the best and ⚠ for the weakest.
/// Every row is one line of exact width, so the chart never wraps inside a box that fits it.
/// </summary>
public static class GradeBars
{
    private const char Fill = '▆';
    private const char Track = '┄';
    private const char Marker = '┊';
    private const int MaxLabelWidth = 30;

    /// <param name="progress">0–1: lets dashboards grow the bars in.</param>
    /// <param name="words">Show the band name ("Мн. добър") after the value.</param>
    /// <param name="spacing">An empty line between bars; dense dashboards turn it off (the ▆ glyph still leaves a gap).</param>
    public static IRenderable Render(IReadOnlyList<GradeBar> items, decimal? reference = null, int barWidth = 28, double progress = 1, bool markExtremes = true, bool words = true, bool spacing = true)
    {
        var values = items.Where(i => i.Value is not null).Select(i => DomainRules.RoundForDisplay(i.Value!.Value)).ToList();
        var mark = markExtremes && values.Count >= 3 && values.Max() > values.Min();
        var best = mark ? values.Max() : (decimal?)null;
        var worst = mark ? values.Min() : (decimal?)null;
        var markerAt = reference is { } r ? Cells(r, barWidth, 1) : (int?)null;
        var labelWidth = Math.Min(MaxLabelWidth, items.Count == 0 ? 0 : items.Max(i => i.Label.Length));

        var lines = new List<string>();
        foreach (var item in items)
        {
            if (spacing && lines.Count > 0)
            {
                lines.Add("");
            }

            var label = Ui.Escape(Fit(item.Label, labelWidth).PadRight(labelWidth)) + "  ";
            if (item.Value is not { } raw)
            {
                lines.Add($"{label}[{ShkoloTheme.SurfaceHex}]{new string(Track, barWidth)}[/] {Ui.Muted("няма оценки")}");
                continue;
            }

            var value = DomainRules.RoundForDisplay(raw);
            var hex = GradeScale.HexOf(value);
            var filled = Cells(value, barWidth, progress);
            var bar = new StringBuilder($"[{hex}]{new string(Fill, filled)}[/]");
            for (var c = filled; c < barWidth; c++)
            {
                bar.Append(c == markerAt ? $"[{ShkoloTheme.LavenderHex}]{Marker}[/]" : $"[{ShkoloTheme.SurfaceHex}]{Track}[/]");
            }

            var badge = value == best ? $"[{ShkoloTheme.WarningHex}]{Glyphs.Star}[/]" : value == worst ? $"[{ShkoloTheme.PeachHex}]{Glyphs.Warn}[/]" : " ";
            var word = words ? " " + Ui.Muted(BandName(value)) : "";
            lines.Add($"{label}{bar} [bold {hex}]{BulgarianNames.Grade(value)}[/] {badge}{word}");
        }

        if (reference is { } avg && markerAt is { } at)
        {
            lines.Add($"{new string(' ', labelWidth + 2 + at)}[{ShkoloTheme.LavenderHex}]{Marker} средно {BulgarianNames.Grade(DomainRules.RoundForDisplay(avg))}[/]");
        }

        return new Markup(string.Join("\n", lines));
    }

    /// <summary>Short band name used next to a bar.</summary>
    public static string BandName(decimal value) => GradeScale.Bands.First(b => b.Hex == GradeScale.HexOf(value)).Name;

    /// <summary>Number of filled cells for a value on the 2–6 scale.</summary>
    private static int Cells(decimal value, int width, double progress)
    {
        var share = (double)Math.Clamp((value - 2m) / 4m, 0m, 1m) * Math.Clamp(progress, 0, 1);
        return (int)Math.Round(share * width, MidpointRounding.AwayFromZero);
    }

    private static string Fit(string text, int width) => text.Length <= width ? text : text[..(width - 1)] + "…";
}
