// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Theme;

namespace Shkolo.Presentation.Design;

/// <summary>Direction of change between two averages: ▲ up (green), ▼ down (red), ▬ steady or unknown.</summary>
public static class Trend
{
    private const decimal Threshold = 0.05m;

    public static string Markup(decimal? previous, decimal? current)
    {
        if (previous is not { } p || current is not { } c || Math.Abs(c - p) < Threshold)
        {
            return $"[{ShkoloTheme.MutedHex}]{Glyphs.Flat}[/]";
        }

        return c > p ? $"[{ShkoloTheme.SuccessHex}]{Glyphs.Up}[/]" : $"[{ShkoloTheme.ErrorHex}]{Glyphs.Down}[/]";
    }

    /// <summary>Compares the last value with the closest earlier non-null value.</summary>
    public static string Of(IReadOnlyList<decimal?> series)
    {
        var known = series.Where(v => v is not null).ToList();
        return known.Count < 2 ? Markup(null, null) : Markup(known[^2], known[^1]);
    }
}
