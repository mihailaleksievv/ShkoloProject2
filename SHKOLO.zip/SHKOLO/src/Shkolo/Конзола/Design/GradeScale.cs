// Owner: Participant 2 – Presentation Developer
using Shkolo.Domain;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Design;

/// <summary>
/// One colour per grade band, used by every chart: 6 green, 5 sapphire, 4 yellow, 3 peach, 2 red.
/// Bands follow the Bulgarian scale (Отличен ≥ 5,50, Много добър ≥ 4,50, Добър ≥ 3,50, Среден ≥ 3,00).
/// </summary>
public static class GradeScale
{
    public static string HexOf(decimal value) => DomainRules.RoundForDisplay(value) switch
    {
        < 3.00m => ShkoloTheme.ErrorHex,
        < 3.50m => ShkoloTheme.PeachHex,
        < 4.50m => ShkoloTheme.WarningHex,
        < 5.50m => ShkoloTheme.AccentHex,
        _ => ShkoloTheme.SuccessHex,
    };

    public static Color Of(decimal value) => Color.FromHex(HexOf(value).TrimStart('#'));

    /// <summary>The five bands from best to worst with their name and representative grade.</summary>
    public static IReadOnlyList<(string Name, int Grade, string Hex)> Bands { get; } =
    [
        ("Отличен", 6, ShkoloTheme.SuccessHex),
        ("Мн. добър", 5, ShkoloTheme.AccentHex),
        ("Добър", 4, ShkoloTheme.WarningHex),
        ("Среден", 3, ShkoloTheme.PeachHex),
        ("Слаб", 2, ShkoloTheme.ErrorHex),
    ];
}
