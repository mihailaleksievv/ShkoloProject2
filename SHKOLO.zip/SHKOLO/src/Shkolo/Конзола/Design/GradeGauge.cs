// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Domain;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>Large average with its verbal grade and a 2,00 → 6,00 scale with a marker.</summary>
public static class GradeGauge
{
    private const int ScaleWidth = 32;

    public static IRenderable Render(decimal? average)
    {
        if (average is not { } value)
        {
            return new Markup($"[{ShkoloTheme.MutedHex}]Няма данни[/]\n[{ShkoloTheme.MutedHex}]{new string('─', ScaleWidth)}[/]");
        }

        var rounded = DomainRules.RoundForDisplay(value);
        var color = GradeFormatter.Color(rounded);
        var position = (int)Math.Round((rounded - 2m) / 4m * (ScaleWidth - 1), MidpointRounding.AwayFromZero);
        var marker = new string(' ', Math.Clamp(position, 0, ScaleWidth - 1)) + "▼";
        var scale = Meter.Markup(rounded - 2m, 4m, ScaleWidth, ShkoloTheme.Error, ShkoloTheme.Success);

        return new Rows(
            new Markup($"[bold {color}]{BulgarianNames.Grade(rounded)}[/]  [{color}]{DomainRules.GradeWord(rounded)}[/]"),
            new Markup($"[{color}]{marker}[/]"),
            new Markup(scale),
            new Markup($"[{ShkoloTheme.MutedHex}]2,00{new string(' ', ScaleWidth - 8)}6,00[/]"));
    }
}
