﻿// Owner: Participant 2 – Presentation Developer
using System.Text;
using Shkolo.Presentation.Components;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>One part of a <see cref="SegmentBar"/>.</summary>
public sealed record Segment(string Label, int Count, Color Color);

/// <summary>
/// A whole split into parts: coloured segments with a one-column gap between them (so neighbours never merge),
/// then a legend with every part's count and share. Every non-empty part gets at least one cell.
/// </summary>
public static class SegmentBar
{
    /// <summary>The usual attendance split: present, late, excused, unexcused.</summary>
    public static IRenderable Attendance(Shkolo.Application.Reports.AttendanceSummary s, int width = 80) => Render(
    [
        new Segment("Присъствия", s.Present, Theme.ShkoloTheme.Success),
        new Segment("Закъснения", s.Late, Theme.ShkoloTheme.Accent),
        new Segment("Извинени", s.Excused, Theme.ShkoloTheme.Warning),
        new Segment("Неизвинени", s.Unexcused, Theme.ShkoloTheme.Error),
    ], width);

    public static IRenderable Render(IReadOnlyList<Segment> segments, int width = 80)
    {
        var parts = segments.Where(s => s.Count > 0).ToList();
        var total = parts.Sum(s => s.Count);
        if (total == 0)
        {
            return new Markup(Ui.Muted("Няма записи."));
        }

        var available = Math.Max(parts.Count, width - (parts.Count - 1));
        var cells = parts.Select(p => Math.Max(1, (int)Math.Round((double)p.Count / total * available))).ToArray();
        var largest = Array.IndexOf(cells, cells.Max());
        cells[largest] = Math.Max(1, cells[largest] + available - cells.Sum());

        var bar = new StringBuilder();
        for (var i = 0; i < parts.Count; i++)
        {
            bar.Append(i > 0 ? " " : "");
            bar.Append($"[{Gradient.Hex(parts[i].Color)}]{new string('█', cells[i])}[/]");
        }

        var legend = new Columns(segments.Select(s =>
            new Markup($"[{Gradient.Hex(s.Color)}]■[/] {Ui.Escape(s.Label)} [bold]{s.Count}[/] {Ui.Muted($"{(double)s.Count / total:P0}".Replace(" ", ""))}"))).Padding(0, 0, 4, 0);
        return new Rows(new Markup(bar.ToString()), new Text(""), legend);
    }
}
