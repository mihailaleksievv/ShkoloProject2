// Owner: Participant 2 – Presentation Developer
using System.Text;
using Shkolo.Application;
using Shkolo.Domain;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>
/// Weekly averages as small vertical columns on the 2–6 scale, each in its grade colour with the value
/// underneath; a week without grades shows "·". Columns are three cells wide with a gap between them.
/// </summary>
public static class WeekColumns
{
    private const int ColumnWidth = 6;
    private const int BarWidth = 3;
    private static readonly string Blocks = " ▁▂▃▄▅▆▇█";

    /// <remarks>
    /// Heights follow the student's own range (lowest week − 0,25 … highest + 0,25), so small changes stay visible;
    /// the exact values are printed under the columns.
    /// </remarks>
    public static IRenderable Render(IReadOnlyList<decimal?> weeks, int height = 4)
    {
        var known = weeks.Where(w => w is not null).Select(w => w!.Value).ToList();
        var low = known.Count == 0 ? 2m : Math.Max(2m, known.Min() - 0.25m);
        var high = known.Count == 0 ? 6m : Math.Min(6m, known.Max() + 0.25m);
        var span = Math.Max(0.5m, high - low);
        var lines = new List<string>();
        for (var level = height; level >= 1; level--)
        {
            var line = new StringBuilder();
            foreach (var week in weeks)
            {
                if (week is not { } v)
                {
                    line.Append(new string(' ', ColumnWidth));
                    continue;
                }

                var h = (double)Math.Clamp((v - low) / span, 0.12m, 1m) * height;
                var fill = Math.Clamp(h - (level - 1), 0, 1);
                var block = Blocks[(int)Math.Round(fill * 8, MidpointRounding.AwayFromZero)];
                line.Append($" [{GradeScale.HexOf(v)}]{new string(block, BarWidth)}[/]  ");
            }

            lines.Add(line.ToString());
        }

        lines.Add(string.Concat(weeks.Select(w => w is { } v
            ? $"[{GradeScale.HexOf(v)}]{BulgarianNames.Grade(DomainRules.RoundForDisplay(v)),-ColumnWidth}[/]"
            : Ui.Muted(" ·".PadRight(ColumnWidth)))));
        return new Markup(string.Join("\n", lines));
    }
}
