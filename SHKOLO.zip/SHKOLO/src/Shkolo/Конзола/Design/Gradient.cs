// Owner: Participant 2 – Presentation Developer
using System.Text;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>24-bit colour gradients for text and multi-line art (the SHKOLO logo).</summary>
public static class Gradient
{
    public static Color Lerp(Color a, Color b, double t)
    {
        t = Math.Clamp(t, 0, 1);
        return new Color(
            (byte)Math.Round(a.R + ((b.R - a.R) * t)),
            (byte)Math.Round(a.G + ((b.G - a.G) * t)),
            (byte)Math.Round(a.B + ((b.B - a.B) * t)));
    }

    public static string Hex(Color c) => $"#{c.R:X2}{c.G:X2}{c.B:X2}";

    /// <summary>Markup where every character has its own colour along the gradient. Text is escaped.</summary>
    public static string Text(string text, Color from, Color to)
    {
        if (string.IsNullOrEmpty(text))
        {
            return "";
        }

        return Colorize(text, from, to, text.Length, 0);
    }

    /// <summary>Colours lines column by column, so the gradient runs left → right across the whole block.</summary>
    /// <param name="gradientWidth">Width the gradient is spread over (defaults to the widest line).</param>
    public static IRenderable Lines(IReadOnlyList<string> lines, Color from, Color to, int? gradientWidth = null)
    {
        var width = gradientWidth ?? (lines.Count == 0 ? 1 : lines.Max(l => l.Length));
        return new Markup(string.Join("\n", lines.Select(l => Colorize(l, from, to, width, 0))));
    }

    private static string Colorize(string text, Color from, Color to, int width, int offset)
    {
        var builder = new StringBuilder();
        for (var i = 0; i < text.Length; i++)
        {
            var c = text[i];
            if (char.IsWhiteSpace(c))
            {
                builder.Append(c);
                continue;
            }

            var t = width <= 1 ? 0 : (double)(i + offset) / (width - 1);
            builder.Append('[').Append(Hex(Lerp(from, to, t))).Append(']')
                .Append(Markup.Escape(c.ToString()))
                .Append("[/]");
        }

        return builder.ToString();
    }
}
