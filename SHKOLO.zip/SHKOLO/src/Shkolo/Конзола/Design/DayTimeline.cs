// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>
/// The school day on one line: a cell per bell period with its start time, a status glyph
/// (✔ recorded · ● happening now · ○ upcoming · ○ amber = past but not recorded · · free) and the lesson.
/// </summary>
public static class DayTimeline
{
    public static IRenderable Render(IReadOnlyList<LessonSlot> slots, IReadOnlyList<TimetableRow> today, IReadOnlySet<Guid> recorded, TimeOnly now)
    {
        var grid = new Grid();
        foreach (var _ in slots)
        {
            grid.AddColumn(new GridColumn().Centered().PadRight(2));
        }

        var times = new List<IRenderable>();
        var marks = new List<IRenderable>();
        var labels = new List<IRenderable>();
        foreach (var slot in slots)
        {
            var row = today.FirstOrDefault(r => r.LessonNumber == slot.LessonNumber);
            var isNow = now >= slot.StartTime && now < slot.EndTime;
            times.Add(new Markup(isNow ? $"[bold {ShkoloTheme.AccentHex}]{Ui.Time(slot.StartTime)}[/]" : Ui.Muted(Ui.Time(slot.StartTime))));
            marks.Add(new Markup(Status(row, recorded, slot, now, isNow)));
            labels.Add(new Markup(row is null ? Ui.Muted("—") : $"{Ui.Escape(Short(row.SubjectName))}\n{Ui.Muted(row.ClassName)}"));
        }

        grid.AddRow(times.ToArray());
        grid.AddRow(marks.ToArray());
        grid.AddRow(labels.ToArray());
        return grid;
    }

    private static string Status(TimetableRow? row, IReadOnlySet<Guid> recorded, LessonSlot slot, TimeOnly now, bool isNow)
    {
        if (row is null)
        {
            return Ui.Muted(Glyphs.Empty);
        }

        if (recorded.Contains(row.EntryId))
        {
            return $"[bold {ShkoloTheme.SuccessHex}]{Glyphs.Done}[/]";
        }

        if (isNow)
        {
            return $"[bold {ShkoloTheme.AccentHex}]{Glyphs.Now}[/]";
        }

        return now >= slot.EndTime ? $"[{ShkoloTheme.WarningHex}]{Glyphs.Pending}[/]" : Ui.Muted(Glyphs.Pending);
    }

    private static string Short(string subject) => subject.Length <= 12 ? subject : subject[..11] + "…";
}
