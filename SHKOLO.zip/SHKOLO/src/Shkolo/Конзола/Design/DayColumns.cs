// Owner: Participant 2 – Presentation Developer
using System.Text;
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Design;

/// <summary>
/// Daily attendance shares as separate vertical columns: green ≥ 95 %, sapphire ≥ 90 %, yellow ≥ 85 %, red below.
/// Under every column: the share, the weekday and the date. Heights follow the shown range so small dips stay visible.
/// </summary>
public static class DayColumns
{
    private const int ColumnWidth = 8;
    private const int BarWidth = 4;
    private static readonly string Blocks = " ▁▂▃▄▅▆▇█";
    private static readonly string[] Weekdays = ["нд", "пн", "вт", "ср", "чт", "пт", "сб"];

    public static IRenderable Render(IReadOnlyList<DayPresence> days, int height = 5)
    {
        if (days.Count == 0)
        {
            return new Markup(Ui.Muted("Няма данни за присъствия."));
        }

        var known = days.Where(d => d.PresentShare is not null).Select(d => d.PresentShare!.Value).ToList();
        var low = known.Count == 0 ? 0m : Math.Max(0m, known.Min() - 0.05m);
        var span = Math.Max(0.05m, 1m - low);
        var lines = new List<string>();

        for (var level = height; level >= 1; level--)
        {
            var line = new StringBuilder();
            foreach (var day in days)
            {
                if (day.PresentShare is not { } share)
                {
                    line.Append(new string(' ', ColumnWidth));
                    continue;
                }

                var h = (double)Math.Clamp((share - low) / span, 0.1m, 1m) * height;
                var fill = Math.Clamp(h - (level - 1), 0, 1);
                var block = Blocks[(int)Math.Round(fill * 8, MidpointRounding.AwayFromZero)];
                line.Append($"  [{HexOf(share)}]{new string(block, BarWidth)}[/]  ");
            }

            lines.Add(line.ToString());
        }

        lines.Add(string.Concat(days.Select(d => d.PresentShare is { } s
            ? $"[bold {HexOf(s)}]{Center($"{s:P0}".Replace(" ", ""))}[/]"
            : Ui.Muted(Center("·")))));
        lines.Add(string.Concat(days.Select(d => Ui.Muted(Center(Weekdays[(int)d.Date.DayOfWeek])))));
        lines.Add(string.Concat(days.Select(d => Ui.Muted(Center(d.Date.ToString("dd.MM", Application.BulgarianNames.Culture))))));
        return new Markup(string.Join("\n", lines));
    }

    public static string HexOf(decimal share) => share switch
    {
        >= 0.95m => ShkoloTheme.SuccessHex,
        >= 0.90m => ShkoloTheme.AccentHex,
        >= 0.85m => ShkoloTheme.WarningHex,
        _ => ShkoloTheme.ErrorHex,
    };

    private static string Center(string text)
    {
        var left = Math.Max(0, (ColumnWidth - text.Length) / 2);
        return new string(' ', left) + text + new string(' ', Math.Max(0, ColumnWidth - text.Length - left));
    }
}
