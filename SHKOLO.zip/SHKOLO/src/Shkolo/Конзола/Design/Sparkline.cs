// Owner: Participant 2 – Presentation Developer
using System.Text;

namespace Shkolo.Presentation.Design;

/// <summary>Tiny inline chart of a series, one block per value (▁ lowest … █ highest, · missing).</summary>
public static class Sparkline
{
    public static string Render(IReadOnlyList<decimal?> values, decimal min, decimal max)
    {
        var builder = new StringBuilder();
        foreach (var value in values)
        {
            if (value is not { } v)
            {
                builder.Append(Glyphs.Empty);
                continue;
            }

            var level = max <= min
                ? 3
                : (int)Math.Round((Math.Clamp(v, min, max) - min) / (max - min) * 7, MidpointRounding.AwayFromZero);
            builder.Append(Glyphs.SparkBlocks[level]);
        }

        return builder.ToString();
    }

    /// <summary>Grade series on the fixed 2–6 scale.</summary>
    public static string Grades(IReadOnlyList<decimal?> values) => Render(values, 2m, 6m);
}
