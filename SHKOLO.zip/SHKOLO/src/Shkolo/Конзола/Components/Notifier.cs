// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Results;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Components;

/// <summary>Consistent success / warning / error messages. Messages are always escaped.</summary>
public sealed class Notifier
{
    private readonly IAnsiConsole _console;

    public Notifier(IAnsiConsole console) => _console = console;

    /// <summary>
    /// Outcome of the last success/error message (null = none since <see cref="ResetOutcome"/>).
    /// The command centre uses it to flash "✔ Готово" after a form.
    /// </summary>
    public bool? LastWasSuccess { get; private set; }

    public void ResetOutcome() => LastWasSuccess = null;

    public void Success(string message)
    {
        LastWasSuccess = true;
        _console.MarkupLine($"[{ShkoloTheme.SuccessHex}]✔ {Ui.Escape(message)}[/]");
    }

    public void Warning(string message) => _console.MarkupLine($"[{ShkoloTheme.WarningHex}]⚠ {Ui.Escape(message)}[/]");

    public void Error(string message)
    {
        LastWasSuccess = false;
        _console.MarkupLine($"[{ShkoloTheme.ErrorHex}]✖ {Ui.Escape(message)}[/]");
    }

    public void Info(string message) => _console.MarkupLine($"[{ShkoloTheme.AccentHex}]ℹ {Ui.Escape(message)}[/]");

    /// <summary>Shows the outcome of a service call and returns whether it succeeded.</summary>
    public bool Show(OperationResult result, string successMessage)
    {
        if (result.Success)
        {
            Success(successMessage);
        }
        else
        {
            Error(result.Error?.Message ?? "Операцията не е изпълнена.");
        }

        return result.Success;
    }

    /// <summary>Waits for a key so the user can read the screen before it is cleared.</summary>
    public void Pause()
    {
        if (!_console.Profile.Capabilities.Interactive)
        {
            return;
        }

        _console.WriteLine();
        _console.MarkupLine(Ui.Muted("Натиснете произволен клавиш за продължаване…"));
        _console.Input.ReadKey(intercept: true);
    }
}
