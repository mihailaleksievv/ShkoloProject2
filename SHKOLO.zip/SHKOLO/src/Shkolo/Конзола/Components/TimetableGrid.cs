// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Components;

/// <summary>Weekly timetable as a grid: lesson periods in rows, school days in columns.</summary>
public static class TimetableGrid
{
    private static readonly DayOfWeek[] Days = [DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday];

    /// <param name="secondLine">What to show under the subject: class name (teacher view) or teacher name (class view).</param>
    public static void Render(IAnsiConsole console, string title, IReadOnlyList<TimetableRow> rows, IReadOnlyList<LessonSlot> slots, Func<TimetableRow, string> secondLine, DayOfWeek? highlight = null)
        => console.Write(Build(title, rows, slots, secondLine, highlight));

    /// <param name="nowLesson">Lesson number happening right now (highlighted on the <paramref name="highlight"/> day).</param>
    public static Spectre.Console.Rendering.IRenderable Build(string title, IReadOnlyList<TimetableRow> rows, IReadOnlyList<LessonSlot> slots, Func<TimetableRow, string> secondLine, DayOfWeek? highlight = null, int? nowLesson = null)
    {
        var table = new Table()
            .Border(TableBorder.Rounded)
            .BorderColor(ShkoloTheme.Primary)
            .Title($"[bold {ShkoloTheme.PrimaryHex}]{Ui.Escape(title)}[/]")
            .AddColumn(new TableColumn("[bold]Час[/]").Centered());

        foreach (var day in Days)
        {
            var name = Ui.Escape(BulgarianNames.Of(day));
            table.AddColumn(new TableColumn(day == highlight ? $"[bold {ShkoloTheme.AccentHex}]{name} ●[/]" : $"[bold]{name}[/]"));
        }

        var used = slots.Where(s => rows.Any(r => r.LessonNumber == s.LessonNumber)).ToList();
        foreach (var slot in used)
        {
            var cells = new List<string> { $"[bold]{slot.LessonNumber}[/]\n{Ui.Muted($"{Ui.Time(slot.StartTime)}–{Ui.Time(slot.EndTime)}")}" };
            foreach (var day in Days)
            {
                var entries = rows.Where(r => r.Day == day && r.LessonNumber == slot.LessonNumber).ToList();
                var isNow = day == highlight && slot.LessonNumber == nowLesson;
                var cell = entries.Count == 0
                    ? Ui.Muted("·")
                    : string.Join("\n", entries.Select(e =>
                        $"{Ui.Escape(e.SubjectName)}\n{Ui.Muted(secondLine(e) + (e.Room is null ? "" : $" · {e.Room}"))}"));
                cells.Add(isNow ? $"[bold {ShkoloTheme.AccentHex}]● сега[/]\n{cell}" : cell);
            }

            table.AddRow(cells.Select(c => new Markup(c)).ToArray());
        }

        return used.Count == 0
            ? new Panel(new Markup(Ui.Muted("Няма записи в разписанието."))).Header($" {Ui.Escape(title)} ").BorderColor(ShkoloTheme.Muted)
            : table;
    }
}
