﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Components;

/// <summary>Dashboard tiles with a big value and a small label.</summary>
public static class StatPanel
{
    public static IRenderable Tiles(params (string Label, string ValueMarkup)[] tiles) => Tiles(2, tiles);

    /// <summary>Tiles with a chosen inner padding; dashboards use 1 so a whole row fits next to the navigation.</summary>
    public static IRenderable Tiles(int padding, params (string Label, string ValueMarkup)[] tiles)
        => new Columns(tiles.Select(t => (IRenderable)new Panel(new Markup($"{t.ValueMarkup}\n{Ui.Muted(t.Label)}").Centered())
                .Border(BoxBorder.Rounded)
                .BorderColor(ShkoloTheme.Primary)
                .Padding(padding, 0)))
            .Collapse();

    public static string Number(int value) => $"[bold {ShkoloTheme.TextHex}]{Ui.Count(value)}[/]";

    /// <summary>Section heading inside a screen.</summary>
    public static void Section(IAnsiConsole console, string title)
    {
        console.WriteLine();
        console.Write(new Rule($"[bold {ShkoloTheme.AccentHex}]{Ui.Escape(title)}[/]").LeftJustified().RuleStyle(new Style(ShkoloTheme.Muted)));
    }
}
