// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Components;

/// <summary>
/// Formatting helpers. Every user-provided string must reach Spectre markup through <see cref="Escape"/>,
/// otherwise a name such as "Иван [test]" would be parsed as markup and crash the renderer.
/// </summary>
public static class Ui
{
    public static string Escape(string? text) => Markup.Escape(text ?? "");

    public static string Muted(string? text) => $"[{ShkoloTheme.MutedHex}]{Escape(text)}[/]";

    public static string Accent(string? text) => $"[{ShkoloTheme.AccentHex}]{Escape(text)}[/]";

    public static string Strong(string? text) => $"[bold]{Escape(text)}[/]";

    public static string Date(DateOnly date) => date.ToString("dd.MM.yyyy", BulgarianNames.Culture);

    public static string Time(TimeOnly time) => time.ToString("HH:mm", BulgarianNames.Culture);

    public static string DateTime(DateTime local) => local.ToString("dd.MM.yyyy HH:mm", BulgarianNames.Culture);

    /// <summary>Stored UTC moment shown in local time.</summary>
    public static string FromUtc(DateTime utc) => DateTime(System.DateTime.SpecifyKind(utc, DateTimeKind.Utc).ToLocalTime());

    public static string Count(int value) => value.ToString(BulgarianNames.Culture);

    public static string LongDate(DateOnly date) => $"{BulgarianNames.Of(date.DayOfWeek)}, {Date(date)}";

    /// <summary>Clears the screen; when output is redirected (no console window) clearing is skipped instead of failing.</summary>
    public static void Clear(IAnsiConsole console)
    {
        try
        {
            console.Clear();
        }
        catch (IOException)
        {
            console.WriteLine();
        }
    }
}
