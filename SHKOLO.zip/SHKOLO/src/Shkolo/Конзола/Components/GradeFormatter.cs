﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Domain;
using Shkolo.Presentation.Theme;

namespace Shkolo.Presentation.Components;

/// <summary>Coloured display of grades and averages (rounded to two decimals only for display).</summary>
public static class GradeFormatter
{
    /// <summary>Colour of a grade band (see <see cref="Design.GradeScale"/>).</summary>
    public static string Color(decimal value) => Design.GradeScale.HexOf(value);

    public static string Markup(decimal? value)
    {
        if (value is not { } v)
        {
            return Ui.Muted("Няма данни");
        }

        var rounded = DomainRules.RoundForDisplay(v);
        return $"[bold {Color(rounded)}]{BulgarianNames.Grade(rounded)}[/]";
    }

    /// <summary>Grade with its verbal name, e.g. "5,50 Отличен".</summary>
    public static string WithWord(decimal? value)
        => value is { } v ? $"{Markup(v)} {Ui.Muted(DomainRules.GradeWord(DomainRules.RoundForDisplay(v)))}" : Markup(null);

    public static string TermGrade(int? value)
        => value is { } v ? $"[bold {Color(v)}]{v}[/]" : Ui.Muted("—");
}
