// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Components;

/// <summary>Top bar shown on every screen: brand, role, user, date, term, unread notifications and breadcrumbs.</summary>
public static class Header
{
    public static void Render(ScreenContext ctx)
    {
        var services = ctx.Services;
        var today = services.Clock.Today;
        var parts = new List<string> { $"[bold {ShkoloTheme.PrimaryHex}]{ShkoloTheme.Brand}[/]" };

        if (services.Session.CurrentUser is { } user)
        {
            parts.Add($"[{ShkoloTheme.AccentHex}]{Ui.Escape(BulgarianNames.Of(user.Role))}[/]");
            parts.Add($"[bold]{Ui.Escape(user.DisplayName)}[/]");
        }

        parts.Add(Ui.Muted(Ui.LongDate(today)));

        var year = services.AcademicYears.GetActive();
        if (year is not null && year.Contains(today))
        {
            parts.Add(Ui.Muted($"{year.Name} · {BulgarianNames.Of(year.GetTerm(today))}"));
        }

        if (services.Session.IsAuthenticated)
        {
            var unread = services.Notifications.GetUnreadCount();
            parts.Add(unread > 0 ? $"[bold {ShkoloTheme.WarningHex}]✉ {unread} нови[/]" : Ui.Muted("✉ 0"));
        }

        ctx.Console.Write(new Rule(string.Join(Ui.Muted(" │ "), parts)).LeftJustified().RuleStyle(new Style(ShkoloTheme.Primary)));
        if (ctx.Breadcrumbs.Count > 1)
        {
            ctx.Console.MarkupLine(Ui.Muted(string.Join(" › ", ctx.Breadcrumbs)));
        }

        if (services.Authorization.IsAdmin && ctx.Services.System.GetStorageInfo().Value?.IsReadOnly == true)
        {
            ctx.Notifier.Warning("Режим само за четене: открити са проблеми в данните. Възстановете архив от „Системна информация“.");
        }

        ctx.Console.WriteLine();
    }
}
