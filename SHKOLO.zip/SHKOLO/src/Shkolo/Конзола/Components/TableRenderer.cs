// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Components;

/// <summary>A table column: header plus a function returning SAFE markup for a row.</summary>
public sealed record Col<T>(string Header, Func<T, string> Markup, Justify Alignment = Justify.Left);

/// <summary>Column factories. <see cref="Text{T}"/> escapes values; <see cref="Markup{T}"/> is for trusted, pre-built markup.</summary>
public static class Col
{
    public static Col<T> Text<T>(string header, Func<T, string?> value, Justify alignment = Justify.Left)
        => new(header, row => Ui.Escape(value(row)), alignment);

    public static Col<T> Markup<T>(string header, Func<T, string> markup, Justify alignment = Justify.Left)
        => new(header, markup, alignment);
}

/// <summary>Renders consistent, paged tables with an empty-state message.</summary>
public static class TableRenderer
{
    public const int PageSize = 20;

    public static void Render<T>(IAnsiConsole console, string title, IReadOnlyList<T> rows, params Col<T>[] columns)
    {
        if (rows.Count == 0)
        {
            console.Write(new Panel(new Markup(Ui.Muted("Няма записи.")))
                .Header($" {Ui.Escape(title)} ")
                .Border(BoxBorder.Rounded)
                .BorderColor(ShkoloTheme.Muted));
            return;
        }

        var pages = (rows.Count + PageSize - 1) / PageSize;
        for (var page = 0; page < pages; page++)
        {
            var table = new Table()
                .Border(TableBorder.Rounded)
                .BorderColor(ShkoloTheme.Primary)
                .Title($"[bold {ShkoloTheme.PrimaryHex}]{Ui.Escape(title)}[/]")
                .Caption(pages > 1 ? Ui.Muted($"Страница {page + 1} от {pages} · общо {rows.Count} записа") : Ui.Muted($"Общо {rows.Count}"));

            foreach (var column in columns)
            {
                table.AddColumn(new TableColumn($"[bold]{Ui.Escape(column.Header)}[/]") { Alignment = column.Alignment });
            }

            foreach (var row in rows.Skip(page * PageSize).Take(PageSize))
            {
                table.AddRow(columns.Select(c => (Spectre.Console.Rendering.IRenderable)new Markup(c.Markup(row))).ToArray());
            }

            console.Write(table);

            if (page < pages - 1)
            {
                if (!console.Profile.Capabilities.Interactive)
                {
                    continue;
                }

                console.MarkupLine(Ui.Muted("Enter – следваща страница · Esc – край на списъка"));
                if (console.Input.ReadKey(intercept: true)?.Key == ConsoleKey.Escape)
                {
                    return;
                }
            }
        }
    }
}
