﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Navigation;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Shell;

/// <summary>How the command centre (or one of its actions) ends.</summary>
public enum ShellOutcome
{
    Stay,
    Logout,
    Exit,
}

/// <summary>Per-frame information given to a section when it renders.</summary>
/// <param name="ActionsFocused">True when the keyboard is in the action row; false when it is in the navigation menu.</param>
public sealed record ShellFrame(DateTime LocalNow, double TransitionProgress, int SelectedAction, bool ActionsFocused = false);

/// <summary>A tab of a role workspace: renders live content from data cached in <see cref="Load"/>.</summary>
public interface ISection
{
    string Title { get; }

    /// <summary>Width-1 symbol from <c>Glyphs</c>.</summary>
    string Icon { get; }

    IReadOnlyList<SectionAction> Actions { get; }

    /// <summary>Computes and caches the section's data. Called on entering the section and after every action – never per frame.</summary>
    void Load(ScreenContext ctx);

    /// <summary>Draws the section from the cached data (called on every frame).</summary>
    IRenderable Render(ScreenContext ctx, ShellFrame frame);

    /// <summary>Optional section-specific keys (e.g. ←/→ in the calendar). Return true when handled.</summary>
    bool HandleKey(ScreenContext ctx, ConsoleKeyInfo key) => false;

    /// <summary>True while the section runs its own animation (e.g. counters counting up), so the shell keeps redrawing.</summary>
    bool IsAnimating => false;
}

/// <summary>A role's set of sections.</summary>
public interface IWorkspace
{
    string Name { get; }

    IReadOnlyList<ISection> Sections(ScreenContext ctx);
}

/// <summary>An action of a section: label, optional Cyrillic hotkey and what it does.</summary>
public sealed record SectionAction(string Label, char? Hotkey, Func<ScreenContext, ShellOutcome> Run)
{
    /// <summary>Runs a v1.0 form function inside a framed form host.</summary>
    public static SectionAction Form(string label, char? hotkey, Action<ScreenContext> form)
        => new(label, hotkey, ctx =>
        {
            FormHost.Run(ctx, label, form);
            return ShellOutcome.Stay;
        });

    /// <summary>Opens a v1.0 screen (with its own sub-menus) in a nested navigator.</summary>
    public static SectionAction Open(string label, char? hotkey, Func<IScreen> screen)
        => new(label, hotkey, ctx => FormHost.Open(ctx, label, screen));
}
