﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Shell;

/// <summary>Builds the command-centre frame: header, navigation rail, main area with actions, key-hint footer.</summary>
public static class ShellLayout
{
    private const int NavWidth = 26;

    public static IRenderable Build(ScreenContext ctx, IReadOnlyList<ISection> sections, int active, ShellFrame frame, IRenderable main, bool compact, string? flash)
    {
        var accent = RoleAccent.For(ctx.Services.Session.Role);
        var root = new Layout("root").SplitRows(
            new Layout("header").Size(3),
            new Layout("body"),
            new Layout("footer").Size(3));

        root["header"].Update(Header(ctx, frame, accent));
        root["footer"].Update(Footer(accent, flash, sections[active], frame.ActionsFocused));

        var mainPanel = new Panel(MainArea(sections[active], frame, main, accent)).Border(BoxBorder.Rounded).BorderColor(frame.ActionsFocused || compact ? accent : ShkoloTheme.Muted).Expand();
        if (compact)
        {
            root["body"].Update(mainPanel);
        }
        else
        {
            root["body"].SplitColumns(new Layout("nav").Size(NavWidth), new Layout("main"));
            root["body"]["nav"].Update(Nav(sections, active, accent, !frame.ActionsFocused));
            root["body"]["main"].Update(mainPanel);
        }

        return root;
    }

    private static IRenderable Header(ScreenContext ctx, ShellFrame frame, Color accent)
    {
        var services = ctx.Services;
        var user = services.Session.CurrentUser;
        var hex = Gradient.Hex(accent);
        var left = $"{Gradient.Text(ShkoloTheme.Brand, ShkoloTheme.Primary, ShkoloTheme.Accent)}  [{ShkoloTheme.MutedHex}]│[/]  [bold {ShkoloTheme.BackgroundHex} on {RoleAccent.BadgeHexFor(user?.Role)}] {Ui.Escape(user is null ? "" : BulgarianNames.Of(user.Role))} [/]  [{ShkoloTheme.MutedHex}]│[/]  [bold]{Ui.Escape(user?.DisplayName)}[/]";

        var unread = services.Notifications.GetUnreadCount();
        var today = DateOnly.FromDateTime(frame.LocalNow);
        var year = services.AcademicYears.GetActive();
        var term = year is not null && year.Contains(today) ? $"{year.Name} · {BulgarianNames.Of(year.GetTerm(today))}" : "извън учебната година";
        var mail = unread > 0 ? $"[bold {ShkoloTheme.WarningHex}]{Glyphs.Mail} {unread}[/]" : Ui.Muted($"{Glyphs.Mail} 0");
        var right = $"{mail}  [{ShkoloTheme.MutedHex}]│[/]  {Ui.Escape(BulgarianNames.Of(today.DayOfWeek).ToLower(BulgarianNames.Culture))} {today:dd.MM} · [bold]{frame.LocalNow:HH:mm:ss}[/]  [{ShkoloTheme.MutedHex}]│[/]  {Ui.Muted(term)}";

        var grid = new Grid().AddColumn(new GridColumn().NoWrap()).AddColumn(new GridColumn().RightAligned());
        grid.AddRow(new Markup(left), new Markup(right));
        return new Panel(grid).Border(BoxBorder.Rounded).BorderColor(accent).Expand();
    }

    private static IRenderable Nav(IReadOnlyList<ISection> sections, int active, Color accent, bool focused)
    {
        var hex = Gradient.Hex(accent);
        var lines = sections.Select((s, i) => i == active
            ? focused
                ? $"[bold {ShkoloTheme.BackgroundHex} on {hex}] {Glyphs.Selected} {Ui.Escape(s.Icon)} {Ui.Escape(Fit(s.Title, 13)),-13} {i + 1} [/]"
                : $"[bold {hex}] {Glyphs.Selected} {Ui.Escape(s.Icon)} {Ui.Escape(Fit(s.Title, 13)),-13} {i + 1} [/]"
            : $"   {Ui.Escape(s.Icon)} {Ui.Escape(Fit(s.Title, 13)),-13} [{ShkoloTheme.MutedHex}]{i + 1}[/]");
        return new Panel(new Markup(string.Join("\n\n", lines))).Border(BoxBorder.Rounded).BorderColor(focused ? accent : ShkoloTheme.Muted).Expand();
    }

    private static IRenderable MainArea(ISection section, ShellFrame frame, IRenderable content, Color accent)
    {
        var rows = new List<IRenderable> { SectionHeader.Render(section.Icon, section.Title, accent), content };
        if (section.Actions.Count > 0)
        {
            rows.Add(new Rule($"[{ShkoloTheme.MutedHex}]Действия[/]").LeftJustified().RuleStyle(new Style(ShkoloTheme.Muted)));
            var hex = Gradient.Hex(accent);
            var actions = section.Actions.Select((a, i) =>
            {
                var key = a.Hotkey is { } h ? $" [{ShkoloTheme.MutedHex}][[{h}]][/]" : "";
                return i == frame.SelectedAction
                    ? $"[bold {ShkoloTheme.BackgroundHex} on {hex}] {Glyphs.Selected} {Ui.Escape(a.Label)} [/]{key}"
                    : $"   {Ui.Escape(a.Label)}{key}";
            });
            rows.Add(new Markup(string.Join("    ", actions)));
        }

        return new Rows(rows);
    }

    private static IRenderable Footer(Color accent, string? flash, ISection section, bool actionsFocused)
    {
        string[] keys = actionsFocused
            ? [Hint("←→", "действие"), Hint("Enter", "изпълни"), Hint("Esc", "към менюто")]
            : section.Actions.Count > 0
                ? [Hint("↑↓", "раздел"), Hint("→", "действия"), Hint("1-9", "раздел")]
                : [Hint("↑↓", "раздел"), Hint("1-9", "раздел")];
        string[] tail = actionsFocused
            ? [Hint("/", "търсене"), Hint("?", "помощ")]
            : [Hint("/", "търсене"), Hint("?", "помощ"), Hint("Esc", "изход")];
        var hints = string.Join($"  [{ShkoloTheme.MutedHex}]·[/]  ", [.. keys, .. tail]);
        var text = flash is null ? hints : $"[bold {ShkoloTheme.BackgroundHex} on {ShkoloTheme.SuccessHex}] {Ui.Escape(flash)} [/]   {hints}";
        return new Panel(new Markup(text)).Border(BoxBorder.Rounded).BorderColor(accent).Expand();
    }

    private static string Hint(string key, string label) => $"[bold]{Ui.Escape(key)}[/] {Ui.Muted(label)}";

    private static string Fit(string text, int width) => text.Length <= width ? text : text[..(width - 1)] + "…";
}
