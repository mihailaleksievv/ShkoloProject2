// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Shell;

/// <summary>Protects the layout: below 120×34 the user is asked to enlarge the window or continue in compact mode.</summary>
public static class SmallWindowGuard
{
    public const int MinWidth = 120;
    public const int MinHeight = 34;

    public static bool IsTooSmall(IAnsiConsole console)
        => console.Profile.Width < MinWidth || console.Profile.Height < MinHeight;

    /// <summary>Returns true to continue in compact mode, false when the window became large enough, null to log out.</summary>
    public static bool? Show(ScreenContext ctx)
    {
        while (IsTooSmall(ctx.Console))
        {
            Ui.Clear(ctx.Console);
            var size = $"{ctx.Console.Profile.Width}×{ctx.Console.Profile.Height}";
            ctx.Console.Write(new Panel(new Markup(
                    $"SHKOLO се нуждае от прозорец поне [bold]{MinWidth}×{MinHeight}[/] (сега [bold {ShkoloTheme.WarningHex}]{size}[/]).\n\n" +
                    $"Увеличете прозореца и натиснете произволен клавиш,\nили {Ui.Strong("Enter")} за компактен режим · {Ui.Strong("Esc")} за изход от профила."))
                .Header(" [bold]Малък прозорец[/] ")
                .Border(BoxBorder.Rounded)
                .BorderColor(ShkoloTheme.Warning)
                .Padding(2, 1));

            var key = ctx.Console.Input.ReadKey(intercept: true);
            if (key?.Key == ConsoleKey.Enter)
            {
                return true;
            }

            if (key?.Key == ConsoleKey.Escape)
            {
                return null;
            }
        }

        return false;
    }
}
