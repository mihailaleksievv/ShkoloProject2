// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Shell;

/// <summary>
/// "/" search over people, classes and actions, filtered live while typing (like VS Code's command palette).
/// Returns the chosen entry as an action, or null when closed with Esc.
/// </summary>
public static class CommandPalette
{
    public static SectionAction? Show(ScreenContext ctx, PaletteIndex index)
    {
        var console = ctx.Console;
        var accent = RoleAccent.For(ctx.Services.Session.Role);
        var query = "";
        var selected = 0;
        PaletteItem? chosen = null;
        var closed = false;

        Ui.Clear(console);
        console.Live(Render(query, index.Search(query), selected, accent)).AutoClear(false).Start(live =>
        {
            live.Refresh();
            while (chosen is null && !closed)
            {
                var key = console.Input.ReadKey(intercept: true);
                if (key is not { } k)
                {
                    continue;
                }

                var results = index.Search(query);
                switch (k.Key)
                {
                    case ConsoleKey.Escape:
                        closed = true;
                        break;
                    case ConsoleKey.Enter:
                        if (results.Count > 0)
                        {
                            chosen = results[Math.Clamp(selected, 0, results.Count - 1)];
                        }

                        break;
                    case ConsoleKey.DownArrow:
                        selected = results.Count == 0 ? 0 : (selected + 1) % results.Count;
                        break;
                    case ConsoleKey.UpArrow:
                        selected = results.Count == 0 ? 0 : (selected - 1 + results.Count) % results.Count;
                        break;
                    case ConsoleKey.Backspace:
                        query = query.Length == 0 ? query : query[..^1];
                        selected = 0;
                        break;
                    default:
                        if (!char.IsControl(k.KeyChar))
                        {
                            query += k.KeyChar;
                            selected = 0;
                        }

                        break;
                }

                live.UpdateTarget(Render(query, index.Search(query), selected, accent));
                live.Refresh();
            }
        });

        return chosen is null ? null : new SectionAction(chosen.Label, null, chosen.Run);
    }

    private static IRenderable Render(string query, IReadOnlyList<PaletteItem> results, int selected, Color accent)
    {
        var hex = Gradient.Hex(accent);
        var lines = new List<string> { $"[bold {hex}]›[/] {Ui.Escape(query)}[{hex}]▌[/]", "" };
        string? group = null;
        for (var i = 0; i < results.Count; i++)
        {
            var item = results[i];
            if (item.Group != group)
            {
                group = item.Group;
                lines.Add($"[{ShkoloTheme.MutedHex}]{Ui.Escape(group)}[/]");
            }

            lines.Add(i == selected
                ? $"[bold {ShkoloTheme.BackgroundHex} on {hex}] {Glyphs.Selected} {Ui.Escape(item.Label)} [/]"
                : $"   {Ui.Escape(item.Label)}");
        }

        if (results.Count == 0)
        {
            lines.Add(Ui.Muted("Няма резултати."));
        }

        lines.Add("");
        lines.Add(Ui.Muted("Пишете за търсене · ↑↓ избор · Enter отвори · Esc затвори"));
        return new Panel(new Markup(string.Join("\n", lines)))
            .Header($" [bold {hex}]{Glyphs.Selected} Търсене в SHKOLO[/] ")
            .Border(BoxBorder.Double)
            .BorderColor(accent)
            .Padding(2, 1)
            .Expand();
    }
}
