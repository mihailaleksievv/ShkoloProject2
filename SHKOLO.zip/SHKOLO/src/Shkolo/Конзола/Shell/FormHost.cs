// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Shell;

/// <summary>
/// Runs dialog-style work outside the live command centre: a framed title in the role accent,
/// then the reliable v1.0 form or screen. The shell resumes afterwards.
/// </summary>
public static class FormHost
{
    public static void Run(ScreenContext ctx, string action, Action<ScreenContext> form)
    {
        Frame(ctx, action);
        form(ctx);
    }

    public static ShellOutcome Open(ScreenContext ctx, string action, Func<IScreen> screen)
        => new ScreenNavigator().Run(screen(), ctx, exitOnLogout: true) switch
        {
            NavigationOutcome.Logout => ShellOutcome.Logout,
            NavigationOutcome.Exit => ShellOutcome.Exit,
            _ => ShellOutcome.Stay,
        };

    private static void Frame(ScreenContext ctx, string action)
    {
        Ui.Clear(ctx.Console);
        var accent = RoleAccent.For(ctx.Services.Session.Role);
        var path = ctx.ShellSection is null ? action : $"{ctx.ShellSection} › {action}";
        ctx.Console.Write(new Panel(new Markup($"{Gradient.Text(ShkoloTheme.Brand, ShkoloTheme.Primary, ShkoloTheme.Accent)} [{ShkoloTheme.MutedHex}]›[/] [bold]{Ui.Escape(path)}[/]"))
            .Border(BoxBorder.Rounded)
            .BorderColor(accent)
            .Expand());
        ctx.Console.WriteLine();
    }
}
