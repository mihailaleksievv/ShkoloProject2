﻿// Owner: Participant 2 – Presentation Developer
using System.Diagnostics;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Motion;
using Shkolo.Presentation.Navigation;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Shell;

/// <summary>Командният център след вход: менюто вляво, разделите и клавишите.</summary>
public sealed class AppShell
{
    private static readonly TimeSpan TransitionDuration = TimeSpan.FromMilliseconds(150);
    private static readonly TimeSpan FlashDuration = TimeSpan.FromMilliseconds(900);
    private static readonly TimeSpan IdleTick = TimeSpan.FromMilliseconds(50);

    private enum CommandKind
    {
        RunAction,
        Palette,
        Help,
        Escape,
    }

    private sealed record Command(CommandKind Kind, SectionAction? Action = null);

    private ScreenContext _ctx = null!;
    private IReadOnlyList<ISection> _sections = [];
    private int _active;
    private int _selected;
    private bool _actionsFocused;
    private bool _compact;
    private IRenderable? _previousMain;
    private readonly Stopwatch _transition = new();
    private string? _flash;
    private readonly Stopwatch _flashTimer = new();

    public ShellOutcome Run(ScreenContext ctx, IWorkspace workspace)
    {
        _ctx = ctx;
        _sections = workspace.Sections(ctx);
        if (_sections.Count == 0)
        {
            return ShellOutcome.Logout;
        }

        SwitchTo(0, animate: false);
        while (true)
        {
            if (!_compact && SmallWindowGuard.IsTooSmall(ctx.Console))
            {
                var decision = SmallWindowGuard.Show(ctx);
                if (decision is null)
                {
                    return ShellOutcome.Logout;
                }

                _compact = decision.Value;
            }

            var command = LiveLoop();
            var outcome = Execute(command);
            if (outcome != ShellOutcome.Stay)
            {
                return outcome;
            }
        }
    }

    /// <summary>Lists every action of every section – used by the command palette.</summary>
    public IReadOnlyList<ISection> Sections => _sections;

    private Command LiveLoop()
    {
        var console = _ctx.Console;
        Ui.Clear(console);
        Command? command = null;
        var lastSecond = -1;
        console.Live(Build()).AutoClear(false).Overflow(VerticalOverflow.Crop).Start(live =>
        {
            live.Refresh(); // Spectre draws the initial target only on the first refresh
            while (command is null)
            {
                ConsoleKeyInfo? key = null;
                if (console.Input.IsKeyAvailable())
                {
                    key = console.Input.ReadKey(intercept: true);
                }
                else if (_ctx.Motion.Enabled)
                {
                    var animating = _transition.IsRunning || _flashTimer.IsRunning || _sections[_active].IsAnimating;
                    var second = _ctx.Services.Clock.LocalNow.Second;
                    if (animating || second != lastSecond)
                    {
                        lastSecond = second;
                        live.UpdateTarget(Build());
                        live.Refresh();
                    }

                    Thread.Sleep(animating ? TimeSpan.FromMilliseconds(16) : IdleTick);
                    continue;
                }
                else
                {
                    key = console.Input.ReadKey(intercept: true);
                }

                if (key is { } k)
                {
                    command = Handle(k);
                    live.UpdateTarget(Build());
                    live.Refresh();
                }
            }
        });
        return command!;
    }

    private Command? Handle(ConsoleKeyInfo key)
    {
        var section = _sections[_active];
        var actions = section.Actions;
        if (_actionsFocused && actions.Count == 0)
        {
            _actionsFocused = false;
        }

        // Two panes: the navigation menu (↑↓ change section, → / Enter go to the actions)
        // and the action row (←→ ↑↓ pick, Enter runs, ← on the first action or Esc go back).
        if (_actionsFocused)
        {
            switch (key.Key)
            {
                case ConsoleKey.RightArrow or ConsoleKey.DownArrow:
                    _selected = (_selected + 1) % actions.Count;
                    return null;
                case ConsoleKey.LeftArrow when _selected == 0:
                case ConsoleKey.Escape or ConsoleKey.Backspace:
                    _actionsFocused = false;
                    return null;
                case ConsoleKey.LeftArrow or ConsoleKey.UpArrow:
                    _selected = (_selected - 1 + actions.Count) % actions.Count;
                    return null;
                case ConsoleKey.Enter:
                    return new Command(CommandKind.RunAction, actions[Math.Clamp(_selected, 0, actions.Count - 1)]);
            }
        }
        else
        {
            switch (key.Key)
            {
                case ConsoleKey.DownArrow:
                    SwitchTo((_active + 1) % _sections.Count, animate: true);
                    return null;
                case ConsoleKey.UpArrow:
                    SwitchTo((_active - 1 + _sections.Count) % _sections.Count, animate: true);
                    return null;
                case ConsoleKey.LeftArrow or ConsoleKey.RightArrow when section.HandleKey(_ctx, key):
                    return null; // sections that page by class or month use ← →
                case ConsoleKey.RightArrow or ConsoleKey.Enter when actions.Count > 0:
                    _actionsFocused = true;
                    _selected = 0;
                    return null;
                case ConsoleKey.Escape:
                    return new Command(CommandKind.Escape);
            }
        }

        if (key.Key == ConsoleKey.Tab)
        {
            SwitchTo((_active + (key.Modifiers.HasFlag(ConsoleModifiers.Shift) ? _sections.Count - 1 : 1)) % _sections.Count, animate: true);
            return null;
        }

        switch (key.KeyChar)
        {
            case >= '1' and <= '9' when key.KeyChar - '1' < _sections.Count:
                SwitchTo(key.KeyChar - '1', animate: true);
                return null;
            case '/':
                return new Command(CommandKind.Palette);
            case '?':
                return new Command(CommandKind.Help);
        }

        if (section.HandleKey(_ctx, key))
        {
            return null;
        }

        var letter = KeyMap.Normalize(key);
        var match = letter is null ? null : actions.FirstOrDefault(a => a.Hotkey is { } h && char.ToUpperInvariant(h) == letter);
        return match is null ? null : new Command(CommandKind.RunAction, match);
    }

    private ShellOutcome Execute(Command command)
    {
        switch (command.Kind)
        {
            case CommandKind.Escape:
                Ui.Clear(_ctx.Console);
                return _ctx.Input.ReadConfirmation("Изход от профила?", defaultValue: false) ? ShellOutcome.Logout : ShellOutcome.Stay;
            case CommandKind.Help:
                HelpOverlay.Show(_ctx, _sections[_active]);
                return ShellOutcome.Stay;
            case CommandKind.Palette:
                return RunAction(CommandPalette.Show(_ctx, PaletteIndex.Build(_ctx, _sections)));
            default:
                return RunAction(command.Action);
        }
    }

    private ShellOutcome RunAction(SectionAction? action)
    {
        if (action is null)
        {
            return ShellOutcome.Stay;
        }

        _ctx.ShellSection = _sections[_active].Title;
        _ctx.Notifier.ResetOutcome();
        ShellOutcome outcome;
        try
        {
            outcome = action.Run(_ctx);
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            // Same boundary as ScreenNavigator: log, tell the user, stay in the command centre.
            _ctx.LogError(ex);
            _ctx.Notifier.Error("Възникна неочаквана грешка. Тя е записана в дневника на приложението; данните не са променени.");
            _ctx.Notifier.Pause();
            outcome = ShellOutcome.Stay;
        }
        finally
        {
            _ctx.ShellSection = null;
        }

        if (outcome != ShellOutcome.Stay)
        {
            return outcome;
        }

        if (_ctx.Notifier.LastWasSuccess == true)
        {
            _flash = "✔ Готово";
            _flashTimer.Restart();
        }

        _sections[_active].Load(_ctx);
        return ShellOutcome.Stay;
    }

    private void SwitchTo(int index, bool animate)
    {
        _previousMain = _sections.Count > 0 && animate ? _sections[_active].Render(_ctx, Frame(1)) : null;
        _active = index;
        _selected = 0;
        _actionsFocused = false;
        _sections[_active].Load(_ctx);
        if (animate && _ctx.Motion.Enabled)
        {
            _transition.Restart();
        }
    }

    private ShellFrame Frame(double transition)
        => new(_ctx.Services.Clock.LocalNow, transition, _actionsFocused ? _selected : -1, _actionsFocused);

    private IRenderable Build()
    {
        var progress = 1.0;
        if (_transition.IsRunning)
        {
            progress = Tween.Progress(_transition.Elapsed, TransitionDuration, Easing.Linear);
            if (progress >= 1)
            {
                _transition.Reset();
            }
        }

        if (_flashTimer.IsRunning && _flashTimer.Elapsed > FlashDuration)
        {
            _flashTimer.Reset();
            _flash = null;
        }

        var frame = Frame(progress);
        var main = _sections[_active].Render(_ctx, frame);
        if (progress < 1 && _previousMain is not null)
        {
            main = Effects.Wipe(_previousMain, main)(progress);
        }

        var flash = _flash;
        if (!_ctx.Motion.Enabled)
        {
            _flash = null; // without motion the flash is shown on exactly one frame
        }

        return ShellLayout.Build(_ctx, _sections, _active, frame, main, _compact, flash);
    }
}
