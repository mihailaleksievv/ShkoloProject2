// Owner: Participant 2 – Presentation Developer
namespace Shkolo.Presentation.Shell;

/// <summary>
/// Turns a key press into a hotkey letter: upper-case Cyrillic. Latin letters are mapped by the
/// Bulgarian phonetic layout (P → П, N → Н …) so hotkeys work with either keyboard layout.
/// </summary>
public static class KeyMap
{
    private static readonly Dictionary<char, char> Phonetic = new()
    {
        ['A'] = 'А', ['B'] = 'Б', ['W'] = 'В', ['G'] = 'Г', ['D'] = 'Д', ['E'] = 'Е', ['V'] = 'Ж', ['Z'] = 'З',
        ['I'] = 'И', ['J'] = 'Й', ['K'] = 'К', ['L'] = 'Л', ['M'] = 'М', ['N'] = 'Н', ['O'] = 'О', ['P'] = 'П',
        ['R'] = 'Р', ['S'] = 'С', ['T'] = 'Т', ['U'] = 'У', ['F'] = 'Ф', ['H'] = 'Х', ['C'] = 'Ц', ['`'] = 'Ч',
        ['['] = 'Ш', [']'] = 'Щ', ['Y'] = 'Ъ', ['X'] = 'Ь', ['\\'] = 'Ю', ['Q'] = 'Я',
    };

    public static char? Normalize(ConsoleKeyInfo key)
    {
        var c = char.ToUpperInvariant(key.KeyChar);
        if (Phonetic.TryGetValue(c, out var cyrillic))
        {
            return cyrillic;
        }

        return c is >= 'А' and <= 'Я' ? c : null;
    }
}
