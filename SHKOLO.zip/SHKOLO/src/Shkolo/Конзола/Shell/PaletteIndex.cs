// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.AdminArea;
using Shkolo.Presentation.Screens.Shared;

namespace Shkolo.Presentation.Shell;

/// <summary>One searchable entry of the command palette.</summary>
/// <param name="ExactKey">Matched exactly (e.g. a student number) in addition to the label text.</param>
public sealed record PaletteItem(string Group, string Label, Func<ScreenContext, ShellOutcome> Run, string? ExactKey = null);

/// <summary>
/// Everything the palette can find for the current user: people (staff only), classes and every
/// action of every section. Searching is pure and fast – the index is built once when the palette opens.
/// </summary>
public sealed class PaletteIndex
{
    public const string People = "Хора";
    public const string Classes = "Класове";
    public const string Actions = "Действия";

    private static readonly string[] GroupOrder = [People, Classes, Actions];
    private readonly IReadOnlyList<PaletteItem> _items;

    private PaletteIndex(IReadOnlyList<PaletteItem> items) => _items = items;

    public static PaletteIndex Build(ScreenContext ctx, IReadOnlyList<ISection> sections)
    {
        var services = ctx.Services;
        var items = new List<PaletteItem>();
        var isStaff = services.Authorization.IsAdmin || services.Authorization.IsTeacher;
        var classes = services.Classes.GetAll(includeInactive: true).ToDictionary(c => c.Id, c => c.DisplayName);

        if (isStaff && services.Students.GetAllStudents().Value is { } students)
        {
            items.AddRange(students.Select(s => new PaletteItem(People, $"{s.FullName} · {classes.GetValueOrDefault(s.ClassId, "—")} · №{s.StudentNumber}",
                c => FormHost.Open(c, $"Справка за {s.FullName}", () => new StudentReportScreen(s.Id)), s.StudentNumber)));
        }

        if (services.Authorization.IsAdmin && services.Teachers.GetAll().Value is { } teachers)
        {
            items.AddRange(teachers.Select(t => new PaletteItem(People, $"{t.FullName} · учител",
                c => FormHost.Open(c, "Учители", () => new TeachersScreen()), t.EmployeeNumber)));
        }

        items.AddRange(services.Classes.GetAll().Select(cls => new PaletteItem(Classes, $"{cls.DisplayName} клас",
            c => isStaff ? FormHost.Open(c, $"Справка за {cls.DisplayName}", () => new ClassReportScreen(cls.Id)) : ShellOutcome.Stay)));

        items.AddRange(sections.SelectMany(section => section.Actions.Select(a => new PaletteItem(Actions, $"{section.Title} › {a.Label}", a.Run))));
        return new PaletteIndex(items);
    }

    public IReadOnlyList<PaletteItem> Search(string query, int max = 10)
    {
        var q = (query ?? "").Trim();
        var matches = q.Length == 0
            ? _items.Where(i => i.Group == Actions)
            : _items.Where(i => i.Label.Contains(q, StringComparison.CurrentCultureIgnoreCase) || (i.ExactKey is not null && i.ExactKey.Equals(q, StringComparison.OrdinalIgnoreCase)));

        return matches
            .OrderBy(i => Array.IndexOf(GroupOrder, i.Group))
            .ThenBy(i => i.Label, StringComparer.Create(Application.BulgarianNames.Culture, ignoreCase: true))
            .Take(max)
            .ToList();
    }
}
