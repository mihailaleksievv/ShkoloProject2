// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Spectre.Console;

namespace Shkolo.Presentation.Shell;

/// <summary>"?" – every key of the command centre plus the hotkeys of the active section.</summary>
public static class HelpOverlay
{
    private static readonly (string Key, string Meaning)[] Global =
    [
        ("1 – 9", "Отваряне на раздел"),
        ("Tab / Shift+Tab", "Следващ / предишен раздел"),
        ("↑ ↓", "В лявото меню: смяна на раздела"),
        ("→ / Enter", "От менюто към действията на раздела"),
        ("← → ↑ ↓", "В действията: избор на действие"),
        ("Enter", "В действията: изпълнение на избраното"),
        ("Esc / ←", "От действията обратно към менюто"),
        ("буква", "Бърз клавиш на действие (кирилица или латиница)"),
        ("/", "Командна палитра – търсене на хора, класове и действия"),
        ("?", "Тази помощ"),
        ("Esc (в менюто)", "Изход от профила (с потвърждение)"),
    ];

    public static void Show(ScreenContext ctx, ISection section)
    {
        var accent = RoleAccent.For(ctx.Services.Session.Role);
        var table = new Table().Border(TableBorder.Simple).BorderColor(accent).HideHeaders().AddColumn("").AddColumn("");
        foreach (var (key, meaning) in Global)
        {
            table.AddRow(new Markup($"[bold]{Ui.Escape(key)}[/]"), new Markup(Ui.Escape(meaning)));
        }

        foreach (var action in section.Actions.Where(a => a.Hotkey is not null))
        {
            table.AddRow(new Markup($"[bold {Gradient.Hex(accent)}]{action.Hotkey}[/]"), new Markup($"{Ui.Escape(action.Label)} {Ui.Muted("· " + section.Title)}"));
        }

        Ui.Clear(ctx.Console);
        ctx.Console.Write(new Panel(table).Header(" [bold]Помощ · клавиши[/] ").Border(BoxBorder.Double).BorderColor(accent).Padding(2, 1));
        ctx.Console.MarkupLine(Ui.Muted("Натиснете произволен клавиш…"));
        ctx.Console.Input.ReadKey(intercept: true);
    }
}
