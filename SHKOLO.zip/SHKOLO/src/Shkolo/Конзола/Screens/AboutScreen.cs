﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Screens;

/// <summary>Information about the project, architecture, team and the data file location.</summary>
public sealed class AboutScreen : IScreen
{
    public string Title => "За проекта";

    public ScreenResult Show(ScreenContext ctx)
    {
        var grid = new Grid().AddColumn(new GridColumn().NoWrap()).AddColumn();
        void Row(string key, string value) => grid.AddRow(new Markup(Ui.Muted(key)), new Markup(Ui.Escape(value)));

        Row("Продукт", ShkoloTheme.FullName);
        Row("Версия", ShkoloTheme.Version);
        Row("Технологии", "C# 13 · .NET 9 · System.Text.Json · Spectre.Console · xUnit");
        Row("Архитектура", "Domain → Application (services, права) → Infrastructure (JSON) / Presentation (конзола)");
        Row("Съхранение", "Локален JSON файл с атомарен запис, проверка на целостта и 5 автоматични архива");
        Row("Сигурност", "PBKDF2-SHA256 пароли · права проверявани във всеки service");
        Row("Файл с данни", ctx.DataFilePath);
        Row("Екип", "Участник 1 – Core · Участник 2 – Presentation · Участник 3 – Data");

        ctx.Console.Write(new Panel(grid)
            .Header($" [bold {ShkoloTheme.PrimaryHex}]{ShkoloTheme.Brand}[/] ")
            .Border(BoxBorder.Rounded)
            .BorderColor(ShkoloTheme.Primary)
            .Padding(2, 1));

        var tree = new Tree($"[bold {ShkoloTheme.PrimaryHex}]Слоеве на системата[/]").Guide(TreeGuide.Line);
        var presentation = tree.AddNode($"[{ShkoloTheme.AccentHex}]Presentation[/] {Ui.Muted("– команден център, анимации, инфографики")}");
        presentation.AddNode(Ui.Muted("Shell · Workspaces · Design · Motion · Screens"));
        var application = tree.AddNode($"[{ShkoloTheme.AccentHex}]Application[/] {Ui.Muted("– services, права, отчети")}");
        application.AddNode($"[{ShkoloTheme.AccentHex}]Domain[/] {Ui.Muted("– ученици, класове, оценки, отсъствия")}");
        tree.AddNode($"[{ShkoloTheme.AccentHex}]Infrastructure[/] {Ui.Muted("– JSON, архиви, PBKDF2, CSV")}");
        ctx.Console.WriteLine();
        ctx.Console.Write(tree);
        ctx.Console.WriteLine();
        ctx.Console.MarkupLine(Ui.Muted("Всички данни в демонстрационната база са измислени."));
        ctx.Console.MarkupLine(Ui.Muted("SHKOLO е учебен проект и не е свързан с търговската платформа Shkolo."));
        ctx.Notifier.Pause();
        return ScreenResult.Back;
    }
}
