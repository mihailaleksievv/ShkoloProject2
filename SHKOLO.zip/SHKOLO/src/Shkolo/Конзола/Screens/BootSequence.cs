﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Abstractions;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Motion;
using Shkolo.Presentation.Theme;
using Spectre.Console;
using Spectre.Console.Rendering;

namespace Shkolo.Presentation.Screens;

/// <summary>
/// Start-up intro: the logo builds up while the real loading steps tick off one by one
/// (data, integrity, school year with live counts). With motion off it prints the final frame once.
/// </summary>
public static class BootSequence
{
    private static readonly TimeSpan Duration = TimeSpan.FromMilliseconds(1400);

    public static void Run(IAnsiConsole console, Animator animator, LoadResult load)
    {
        var steps = Steps(load);
        Ui.Clear(console);
        animator.Play(console, Duration, p => Frame(steps, p));
    }

    private sealed record Step(string Glyph, Color Color, string Label, string Detail);

    private static List<Step> Steps(LoadResult load)
    {
        var db = load.Database;
        if (db is null)
        {
            return [new Step(Glyphs.Fail, ShkoloTheme.Error, "Зареждане на данните", load.Message ?? "файлът не може да бъде прочетен")];
        }

        var loaded = load.Status == LoadStatus.CreatedNew ? "създадена нова демо база" : "school-data.json";
        var integrity = load.IntegrityIssues.Count == 0
            ? new Step(Glyphs.Done, ShkoloTheme.Success, "Проверка на целостта", "без проблеми")
            : new Step(Glyphs.Warn, ShkoloTheme.Warning, "Проверка на целостта", $"{load.IntegrityIssues.Count} проблема");
        return
        [
            new Step(Glyphs.Done, ShkoloTheme.Success, "Зареждане на данните", loaded),
            integrity,
            new Step(Glyphs.Done, ShkoloTheme.Success, "Училището е готово",
                $"{db.Students.Count} ученици · {db.Teachers.Count} учители · {db.Classes.Count} класа"),
        ];
    }

    private static IRenderable Frame(IReadOnlyList<Step> steps, double p)
    {
        var rows = new List<IRenderable>
        {
            Text.Empty,
            Align.Center(Logo.Render(Math.Min(1, p / 0.45))),
            Text.Empty,
        };

        // Steps tick in during the second half; each shows "○ …" first, then its result.
        var lines = new List<IRenderable>();
        for (var i = 0; i < steps.Count; i++)
        {
            var start = 0.35 + (i * 0.18);
            if (p < start)
            {
                break;
            }

            var done = p >= start + 0.12;
            var step = steps[i];
            var glyph = done ? $"[{Gradient.Hex(step.Color)}]{step.Glyph}[/]" : Ui.Muted(Glyphs.Pending);
            var detail = done ? "  " + Ui.Muted(step.Detail) : Ui.Muted(" …");
            lines.Add(new Markup($"{glyph} {Ui.Escape(step.Label)}{detail}"));
        }

        if (lines.Count > 0)
        {
            rows.Add(Align.Center(new Rows(lines)));
        }

        if (p >= 1)
        {
            rows.Add(Text.Empty);
            rows.Add(Align.Center(new Markup(Gradient.Text(ShkoloTheme.SloganBg, ShkoloTheme.Primary, ShkoloTheme.Accent))));
        }

        return new Rows(rows);
    }
}
