﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Shkolo.Presentation.Workspaces;
using Shkolo.Application;
using Spectre.Console.Rendering;
using Spectre.Console;

namespace Shkolo.Presentation.Screens;

/// <summary>Start screen for small windows: logo, school card, menu (login, about, exit).</summary>
public sealed class ClassicStartScreen : MenuScreen
{
    public override string Title => "Начало";

    protected override bool IsHome => true;

    protected override void RenderBody(ScreenContext ctx)
    {
        // Fastfetch-style hero: the logo and slogans on the left, a live school card on the right.
        var identity = new Rows(
            Logo.Render(),
            new Text(""),
            new Markup($"[bold {ShkoloTheme.AccentHex}]SCHOOL MANAGEMENT & INTELLIGENCE SYSTEM[/]"),
            new Markup(Gradient.Text(ShkoloTheme.SloganBg, ShkoloTheme.Lavender, ShkoloTheme.Accent)),
            new Markup(Ui.Muted(ShkoloTheme.Slogan)));

        var hero = new Grid().AddColumn(new GridColumn().PadRight(6)).AddColumn();
        hero.AddRow(identity, SchoolCard(ctx));

        ctx.Console.WriteLine();
        ctx.Console.Write(Align.Center(hero));
        ctx.Console.WriteLine();
        ctx.Console.Write(new Rule().RuleStyle(new Style(ShkoloTheme.Surface)));
        ctx.Console.Write(new Markup($"[bold]Добре дошли![/] {Ui.Muted("Влезте с потребителско име и парола · ↑↓ и Enter за избор")}").Centered());
    }

    /// <summary>The "fetch" card: key/value lines about the school, then a strip of the palette colours.</summary>
    private static IRenderable SchoolCard(ScreenContext ctx)
    {
        var services = ctx.Services;
        var overview = services.Reports.GetPublicOverview();
        var year = services.AcademicYears.GetActive();
        var today = services.Clock.Today;
        var term = WorkspaceKit.CurrentTerm(ctx);
        var progress = WorkspaceKit.TermProgress(ctx);

        var card = new Grid().AddColumn(new GridColumn().NoWrap().PadRight(2)).AddColumn(new GridColumn().NoWrap());
        void Row(string key, string valueMarkup) => card.AddRow(new Markup($"[bold {ShkoloTheme.PrimaryHex}]{Ui.Escape(key)}[/]"), new Markup(valueMarkup));

        card.AddRow(new Markup($"[bold {ShkoloTheme.LavenderHex}]SHKOLO[/]"), new Markup(Ui.Muted("версия " + ShkoloTheme.Version)));
        card.AddRow(new Markup($"[{ShkoloTheme.SurfaceHex}]──────────────[/]"), new Markup($"[{ShkoloTheme.SurfaceHex}]────────────────────────────[/]"));
        Row("Учебна година", year is null ? Ui.Muted("няма активна") : Ui.Escape(year.Name));
        if (term is { } t && progress is { } p && p.Total > 0)
        {
            var share = (decimal)p.Passed / p.Total;
            Row("Срок", $"{Ui.Escape(t.Name)}  {Meter.Markup(share, 1m, 14, ShkoloTheme.Primary, ShkoloTheme.Accent)} {Ui.Muted($"{share:P0}".Replace(" ", ""))}");
        }

        Row("Днес", Ui.Escape($"{BulgarianNames.Of(today.DayOfWeek).ToLower(BulgarianNames.Culture)}, {Ui.Date(today)}"));
        Row("Ученици", $"[bold]{overview.Students}[/]");
        Row("Учители", $"[bold]{overview.Teachers}[/]");
        Row("Класове", $"[bold]{overview.Classes}[/] {Ui.Muted($"· {overview.Subjects} предмета")}");
        Row("Данни", Ui.Escape(Path.GetFileName(ctx.DataFilePath)));
        Row("Терминал", Ui.Escape($"{ctx.Console.Profile.Width}×{ctx.Console.Profile.Height}"));
        card.AddEmptyRow();
        string[] palette = [ShkoloTheme.ErrorHex, ShkoloTheme.PeachHex, ShkoloTheme.WarningHex, ShkoloTheme.SuccessHex, ShkoloTheme.AccentHex, ShkoloTheme.PrimaryHex, ShkoloTheme.LavenderHex, ShkoloTheme.TextHex];
        card.AddRow(new Text(""), new Markup(string.Concat(palette.Select(h => $"[{h}]███[/]"))));
        return card;
    }

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Open("Вход", () => new LoginScreen());
        yield return MenuItem.Open("За проекта", () => new AboutScreen());
        yield return new MenuItem("Изход", _ => ScreenResult.Exit);
    }
}
