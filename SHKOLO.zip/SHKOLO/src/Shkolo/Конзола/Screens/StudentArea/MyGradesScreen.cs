// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;

namespace Shkolo.Presentation.Screens.StudentArea;

/// <summary>The student's own grades, grouped by subject like a paper gradebook, with filters.</summary>
public sealed class MyGradesScreen : MenuScreen
{
    private GradeFilter _filter = new();
    private string _filterLabel = "цялата година";

    public override string Title => "Моите оценки";

    protected override void RenderBody(ScreenContext ctx)
    {
        var studentId = ctx.Services.Session.StudentId!.Value;
        var grades = ctx.Services.Grades.GetGradesForStudent(studentId, _filter).Value ?? [];
        var bySubject = grades.GroupBy(g => g.SubjectName).OrderBy(g => g.Key, StringComparer.CurrentCulture)
            .Select(g => new SubjectRow(g.Key, g.OrderBy(x => x.Date).ToList()))
            .ToList();
        TableRenderer.Render(ctx.Console, $"Оценки по предмети · {_filterLabel}", bySubject,
            Col.Text<SubjectRow>("Предмет", r => r.Subject),
            Col.Markup<SubjectRow>("Оценки", r => string.Join(" ", r.Grades.Select(g => GradeFormatter.Markup(g.Value)))),
            Col.Markup<SubjectRow>("Среден успех", r => GradeFormatter.WithWord(r.Grades.Average(g => g.Value))));
    }

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.View("Подробен списък", c =>
            GradeTables.Recent(c.Console, c.Services.Grades.GetGradesForStudent(c.Services.Session.StudentId!.Value, _filter).Value ?? [], "Всички оценки"));
        yield return MenuItem.Do("Филтър по срок", c =>
        {
            var (chosen, term) = Pick.TermFilter(c);
            if (chosen)
            {
                _filter = _filter with { Term = term };
                _filterLabel = term is null ? "цялата година" : BulgarianNames.Of(term.Value);
            }
        });
        yield return MenuItem.Do("Филтър по вид оценяване", c =>
        {
            var type = Pick.GradeType(c);
            _filter = _filter with { Type = type };
            _filterLabel = type is { } t ? BulgarianNames.Of(t) : "всички видове";
        });
        yield return MenuItem.Do("Изчистване на филтрите", _ =>
        {
            _filter = new GradeFilter();
            _filterLabel = "цялата година";
        });
    }

    private sealed record SubjectRow(string Subject, IReadOnlyList<GradeView> Grades);
}
