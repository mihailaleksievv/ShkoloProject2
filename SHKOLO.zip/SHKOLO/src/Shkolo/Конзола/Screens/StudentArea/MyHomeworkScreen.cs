// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Screens.StudentArea;

/// <summary>The student's homework with statuses and text submission.</summary>
public sealed class MyHomeworkScreen : MenuScreen
{
    public override string Title => "Домашни работи";

    protected override void RenderBody(ScreenContext ctx)
        => TableRenderer.Render(ctx.Console, "Моите домашни", Mine(ctx),
            Col.Text<HomeworkView>("Срок", h => Ui.Date(h.DueDate)),
            Col.Text<HomeworkView>("Предмет", h => h.SubjectName),
            Col.Text<HomeworkView>("Заглавие", h => h.Title),
            Col.Text<HomeworkView>("Учител", h => h.TeacherName),
            Col.Markup<HomeworkView>("Статус", h => StudentReportScreen.HomeworkStatusMarkup(h.StatusForStudent)));

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Предаване на отговор", c =>
        {
            var hw = c.Picker.Pick("Изберете домашно", Mine(c), h => $"{Ui.Date(h.DueDate)} · {h.SubjectName} · {h.Title}");
            if (hw is null)
            {
                return;
            }

            c.Console.Write(new Panel(new Markup(Ui.Escape(hw.Description))).Header($" [bold]{Ui.Escape(hw.Title)}[/] ").BorderColor(ShkoloTheme.Accent));
            if (c.Input.ReadRequiredString("Вашият отговор", 2000) is { } answer)
            {
                c.Notifier.Show(c.Services.Homework.Submit(hw.Id, answer), "Отговорът е предаден.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.View("Описание на домашно", c =>
        {
            if (c.Picker.Pick("Изберете домашно", Mine(c), h => $"{Ui.Date(h.DueDate)} · {h.SubjectName} · {h.Title}") is { } hw)
            {
                c.Console.Write(new Panel(new Markup($"{Ui.Escape(hw.Description)}\n\n{Ui.Muted($"Възложено {Ui.Date(hw.AssignedDate)} · срок {Ui.Date(hw.DueDate)} · {hw.TeacherName}")}"))
                    .Header($" [bold]{Ui.Escape(hw.Title)}[/] ").BorderColor(ShkoloTheme.Accent));
            }
        });
    }

    private static IReadOnlyList<HomeworkView> Mine(ScreenContext ctx)
        => ctx.Services.Homework.GetHomeworkForStudent(ctx.Services.Session.StudentId!.Value).Value ?? [];
}
