// Owner: Participant 2 – Presentation Developer
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.AdminArea;
using Shkolo.Presentation.Screens.Shared;

namespace Shkolo.Presentation.Screens.StudentArea;

/// <summary>The student's own performance report (whole year or by term) and CSV export.</summary>
public sealed class MyPerformanceScreen : MenuScreen
{
    public override string Title => "Моят успех";

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        var studentId = ctx.Services.Session.StudentId!.Value;
        yield return MenuItem.Open("Справка за цялата година", () => new StudentReportScreen(studentId));
        yield return MenuItem.Open("Справка за I срок", () => new StudentReportScreen(studentId, Term.First));
        yield return MenuItem.Open("Справка за II срок", () => new StudentReportScreen(studentId, Term.Second));
        yield return MenuItem.Do("Експорт на справката (CSV)", c => StudentsScreen.Export(c, c.Services.Students.GetStudentById(studentId).Value));
    }
}
