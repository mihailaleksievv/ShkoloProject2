// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Theme;

namespace Shkolo.Presentation.Screens.TeacherArea;

/// <summary>Praises and remarks written by the teacher.</summary>
public sealed class FeedbackScreen : MenuScreen
{
    public override string Title => "Похвали и забележки";

    protected override void RenderBody(ScreenContext ctx)
        => TableRenderer.Render(ctx.Console, "Моите записи", ctx.Services.Feedback.GetByTeacher(ctx.Services.Session.TeacherId!.Value).Value ?? [],
            Col.Text<FeedbackView>("Дата", f => Ui.Date(f.Date)),
            Col.Text<FeedbackView>("Ученик", f => f.StudentName),
            Col.Markup<FeedbackView>("Вид", f => f.Type == FeedbackType.Praise ? $"[{ShkoloTheme.SuccessHex}]Похвала[/]" : $"[{ShkoloTheme.WarningHex}]Забележка[/]"),
            Col.Text<FeedbackView>("Текст", f => f.Description),
            Col.Text<FeedbackView>("Вижда се от ученика", f => f.IsVisibleToStudent ? "да" : "не"));

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Похвала", c => Add(c, FeedbackType.Praise));
        yield return MenuItem.Do("Забележка", c => Add(c, FeedbackType.Remark));
    }

    private static void Add(ScreenContext ctx, FeedbackType type)
    {
        var student = Pick.Student(ctx);
        var text = student is null ? null : ctx.Input.ReadRequiredString("Текст", 500);
        if (text is null)
        {
            return;
        }

        var visible = ctx.Input.ReadConfirmation("Да се вижда ли от ученика?");
        var date = ctx.Services.Clock.Today;
        var result = type == FeedbackType.Praise
            ? ctx.Services.Feedback.AddPraise(student!.Id, text, date, visible)
            : ctx.Services.Feedback.AddRemark(student!.Id, text, date, visible);
        ctx.Notifier.Show(result, "Записано.");
        ctx.Notifier.Pause();
    }
}
