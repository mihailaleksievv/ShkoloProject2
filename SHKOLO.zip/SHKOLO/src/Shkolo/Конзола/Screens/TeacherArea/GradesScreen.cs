// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;

namespace Shkolo.Presentation.Screens.TeacherArea;

/// <summary>Current grades: add, edit and delete own grades, class grade lists.</summary>
public sealed class GradesScreen : MenuScreen
{
    public override string Title => "Оценки";

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Нова оценка", Add);
        yield return MenuItem.View("Оценки на клас по предмет", c =>
        {
            if (Pick.MyAssignment(c) is { } a)
            {
                GradeTables.Recent(c.Console, c.Services.Grades.GetGradesForClass(a.ClassId, a.SubjectId).Value ?? [], $"{a.ClassName} · {a.SubjectName}");
            }
        });
        yield return MenuItem.Do("Редактиране на моя оценка", c =>
        {
            if (PickOwn(c) is { } g)
            {
                var value = c.Input.ReadDecimal($"Нова стойност (сега {GradeFormatterPlain(g.Value)})", 2m, 6m);
                var type = value is null ? null : Pick.GradeType(c);
                if (type is not null)
                {
                    c.Notifier.Show(c.Services.Grades.UpdateGrade(g.Id, new GradeUpdate(value!.Value, type.Value, c.Input.ReadOptionalString("Коментар", 200, g.Comment))), "Оценката е редактирана.");
                    c.Notifier.Pause();
                }
            }
        });
        yield return MenuItem.Do("Изтриване на моя оценка", c =>
        {
            if (PickOwn(c) is { } g && c.Input.ReadConfirmation($"Изтриване на {GradeFormatterPlain(g.Value)} на {g.StudentName}?", defaultValue: false))
            {
                c.Notifier.Show(c.Services.Grades.DeleteGrade(g.Id), "Оценката е изтрита.");
                c.Notifier.Pause();
            }
        });
    }

    private static string GradeFormatterPlain(decimal v) => Application.BulgarianNames.Grade(v);

    public static void Add(ScreenContext ctx)
    {
        var a = Pick.MyAssignment(ctx);
        var student = a is null ? null : Pick.Student(ctx, a.ClassId);
        var value = student is null ? null : ctx.Input.ReadDecimal("Оценка", 2m, 6m);
        var type = value is null ? null : Pick.GradeType(ctx);
        var date = type is null ? null : ctx.Input.ReadDate("Дата", ctx.Services.Clock.Today);
        if (date is null)
        {
            return;
        }

        var input = new GradeInput(student!.Id, a!.SubjectId, value!.Value, date.Value, type!.Value, ctx.Input.ReadOptionalString("Коментар", 200));
        ctx.Notifier.Show(ctx.Services.Grades.AddGrade(input), $"Оценката е поставена на {student.FullName}. Ученикът е известен.");
        ctx.Notifier.Pause();
    }

    private static GradeView? PickOwn(ScreenContext ctx)
    {
        var a = Pick.MyAssignment(ctx);
        if (a is null)
        {
            return null;
        }

        var mine = (ctx.Services.Grades.GetGradesForClass(a.ClassId, a.SubjectId).Value ?? [])
            .Where(g => g.TeacherId == ctx.Services.Session.TeacherId).ToList();
        return ctx.Picker.Pick("Изберете оценка", mine, g => $"{Ui.Date(g.Date)} · {g.StudentName} · {GradeFormatterPlain(g.Value)} · {Application.BulgarianNames.Of(g.Type)}");
    }
}
