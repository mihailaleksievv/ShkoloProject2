// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.AdminArea;
using Shkolo.Presentation.Screens.Shared;
using Spectre.Console;

namespace Shkolo.Presentation.Screens.TeacherArea;

/// <summary>Classes the teacher teaches, their students and reports.</summary>
public sealed class MyClassesScreen : MenuScreen
{
    public override string Title => "Моите класове";

    protected override void RenderBody(ScreenContext ctx)
    {
        var assignments = ctx.Services.Assignments.GetForTeacher(ctx.Services.Session.TeacherId!.Value).Value ?? [];
        var classes = ctx.Services.Reports.GetTeacherDashboard().Value?.Classes ?? [];
        TableRenderer.Render(ctx.Console, "Преподавани класове", classes,
            Col.Text<ClassSize>("Клас", c => c.ClassName),
            Col.Text<ClassSize>("Ученици", c => Ui.Count(c.StudentCount), Justify.Right),
            Col.Text<ClassSize>("Предмети", c => string.Join(", ", assignments.Where(a => a.ClassId == c.ClassId).Select(a => a.SubjectName))),
            Col.Text<ClassSize>("Класен ръководител", c => ctx.Services.Authorization.IsClassTeacherOf(c.ClassId) ? "да" : ""));
    }

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.View("Ученици в клас", c =>
        {
            if (Pick.Class(c) is { } cls)
            {
                StudentsScreen.Render(c, $"Ученици в {cls.DisplayName}", c.Services.Students.GetStudentsByClass(cls.Id).Value ?? []);
            }
        });
        yield return new MenuItem("Справка за ученик", c => Pick.Student(c) is { } s ? ScreenResult.Push(new StudentReportScreen(s.Id)) : ScreenResult.Stay);
        yield return new MenuItem("Справка за клас", c => Pick.Class(c) is { } cls ? ScreenResult.Push(new ClassReportScreen(cls.Id)) : ScreenResult.Stay);
    }
}
