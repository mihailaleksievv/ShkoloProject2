// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;

namespace Shkolo.Presentation.Screens.TeacherArea;

/// <summary>Awarding achievement badges to students of taught classes.</summary>
public sealed class AwardAchievementScreen : MenuScreen
{
    public override string Title => "Отличия";

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Присъждане на отличие", c =>
        {
            var student = Pick.Student(c);
            var badge = student is null ? null : c.Picker.Pick("Отличие", c.Services.Achievements.GetCatalog(), b => $"{b.Symbol} {b.Name} – {b.Description}");
            if (badge is not null)
            {
                c.Notifier.Show(c.Services.Achievements.Award(student!.Id, badge.Id, c.Input.ReadOptionalString("Бележка", 200)), $"{student.FullName} получи „{badge.Name}“.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.View("Отличия на ученик", c =>
        {
            if (Pick.Student(c) is { } s)
            {
                TableRenderer.Render(c.Console, $"Отличия на {s.FullName}", c.Services.Achievements.GetForStudent(s.Id).Value ?? [],
                    Col.Text<AchievementView>("", a => a.Symbol),
                    Col.Text<AchievementView>("Отличие", a => a.Name),
                    Col.Text<AchievementView>("Дата", a => Ui.FromUtc(a.AssignedAtUtc)),
                    Col.Text<AchievementView>("От", a => a.TeacherName),
                    Col.Text<AchievementView>("Бележка", a => a.Note ?? ""));
            }
        });
    }
}
