// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Theme;

namespace Shkolo.Presentation.Screens.TeacherArea;

/// <summary>Attendance of taught classes; class teachers can excuse absences.</summary>
public sealed class AttendanceScreen : MenuScreen
{
    public override string Title => "Отсъствия";

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.View("Отсъствия и закъснения в клас", c =>
        {
            if (Pick.Class(c) is { } cls)
            {
                GradeTables.Attendance(c.Console, NotPresent(c, cls.Id), $"Отсъствия и закъснения в {cls.DisplayName}");
            }
        });
        yield return MenuItem.View("Обобщение за ученик", c =>
        {
            if (Pick.Student(c) is { } s && c.Services.Attendance.GetAttendanceSummary(s.Id).Value is { } sum)
            {
                c.Console.Write(StatPanel.Tiles(
                    ("Присъствия", $"[bold {ShkoloTheme.SuccessHex}]{sum.Present}[/]"),
                    ("Неизвинени", $"[bold {ShkoloTheme.ErrorHex}]{sum.Unexcused}[/]"),
                    ("Извинени", $"[bold {ShkoloTheme.WarningHex}]{sum.Excused}[/]"),
                    ("Закъснения", StatPanel.Number(sum.Late))));
                GradeTables.AttendanceChart(c.Console, sum);
            }
        });
        yield return MenuItem.Do("Извиняване на отсъствие", Excuse);
    }

    private static List<AttendanceView> NotPresent(ScreenContext ctx, Guid classId)
        => (ctx.Services.Attendance.GetAttendanceForClass(classId).Value ?? []).Where(a => a.Status != AttendanceStatus.Present).ToList();

    private static void Excuse(ScreenContext ctx)
    {
        var cls = Pick.Class(ctx);
        if (cls is null)
        {
            return;
        }

        var unexcused = NotPresent(ctx, cls.Id).Where(a => a.Status == AttendanceStatus.Absent).ToList();
        var record = ctx.Picker.Pick("Неизвинено отсъствие", unexcused, a => $"{a.StudentName} · {Ui.Date(a.Date)} · {a.LessonNumber}. час · {a.SubjectName}");
        if (record is not null)
        {
            var note = ctx.Input.ReadOptionalString("Основание (напр. медицинска бележка)", 200);
            ctx.Notifier.Show(ctx.Services.Attendance.UpdateAttendanceStatus(record.Id, AttendanceStatus.ExcusedAbsent, note), "Отсъствието е извинено.");
            ctx.Notifier.Pause();
        }
    }
}
