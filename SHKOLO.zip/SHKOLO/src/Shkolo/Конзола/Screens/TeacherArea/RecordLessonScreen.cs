// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Screens.TeacherArea;

/// <summary>
/// The core teacher workflow: choose the lesson (from today's programme or manually), write the topic,
/// mark only the exceptions in attendance, optionally give grades, review and save – as ONE atomic operation.
/// </summary>
public sealed class RecordLessonScreen : IScreen
{
    public string Title => "Провеждане на час";

    public ScreenResult Show(ScreenContext ctx)
    {
        var lesson = ChooseLesson(ctx);
        if (lesson is null)
        {
            return ScreenResult.Back;
        }

        var (input, entryId, className) = lesson.Value;
        StatPanel.Section(ctx.Console, $"{className} · {ctx.Services.Subjects.GetById(input.SubjectId).Value?.Name} · {Ui.Date(input.Date)} · {input.LessonNumber}. час");

        var topic = ctx.Input.ReadRequiredString("Тема на урока", 200);
        if (topic is null)
        {
            return ScreenResult.Back;
        }

        var notes = ctx.Input.ReadOptionalString("Бележка към часа", 500);
        var students = ctx.Services.Students.GetStudentsByClass(input.ClassId).Value ?? [];
        var marks = ReadAttendance(ctx, students);
        var grades = ReadGrades(ctx, students, marks);

        RenderSummary(ctx, students, marks, grades, topic);
        if (!ctx.Input.ReadConfirmation("Записване на часа?"))
        {
            ctx.Notifier.Warning("Часът не е записан.");
            ctx.Notifier.Pause();
            return ScreenResult.Back;
        }

        var result = ctx.Services.LessonWorkflow.RecordLesson(new LessonRecordRequest(input with { Topic = topic, Notes = notes }, entryId, marks, grades));
        if (ctx.Notifier.Show(result, "Часът е записан."))
        {
            var s = result.Value!;
            ctx.Notifier.Info($"Присъстващи: {s.Present} · Отсъстващи: {s.Absent} · Закъснели: {s.Late} · Оценки: {s.GradesAdded}");
        }

        ctx.Notifier.Pause();
        return ScreenResult.Back;
    }

    private static (LessonInput Input, Guid? EntryId, string ClassName)? ChooseLesson(ScreenContext ctx)
    {
        var dashboard = ctx.Services.Reports.GetTeacherDashboard().Value;
        var today = ctx.Services.Clock.Today;
        var options = (dashboard?.Today ?? [])
            .Select(r => (Row: (TimetableRow?)r, Label: $"{r.LessonNumber}. час {Ui.Time(r.Start)} · {r.SubjectName} · {r.ClassName}"
                                                       + (dashboard!.TodayRecordedEntryIds.Contains(r.EntryId) ? " · ✔ записан" : "")))
            .ToList();
        options.Add((null, "Друг час (избор на клас, предмет и дата)"));

        var index = ctx.Picker.PickValue("Кой час провеждате?", options.Select((o, i) => (i, o.Label)).ToList());
        if (index is null)
        {
            return null;
        }

        if (options[index.Value].Row is { } row)
        {
            if (dashboard!.TodayRecordedEntryIds.Contains(row.EntryId))
            {
                ctx.Notifier.Warning("Този час вече е записан. Промени правете от „История на часовете“.");
                ctx.Notifier.Pause();
                return null;
            }

            return (new LessonInput(row.ClassId, row.SubjectId, today, row.LessonNumber, "", null), row.EntryId, row.ClassName);
        }

        var assignment = Pick.MyAssignment(ctx);
        var date = assignment is null ? null : ctx.Input.ReadDate("Дата на часа", today);
        var slot = date is null ? null : ctx.Picker.Pick("Номер на часа", ctx.Services.BellSchedule.GetSlots(), s => $"{s.LessonNumber}. час · {Ui.Time(s.StartTime)}–{Ui.Time(s.EndTime)}");
        return slot is null ? null : (new LessonInput(assignment!.ClassId, assignment.SubjectId, date!.Value, slot.LessonNumber, "", null), null, assignment.ClassName);
    }

    private static List<AttendanceMark> ReadAttendance(ScreenContext ctx, IReadOnlyList<Student> students)
    {
        var marks = new List<AttendanceMark>();
        if (students.Count == 0)
        {
            return marks;
        }

        var absent = ctx.Console.Prompt(new MultiSelectionPrompt<Student>()
            .Title($"[bold]Присъствие[/] {Ui.Muted("– всички са отбелязани като присъстващи. Изберете само отсъстващите и закъснелите (интервал), после Enter.")}")
            .NotRequired()
            .PageSize(15)
            .HighlightStyle(new Style(ShkoloTheme.Background, ShkoloTheme.Accent))
            .UseConverter(s => Ui.Escape($"{s.FullName} · №{s.StudentNumber}"))
            .AddChoices(students));

        foreach (var student in absent)
        {
            var status = ctx.Picker.PickValue($"Статус на {student.FullName}",
            [
                (AttendanceStatus.Absent, "Неизвинено отсъствие"),
                (AttendanceStatus.ExcusedAbsent, "Извинено отсъствие"),
                (AttendanceStatus.Late, "Закъснение"),
            ]) ?? AttendanceStatus.Absent;
            marks.Add(new AttendanceMark(student.Id, status, null));
        }

        return marks;
    }

    private static List<LessonGradeInput> ReadGrades(ScreenContext ctx, IReadOnlyList<Student> students, List<AttendanceMark> marks)
    {
        var grades = new List<LessonGradeInput>();
        var absentIds = marks.Where(m => m.Status is AttendanceStatus.Absent or AttendanceStatus.ExcusedAbsent).Select(m => m.StudentId).ToHashSet();
        var present = students.Where(s => !absentIds.Contains(s.Id)).ToList();

        while (ctx.Input.ReadConfirmation(grades.Count == 0 ? "Добавяне на оценки в този час?" : "Още оценка?", defaultValue: false))
        {
            var student = ctx.Picker.Pick("Ученик", present, s => $"{s.FullName} · №{s.StudentNumber}");
            var value = student is null ? null : ctx.Input.ReadDecimal("Оценка", 2m, 6m);
            var type = value is null ? null : Pick.GradeType(ctx);
            if (type is null)
            {
                continue;
            }

            grades.Add(new LessonGradeInput(student!.Id, value!.Value, type.Value, ctx.Input.ReadOptionalString("Коментар", 200)));
        }

        return grades;
    }

    private static void RenderSummary(ScreenContext ctx, IReadOnlyList<Student> students, List<AttendanceMark> marks, List<LessonGradeInput> grades, string topic)
    {
        var names = students.ToDictionary(s => s.Id, s => s.FullName);
        StatPanel.Section(ctx.Console, "Обобщение");
        ctx.Console.MarkupLine($"Тема: [bold]{Ui.Escape(topic)}[/]");
        ctx.Console.MarkupLine($"Присъстващи: [bold {ShkoloTheme.SuccessHex}]{students.Count - marks.Count(m => m.Status != AttendanceStatus.Late)}[/] от {students.Count}");
        foreach (var m in marks)
        {
            ctx.Console.MarkupLine($"  {GradeTables.StatusMarkup(m.Status)} {Ui.Escape(names.GetValueOrDefault(m.StudentId, "—"))}");
        }

        foreach (var g in grades)
        {
            ctx.Console.MarkupLine($"  {GradeFormatter.Markup(g.Value)} {Ui.Escape(names.GetValueOrDefault(g.StudentId, "—"))} {Ui.Muted(BulgarianNames.Of(g.Type))}");
        }
    }
}
