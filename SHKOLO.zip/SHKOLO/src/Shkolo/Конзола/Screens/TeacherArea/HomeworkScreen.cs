// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;

namespace Shkolo.Presentation.Screens.TeacherArea;

/// <summary>Homework management for teachers, including submission overview.</summary>
public sealed class HomeworkScreen : MenuScreen
{
    public override string Title => "Домашни работи";

    protected override void RenderBody(ScreenContext ctx)
    {
        Render(ctx, "Предстоящи", ctx.Services.Homework.GetUpcomingHomework());
        Render(ctx, "С изтекъл срок", ctx.Services.Homework.GetOverdueHomework());
    }

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Ново домашно", c => Save(c, null));
        yield return MenuItem.Do("Редактиране", c =>
        {
            if (PickMine(c) is { } h)
            {
                Save(c, h);
            }
        });
        yield return MenuItem.View("Предадени отговори", c =>
        {
            if (PickMine(c) is { } h && c.Services.Homework.GetSubmissions(h.Id).Value is { } rows)
            {
                TableRenderer.Render(c.Console, $"{h.Title} · {h.ClassName} · срок {Ui.Date(h.DueDate)}", rows,
                    Col.Text<SubmissionView>("Ученик", r => r.StudentName),
                    Col.Markup<SubmissionView>("Статус", r => StudentReportScreen.HomeworkStatusMarkup(r.Status)),
                    Col.Text<SubmissionView>("Предадено", r => r.SubmittedAtUtc is { } t ? Ui.FromUtc(t) : "—"),
                    Col.Text<SubmissionView>("Отговор", r => r.Content ?? ""));
            }
        });
        yield return MenuItem.Do("Архивиране", c =>
        {
            if (PickMine(c) is { } h && c.Input.ReadConfirmation($"Архивиране на „{h.Title}“?"))
            {
                c.Notifier.Show(c.Services.Homework.ArchiveHomework(h.Id), "Домашното е архивирано.");
                c.Notifier.Pause();
            }
        });
    }

    public static void Render(ScreenContext ctx, string title, IReadOnlyList<HomeworkView> items)
        => TableRenderer.Render(ctx.Console, title, items,
            Col.Text<HomeworkView>("Срок", h => Ui.Date(h.DueDate)),
            Col.Text<HomeworkView>("Клас", h => h.ClassName),
            Col.Text<HomeworkView>("Предмет", h => h.SubjectName),
            Col.Text<HomeworkView>("Заглавие", h => h.Title),
            Col.Text<HomeworkView>("Предадени", h => $"{h.SubmissionCount}/{h.ClassSize}", Spectre.Console.Justify.Right));

    private static HomeworkView? PickMine(ScreenContext ctx)
        => ctx.Picker.Pick("Изберете домашно", ctx.Services.Homework.GetUpcomingHomework().Concat(ctx.Services.Homework.GetOverdueHomework()).ToList(),
            h => $"{Ui.Date(h.DueDate)} · {h.ClassName} · {h.Title}");

    private static void Save(ScreenContext ctx, HomeworkView? current)
    {
        var a = current is null ? Pick.MyAssignment(ctx) : null;
        var classId = current?.ClassId ?? a?.ClassId;
        var subjectId = current?.SubjectId ?? a?.SubjectId;
        if (classId is null || subjectId is null)
        {
            return;
        }

        var title = ctx.Input.ReadRequiredString("Заглавие", 120, current?.Title);
        var description = title is null ? null : ctx.Input.ReadOptionalString("Описание", 1000) ?? current?.Description ?? "";
        var assigned = description is null ? null : ctx.Input.ReadDate("Дата на възлагане", current?.AssignedDate ?? ctx.Services.Clock.Today);
        var due = assigned is null ? null : ctx.Input.ReadDate("Срок", current?.DueDate ?? assigned.Value.AddDays(7));
        if (due is null)
        {
            return;
        }

        var input = new HomeworkInput(classId.Value, subjectId.Value, title!, description!, assigned!.Value, due.Value);
        var result = current is null ? ctx.Services.Homework.CreateHomework(input) : ctx.Services.Homework.UpdateHomework(current.Id, input);
        ctx.Notifier.Show(result, current is null ? "Домашното е създадено; учениците са известени." : "Домашното е редактирано.");
        ctx.Notifier.Pause();
    }
}
