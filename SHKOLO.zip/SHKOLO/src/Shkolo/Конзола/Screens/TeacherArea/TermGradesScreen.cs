// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;

namespace Shkolo.Presentation.Screens.TeacherArea;

/// <summary>Term and annual grades: sheet with current average and suggested value; the teacher decides.</summary>
public sealed class TermGradesScreen : IScreen
{
    public string Title => "Срочни и годишни оценки";

    public ScreenResult Show(ScreenContext ctx)
    {
        var a = Pick.MyAssignment(ctx);
        var period = a is null ? null : Pick.Period(ctx);
        if (period is null)
        {
            return ScreenResult.Back;
        }

        while (true)
        {
            var sheet = ctx.Services.TermGrades.GetTermGradeSheet(a!.ClassId, a.SubjectId, period.Value);
            if (!sheet.Success)
            {
                ctx.Notifier.Error(sheet.Error!.Message);
                ctx.Notifier.Pause();
                return ScreenResult.Back;
            }

            Render(ctx, $"{a.ClassName} · {a.SubjectName} · {BulgarianNames.Of(period.Value)}", sheet.Value!);
            var row = ctx.Picker.Pick("Поставяне на оценка (← Назад за край)", sheet.Value!,
                r => $"{r.StudentName} · предложение {(r.Suggested?.ToString() ?? "—")}{(r.Assigned is { } v ? $" · поставена {v}" : "")}");
            if (row is null)
            {
                return ScreenResult.Back;
            }

            // No default value: an official grade (and the student's notification) must never come from a stray Enter.
            var hint = row.Suggested is { } s ? $" (предложение: {s})" : "";
            var value = ctx.Input.ReadInt($"Оценка за {row.StudentName}{hint}", 2, 6);
            if (value is not null)
            {
                ctx.Notifier.Show(ctx.Services.TermGrades.SetTermGrade(row.StudentId, a.SubjectId, period.Value, value.Value), "Оценката е поставена.");
            }
        }
    }

    private static void Render(ScreenContext ctx, string title, IReadOnlyList<TermGradeRow> rows)
        => TableRenderer.Render(ctx.Console, title, rows,
            Col.Text<TermGradeRow>("Ученик", r => r.StudentName),
            Col.Markup<TermGradeRow>("Текущ успех", r => GradeFormatter.Markup(r.CurrentAverage)),
            Col.Markup<TermGradeRow>("Предложение", r => GradeFormatter.TermGrade(r.Suggested)),
            Col.Markup<TermGradeRow>("Поставена", r => GradeFormatter.TermGrade(r.Assigned)));
}
