// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.AdminArea;
using Shkolo.Presentation.Screens.Shared;
using Spectre.Console;

namespace Shkolo.Presentation.Screens.TeacherArea;

/// <summary>Reports available to a teacher (restricted to taught classes by the services).</summary>
public sealed class TeacherReportsScreen : MenuScreen
{
    public override string Title => "Справки";

    protected override void RenderBody(ScreenContext ctx)
    {
        if (ctx.Services.Reports.GenerateTeacherReport(ctx.Services.Session.TeacherId!.Value).Value is { } r)
        {
            ctx.Console.Write(StatPanel.Tiles(
                ("Проведени часове", StatPanel.Number(r.LessonsHeld)),
                ("Поставени оценки", StatPanel.Number(r.GradesGiven)),
                ("Активни домашни", StatPanel.Number(r.ActiveHomework))));
            ctx.Console.MarkupLine(Ui.Muted("Класове: ") + Ui.Escape(string.Join(", ", r.Classes)) + Ui.Muted("  ·  Предмети: ") + Ui.Escape(string.Join(", ", r.Subjects)));
        }
    }

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return new MenuItem("Справка за ученик", c => Pick.Student(c) is { } s ? ScreenResult.Push(new StudentReportScreen(s.Id)) : ScreenResult.Stay);
        yield return new MenuItem("Справка за клас", c => Pick.Class(c) is { } cls ? ScreenResult.Push(new ClassReportScreen(cls.Id)) : ScreenResult.Stay);
        yield return MenuItem.Open("Статистика за моите класове", () => new SchoolStatisticsScreen());
        yield return MenuItem.Do("Експорт на справка за ученик (CSV)", c => StudentsScreen.Export(c, Pick.Student(c)));
        yield return MenuItem.Do("Експорт на справка за клас (CSV)", c =>
        {
            if (Pick.Class(c) is { } cls)
            {
                var result = c.Services.Export.ExportClassReport(cls.Id);
                c.Notifier.Show(result, $"Справката е записана: {result.Value}");
                c.Notifier.Pause();
            }
        });
    }
}
