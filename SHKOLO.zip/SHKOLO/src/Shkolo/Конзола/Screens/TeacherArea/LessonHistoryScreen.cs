// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;

namespace Shkolo.Presentation.Screens.TeacherArea;

/// <summary>Held lessons: search, edit topic and notes, cancel, correct attendance.</summary>
public sealed class LessonHistoryScreen : MenuScreen
{
    public override string Title => "История на часовете";

    protected override void RenderBody(ScreenContext ctx)
        => GradeTables.Lessons(ctx.Console, MyLessons(ctx).Take(15).ToList(), "Последни 15 часа");

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.View("Търсене на часове (клас и период)", c =>
        {
            var cls = Pick.Class(c);
            var from = cls is null ? null : c.Input.ReadDate("От дата", c.Services.Clock.Today.AddDays(-14));
            var to = from is null ? null : c.Input.ReadDate("До дата", c.Services.Clock.Today);
            if (to is not null)
            {
                GradeTables.Lessons(c.Console, c.Services.Lessons.Search(new LessonFilter(ClassId: cls!.Id, From: from, To: to)).Value ?? []);
            }
        });
        yield return MenuItem.Do("Промяна на тема", c =>
        {
            if (PickLesson(c) is { } l && c.Input.ReadRequiredString("Тема", 200, l.Topic) is { } topic)
            {
                c.Notifier.Show(c.Services.Lessons.UpdateLessonTopic(l.Id, topic), "Темата е обновена.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.Do("Бележка към час", c =>
        {
            if (PickLesson(c) is { } l)
            {
                c.Notifier.Show(c.Services.Lessons.UpdateNotes(l.Id, c.Input.ReadOptionalString("Бележка", 500)), "Бележката е записана.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.Do("Корекция на присъствие", Correct);
        yield return MenuItem.Do("Отмяна на час", c =>
        {
            if (PickLesson(c) is { } l && c.Input.ReadConfirmation("Отмяна на часа?", defaultValue: false))
            {
                c.Notifier.Show(c.Services.Lessons.CancelLesson(l.Id), "Часът е отбелязан като отменен.");
                c.Notifier.Pause();
            }
        });
    }

    private static IEnumerable<LessonView> MyLessons(ScreenContext ctx)
        => ctx.Services.Lessons.GetLessonsForTeacher(ctx.Services.Session.TeacherId!.Value).Value ?? [];

    private static LessonView? PickLesson(ScreenContext ctx)
        => ctx.Picker.Pick("Изберете час", MyLessons(ctx).Where(l => l.Status == LessonStatus.Held).Take(60).ToList(),
            l => $"{Ui.Date(l.Date)} · {l.LessonNumber}. час · {l.ClassName} · {l.SubjectName} · {l.Topic}");

    private static void Correct(ScreenContext ctx)
    {
        var lesson = PickLesson(ctx);
        if (lesson is null)
        {
            return;
        }

        var records = (ctx.Services.Attendance.GetAttendanceForClass(lesson.ClassId).Value ?? []).Where(a => a.LessonId == lesson.Id).ToList();
        var record = ctx.Picker.Pick("Ученик", records, a => $"{a.StudentName} · {Application.BulgarianNames.Of(a.Status)}");
        var status = record is null ? null : ctx.Picker.PickValue("Нов статус", Enum.GetValues<AttendanceStatus>().Select(s => (s, Application.BulgarianNames.Of(s))).ToList());
        if (status is not null)
        {
            ctx.Notifier.Show(ctx.Services.Attendance.UpdateAttendanceStatus(record!.Id, status.Value, ctx.Input.ReadOptionalString("Бележка", 200)), "Записът е коригиран.");
            ctx.Notifier.Pause();
        }
    }
}
