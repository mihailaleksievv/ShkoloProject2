﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Design;
using Spectre.Console;

namespace Shkolo.Presentation.Screens;

/// <summary>
/// Shared stage of the start and login screens: a full-window sky picture with the SHKOLO wordmark,
/// the colours of the buttons and the card, and the size check that falls back to the classic screens.
/// </summary>
public static class SkyScene
{
    public const int MinWidth = 100;
    public const int MinHeight = 30;

    public static readonly Color White = new(255, 255, 255);
    public static readonly Color Ink = new(28, 62, 104);
    public static readonly Color SoftInk = new(78, 108, 138);
    public static readonly Color ButtonIdle = new(232, 241, 250);
    public static readonly Color Card = new(123, 170, 203);
    public static readonly Color CardDark = new(92, 149, 190);
    public static readonly Color Teal = new(69, 181, 174);
    public static readonly Color Placeholder = new(160, 168, 178);
    public static readonly Color Warning = new(255, 228, 160);
    public static readonly Color Band = new(34, 92, 158);
    public static readonly Color BandText = new(196, 222, 246);

    private static readonly System.Collections.Concurrent.ConcurrentDictionary<(int W, int H, double Darken, int LogoTop), Color[,]> Cache = new();

    /// <summary>True when the window is large enough for the picture; otherwise the classic screens are used.</summary>
    public static bool Fits(IAnsiConsole console) => console.Profile.Width >= MinWidth && console.Profile.Height >= MinHeight;

    /// <summary>Rows available for the picture (one less than the window, so the terminal never scrolls).</summary>
    public static int Rows(IAnsiConsole console) => console.Profile.Height - 1;

    /// <summary>The sky with the wordmark at pixel row <paramref name="logoTop"/>; cached per size.</summary>
    public static Color[,] Background(IAnsiConsole console, double darken, int logoTop, double reveal = 1)
    {
        var w = console.Profile.Width;
        var h = Rows(console) * 2;
        var key = (w, h, darken, logoTop);
        if (reveal >= 1 && Cache.TryGetValue(key, out var cached))
        {
            return cached;
        }

        var pixels = SkyPainter.Paint(w, h, darken, reveal);
        BlockLogo.Draw(pixels, w / 2, logoTop, White);
        if (reveal >= 1)
        {
            Cache[key] = pixels;
        }

        return pixels;
    }

    /// <summary>Waits for one key (the scripted test console never returns null; a real one may while idle).</summary>
    public static ConsoleKeyInfo ReadKey(IAnsiConsole console)
    {
        while (true)
        {
            if (console.Input.ReadKey(intercept: true) is { } key)
            {
                return key;
            }
        }
    }
}
