// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Requests;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Theme;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Classes, class teachers, class lists and class reports.</summary>
public sealed class ClassesScreen : MenuScreen
{
    public override string Title => "Класове";

    protected override void RenderBody(ScreenContext ctx)
    {
        var teachers = (ctx.Services.Teachers.GetAll(includeInactive: true).Value ?? []).ToDictionary(t => t.Id, t => t.FullName);
        var years = ctx.Services.AcademicYears.GetAll().ToDictionary(y => y.Id, y => y.Name);
        TableRenderer.Render(ctx.Console, "Класове и паралелки", ctx.Services.Classes.GetAll(includeInactive: true),
            Col.Text<SchoolClass>("Клас", c => c.DisplayName),
            Col.Text<SchoolClass>("Учебна година", c => years.GetValueOrDefault(c.AcademicYearId, "—")),
            Col.Text<SchoolClass>("Класен ръководител", c => c.ClassTeacherId is { } t ? teachers.GetValueOrDefault(t, "—") : "—"),
            Col.Text<SchoolClass>("Ученици", c => Ui.Count(ctx.Services.Students.GetStudentsByClass(c.Id).Value?.Count ?? 0), Spectre.Console.Justify.Right),
            Col.Markup<SchoolClass>("Статус", c => c.IsActive ? $"[{ShkoloTheme.SuccessHex}]активен[/]" : Ui.Muted("неактивен")));
    }

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Създаване на паралелка", Create);
        yield return MenuItem.Do("Редактиране", Edit);
        yield return MenuItem.Do("Назначаване на класен ръководител", AssignClassTeacher);
        yield return MenuItem.View("Ученици в клас", c =>
        {
            if (Pick.Class(c) is { } cls)
            {
                StudentsScreen.Render(c, $"Ученици в {cls.DisplayName}", c.Services.Students.GetStudentsByClass(cls.Id, includeInactive: true).Value ?? []);
            }
        });
        yield return new MenuItem("Справка за клас", c => Pick.Class(c) is { } cls ? ScreenResult.Push(new ClassReportScreen(cls.Id)) : ScreenResult.Stay);
        yield return MenuItem.Do("Експорт на справка за клас (CSV)", c =>
        {
            if (Pick.Class(c) is { } cls)
            {
                var result = c.Services.Export.ExportClassReport(cls.Id);
                c.Notifier.Show(result, $"Справката е записана: {result.Value}");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.Do("Деактивиране", Deactivate);
    }

    private static void Create(ScreenContext ctx)
    {
        var year = ctx.Services.AcademicYears.GetActive();
        if (year is null)
        {
            ctx.Notifier.Error("Първо създайте и активирайте учебна година.");
            ctx.Notifier.Pause();
            return;
        }

        var grade = ctx.Input.ReadInt("Клас (випуск)", 1, 12);
        var section = grade is null ? null : ctx.Input.ReadRequiredString("Паралелка (напр. А)", 3);
        if (section is null)
        {
            return;
        }

        Guid? classTeacher = ctx.Input.ReadConfirmation("Да се назначи ли класен ръководител?") ? Pick.Teacher(ctx)?.Id : null;
        ctx.Notifier.Show(ctx.Services.Classes.Create(new ClassInput(grade!.Value, section, year.Id, classTeacher)), $"Паралелката {grade}{section.ToUpperInvariant()} е създадена за {year.Name}.");
        ctx.Notifier.Pause();
    }

    private static void Edit(ScreenContext ctx)
    {
        var cls = Pick.Class(ctx, includeInactive: true);
        if (cls is null)
        {
            return;
        }

        var grade = ctx.Input.ReadInt("Клас (випуск)", 1, 12, cls.GradeLevel)!.Value;
        var section = ctx.Input.ReadRequiredString("Паралелка", 3, cls.Section)!;
        ctx.Notifier.Show(ctx.Services.Classes.Update(cls.Id, new ClassInput(grade, section, cls.AcademicYearId, cls.ClassTeacherId)), "Класът е обновен.");
        ctx.Notifier.Pause();
    }

    private static void AssignClassTeacher(ScreenContext ctx)
    {
        var cls = Pick.Class(ctx);
        var teacher = cls is null ? null : Pick.Teacher(ctx, title: "Изберете класен ръководител");
        if (cls is not null && teacher is not null)
        {
            ctx.Notifier.Show(ctx.Services.Classes.AssignClassTeacher(cls.Id, teacher.Id), $"{teacher.FullName} е класен ръководител на {cls.DisplayName}.");
            ctx.Notifier.Pause();
        }
    }

    private static void Deactivate(ScreenContext ctx)
    {
        var cls = Pick.Class(ctx);
        if (cls is not null && ctx.Input.ReadConfirmation($"Деактивиране на {cls.DisplayName}?", defaultValue: false))
        {
            ctx.Notifier.Show(ctx.Services.Classes.Deactivate(cls.Id), "Класът е деактивиран.");
            ctx.Notifier.Pause();
        }
    }
}
