// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Abstractions;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Technical information about the data file and restore from backup.</summary>
public sealed class SystemScreen : MenuScreen
{
    public override string Title => "Системна информация";

    protected override void RenderBody(ScreenContext ctx)
    {
        var result = ctx.Services.System.GetStorageInfo();
        if (!result.Success)
        {
            ctx.Notifier.Error(result.Error!.Message);
            return;
        }

        var info = result.Value!;
        var grid = new Grid().AddColumn(new GridColumn().NoWrap()).AddColumn();
        grid.AddRow(new Markup(Ui.Muted("Файл с данни")), new Markup(Ui.Escape(info.DataFilePath)));
        grid.AddRow(new Markup(Ui.Muted("Размер")), new Markup(Ui.Escape($"{info.SizeBytes / 1024.0:0.0} KB")));
        grid.AddRow(new Markup(Ui.Muted("Последен запис")), new Markup(Ui.Escape(Ui.FromUtc(info.LastSavedAtUtc))));
        grid.AddRow(new Markup(Ui.Muted("Режим")), new Markup(info.IsReadOnly ? $"[{ShkoloTheme.WarningHex}]само за четене[/]" : $"[{ShkoloTheme.SuccessHex}]нормален[/]"));
        ctx.Console.Write(new Panel(grid).Header(" [bold]Съхранение[/] ").Border(BoxBorder.Rounded).BorderColor(ShkoloTheme.Primary).Padding(2, 0));

        TableRenderer.Render(ctx.Console, "Архиви (най-новият първи, пазят се последните 5)", info.Backups,
            Col.Text<BackupInfo>("Създаден", b => Ui.FromUtc(b.CreatedAtUtc)),
            Col.Text<BackupInfo>("Файл", b => b.FileName),
            Col.Text<BackupInfo>("Размер", b => $"{b.SizeBytes / 1024.0:0.0} KB", Justify.Right));
    }

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return new MenuItem("Възстановяване от архив", c =>
        {
            var backups = c.Services.System.GetStorageInfo().Value?.Backups ?? [];
            var backup = c.Picker.Pick("Изберете архив", backups, b => $"{Ui.FromUtc(b.CreatedAtUtc)} · {b.FileName}");
            if (backup is null || !c.Input.ReadConfirmation("Текущите данни ще бъдат заменени с архива (текущите се архивират първо). Продължаване?", defaultValue: false))
            {
                return ScreenResult.Stay;
            }

            if (c.Notifier.Show(c.Services.System.RestoreBackup(backup.FileName), "Архивът е възстановен. Приложението ще зареди данните отново."))
            {
                c.Notifier.Pause();
                return ScreenResult.Exit;
            }

            c.Notifier.Pause();
            return ScreenResult.Stay;
        });
    }
}
