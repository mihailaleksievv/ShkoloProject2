// Owner: Participant 2 – Presentation Developer
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Catalog of achievement badges that teachers can award.</summary>
public sealed class BadgeCatalogScreen : MenuScreen
{
    public override string Title => "Отличия";

    protected override void RenderBody(ScreenContext ctx)
        => TableRenderer.Render(ctx.Console, "Каталог на отличията", ctx.Services.Achievements.GetCatalog(includeInactive: true),
            Col.Text<AchievementBadge>("", b => b.Symbol),
            Col.Text<AchievementBadge>("Отличие", b => b.Name),
            Col.Text<AchievementBadge>("Описание", b => b.Description));

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Ново отличие", c =>
        {
            var name = c.Input.ReadRequiredString("Наименование", 50);
            var description = name is null ? null : c.Input.ReadRequiredString("Описание", 200);
            var symbol = description is null ? null : c.Input.ReadRequiredString("Символ (напр. ★)", 4);
            if (symbol is not null)
            {
                c.Notifier.Show(c.Services.Achievements.AddBadge(name!, description!, symbol), $"Отличието „{name}“ е добавено.");
                c.Notifier.Pause();
            }
        });
    }
}
