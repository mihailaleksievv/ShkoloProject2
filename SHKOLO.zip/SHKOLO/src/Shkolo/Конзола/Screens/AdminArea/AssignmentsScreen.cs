// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Teacher assignments (teacher + class + subject) – the basis of every teacher permission.</summary>
public sealed class AssignmentsScreen : MenuScreen
{
    public override string Title => "Назначения";

    protected override void RenderBody(ScreenContext ctx)
        => Render(ctx, "Назначения на учители", ctx.Services.Assignments.GetAll().Value ?? []);

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Ново назначение", c =>
        {
            var teacher = Pick.Teacher(c);
            var cls = teacher is null ? null : Pick.Class(c);
            var subject = cls is null ? null : Pick.Subject(c);
            if (subject is not null)
            {
                c.Notifier.Show(c.Services.Assignments.Assign(teacher!.Id, cls!.Id, subject.Id), $"{teacher.FullName} преподава {subject.Name} в {cls.DisplayName}.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.Do("Премахване на назначение", c =>
        {
            var item = c.Picker.Pick("Изберете назначение", c.Services.Assignments.GetAll().Value ?? [], a => $"{a.ClassName} · {a.SubjectName} · {a.TeacherName}");
            if (item is not null && c.Input.ReadConfirmation("Премахване на назначението?", defaultValue: false))
            {
                c.Notifier.Show(c.Services.Assignments.Remove(item.Id), "Назначението е премахнато.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.View("Назначения в клас", c =>
        {
            if (Pick.Class(c) is { } cls)
            {
                Render(c, $"Назначения в {cls.DisplayName}", c.Services.Assignments.GetForClass(cls.Id).Value ?? []);
            }
        });
    }

    public static void Render(ScreenContext ctx, string title, IReadOnlyList<AssignmentView> items)
        => TableRenderer.Render(ctx.Console, title, items,
            Col.Text<AssignmentView>("Клас", a => a.ClassName),
            Col.Text<AssignmentView>("Предмет", a => a.SubjectName),
            Col.Text<AssignmentView>("Учител", a => a.TeacherName));
}
