// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Requests;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Theme;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Subjects taught at the school.</summary>
public sealed class SubjectsScreen : MenuScreen
{
    public override string Title => "Предмети";

    protected override void RenderBody(ScreenContext ctx) => Render(ctx, "Учебни предмети", ctx.Services.Subjects.GetAll(includeInactive: true));

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Добавяне на предмет", c =>
        {
            var name = c.Input.ReadRequiredString("Наименование", 50);
            if (name is not null)
            {
                c.Notifier.Show(c.Services.Subjects.Add(new SubjectInput(name, c.Input.ReadOptionalString("Код", 10))), $"Предметът „{name}“ е добавен.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.Do("Редактиране", c =>
        {
            if (Pick.Subject(c, includeInactive: true) is { } s)
            {
                var name = c.Input.ReadRequiredString("Наименование", 50, s.Name)!;
                var code = c.Input.ReadRequiredString("Код", 10, s.Code ?? "-");
                c.Notifier.Show(c.Services.Subjects.Update(s.Id, new SubjectInput(name, code == "-" ? null : code)), "Предметът е обновен.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.Do("Деактивиране", c =>
        {
            if (Pick.Subject(c) is { } s && c.Input.ReadConfirmation($"Деактивиране на „{s.Name}“?", defaultValue: false))
            {
                c.Notifier.Show(c.Services.Subjects.Deactivate(s.Id), "Предметът е деактивиран.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.View("Търсене", c =>
        {
            if (c.Input.ReadRequiredString("Част от име или код", 50) is { } q)
            {
                Render(c, $"Резултати за „{q}“", c.Services.Subjects.Search(q));
            }
        });
    }

    private static void Render(ScreenContext ctx, string title, IReadOnlyList<Subject> subjects)
        => TableRenderer.Render(ctx.Console, title, subjects,
            Col.Text<Subject>("Предмет", s => s.Name),
            Col.Text<Subject>("Код", s => s.Code ?? "—"),
            Col.Markup<Subject>("Статус", s => s.IsActive ? $"[{ShkoloTheme.SuccessHex}]активен[/]" : Ui.Muted("неактивен")));
}
