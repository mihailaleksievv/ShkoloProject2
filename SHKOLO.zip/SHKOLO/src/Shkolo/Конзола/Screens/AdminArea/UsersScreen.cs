// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Login accounts: overview, (de)activation, password reset, new accounts.</summary>
public sealed class UsersScreen : MenuScreen
{
    public override string Title => "Потребители";

    protected override void RenderBody(ScreenContext ctx)
        => TableRenderer.Render(ctx.Console, "Акаунти", ctx.Services.Auth.GetUsers().Value ?? [],
            Col.Text<User>("Потребител", u => u.Username),
            Col.Text<User>("Име", u => u.DisplayName),
            Col.Text<User>("Роля", u => BulgarianNames.Of(u.Role)),
            Col.Text<User>("Последен вход", u => u.LastLoginAtUtc is { } t ? Ui.FromUtc(t) : "—"),
            Col.Markup<User>("Статус", u => u.IsActive ? $"[{ShkoloTheme.SuccessHex}]активен[/]" : $"[{ShkoloTheme.ErrorHex}]спрян[/]"));

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Спиране / активиране на акаунт", c =>
        {
            if (PickUser(c) is { } u)
            {
                c.Notifier.Show(c.Services.Auth.SetUserActive(u.Id, !u.IsActive), u.IsActive ? $"Акаунтът „{u.Username}“ е спрян." : $"Акаунтът „{u.Username}“ е активиран.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.Do("Нулиране на парола", c =>
        {
            if (PickUser(c) is { } u && c.Input.ReadPassword("Нова парола") is { } pw)
            {
                c.Notifier.Show(c.Services.Auth.ResetPassword(u.Id, pw), $"Паролата на „{u.Username}“ е сменена.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.Do("Нов администратор", c =>
        {
            if (c.Input.ReadRequiredString("Име за показване", 100) is { } name)
            {
                AccountForm.Create(c, UserRole.Administrator, name, "admin2");
                c.Notifier.Pause();
            }
        });
    }

    private static User? PickUser(ScreenContext ctx)
        => ctx.Picker.Pick("Изберете акаунт", ctx.Services.Auth.GetUsers().Value ?? [], u => $"{u.Username} · {u.DisplayName} · {BulgarianNames.Of(u.Role)}{(u.IsActive ? "" : " (спрян)")}");
}
