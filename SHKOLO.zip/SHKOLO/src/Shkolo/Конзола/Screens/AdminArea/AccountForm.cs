// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Requests;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Navigation;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Creates a login account with an initial password chosen by the administrator.</summary>
public static class AccountForm
{
    public static void Create(ScreenContext ctx, UserRole role, string displayName, string suggestedUsername, Guid? studentId = null, Guid? teacherId = null)
    {
        ctx.Notifier.Info("Паролата трябва да е поне 8 символа и да съдържа буква и цифра.");
        var username = ctx.Input.ReadRequiredString("Потребителско име", 30, suggestedUsername)!;
        var password = ctx.Input.ReadPassword("Начална парола");
        if (password is null)
        {
            ctx.Notifier.Warning("Акаунтът не е създаден.");
            return;
        }

        var result = ctx.Services.Auth.CreateAccount(new AccountInput(username, displayName, password, role, studentId, teacherId));
        ctx.Notifier.Show(result, $"Създаден е акаунт „{username}“.");
    }
}
