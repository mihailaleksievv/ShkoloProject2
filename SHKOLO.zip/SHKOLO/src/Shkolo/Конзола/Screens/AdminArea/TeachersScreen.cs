// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Requests;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Theme;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Teacher profiles and what each teacher teaches.</summary>
public sealed class TeachersScreen : MenuScreen
{
    public override string Title => "Учители";

    protected override void RenderBody(ScreenContext ctx)
    {
        var result = ctx.Services.Teachers.GetAll(includeInactive: true);
        if (!result.Success)
        {
            return;
        }

        TableRenderer.Render(ctx.Console, "Учители", result.Value!,
            Col.Text<Teacher>("Служебен №", t => t.EmployeeNumber),
            Col.Text<Teacher>("Име", t => t.FullName),
            Col.Text<Teacher>("Имейл", t => t.Email),
            Col.Text<Teacher>("Предмети", t => string.Join(", ", ctx.Services.Teachers.GetTaughtSubjects(t.Id).Value?.Select(s => s.Name) ?? [])),
            Col.Markup<Teacher>("Статус", t => t.IsActive ? $"[{ShkoloTheme.SuccessHex}]активен[/]" : Ui.Muted("неактивен")));
    }

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Добавяне на учител", Add);
        yield return MenuItem.Do("Редактиране", Edit);
        yield return MenuItem.Do("Деактивиране", Deactivate);
        yield return MenuItem.View("Класове и предмети на учител", Taught);
        yield return MenuItem.View("Търсене", Search);
    }

    private static void Add(ScreenContext ctx)
    {
        StatPanel.Section(ctx.Console, "Нов учител");
        var number = ctx.Input.ReadRequiredString("Служебен номер", 20);
        var first = number is null ? null : ctx.Input.ReadRequiredString("Име", 50);
        var last = first is null ? null : ctx.Input.ReadRequiredString("Фамилия", 50);
        var email = last is null ? null : ctx.Input.ReadEmail("Имейл", optional: false);
        if (email is null)
        {
            return;
        }

        var result = ctx.Services.Teachers.Add(new TeacherInput(number!, first!, last!, email));
        if (ctx.Notifier.Show(result, $"Учителят {first} {last} е добавен.") && ctx.Input.ReadConfirmation("Да се създаде ли акаунт за вход?"))
        {
            AccountForm.Create(ctx, UserRole.Teacher, result.Value!.FullName, $"t{result.Value.EmployeeNumber.ToLowerInvariant().Replace("-", "")}", teacherId: result.Value.Id);
        }

        ctx.Notifier.Pause();
    }

    private static void Edit(ScreenContext ctx)
    {
        var t = Pick.Teacher(ctx, includeInactive: true);
        if (t is null)
        {
            return;
        }

        var input = new TeacherInput(
            ctx.Input.ReadRequiredString("Служебен номер", 20, t.EmployeeNumber)!,
            ctx.Input.ReadRequiredString("Име", 50, t.FirstName)!,
            ctx.Input.ReadRequiredString("Фамилия", 50, t.LastName)!,
            ctx.Input.ReadEmail("Имейл", optional: false, t.Email)!);
        ctx.Notifier.Show(ctx.Services.Teachers.Update(t.Id, input), "Данните са обновени.");
        ctx.Notifier.Pause();
    }

    private static void Deactivate(ScreenContext ctx)
    {
        var t = Pick.Teacher(ctx);
        if (t is null || !ctx.Input.ReadConfirmation($"Деактивиране на {t.FullName}?", defaultValue: false))
        {
            return;
        }

        var result = ctx.Services.Teachers.Deactivate(t.Id);
        if (ctx.Notifier.Show(result, "Учителят е деактивиран; акаунтът му е спрян.") && result.Value > 0)
        {
            ctx.Notifier.Warning($"Учителят все още има {result.Value} часа в разписанието – преразпределете ги от „Разписание“.");
        }

        ctx.Notifier.Pause();
    }

    private static void Taught(ScreenContext ctx)
    {
        var t = Pick.Teacher(ctx, includeInactive: true);
        if (t is null)
        {
            return;
        }

        var assignments = ctx.Services.Assignments.GetForTeacher(t.Id).Value ?? [];
        AssignmentsScreen.Render(ctx, $"Назначения на {t.FullName}", assignments);
    }

    private static void Search(ScreenContext ctx)
    {
        var q = ctx.Input.ReadRequiredString("Име или служебен номер", 50);
        if (q is null)
        {
            return;
        }

        TableRenderer.Render(ctx.Console, $"Резултати за „{q}“", ctx.Services.Teachers.Search(q).Value ?? [],
            Col.Text<Teacher>("Служебен №", t => t.EmployeeNumber),
            Col.Text<Teacher>("Име", t => t.FullName),
            Col.Text<Teacher>("Имейл", t => t.Email));
    }
}
