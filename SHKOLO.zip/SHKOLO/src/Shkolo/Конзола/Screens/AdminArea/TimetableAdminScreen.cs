// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Weekly timetable management with conflict checks done by the service.</summary>
public sealed class TimetableAdminScreen : MenuScreen
{
    public override string Title => "Разписание";

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.View("Седмично разписание на клас", c =>
        {
            if (Pick.Class(c) is { } cls && c.Services.Timetable.GetForClass(cls.Id).Value is { } rows)
            {
                TimetableGrid.Render(c.Console, $"Разписание на {cls.DisplayName} клас", rows, c.Services.BellSchedule.GetSlots(), r => r.TeacherName, c.Services.Clock.Today.DayOfWeek);
            }
        });
        yield return MenuItem.View("Седмично разписание на учител", c =>
        {
            if (Pick.Teacher(c) is { } t && c.Services.Timetable.GetForTeacher(t.Id).Value is { } rows)
            {
                TimetableGrid.Render(c.Console, $"Разписание на {t.FullName}", rows, c.Services.BellSchedule.GetSlots(), r => r.ClassName, c.Services.Clock.Today.DayOfWeek);
            }
        });
        yield return MenuItem.View("Програма за днес (цялото училище)", c =>
            TableRenderer.Render(c.Console, $"Днес · {Ui.LongDate(c.Services.Clock.Today)}", c.Services.Timetable.GetTodayForCurrentUser(), Columns));
        yield return MenuItem.Do("Добавяне на час", c => Save(c, null));
        yield return MenuItem.Do("Редактиране на час", c =>
        {
            if (PickEntry(c) is { } row)
            {
                Save(c, row);
            }
        });
        yield return MenuItem.Do("Изтриване на час", c =>
        {
            if (PickEntry(c) is { } row && c.Input.ReadConfirmation("Изтриване на часа от разписанието? Проведените часове остават.", defaultValue: false))
            {
                c.Notifier.Show(c.Services.Timetable.DeleteEntry(row.EntryId), "Часът е премахнат от разписанието.");
                c.Notifier.Pause();
            }
        });
    }

    private static readonly Col<TimetableRow>[] Columns =
    [
        Col.Text<TimetableRow>("Час", r => $"{r.LessonNumber}. {Ui.Time(r.Start)}–{Ui.Time(r.End)}"),
        Col.Text<TimetableRow>("Клас", r => r.ClassName),
        Col.Text<TimetableRow>("Предмет", r => r.SubjectName),
        Col.Text<TimetableRow>("Учител", r => r.TeacherName),
        Col.Text<TimetableRow>("Стая", r => r.Room ?? "—"),
    ];

    private static TimetableRow? PickEntry(ScreenContext ctx)
    {
        var cls = Pick.Class(ctx);
        var rows = cls is null ? null : ctx.Services.Timetable.GetForClass(cls.Id).Value;
        return rows is null ? null : ctx.Picker.Pick("Изберете час", rows, r => $"{BulgarianNames.Of(r.Day)}, {r.LessonNumber}. час · {r.SubjectName} · {r.TeacherName}");
    }

    private static void Save(ScreenContext ctx, TimetableRow? current)
    {
        var cls = current is null ? Pick.Class(ctx) : null;
        var classId = current?.ClassId ?? cls?.Id;
        if (classId is null)
        {
            return;
        }

        var assignment = ctx.Picker.Pick("Предмет и учител (от назначенията)", ctx.Services.Assignments.GetForClass(classId.Value).Value ?? [], a => $"{a.SubjectName} · {a.TeacherName}");
        var day = assignment is null ? null : Pick.Day(ctx);
        var slot = day is null ? null : ctx.Picker.Pick("Час", ctx.Services.BellSchedule.GetSlots(), s => $"{s.LessonNumber}. час · {Ui.Time(s.StartTime)}–{Ui.Time(s.EndTime)}");
        if (slot is null)
        {
            return;
        }

        var room = ctx.Input.ReadOptionalString("Стая", 10) ?? current?.Room;
        var input = new TimetableEntryInput(classId.Value, assignment!.SubjectId, assignment.TeacherId, day!.Value, slot.LessonNumber, room);
        var result = current is null ? ctx.Services.Timetable.AddEntry(input) : ctx.Services.Timetable.UpdateEntry(current.EntryId, input);
        ctx.Notifier.Show(result, "Разписанието е обновено.");
        ctx.Notifier.Pause();
    }
}
