// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Requests;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Read-only view of the gradebook for administrators: grades, attendance and lessons.</summary>
public sealed class GradebookOverviewScreen : MenuScreen
{
    public override string Title => "Оценки, отсъствия и часове";

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.View("Оценки на клас", c =>
        {
            if (Pick.Class(c) is { } cls)
            {
                GradeTables.Recent(c.Console, c.Services.Grades.GetGradesForClass(cls.Id).Value ?? [], $"Оценки в {cls.DisplayName}");
            }
        });
        yield return MenuItem.View("Оценки на ученик", c =>
        {
            if (Pick.Student(c, includeInactive: true) is { } s)
            {
                GradeTables.Recent(c.Console, c.Services.Grades.GetGradesForStudent(s.Id).Value ?? [], $"Оценки на {s.FullName}");
            }
        });
        yield return MenuItem.View("Отсъствия за период", c =>
        {
            var from = c.Input.ReadDate("От дата", c.Services.Clock.Today.AddDays(-7));
            var to = from is null ? null : c.Input.ReadDate("До дата", c.Services.Clock.Today);
            if (from is not null && to is not null)
            {
                var records = (c.Services.Attendance.GetAttendanceByPeriod(from.Value, to.Value).Value ?? [])
                    .Where(a => a.Status != Domain.Enums.AttendanceStatus.Present).ToList();
                GradeTables.Attendance(c.Console, records, $"Отсъствия и закъснения {Ui.Date(from.Value)} – {Ui.Date(to.Value)}");
            }
        });
        yield return MenuItem.View("Учебни часове на клас", c =>
        {
            if (Pick.Class(c) is { } cls)
            {
                GradeTables.Lessons(c.Console, c.Services.Lessons.Search(new LessonFilter(ClassId: cls.Id)).Value ?? [], $"Часове в {cls.DisplayName}");
            }
        });
    }
}
