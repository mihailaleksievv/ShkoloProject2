// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>School statistics computed live from the data (teachers see their own classes only).</summary>
public sealed class SchoolStatisticsScreen : MenuScreen
{
    public override string Title => "Статистики";

    protected override void RenderBody(ScreenContext ctx)
    {
        var result = ctx.Services.Reports.GetSchoolStatistics();
        if (!result.Success)
        {
            ctx.Notifier.Error(result.Error!.Message);
            return;
        }

        var s = result.Value!;
        ctx.Console.Write(StatPanel.Tiles(
            ("Ученици", StatPanel.Number(s.ActiveStudents)),
            ("Класове", StatPanel.Number(s.Classes)),
            ("Оценки", StatPanel.Number(s.TotalGrades)),
            ("Среден успех", GradeFormatter.WithWord(s.SchoolAverage)),
            ("Неизвинени", $"[bold {ShkoloTheme.ErrorHex}]{s.Attendance.Unexcused}[/]"),
            ("Извинени", $"[bold {ShkoloTheme.WarningHex}]{s.Attendance.Excused}[/]")));
        GradeTables.AverageChart(ctx.Console, "Среден успех по класове", s.ClassAverages.Select(c => (c.ClassName, c.Average)));
        ctx.Console.WriteLine();
        GradeTables.DistributionChart(ctx.Console, s.Distribution);
    }

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.View("Успех по предмети", c =>
        {
            var rows = c.Services.Subjects.GetAll()
                .Select(subject => c.Services.Reports.GetSubjectPerformance(subject.Id).Value)
                .Where(p => p is not null && p.GradeCount > 0)
                .Select(p => p!)
                .OrderByDescending(p => p.Average)
                .ToList();
            TableRenderer.Render(c.Console, "Успех по предмети", rows,
                Col.Text<SubjectPerformance>("Предмет", p => p.SubjectName),
                Col.Markup<SubjectPerformance>("Среден успех", p => GradeFormatter.WithWord(p.Average)),
                Col.Text<SubjectPerformance>("Оценки", p => Ui.Count(p.GradeCount), Justify.Right),
                Col.Text<SubjectPerformance>("Отлични / Слаби", p => $"{p.Distribution.Excellent} / {p.Distribution.Poor}", Justify.Right));
        });
        yield return new MenuItem("Справка за клас", c => Pick.Class(c) is { } cls ? ScreenResult.Push(new ClassReportScreen(cls.Id)) : ScreenResult.Stay);
        yield return MenuItem.View("Статистика на присъствията", c =>
        {
            if (c.Services.Reports.GetAttendanceStatistics().Value is { } a)
            {
                c.Console.MarkupLine($"Присъствия: [bold]{a.Present}[/] · Закъснения: [bold]{a.Late}[/] · Извинени: [bold]{a.Excused}[/] · Неизвинени: [bold]{a.Unexcused}[/]");
                GradeTables.AttendanceChart(c.Console, a);
            }
        });
    }
}
