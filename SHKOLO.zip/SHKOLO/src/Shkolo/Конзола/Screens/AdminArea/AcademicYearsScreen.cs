// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Requests;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Academic years (with terms) and the bell schedule.</summary>
public sealed class AcademicYearsScreen : MenuScreen
{
    public override string Title => "Учебни години и звънец";

    protected override void RenderBody(ScreenContext ctx)
    {
        TableRenderer.Render(ctx.Console, "Учебни години", ctx.Services.AcademicYears.GetAll(),
            Col.Text<AcademicYear>("Година", y => y.Name),
            Col.Text<AcademicYear>("Начало", y => Ui.Date(y.StartDate)),
            Col.Text<AcademicYear>("Край на I срок", y => Ui.Date(y.FirstTermEndDate)),
            Col.Text<AcademicYear>("Край", y => Ui.Date(y.EndDate)),
            Col.Markup<AcademicYear>("Статус", y => y.IsActive ? $"[bold {ShkoloTheme.SuccessHex}]активна[/]" : Ui.Muted("—")));
        TableRenderer.Render(ctx.Console, "Звънец", ctx.Services.BellSchedule.GetSlots(),
            Col.Text<LessonSlot>("Час", s => s.LessonNumber.ToString()),
            Col.Text<LessonSlot>("Начало", s => Ui.Time(s.StartTime)),
            Col.Text<LessonSlot>("Край", s => Ui.Time(s.EndTime)));
    }

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Нова учебна година", c => Save(c, null));
        yield return MenuItem.Do("Редактиране на учебна година", c =>
        {
            if (c.Picker.Pick("Изберете година", c.Services.AcademicYears.GetAll(), y => y.Name) is { } y)
            {
                Save(c, y);
            }
        });
        yield return MenuItem.Do("Активиране на учебна година", c =>
        {
            if (c.Picker.Pick("Изберете година", c.Services.AcademicYears.GetAll(), y => y.Name + (y.IsActive ? " (активна)" : "")) is { } y)
            {
                c.Notifier.Show(c.Services.AcademicYears.SetActive(y.Id), $"{y.Name} е активната учебна година.");
                c.Notifier.Pause();
            }
        });
        yield return MenuItem.Do("Промяна на час от звънеца", c =>
        {
            var slot = c.Picker.Pick("Изберете час", c.Services.BellSchedule.GetSlots(), s => $"{s.LessonNumber}. час · {Ui.Time(s.StartTime)}–{Ui.Time(s.EndTime)}");
            if (slot is null)
            {
                return;
            }

            var start = c.Input.ReadTime("Начало", slot.StartTime)!.Value;
            var end = c.Input.ReadTime("Край", slot.EndTime)!.Value;
            c.Notifier.Show(c.Services.BellSchedule.UpdateSlot(slot.LessonNumber, start, end), "Звънецът е обновен – всички разписания използват новите часове.");
            c.Notifier.Pause();
        });
    }

    private static void Save(ScreenContext ctx, AcademicYear? current)
    {
        var name = ctx.Input.ReadRequiredString("Наименование (напр. 2027/2028)", 20, current?.Name);
        var start = name is null ? null : ctx.Input.ReadDate("Начало", current?.StartDate);
        var termEnd = start is null ? null : ctx.Input.ReadDate("Край на I срок", current?.FirstTermEndDate);
        var end = termEnd is null ? null : ctx.Input.ReadDate("Край на годината", current?.EndDate);
        if (end is null)
        {
            return;
        }

        var input = new AcademicYearInput(name!, start!.Value, termEnd!.Value, end.Value);
        var result = current is null ? ctx.Services.AcademicYears.Create(input) : ctx.Services.AcademicYears.Update(current.Id, input);
        ctx.Notifier.Show(result, "Учебната година е записана.");
        ctx.Notifier.Pause();
    }
}
