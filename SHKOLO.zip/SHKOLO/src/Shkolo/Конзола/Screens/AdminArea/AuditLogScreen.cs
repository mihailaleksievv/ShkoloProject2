// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>History of actions: who did what and when.</summary>
public sealed class AuditLogScreen : MenuScreen
{
    private static readonly (string Prefix, string Label)[] Filters =
    [
        ("", "Всички"), ("Grade.", "Оценки"), ("Attendance.", "Присъствия"), ("Lesson.", "Учебни часове"), ("Student.", "Ученици"),
        ("Teacher.", "Учители"), ("Homework.", "Домашни"), ("Announcement.", "Съобщения"), ("User.", "Акаунти"), ("Auth.", "Вход в системата"),
    ];

    private string _prefix = "";

    public override string Title => "История на действията";

    protected override void RenderBody(ScreenContext ctx)
        => TableRenderer.Render(ctx.Console, "Последни 100 действия" + (_prefix == "" ? "" : $" · {_prefix}"), ctx.Services.Audit.GetRecent(100, _prefix).Value ?? [],
            Col.Text<AuditEntryView>("Кога", a => Ui.FromUtc(a.OccurredAtUtc)),
            Col.Text<AuditEntryView>("Потребител", a => a.UserName),
            Col.Text<AuditEntryView>("Действие", a => a.Action),
            Col.Text<AuditEntryView>("Описание", a => a.Summary));

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Филтър по вид действие", c =>
        {
            var index = c.Picker.PickValue("Вид", Filters.Select((f, i) => (i, f.Label)).ToList());
            if (index is { } i)
            {
                _prefix = Filters[i].Prefix;
            }
        });
    }
}
