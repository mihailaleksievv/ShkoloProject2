// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Requests;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens.Shared;
using Shkolo.Presentation.Theme;

namespace Shkolo.Presentation.Screens.AdminArea;

/// <summary>Student profiles: list, search, filter, add (with optional account), edit, (de)activate, reports.</summary>
public sealed class StudentsScreen : MenuScreen
{
    public override string Title => "Ученици";

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.View("Списък на всички ученици", c => List(c, includeInactive: true));
        yield return MenuItem.View("Търсене по име или номер", Search);
        yield return MenuItem.View("Ученици по клас", ByClass);
        yield return MenuItem.Do("Добавяне на ученик", Add);
        yield return MenuItem.Do("Редактиране на профил", Edit);
        yield return MenuItem.Do("Деактивиране / активиране", ToggleActive);
        yield return new MenuItem("Справка за ученик", c => Pick.Student(c, includeInactive: true) is { } s ? ScreenResult.Push(new StudentReportScreen(s.Id)) : ScreenResult.Stay);
        yield return MenuItem.Do("Експорт на справка (CSV)", c => Export(c, Pick.Student(c, includeInactive: true)));
    }

    public static void Render(ScreenContext ctx, string title, IReadOnlyList<Student> students)
    {
        var classes = Pick.ClassNames(ctx);
        TableRenderer.Render(ctx.Console, title, students,
            Col.Text<Student>("№", s => s.StudentNumber),
            Col.Text<Student>("Име", s => s.FullName),
            Col.Text<Student>("Клас", s => classes.GetValueOrDefault(s.ClassId, "—")),
            Col.Text<Student>("Имейл", s => s.Email ?? "—"),
            Col.Markup<Student>("Статус", s => s.IsActive ? $"[{ShkoloTheme.SuccessHex}]активен[/]" : Ui.Muted("неактивен")));
    }

    public static void Export(ScreenContext ctx, Student? student)
    {
        if (student is null)
        {
            return;
        }

        var result = ctx.Services.Export.ExportStudentReport(student.Id);
        ctx.Notifier.Show(result, $"Справката е записана: {result.Value}");
        ctx.Notifier.Pause();
    }

    private static void List(ScreenContext ctx, bool includeInactive)
    {
        var result = ctx.Services.Students.GetAllStudents(includeInactive);
        if (result.Success)
        {
            Render(ctx, "Ученици", result.Value!);
        }
        else
        {
            ctx.Notifier.Error(result.Error!.Message);
        }
    }

    private static void Search(ScreenContext ctx)
    {
        var query = ctx.Input.ReadRequiredString("Име, фамилия или ученически номер", 50);
        if (query is null)
        {
            return;
        }

        var result = ctx.Services.Students.SearchStudents(query);
        if (result.Success)
        {
            Render(ctx, $"Резултати за „{query}“", result.Value!);
        }
        else
        {
            ctx.Notifier.Error(result.Error!.Message);
        }
    }

    private static void ByClass(ScreenContext ctx)
    {
        var cls = Pick.Class(ctx);
        if (cls is null)
        {
            return;
        }

        var result = ctx.Services.Students.GetStudentsByClass(cls.Id, includeInactive: true);
        if (result.Success)
        {
            Render(ctx, $"Ученици в {cls.DisplayName} клас", result.Value!);
        }
    }

    private static void Add(ScreenContext ctx)
    {
        StatPanel.Section(ctx.Console, "Нов ученик");
        var number = ctx.Input.ReadRequiredString("Ученически номер", 20);
        var first = number is null ? null : ctx.Input.ReadRequiredString("Име", 50);
        var last = first is null ? null : ctx.Input.ReadRequiredString("Фамилия", 50);
        var cls = last is null ? null : Pick.Class(ctx);
        if (cls is null)
        {
            return;
        }

        var email = ctx.Input.ReadEmail("Имейл", optional: true);
        var result = ctx.Services.Students.AddStudent(new StudentInput(number!, first!, last!, cls.Id, string.IsNullOrEmpty(email) ? null : email));
        if (!ctx.Notifier.Show(result, $"Ученикът {first} {last} е добавен в {cls.DisplayName} клас."))
        {
            ctx.Notifier.Pause();
            return;
        }

        if (ctx.Input.ReadConfirmation("Да се създаде ли акаунт за вход?"))
        {
            AccountForm.Create(ctx, UserRole.Student, result.Value!.FullName, $"student{result.Value.StudentNumber}", studentId: result.Value.Id);
        }

        ctx.Notifier.Pause();
    }

    private static void Edit(ScreenContext ctx)
    {
        var s = Pick.Student(ctx, includeInactive: true);
        if (s is null)
        {
            return;
        }

        ctx.Notifier.Info("Enter запазва текущата стойност.");
        var number = ctx.Input.ReadRequiredString("Ученически номер", 20, s.StudentNumber)!;
        var first = ctx.Input.ReadRequiredString("Име", 50, s.FirstName)!;
        var last = ctx.Input.ReadRequiredString("Фамилия", 50, s.LastName)!;
        var classId = s.ClassId;
        if (ctx.Input.ReadConfirmation("Смяна на класа?", defaultValue: false))
        {
            ctx.Notifier.Info("Старите оценки остават към класа, в който са поставени.");
            classId = Pick.Class(ctx)?.Id ?? s.ClassId;
        }

        var email = ctx.Input.ReadEmail("Имейл", optional: true, s.Email);
        ctx.Notifier.Show(ctx.Services.Students.UpdateStudent(s.Id, new StudentInput(number, first, last, classId, string.IsNullOrEmpty(email) ? null : email)), "Профилът е обновен.");
        ctx.Notifier.Pause();
    }

    private static void ToggleActive(ScreenContext ctx)
    {
        var s = Pick.Student(ctx, includeInactive: true);
        if (s is null)
        {
            return;
        }

        if (s.IsActive)
        {
            if (ctx.Input.ReadConfirmation($"Деактивиране на {s.FullName}? Оценките и отсъствията остават в историята.", defaultValue: false))
            {
                ctx.Notifier.Show(ctx.Services.Students.DeactivateStudent(s.Id), "Ученикът е деактивиран; акаунтът му е спрян.");
            }
        }
        else if (ctx.Input.ReadConfirmation($"Активиране на {s.FullName}?"))
        {
            ctx.Notifier.Show(ctx.Services.Students.ReactivateStudent(s.Id), "Ученикът е активиран отново.");
        }

        ctx.Notifier.Pause();
    }
}
