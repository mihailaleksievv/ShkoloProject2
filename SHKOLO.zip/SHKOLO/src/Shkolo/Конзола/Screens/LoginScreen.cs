﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Screens;

/// <summary>Екранът за вход: потребителско име, парола и демо акаунти.</summary>
public sealed class LoginScreen : IScreen
{
    private const int FreeAttempts = 3;
    private const int MaxLength = 30;
    private const int CardWidth = 64;

    private static readonly (UserRole Role, string User, string Password)[] DemoAccounts =
    [
        (UserRole.Administrator, "admin", "Admin123!"),
        (UserRole.Teacher, "teacher1", "Teacher123!"),
        (UserRole.Student, "student1", "Student123!"),
    ];

    private sealed class Form
    {
        public string User = "";
        public string Password = "";
        public int Focus;          // 0 user, 1 password
        public bool DemoTab;
        public int Demo;
        public string? Message;
        public bool MessageIsError;
    }

    public string Title => "Вход";

    public ScreenResult Show(ScreenContext ctx)
        => SkyScene.Fits(ctx.Console) ? ShowCard(ctx) : ShowClassic(ctx);

    private ScreenResult ShowCard(ScreenContext ctx)
    {
        var console = ctx.Console;
        var form = new Form();
        ScreenResult? result = null;
        Ui.Clear(console);

        console.Live(Build(console, form)).AutoClear(false).Overflow(VerticalOverflow.Crop).Start(live =>
        {
            void Redraw()
            {
                live.UpdateTarget(Build(console, form));
                live.Refresh();
            }

            live.Refresh();
            while (result is null)
            {
                var key = SkyScene.ReadKey(console);
                form.Message = null;
                if (key.Key == ConsoleKey.Escape)
                {
                    result = ScreenResult.Back;
                    break;
                }

                if (key.Key == ConsoleKey.Tab)
                {
                    form.DemoTab = !form.DemoTab;
                }
                else if (form.DemoTab)
                {
                    HandleDemoKey(form, key);
                }
                else if (key.Key == ConsoleKey.Enter)
                {
                    if (form.Focus == 0 && form.User.Length == 0)
                    {
                        result = ScreenResult.Back; // an empty username returns to the start screen, as before
                        break;
                    }

                    if (form.Focus == 0)
                    {
                        form.Focus = 1;
                    }
                    else
                    {
                        result = Submit(ctx, form, Redraw);
                    }
                }
                else
                {
                    HandleFieldKey(form, key);
                }

                Redraw();
            }
        });

        Ui.Clear(console);
        return result!;
    }

    private static void HandleDemoKey(Form form, ConsoleKeyInfo key)
    {
        switch (key.Key)
        {
            case ConsoleKey.DownArrow:
                form.Demo = (form.Demo + 1) % DemoAccounts.Length;
                break;
            case ConsoleKey.UpArrow:
                form.Demo = (form.Demo - 1 + DemoAccounts.Length) % DemoAccounts.Length;
                break;
            case ConsoleKey.Enter:
                (_, form.User, form.Password) = DemoAccounts[form.Demo];
                form.DemoTab = false;
                form.Focus = 1;
                form.Message = "Формата е попълнена – натиснете Enter за вход.";
                form.MessageIsError = false;
                break;
        }
    }

    private static void HandleFieldKey(Form form, ConsoleKeyInfo key)
    {
        switch (key.Key)
        {
            case ConsoleKey.UpArrow:
                form.Focus = 0;
                return;
            case ConsoleKey.DownArrow:
                form.Focus = 1;
                return;
            case ConsoleKey.Backspace:
                if (form.Focus == 0 && form.User.Length > 0)
                {
                    form.User = form.User[..^1];
                }
                else if (form.Focus == 1 && form.Password.Length > 0)
                {
                    form.Password = form.Password[..^1];
                }

                return;
        }

        if (char.IsControl(key.KeyChar) || key.KeyChar == '\0')
        {
            return;
        }

        if (form.Focus == 0 && form.User.Length < MaxLength)
        {
            form.User += key.KeyChar;
        }
        else if (form.Focus == 1 && form.Password.Length < MaxLength)
        {
            form.Password += key.KeyChar;
        }
    }

    private ScreenResult? Submit(ScreenContext ctx, Form form, Action redraw)
    {
        if (ctx.FailedLoginAttempts >= FreeAttempts)
        {
            var delay = Math.Min(30, 1 << Math.Min(5, ctx.FailedLoginAttempts - FreeAttempts + 1));
            form.Message = $"Проверка… изчакване {delay} сек. след неуспешни опити";
            form.MessageIsError = false;
            redraw();
            Thread.Sleep(TimeSpan.FromSeconds(delay));
        }

        var result = ctx.Services.Auth.Login(form.User.Trim(), form.Password);
        if (result.Success)
        {
            ctx.FailedLoginAttempts = 0;
            return ScreenResult.Replace(new ShellHostScreen(result.Value!.Role));
        }

        ctx.FailedLoginAttempts++;
        form.Message = $"✖ {result.Error!.Message}  Натиснете клавиш.";
        form.MessageIsError = true;
        redraw();
        SkyScene.ReadKey(ctx.Console);
        form.User = "";
        form.Password = "";
        form.Focus = 0;
        return null;
    }

    private static PixelCanvas Build(IAnsiConsole console, Form form)
    {
        var rows = SkyScene.Rows(console);
        var canvas = new PixelCanvas(SkyScene.Background(console, 0.35, 4));
        var left = (canvas.Width - CardWidth) / 2;
        var top = Math.Max(8, (rows - 20) / 2 + 3);

        // Card and tabs.
        canvas.Fill(left, top, CardWidth, 19, SkyScene.Card);
        var half = CardWidth / 2;
        canvas.Fill(left + (form.DemoTab ? 0 : half), top, half, 3, SkyScene.CardDark);
        canvas.Text(left + (half - 4) / 2, top + 1, "ВХОД", SkyScene.White, form.DemoTab ? SkyScene.CardDark : SkyScene.Card, bold: !form.DemoTab);
        canvas.Text(left + half + (half - 12) / 2, top + 1, "ДЕМО АКАУНТИ", SkyScene.White, form.DemoTab ? SkyScene.Card : SkyScene.CardDark, bold: form.DemoTab);

        var inner = left + 5;
        var innerWidth = CardWidth - 10;
        if (form.DemoTab)
        {
            canvas.Text(inner, top + 4, "Изберете акаунт – формата се попълва сама.", SkyScene.White, SkyScene.Card);
            for (var i = 0; i < DemoAccounts.Length; i++)
            {
                var (role, user, password) = DemoAccounts[i];
                var row = top + 6 + i * 3;
                var active = i == form.Demo;
                var bg = active ? SkyScene.White : SkyScene.ButtonIdle;
                canvas.Fill(inner, row, innerWidth, 2, bg);
                canvas.Text(inner, row, active ? "▌" : " ", SkyScene.Teal, bg);
                canvas.Text(inner + 2, row, BulgarianNames.Of(role), active ? SkyScene.Ink : SkyScene.SoftInk, bg, bold: true);
                canvas.Text(inner + 18, row, user, SkyScene.Ink, bg, bold: active);
                canvas.Text(inner + 32, row, password, SkyScene.SoftInk, bg);
                canvas.Text(inner + 2, row + 1, role switch
                {
                    UserRole.Administrator => "цялото училище",
                    UserRole.Teacher => "също teacher2, teacher3",
                    _ => "също student2 … student18",
                }, SkyScene.Placeholder, bg);
            }

            canvas.Text(inner, top + 16, "↑↓ избор   Enter попълва   Tab към вход", SkyScene.White, SkyScene.Card);
            return canvas;
        }

        Field(canvas, inner, top + 4, innerWidth, "◉", form.User, "Потребителско име", form.Focus == 0, mask: false);
        Field(canvas, inner, top + 8, innerWidth, "◈", form.Password, "Парола", form.Focus == 1, mask: true);
        canvas.Fill(inner, top + 12, innerWidth, 3, SkyScene.Teal);
        canvas.Text(inner + (innerWidth - 4) / 2, top + 13, "ВХОД", SkyScene.White, SkyScene.Teal, bold: true);

        var message = form.Message ?? "Tab демо акаунти   ↑↓ поле   Enter напред   Esc назад";
        canvas.Text(inner, top + 16, message.Length > innerWidth ? message[..innerWidth] : message,
            form.Message is null ? SkyScene.White : form.MessageIsError ? SkyScene.Warning : SkyScene.White, SkyScene.Card, bold: form.Message is not null);
        return canvas;
    }

    private static void Field(PixelCanvas canvas, int x, int row, int width, string icon, string value, string placeholder, bool focused, bool mask)
    {
        canvas.Fill(x, row, width, 3, SkyScene.White);
        if (focused)
        {
            canvas.Text(x, row, "▌", SkyScene.Teal, SkyScene.White);
            canvas.Text(x, row + 1, "▌", SkyScene.Teal, SkyScene.White);
            canvas.Text(x, row + 2, "▌", SkyScene.Teal, SkyScene.White);
        }

        canvas.Text(x + 2, row + 1, icon, focused ? SkyScene.Teal : SkyScene.SoftInk, SkyScene.White);
        var shown = mask ? new string('•', value.Length) : value;
        if (shown.Length == 0)
        {
            canvas.Text(x + 5, row + 1, placeholder, SkyScene.Placeholder, SkyScene.White);
        }
        else
        {
            canvas.Text(x + 5, row + 1, shown, SkyScene.Ink, SkyScene.White, bold: true);
        }

        if (focused)
        {
            canvas.Text(x + 5 + shown.Length, row + 1, "▏", SkyScene.Ink, SkyScene.White);
        }
    }

    private static ScreenResult ShowClassic(ScreenContext ctx)
    {
        var intro = new Panel(new Markup(
                $"Въведете потребителско име и парола.\n{Ui.Muted("Празно потребителско име връща към началния екран.")}\n\n" +
                $"{Ui.Muted("След вход: ↑↓ раздели · → действия · / търсене · ? помощ")}"))
            .Header($" [bold {ShkoloTheme.PrimaryHex}]Вход в SHKOLO[/] ")
            .Border(BoxBorder.Rounded)
            .BorderColor(ShkoloTheme.Frame)
            .Padding(2, 1);

        var accounts = new Table().Border(TableBorder.Simple).BorderColor(ShkoloTheme.Surface)
            .AddColumn("Роля").AddColumn("Потребител").AddColumn("Парола");
        void Account(UserRole role, string user, string password) => accounts.AddRow(
            new Markup($"[bold {ShkoloTheme.BackgroundHex} on {RoleAccent.BadgeHexFor(role)}] {Ui.Escape(BulgarianNames.Of(role))} [/]"),
            new Markup($"[bold]{Ui.Escape(user)}[/]"),
            new Markup(Ui.Muted(password)));
        Account(UserRole.Administrator, "admin", "Admin123!");
        Account(UserRole.Teacher, "teacher1 … 3", "Teacher123!");
        Account(UserRole.Student, "student1 … 18", "Student123!");

        var demo = new Panel(accounts)
            .Header($" [bold {ShkoloTheme.LavenderHex}]Демо акаунти[/] ")
            .Border(BoxBorder.Rounded)
            .BorderColor(ShkoloTheme.Surface);

        var row = new Grid().AddColumn(new GridColumn().PadRight(2)).AddColumn();
        row.AddRow(intro, demo);
        ctx.Console.Write(row);
        ctx.Console.WriteLine();

        var username = ctx.Input.ReadOptionalString("Потребителско име", MaxLength);
        if (username is null)
        {
            return ScreenResult.Back;
        }

        var password = ctx.Input.ReadPassword("Парола") ?? "";
        if (ctx.FailedLoginAttempts >= FreeAttempts)
        {
            var delay = Math.Min(30, 1 << Math.Min(5, ctx.FailedLoginAttempts - FreeAttempts + 1));
            ctx.Console.Status().Start($"Проверка… (изчакване {delay} сек. след неуспешни опити)", _ => Thread.Sleep(TimeSpan.FromSeconds(delay)));
        }

        var result = ctx.Services.Auth.Login(username, password);
        if (!result.Success)
        {
            ctx.FailedLoginAttempts++;
            ctx.Notifier.Error(result.Error!.Message);
            ctx.Notifier.Pause();
            return ScreenResult.Stay;
        }

        ctx.FailedLoginAttempts = 0;
        return ScreenResult.Replace(new ShellHostScreen(result.Value!.Role));
    }
}
