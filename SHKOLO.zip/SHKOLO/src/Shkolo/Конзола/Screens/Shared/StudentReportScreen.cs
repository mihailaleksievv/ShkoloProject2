// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Screens.Shared;

/// <summary>Detailed student performance report (used by all three roles; the service enforces access).</summary>
public sealed class StudentReportScreen(Guid studentId, Term? term = null) : IScreen
{
    public string Title => "Справка за ученик";

    public ScreenResult Show(ScreenContext ctx)
    {
        var result = ctx.Services.Reports.GenerateStudentReport(studentId, term);
        if (!result.Success)
        {
            ctx.Notifier.Error(result.Error!.Message);
            ctx.Notifier.Pause();
            return ScreenResult.Back;
        }

        Render(ctx, result.Value!, term);
        ctx.Notifier.Pause();
        return ScreenResult.Back;
    }

    public static void Render(ScreenContext ctx, StudentReport r, Term? term = null)
    {
        var console = ctx.Console;
        console.Write(new Panel(new Markup(
                $"[bold]{Ui.Escape(r.Student.FullName)}[/]\n{Ui.Muted($"{r.ClassName} клас · №{r.Student.StudentNumber}{(term is null ? "" : " · " + BulgarianNames.Of(term.Value))}")}"))
            .Border(BoxBorder.Rounded).BorderColor(ShkoloTheme.Accent).Padding(2, 0));

        console.Write(StatPanel.Tiles(
            ("Среден успех", GradeFormatter.WithWord(r.OverallAverage)),
            ("Брой оценки", StatPanel.Number(r.GradeCount)),
            ("Неизвинени", $"[bold {ShkoloTheme.ErrorHex}]{r.Attendance.Unexcused}[/]"),
            ("Извинени", $"[bold {ShkoloTheme.WarningHex}]{r.Attendance.Excused}[/]"),
            ("Закъснения", StatPanel.Number(r.Attendance.Late)),
            ("Присъствия", $"[bold {ShkoloTheme.SuccessHex}]{r.Attendance.Present}[/]")));

        StatPanel.Section(console, "Успех по предмети");
        TableRenderer.Render(console, "Среден успех по предмети", r.SubjectAverages,
            Col.Text<SubjectAverage>("Предмет", s => s.SubjectName),
            Col.Markup<SubjectAverage>("Среден успех", s => GradeFormatter.WithWord(s.Average)),
            Col.Text<SubjectAverage>("Оценки", s => Ui.Count(s.GradeCount), Justify.Right));

        if (r.TermGrades.Count > 0)
        {
            TableRenderer.Render(console, "Срочни и годишни оценки", r.TermGrades,
                Col.Text<Domain.Models.TermGrade>("Период", t => BulgarianNames.Of(t.Period)),
                Col.Text<Domain.Models.TermGrade>("Предмет", t => r.SubjectAverages.FirstOrDefault(s => s.SubjectId == t.SubjectId)?.SubjectName ?? "—"),
                Col.Markup<Domain.Models.TermGrade>("Оценка", t => GradeFormatter.TermGrade(t.Value)));
        }

        StatPanel.Section(console, "Последни оценки");
        GradeTables.Recent(console, r.RecentGrades);

        if (r.UpcomingHomework.Count > 0)
        {
            StatPanel.Section(console, "Предстоящи домашни");
            TableRenderer.Render(console, "Домашни", r.UpcomingHomework,
                Col.Text<HomeworkView>("Срок", h => Ui.Date(h.DueDate)),
                Col.Text<HomeworkView>("Предмет", h => h.SubjectName),
                Col.Text<HomeworkView>("Заглавие", h => h.Title),
                Col.Markup<HomeworkView>("Статус", h => HomeworkStatusMarkup(h.StatusForStudent)));
        }

        if (r.RecentFeedback.Count > 0)
        {
            StatPanel.Section(console, "Похвали и забележки");
            TableRenderer.Render(console, "Последни", r.RecentFeedback,
                Col.Text<FeedbackView>("Дата", f => Ui.Date(f.Date)),
                Col.Markup<FeedbackView>("Вид", f => f.Type == FeedbackType.Praise ? $"[{ShkoloTheme.SuccessHex}]Похвала[/]" : $"[{ShkoloTheme.WarningHex}]Забележка[/]"),
                Col.Text<FeedbackView>("Текст", f => f.Description),
                Col.Text<FeedbackView>("Учител", f => f.TeacherName));
        }

        if (r.Achievements.Count > 0)
        {
            StatPanel.Section(console, "Отличия");
            console.MarkupLine(string.Join("   ", r.Achievements.Select(a => $"[bold {ShkoloTheme.WarningHex}]{Ui.Escape(a.Symbol)}[/] {Ui.Escape(a.Name)}")));
        }
    }

    public static string HomeworkStatusMarkup(HomeworkStatus? status) => status switch
    {
        HomeworkStatus.Submitted => $"[{ShkoloTheme.SuccessHex}]Предадено[/]",
        HomeworkStatus.SubmittedLate => $"[{ShkoloTheme.WarningHex}]Предадено със закъснение[/]",
        HomeworkStatus.Overdue => $"[{ShkoloTheme.ErrorHex}]Просрочено[/]",
        HomeworkStatus.Pending => $"[{ShkoloTheme.AccentHex}]Предстои[/]",
        _ => Ui.Muted("—"),
    };
}
