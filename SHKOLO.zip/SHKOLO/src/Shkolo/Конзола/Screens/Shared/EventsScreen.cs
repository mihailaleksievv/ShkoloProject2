// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;

namespace Shkolo.Presentation.Screens.Shared;

/// <summary>School calendar. Students read; administrators and teachers manage (rules enforced by the service).</summary>
public sealed class EventsScreen(bool canManage) : MenuScreen
{
    public override string Title => "Училищни събития";

    protected override void RenderBody(ScreenContext ctx)
        => Render(ctx, "Предстоящи събития (30 дни)", ctx.Services.Events.GetUpcoming());

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.View("Събития за период", ByPeriod);
        if (canManage)
        {
            yield return MenuItem.Do("Създаване на събитие", Create);
            yield return MenuItem.Do("Редактиране", Edit);
            yield return MenuItem.Do("Изтриване", Delete);
        }
    }

    public static void Render(ScreenContext ctx, string title, IReadOnlyList<EventView> events)
        => TableRenderer.Render(ctx.Console, title, events,
            Col.Text<EventView>("Начало", e => Ui.DateTime(e.Start)),
            Col.Text<EventView>("Край", e => Ui.DateTime(e.End)),
            Col.Text<EventView>("Събитие", e => e.Title),
            Col.Text<EventView>("Описание", e => e.Description),
            Col.Text<EventView>("За", e => e.Target));

    private static void ByPeriod(ScreenContext ctx)
    {
        var from = ctx.Input.ReadDate("От дата", ctx.Services.Clock.Today);
        var to = from is null ? null : ctx.Input.ReadDate("До дата", from.Value.AddDays(30));
        if (from is not null && to is not null)
        {
            Render(ctx, $"Събития {Ui.Date(from.Value)} – {Ui.Date(to.Value)}", ctx.Services.Events.GetByDateRange(from.Value, to.Value));
        }
    }

    private static void Create(ScreenContext ctx)
    {
        var input = ReadInput(ctx, null);
        if (input is not null)
        {
            ctx.Notifier.Show(ctx.Services.Events.Create(input), "Събитието е създадено.");
            ctx.Notifier.Pause();
        }
    }

    private static void Edit(ScreenContext ctx)
    {
        var ev = PickManageable(ctx);
        var input = ev is null ? null : ReadInput(ctx, ev);
        if (ev is not null && input is not null)
        {
            ctx.Notifier.Show(ctx.Services.Events.Update(ev.Id, input), "Събитието е редактирано.");
            ctx.Notifier.Pause();
        }
    }

    private static void Delete(ScreenContext ctx)
    {
        var ev = PickManageable(ctx);
        if (ev is not null && ctx.Input.ReadConfirmation($"Изтриване на „{ev.Title}“?", defaultValue: false))
        {
            ctx.Notifier.Show(ctx.Services.Events.Delete(ev.Id), "Събитието е изтрито.");
            ctx.Notifier.Pause();
        }
    }

    private static EventView? PickManageable(ScreenContext ctx)
    {
        var today = ctx.Services.Clock.Today;
        var events = ctx.Services.Events.GetByDateRange(today.AddDays(-60), today.AddDays(365))
            .Where(e => ctx.Services.Authorization.IsAdmin || e.CreatedByUserId == ctx.Services.Session.UserId).ToList();
        return ctx.Picker.Pick("Изберете събитие", events, e => $"{Ui.DateTime(e.Start)} · {e.Title} · {e.Target}");
    }

    private static SchoolEventInput? ReadInput(ScreenContext ctx, EventView? current)
    {
        var title = ctx.Input.ReadRequiredString("Заглавие", 120, current?.Title);
        if (title is null)
        {
            return null;
        }

        var description = ctx.Input.ReadOptionalString("Описание", 1000) ?? current?.Description ?? "";
        var date = ctx.Input.ReadDate("Дата", current is null ? null : DateOnly.FromDateTime(current.Start));
        if (date is null)
        {
            return null;
        }

        var start = ctx.Input.ReadTime("Начален час", current is null ? null : TimeOnly.FromDateTime(current.Start));
        var end = start is null ? null : ctx.Input.ReadTime("Краен час", current is null ? start.Value.AddHours(1) : TimeOnly.FromDateTime(current.End));
        if (start is null || end is null)
        {
            return null;
        }

        var options = new List<(int, string)>();
        if (ctx.Services.Authorization.IsAdmin)
        {
            options.Add((0, "Цялото училище"));
        }

        var classes = ctx.Services.Classes.GetAll();
        options.AddRange(classes.Select((c, i) => (i + 1, c.DisplayName + " клас")));
        var target = ctx.Picker.PickValue("За кого е събитието", options);
        if (target is null)
        {
            return null;
        }

        return new SchoolEventInput(title, description, date.Value.ToDateTime(start.Value), date.Value.ToDateTime(end.Value),
            target == 0 ? null : classes[target.Value - 1].Id);
    }
}
