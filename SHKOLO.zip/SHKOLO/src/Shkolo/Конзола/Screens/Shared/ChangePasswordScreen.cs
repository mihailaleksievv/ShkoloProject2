// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Navigation;

namespace Shkolo.Presentation.Screens.Shared;

/// <summary>Password change for the logged-in user.</summary>
public sealed class ChangePasswordScreen : IScreen
{
    public string Title => "Смяна на парола";

    public ScreenResult Show(ScreenContext ctx)
    {
        ctx.Notifier.Info("Новата парола трябва да е поне 8 символа и да съдържа буква и цифра. Празен вход = отказ.");
        var current = ctx.Input.ReadPassword("Текуща парола");
        var next = current is null ? null : ctx.Input.ReadPassword("Нова парола");
        var repeat = next is null ? null : ctx.Input.ReadPassword("Повторете новата парола");
        if (current is null || next is null || repeat is null)
        {
            return ScreenResult.Back;
        }

        if (next != repeat)
        {
            ctx.Notifier.Error("Двете нови пароли не съвпадат.");
        }
        else
        {
            ctx.Notifier.Show(ctx.Services.Auth.ChangePassword(current, next), "Паролата е сменена.");
        }

        ctx.Notifier.Pause();
        return ScreenResult.Back;
    }
}
