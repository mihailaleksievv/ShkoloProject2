// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Screens.Shared;

/// <summary>Class performance report (administrators and teachers of the class).</summary>
public sealed class ClassReportScreen(Guid classId) : IScreen
{
    public string Title => "Справка за клас";

    public ScreenResult Show(ScreenContext ctx)
    {
        var result = ctx.Services.Reports.GenerateClassReport(classId);
        if (!result.Success)
        {
            ctx.Notifier.Error(result.Error!.Message);
            ctx.Notifier.Pause();
            return ScreenResult.Back;
        }

        var r = result.Value!;
        var console = ctx.Console;
        console.Write(new Panel(new Markup($"[bold]{Ui.Escape(r.Class.DisplayName)} клас[/]\n{Ui.Muted("Класен ръководител: " + r.ClassTeacherName)}"))
            .Border(BoxBorder.Rounded).BorderColor(ShkoloTheme.Accent).Padding(2, 0));
        console.Write(StatPanel.Tiles(
            ("Ученици", StatPanel.Number(r.StudentCount)),
            ("Среден успех", GradeFormatter.WithWord(r.ClassAverage)),
            ("Оценки", StatPanel.Number(r.GradeCount)),
            ("Неизвинени", $"[bold {ShkoloTheme.ErrorHex}]{r.Attendance.Unexcused}[/]"),
            ("Извинени", $"[bold {ShkoloTheme.WarningHex}]{r.Attendance.Excused}[/]"),
            ("Закъснения", StatPanel.Number(r.Attendance.Late))));

        StatPanel.Section(console, "Успех");
        GradeTables.AverageChart(console, "Среден успех по предмети", r.SubjectAverages.Select(s => (s.SubjectName, s.Average)));
        console.WriteLine();
        GradeTables.DistributionChart(console, r.Distribution);
        console.WriteLine();
        GradeTables.AttendanceChart(console, r.Attendance);

        StatPanel.Section(console, "Ученици");
        TableRenderer.Render(console, "Среден успех по ученици", r.StudentAverages,
            Col.Text<StudentAverage>("Ученик", s => s.StudentName),
            Col.Markup<StudentAverage>("Среден успех", s => GradeFormatter.WithWord(s.Average)));

        if (r.MostActiveSubjects.Count > 0)
        {
            console.MarkupLine(Ui.Muted("Най-активни предмети (по брой оценки): ") +
                               string.Join(", ", r.MostActiveSubjects.Select(s => $"{Ui.Escape(s.SubjectName)} ({s.GradeCount})")));
        }

        if (r.UpcomingHomework.Count > 0)
        {
            TableRenderer.Render(console, "Предстоящи домашни", r.UpcomingHomework,
                Col.Text<HomeworkView>("Срок", h => Ui.Date(h.DueDate)),
                Col.Text<HomeworkView>("Предмет", h => h.SubjectName),
                Col.Text<HomeworkView>("Заглавие", h => h.Title),
                Col.Text<HomeworkView>("Предадени", h => $"{h.SubmissionCount}/{h.ClassSize}", Justify.Right));
        }

        ctx.Notifier.Pause();
        return ScreenResult.Back;
    }
}
