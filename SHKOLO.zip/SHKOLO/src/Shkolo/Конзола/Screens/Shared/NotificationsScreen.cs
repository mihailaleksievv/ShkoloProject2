// Owner: Participant 2 – Presentation Developer
using Shkolo.Domain.Models;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;

namespace Shkolo.Presentation.Screens.Shared;

/// <summary>Internal notifications of the logged-in user.</summary>
public sealed class NotificationsScreen : MenuScreen
{
    public override string Title => "Известия";

    protected override void RenderBody(ScreenContext ctx)
        => TableRenderer.Render(ctx.Console, "Известия", ctx.Services.Notifications.GetForCurrentUser().Take(40).ToList(),
            Col.Markup<Notification>("", n => n.IsRead ? Ui.Muted("·") : $"[bold {ShkoloTheme.WarningHex}]●[/]"),
            Col.Text<Notification>("Дата", n => Ui.FromUtc(n.CreatedAtUtc)),
            Col.Text<Notification>("Известие", n => n.Title),
            Col.Text<Notification>("Съдържание", n => n.Message));

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.Do("Маркиране на всички като прочетени", c =>
            c.Notifier.Show(c.Services.Notifications.MarkAllAsRead(), "Всички известия са маркирани като прочетени."));
        yield return MenuItem.Do("Маркиране на едно като прочетено", c =>
        {
            var item = c.Picker.Pick("Изберете известие", c.Services.Notifications.GetForCurrentUser(unreadOnly: true), n => $"{n.Title}: {n.Message}");
            if (item is not null)
            {
                c.Notifier.Show(c.Services.Notifications.MarkAsRead(item.Id), "Известието е маркирано като прочетено.");
            }
        });
    }
}
