// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Reports;
using Shkolo.Application.Requests;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Screens.Shared;

/// <summary>Announcements: everyone reads; administrators and teachers publish, edit and archive their own.</summary>
public sealed class AnnouncementsScreen(bool canPublish) : MenuScreen
{
    public override string Title => "Съобщения";

    protected override void RenderBody(ScreenContext ctx)
        => Render(ctx, ctx.Services.Announcements.GetActiveForCurrentUser());

    protected override IEnumerable<MenuItem> Items(ScreenContext ctx)
    {
        yield return MenuItem.View("Прочитане на съобщение", Read);
        if (canPublish)
        {
            yield return MenuItem.Do("Публикуване", Publish);
            yield return MenuItem.Do("Редактиране", Edit);
            yield return MenuItem.Do("Архивиране", Archive);
        }
    }

    public static void Render(ScreenContext ctx, IReadOnlyList<AnnouncementView> items)
        => TableRenderer.Render(ctx.Console, "Активни съобщения", items,
            Col.Text<AnnouncementView>("Дата", a => Ui.FromUtc(a.PublishedAtUtc)),
            Col.Text<AnnouncementView>("Заглавие", a => a.Title),
            Col.Text<AnnouncementView>("За", a => a.Target),
            Col.Text<AnnouncementView>("Автор", a => a.AuthorName));

    private static void Read(ScreenContext ctx)
    {
        var item = ctx.Picker.Pick("Изберете съобщение", ctx.Services.Announcements.GetActiveForCurrentUser(), a => $"{a.Title} · {a.Target}");
        if (item is not null)
        {
            ctx.Console.Write(new Panel(new Markup($"{Ui.Escape(item.Body)}\n\n{Ui.Muted($"{item.AuthorName} · {Ui.FromUtc(item.PublishedAtUtc)} · {item.Target}")}"))
                .Header($" [bold]{Ui.Escape(item.Title)}[/] ").Border(BoxBorder.Rounded).BorderColor(ShkoloTheme.Accent).Padding(2, 1));
        }
    }

    private static void Publish(ScreenContext ctx)
    {
        var input = ReadInput(ctx, null);
        if (input is not null)
        {
            ctx.Notifier.Show(ctx.Services.Announcements.Publish(input), "Съобщението е публикувано и получателите са известени.");
            ctx.Notifier.Pause();
        }
    }

    private static void Edit(ScreenContext ctx)
    {
        var item = PickOwn(ctx);
        var input = item is null ? null : ReadInput(ctx, item);
        if (item is not null && input is not null)
        {
            ctx.Notifier.Show(ctx.Services.Announcements.Update(item.Id, input), "Съобщението е редактирано.");
            ctx.Notifier.Pause();
        }
    }

    private static void Archive(ScreenContext ctx)
    {
        var item = PickOwn(ctx);
        if (item is not null && ctx.Input.ReadConfirmation($"Архивиране на „{item.Title}“?"))
        {
            ctx.Notifier.Show(ctx.Services.Announcements.Archive(item.Id), "Съобщението е архивирано.");
            ctx.Notifier.Pause();
        }
    }

    private static AnnouncementView? PickOwn(ScreenContext ctx)
    {
        var mine = ctx.Services.Announcements.GetActiveForCurrentUser()
            .Where(a => ctx.Services.Authorization.IsAdmin || a.AuthorUserId == ctx.Services.Session.UserId).ToList();
        return ctx.Picker.Pick("Изберете съобщение", mine, a => $"{a.Title} · {a.Target}");
    }

    private static AnnouncementInput? ReadInput(ScreenContext ctx, AnnouncementView? current)
    {
        var title = ctx.Input.ReadRequiredString("Заглавие", 120, current?.Title);
        if (title is null)
        {
            return null;
        }

        var body = ctx.Input.ReadRequiredString("Текст", 2000, current?.Body);
        if (body is null)
        {
            return null;
        }

        var options = new List<(int, string)> { (0, "Цялото училище") };
        var classes = ctx.Services.Classes.GetAll();
        options.AddRange(classes.Select((c, i) => (i + 1, c.DisplayName + " клас")));
        var target = ctx.Picker.PickValue("Получатели", options);
        if (target is null)
        {
            return null;
        }

        return new AnnouncementInput(title, body, target == 0 ? null : classes[target.Value - 1].Id);
    }
}
