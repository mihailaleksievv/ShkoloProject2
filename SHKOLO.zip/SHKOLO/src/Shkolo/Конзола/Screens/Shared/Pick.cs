// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Domain.Enums;
using Shkolo.Domain.Models;
using Shkolo.Presentation.Navigation;


namespace Shkolo.Presentation.Screens.Shared;

/// <summary>Reusable pickers: every entity is chosen by a readable label from a searchable list.</summary>
public static class Pick
{
    public static SchoolClass? Class(ScreenContext ctx, string title = "Изберете клас", bool includeInactive = false)
        => ctx.Picker.Pick(title, ctx.Services.Classes.GetAll(includeInactive), c => c.DisplayName + (c.IsActive ? "" : " (неактивен)"));

    public static Student? Student(ScreenContext ctx, Guid? classId = null, bool includeInactive = false, string title = "Изберете ученик")
    {
        var result = classId is { } id
            ? ctx.Services.Students.GetStudentsByClass(id, includeInactive)
            : ctx.Services.Students.GetAllStudents(includeInactive);
        if (!result.Success)
        {
            ctx.Notifier.Error(result.Error!.Message);
            return null;
        }

        var classes = ClassNames(ctx);
        return ctx.Picker.Pick(title, result.Value!, s =>
            $"{s.FullName} · {classes.GetValueOrDefault(s.ClassId, "—")} · №{s.StudentNumber}{(s.IsActive ? "" : " (неактивен)")}");
    }

    public static Teacher? Teacher(ScreenContext ctx, bool includeInactive = false, string title = "Изберете учител")
    {
        var result = ctx.Services.Teachers.GetAll(includeInactive);
        if (!result.Success)
        {
            ctx.Notifier.Error(result.Error!.Message);
            return null;
        }

        return ctx.Picker.Pick(title, result.Value!, t => $"{t.FullName} · {t.EmployeeNumber}{(t.IsActive ? "" : " (неактивен)")}");
    }

    public static Subject? Subject(ScreenContext ctx, bool includeInactive = false, string title = "Изберете предмет")
        => ctx.Picker.Pick(title, ctx.Services.Subjects.GetAll(includeInactive), s => s.Name + (s.Code is null ? "" : $" ({s.Code})") + (s.IsActive ? "" : " (неактивен)"));

    /// <summary>A class + subject pair the current teacher is assigned to.</summary>
    public static AssignmentView? MyAssignment(ScreenContext ctx, string title = "Изберете клас и предмет")
    {
        var result = ctx.Services.Assignments.GetForTeacher(ctx.Services.Session.TeacherId!.Value);
        if (!result.Success)
        {
            ctx.Notifier.Error(result.Error!.Message);
            return null;
        }

        return ctx.Picker.Pick(title, result.Value!, a => $"{a.ClassName} · {a.SubjectName}");
    }

    public static GradeType? GradeType(ScreenContext ctx)
        => ctx.Picker.PickValue("Вид оценка", Enum.GetValues<GradeType>().Select(t => (t, BulgarianNames.Of(t))).ToList());

    public static DayOfWeek? Day(ScreenContext ctx)
        => ctx.Picker.PickValue("Ден от седмицата",
            new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday }
                .Select(d => (d, BulgarianNames.Of(d))).ToList());

    public static TermPeriod? Period(ScreenContext ctx)
        => ctx.Picker.PickValue("Период", Enum.GetValues<TermPeriod>().Select(p => (p, BulgarianNames.Of(p))).ToList());

    /// <summary>Optional term filter: null = whole year.</summary>
    public static (bool Chosen, Term? Term) TermFilter(ScreenContext ctx)
    {
        var options = new List<(int, string)> { (0, "Цялата година"), (1, "I срок"), (2, "II срок") };
        return ctx.Picker.PickValue("Период", options) switch
        {
            null => (false, null),
            1 => (true, Term.First),
            2 => (true, Term.Second),
            _ => (true, null),
        };
    }

    public static Dictionary<Guid, string> ClassNames(ScreenContext ctx)
        => ctx.Services.Classes.GetAll(includeInactive: true).ToDictionary(c => c.Id, c => c.DisplayName);
}
