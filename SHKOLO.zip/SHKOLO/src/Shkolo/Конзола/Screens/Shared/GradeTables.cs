﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Application.Reports;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Screens.Shared;

/// <summary>Shared renderers for grade, attendance and lesson lists.</summary>
public static class GradeTables
{
    public static void Recent(IAnsiConsole console, IReadOnlyList<GradeView> grades, string title = "Оценки")
        => TableRenderer.Render(console, title, grades,
            Col.Text<GradeView>("Дата", g => Ui.Date(g.Date)),
            Col.Text<GradeView>("Ученик", g => g.StudentName),
            Col.Text<GradeView>("Предмет", g => g.SubjectName),
            Col.Markup<GradeView>("Оценка", g => GradeFormatter.Markup(g.Value)),
            Col.Text<GradeView>("Вид", g => BulgarianNames.Of(g.Type)),
            Col.Text<GradeView>("Коментар", g => g.Comment ?? ""),
            Col.Text<GradeView>("Учител", g => g.TeacherName));

    public static void Attendance(IAnsiConsole console, IReadOnlyList<AttendanceView> records, string title = "Присъствия")
        => TableRenderer.Render(console, title, records,
            Col.Text<AttendanceView>("Дата", a => Ui.Date(a.Date)),
            Col.Text<AttendanceView>("Час", a => a.LessonNumber.ToString(BulgarianNames.Culture), Justify.Right),
            Col.Text<AttendanceView>("Ученик", a => a.StudentName),
            Col.Text<AttendanceView>("Клас", a => a.ClassName),
            Col.Text<AttendanceView>("Предмет", a => a.SubjectName),
            Col.Markup<AttendanceView>("Статус", a => StatusMarkup(a.Status)),
            Col.Text<AttendanceView>("Бележка", a => a.Note ?? ""));

    public static void Lessons(IAnsiConsole console, IReadOnlyList<LessonView> lessons, string title = "Учебни часове")
        => TableRenderer.Render(console, title, lessons,
            Col.Text<LessonView>("Дата", l => Ui.Date(l.Date)),
            Col.Text<LessonView>("Час", l => l.LessonNumber.ToString(BulgarianNames.Culture), Justify.Right),
            Col.Text<LessonView>("Клас", l => l.ClassName),
            Col.Text<LessonView>("Предмет", l => l.SubjectName),
            Col.Text<LessonView>("Тема", l => l.Topic),
            Col.Text<LessonView>("Учител", l => l.TeacherName),
            Col.Markup<LessonView>("Статус", l => l.Status == Domain.Enums.LessonStatus.Held ? $"[{ShkoloTheme.SuccessHex}]Проведен[/]" : $"[{ShkoloTheme.WarningHex}]Отменен[/]"),
            Col.Text<LessonView>("Присъствия/оценки", l => $"{l.AttendanceCount} / {l.GradeCount}", Justify.Right));

    public static string StatusMarkup(Domain.Enums.AttendanceStatus status) => status switch
    {
        Domain.Enums.AttendanceStatus.Present => $"[{ShkoloTheme.SuccessHex}]Присъства[/]",
        Domain.Enums.AttendanceStatus.Absent => $"[{ShkoloTheme.ErrorHex}]Неизвинено[/]",
        Domain.Enums.AttendanceStatus.ExcusedAbsent => $"[{ShkoloTheme.WarningHex}]Извинено[/]",
        _ => $"[{ShkoloTheme.AccentHex}]Закъснение[/]",
    };

    /// <summary>Attendance totals as separated coloured segments with shares.</summary>
    public static void AttendanceChart(IAnsiConsole console, AttendanceSummary s)
    {
        if (s.TotalRecords == 0)
        {
            console.MarkupLine(Ui.Muted("Няма записи за присъствия."));
            return;
        }

        console.Write(SegmentBar.Attendance(s, Math.Min(100, console.Profile.Width - 2)));
        console.WriteLine();
    }

    /// <summary>Grade distribution by the Bulgarian verbal scale, as a vertical histogram.</summary>
    public static void DistributionChart(IAnsiConsole console, GradeDistribution d, string title = "Разпределение на оценките")
    {
        if (d.Total == 0)
        {
            console.MarkupLine(Ui.Muted("Няма оценки."));
            return;
        }

        console.MarkupLine($"[bold]{Ui.Escape(title)}[/]");
        console.WriteLine();
        console.Write(GradeHistogram.Render(d));
        console.WriteLine();
        console.WriteLine();
    }

    /// <summary>Averages as separate bars coloured by grade band (items without an average are skipped).</summary>
    public static void AverageChart(IAnsiConsole console, string title, IEnumerable<(string Label, decimal? Average)> items)
    {
        var list = items.Where(i => i.Average is not null).ToList();
        if (list.Count == 0)
        {
            console.MarkupLine(Ui.Muted("Няма данни за среден успех."));
            return;
        }

        console.MarkupLine($"[bold]{Ui.Escape(title)}[/]");
        console.WriteLine();
        console.Write(GradeBars.Render(list.Select(i => new GradeBar(i.Label, i.Average)).ToList(), barWidth: 36));
        console.WriteLine();
    }
}
