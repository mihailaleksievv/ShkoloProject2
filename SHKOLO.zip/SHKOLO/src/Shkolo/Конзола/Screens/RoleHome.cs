// Owner: Participant 2 – Presentation Developer
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Workspaces.Administration;
using Shkolo.Presentation.Workspaces.Learning;
using Shkolo.Presentation.Workspaces.Teaching;

namespace Shkolo.Presentation.Screens;

/// <summary>Chooses the command-centre workspace of a role.</summary>
public static class RoleHome
{
    public static IWorkspace Workspace(UserRole role) => role switch
    {
        UserRole.Administrator => new AdminWorkspace(),
        UserRole.Teacher => new TeacherWorkspace(),
        _ => new StudentWorkspace(),
    };
}
