﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Theme;
using Shkolo.Presentation.Workspaces;
using Spectre.Console;

namespace Shkolo.Presentation.Screens;

/// <summary>Началният екран: небето, логото и бутоните Вход, За проекта и Изход.</summary>
public sealed class StartScreen : IScreen
{
    private static readonly string[] Buttons = ["Вход", "За проекта", "Изход"];
    private static readonly TimeSpan RevealDuration = TimeSpan.FromMilliseconds(900);
    private static bool _revealed;

    private const int ButtonWidth = 20;
    private const int ButtonGap = 4;

    public string Title => "Начало";

    public ScreenResult Show(ScreenContext ctx)
    {
        var console = ctx.Console;
        if (!SkyScene.Fits(console))
        {
            return new ClassicStartScreen().Show(ctx);
        }

        var strip = Strip(ctx);
        var selected = 0;
        Components.Ui.Clear(console);
        if (!_revealed && ctx.Motion.Enabled)
        {
            ctx.Animator.Play(console, RevealDuration, p => Build(console, selected, strip, p));
            Components.Ui.Clear(console);
        }

        _revealed = true;
        ScreenResult? result = null;
        console.Live(Build(console, selected, strip)).AutoClear(false).Overflow(VerticalOverflow.Crop).Start(live =>
        {
            live.Refresh();
            while (result is null)
            {
                var key = SkyScene.ReadKey(console);
                switch (key.Key)
                {
                    case ConsoleKey.RightArrow or ConsoleKey.DownArrow or ConsoleKey.Tab:
                        selected = (selected + 1) % Buttons.Length;
                        break;
                    case ConsoleKey.LeftArrow or ConsoleKey.UpArrow:
                        selected = (selected - 1 + Buttons.Length) % Buttons.Length;
                        break;
                    case ConsoleKey.Enter:
                        result = selected switch
                        {
                            0 => ScreenResult.Push(new LoginScreen()),
                            1 => ScreenResult.Push(new AboutScreen()),
                            _ => ScreenResult.Exit,
                        };
                        break;
                }

                live.UpdateTarget(Build(console, selected, strip));
                live.Refresh();
            }
        });

        Components.Ui.Clear(console);
        return result!;
    }

    private static string Strip(ScreenContext ctx)
    {
        var o = ctx.Services.Reports.GetPublicOverview();
        var year = ctx.Services.AcademicYears.GetActive();
        var term = WorkspaceKit.CurrentTerm(ctx);
        var yearText = year is null ? "няма активна учебна година" : $"{year.Name}{(term is { } t ? " · " + t.Name : "")}";
        return $"{yearText}   ·   {o.Students} ученици   ·   {o.Teachers} учители   ·   {o.Classes} класа";
    }

    private static PixelCanvas Build(IAnsiConsole console, int selected, string strip, double reveal = 1)
    {
        var rows = SkyScene.Rows(console);
        var logoRow = Math.Max(2, (int)(rows * 0.30) - 2);
        var canvas = new PixelCanvas(SkyScene.Background(console, 0, logoRow * 2, reveal));
        var w = canvas.Width;
        if (reveal < 1)
        {
            return canvas;
        }

        // "school management & intelligence" right-aligned under the wordmark, like a product line.
        var tagline = "school management & intelligence";
        var logoRight = w / 2 - BlockLogo.Width / 2 + BlockLogo.Width;
        canvas.Text(logoRight - tagline.Length, logoRow + 4, tagline, SkyScene.White, bold: true);
        canvas.Centered(logoRow + 6, ShkoloTheme.SloganBg, SkyScene.White);

        var buttonsRow = logoRow + 9;
        var total = Buttons.Length * ButtonWidth + (Buttons.Length - 1) * ButtonGap;
        var left = (w - total) / 2;
        for (var i = 0; i < Buttons.Length; i++)
        {
            var x = left + i * (ButtonWidth + ButtonGap);
            var active = i == selected;
            var bg = active ? SkyScene.White : SkyScene.ButtonIdle;
            canvas.Fill(x, buttonsRow, ButtonWidth, 3, bg);
            var label = active ? $"▸  {Buttons[i]}  ◂" : Buttons[i];
            canvas.Text(x + (ButtonWidth - label.Length) / 2, buttonsRow + 1, label, active ? SkyScene.Ink : SkyScene.SoftInk, bg, bold: active);
            if (active)
            {
                canvas.Text(x, buttonsRow + 3, new string((char)0x2580, ButtonWidth), SkyScene.Teal);
            }
        }

        // A calm blue band at the bottom keeps the white text readable over the clouds.
        canvas.Fill(0, rows - 4, w, 4, SkyScene.Band);
        canvas.Centered(rows - 3, strip, SkyScene.White, SkyScene.Band, bold: true);
        var hint = "← → избор   Enter потвърждение";
        canvas.Text(w - hint.Length - 2, rows - 1, hint, SkyScene.BandText, SkyScene.Band);
        return canvas;
    }
}
