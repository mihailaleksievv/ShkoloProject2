// Owner: Participant 2 – Presentation Developer
using Shkolo.Application.Abstractions;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Screens;

public enum RecoveryChoice
{
    Restored,
    ContinueReadOnly,
    Exit,
}

/// <summary>
/// Shown at start-up when the data file is damaged or inconsistent. The damaged file is never
/// overwritten silently – the user restores a backup, continues read-only, or exits.
/// </summary>
public static class RecoveryScreen
{
    public static RecoveryChoice Run(IAnsiConsole console, LoadResult load, IBackupProvider backups, bool allowReadOnly)
    {
        Ui.Clear(console);
        console.Write(new FigletText(ShkoloTheme.Brand).Color(ShkoloTheme.Primary));
        var body = Ui.Escape(load.Message ?? "Данните не могат да бъдат заредени.");
        if (load.IntegrityIssues.Count > 0)
        {
            body += "\n\n" + string.Join("\n", load.IntegrityIssues.Take(15).Select(i => "• " + Ui.Escape(i)));
            if (load.IntegrityIssues.Count > 15)
            {
                body += "\n" + Ui.Muted($"… и още {load.IntegrityIssues.Count - 15}");
            }
        }

        console.Write(new Panel(new Markup(body))
            .Header($" [bold {ShkoloTheme.WarningHex}]Проблем с данните[/] ")
            .Border(BoxBorder.Double)
            .BorderColor(ShkoloTheme.Warning));

        var available = backups.GetBackups();
        var options = new List<(RecoveryChoice Choice, string Label)>();
        if (available.Count > 0)
        {
            options.Add((RecoveryChoice.Restored, "Възстановяване от архив"));
        }

        if (allowReadOnly)
        {
            options.Add((RecoveryChoice.ContinueReadOnly, "Продължаване в режим само за четене"));
        }

        options.Add((RecoveryChoice.Exit, "Изход"));
        if (available.Count == 0)
        {
            console.MarkupLine(Ui.Muted("Няма налични архиви."));
        }

        var choice = console.Prompt(new SelectionPrompt<int>()
            .Title("[bold]Какво искате да направите?[/]")
            .HighlightStyle(new Style(ShkoloTheme.Background, ShkoloTheme.Accent))
            .UseConverter(i => Ui.Escape(options[i].Label))
            .AddChoices(Enumerable.Range(0, options.Count)));

        if (options[choice].Choice != RecoveryChoice.Restored)
        {
            return options[choice].Choice;
        }

        var backup = console.Prompt(new SelectionPrompt<BackupInfo>()
            .Title("[bold]Изберете архив:[/]")
            .HighlightStyle(new Style(ShkoloTheme.Background, ShkoloTheme.Accent))
            .UseConverter(b => Ui.Escape($"{Ui.FromUtc(b.CreatedAtUtc)}  ·  {b.SizeBytes / 1024.0:0.0} KB  ·  {b.FileName}"))
            .AddChoices(available));

        try
        {
            backups.RestoreBackup(backup.FileName);
            console.MarkupLine($"[{ShkoloTheme.SuccessHex}]✔ Архивът е възстановен. Данните се зареждат отново…[/]");
            return RecoveryChoice.Restored;
        }
        catch (DataStoreException ex)
        {
            console.MarkupLine($"[{ShkoloTheme.ErrorHex}]✖ {Ui.Escape(ex.Message)}[/]");
            return RecoveryChoice.Exit;
        }
    }

    /// <summary>Message for a database written by a newer Shkolo version.</summary>
    public static void ShowUnsupported(IAnsiConsole console, LoadResult load)
        => console.Write(new Panel(new Markup(Ui.Escape(load.Message ?? "Неподдържана версия на данните.")))
            .Header($" [bold {ShkoloTheme.ErrorHex}]Неподдържана версия[/] ")
            .BorderColor(ShkoloTheme.Error));
}
