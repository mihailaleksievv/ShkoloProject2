﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Domain.Enums;
using Shkolo.Presentation.Design;
using Shkolo.Presentation.Motion;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Shell;
using Shkolo.Presentation.Theme;
using Shkolo.Presentation.Workspaces;
using Spectre.Console;

namespace Shkolo.Presentation.Screens;

/// <summary>
/// Bridges the classic screen navigator and the live command centre: runs the role's workspace
/// and, on logout, says goodbye before handing control back to the start screen.
/// </summary>
public sealed class ShellHostScreen(UserRole role) : IScreen
{
    private static readonly TimeSpan GoodbyeDuration = TimeSpan.FromMilliseconds(700);

    public string Title => "Команден център";

    public UserRole Role { get; } = role;

    public ScreenResult Show(ScreenContext ctx)
    {
        ShellOutcome outcome;
        try
        {
            outcome = new AppShell().Run(ctx, RoleHome.Workspace(Role));
        }
        catch
        {
            // A failure outside the shell's own boundary (e.g. a section's Load) must not leave the session open.
            ctx.ShellSection = null;
            ctx.Services.Auth.Logout();
            throw;
        }

        if (outcome == ShellOutcome.Exit)
        {
            return ScreenResult.Exit;
        }

        var name = WorkspaceKit.FirstName(ctx);
        var goodbye = string.IsNullOrWhiteSpace(name) ? "Довиждане!" : $"Довиждане, {name}!";
        Components.Ui.Clear(ctx.Console);
        ctx.Console.WriteLine();
        ctx.Animator.Play(ctx.Console, GoodbyeDuration, Effects.Typewriter(goodbye, RoleAccent.For(Role)));
        ctx.Console.WriteLine();
        return ScreenResult.Logout;
    }
}
