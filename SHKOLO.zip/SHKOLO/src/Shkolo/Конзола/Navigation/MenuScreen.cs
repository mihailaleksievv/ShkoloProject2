// Owner: Participant 2 – Presentation Developer
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo.Presentation.Navigation;

/// <summary>A menu entry. <see cref="Action"/> returns what the navigator should do next.</summary>
public sealed record MenuItem(string Label, Func<ScreenContext, ScreenResult> Action)
{
    /// <summary>Opens a sub-screen.</summary>
    public static MenuItem Open(string label, Func<IScreen> screen) => new(label, _ => ScreenResult.Push(screen()));

    /// <summary>Runs an action on the current screen, then shows the screen again.</summary>
    public static MenuItem Do(string label, Action<ScreenContext> action) => new(label, ctx =>
    {
        action(ctx);
        return ScreenResult.Stay;
    });

    /// <summary>Runs an action that renders information, then waits for a key.</summary>
    public static MenuItem View(string label, Action<ScreenContext> action) => new(label, ctx =>
    {
        action(ctx);
        ctx.Notifier.Pause();
        return ScreenResult.Stay;
    });
}

/// <summary>
/// Base class for menu screens: optional body (dashboard, info), then an arrow-key menu that always
/// offers "← Назад" (sub-menus) and "Изход от профила".
/// </summary>
public abstract class MenuScreen : IScreen
{
    public abstract string Title { get; }

    /// <summary>Role home screens have no "Назад" – only logout.</summary>
    protected virtual bool IsHome => false;

    public ScreenResult Show(ScreenContext ctx)
    {
        RenderBody(ctx);
        ctx.Console.WriteLine();

        var items = Items(ctx).ToList();
        if (!IsHome)
        {
            items.Add(new MenuItem(ShkoloTheme.BackLabel, _ => ScreenResult.Back));
        }

        if (ctx.Services.Session.IsAuthenticated)
        {
            items.Add(new MenuItem(ShkoloTheme.LogoutLabel, _ => ScreenResult.Logout));
        }

        var choice = ctx.Console.Prompt(new SelectionPrompt<MenuItem>()
            .Title($"[bold {ShkoloTheme.TextHex}]Изберете действие:[/]")
            .PageSize(18)
            .HighlightStyle(new Style(ShkoloTheme.Background, ShkoloTheme.Accent))
            .UseConverter(i => Ui.Escape(i.Label))
            .AddChoices(items));
        ctx.Console.WriteLine();
        return choice.Action(ctx);
    }

    protected virtual void RenderBody(ScreenContext ctx)
    {
    }

    protected abstract IEnumerable<MenuItem> Items(ScreenContext ctx);
}
