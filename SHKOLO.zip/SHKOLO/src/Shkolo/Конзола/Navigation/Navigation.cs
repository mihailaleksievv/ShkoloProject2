﻿// Owner: Participant 2 – Presentation Developer
using Shkolo.Application;
using Shkolo.Presentation.Components;
using Shkolo.Presentation.Input;
using Shkolo.Presentation.Motion;
using Spectre.Console;

namespace Shkolo.Presentation.Navigation;

/// <summary>A full-screen page of the console application.</summary>
public interface IScreen
{
    string Title { get; }

    ScreenResult Show(ScreenContext ctx);
}

public enum ScreenAction
{
    Stay,
    Back,
    Push,
    Replace,
    Logout,
    Exit,
}

/// <summary>What the navigator should do after a screen returns.</summary>
public sealed record ScreenResult(ScreenAction Action, IScreen? Next = null)
{
    public static ScreenResult Stay { get; } = new(ScreenAction.Stay);

    public static ScreenResult Back { get; } = new(ScreenAction.Back);

    public static ScreenResult Logout { get; } = new(ScreenAction.Logout);

    public static ScreenResult Exit { get; } = new(ScreenAction.Exit);

    public static ScreenResult Push(IScreen next) => new(ScreenAction.Push, next);

    public static ScreenResult Replace(IScreen next) => new(ScreenAction.Replace, next);
}

/// <summary>Everything a screen needs. Screens talk to the system only through <see cref="Services"/>.</summary>
public sealed class ScreenContext
{
    public ScreenContext(IAnsiConsole console, ApplicationServices services, string dataFilePath, Action<Exception> logError, MotionSettings? motion = null)
    {
        Console = console;
        Services = services;
        DataFilePath = dataFilePath;
        LogError = logError;
        Notifier = new Notifier(console);
        Input = new InputHelper(console, services.Clock);
        Picker = new EntityPicker(console, Notifier);
        Motion = motion ?? MotionSettings.Disabled;
        Animator = new Animator(Motion, new StopwatchFrameTimer());
    }

    /// <summary>Animation settings of this run (disabled unless the composition root enables them).</summary>
    public MotionSettings Motion { get; }

    public Animator Animator { get; set; }

    public IAnsiConsole Console { get; }

    public ApplicationServices Services { get; }

    public string DataFilePath { get; }

    public Action<Exception> LogError { get; }

    public Notifier Notifier { get; }

    public InputHelper Input { get; }

    public EntityPicker Picker { get; }

    /// <summary>Title of the command-centre section an action was started from (used in form headers).</summary>
    public string? ShellSection { get; set; }

    /// <summary>Failed logins during this application run – kept here so leaving the login screen does not reset the throttle.</summary>
    public int FailedLoginAttempts { get; set; }

    /// <summary>Breadcrumb trail of the current screen stack (set by the navigator).</summary>
    public IReadOnlyList<string> Breadcrumbs { get; internal set; } = [];
}

/// <summary>
/// Stack-based navigation loop. No recursion: screens return what to do next.
/// Unexpected exceptions are caught, logged and shown without ending the application.
/// </summary>
/// <summary>How a navigation loop ended.</summary>
public enum NavigationOutcome
{
    /// <summary>The root screen was closed with "Назад".</summary>
    Back,

    /// <summary>The user chose "Изход от профила".</summary>
    Logout,

    /// <summary>The application should end (or restart after a backup restore).</summary>
    Exit,
}

public sealed class ScreenNavigator
{
    /// <param name="exitOnLogout">
    /// True for screens opened from the command centre: logout ends this loop and is handled by the shell.
    /// False for the main loop: logout returns to the start screen.
    /// </param>
    public NavigationOutcome Run(IScreen root, ScreenContext ctx, bool exitOnLogout = false)
    {
        var stack = new List<IScreen> { root };
        while (stack.Count > 0)
        {
            var screen = stack[^1];
            ctx.Breadcrumbs = stack.Select(s => s.Title).ToList();
            ScreenResult result;
            try
            {
                Ui.Clear(ctx.Console);
                Header.Render(ctx);
                result = screen.Show(ctx);
            }
            catch (Exception ex) when (ex is not OutOfMemoryException)
            {
                ctx.LogError(ex);
                ctx.Notifier.Error("Възникна неочаквана грешка. Тя е записана в дневника на приложението; данните не са променени.");
                ctx.Notifier.Pause();
                // Nested loops (command centre) go back to the shell; only the main loop's root ends the app.
                result = stack.Count > 1 || exitOnLogout ? ScreenResult.Back : ScreenResult.Exit;
            }

            switch (result.Action)
            {
                case ScreenAction.Back:
                    stack.RemoveAt(stack.Count - 1);
                    break;
                case ScreenAction.Push:
                    stack.Add(result.Next!);
                    break;
                case ScreenAction.Replace:
                    stack[^1] = result.Next!;
                    break;
                case ScreenAction.Logout:
                    if (exitOnLogout)
                    {
                        return NavigationOutcome.Logout;
                    }

                    ctx.Services.Auth.Logout();
                    stack.RemoveRange(1, stack.Count - 1);
                    break;
                case ScreenAction.Exit:
                    return NavigationOutcome.Exit;
            }

            if (ctx.Services.System.RestartRequired)
            {
                return NavigationOutcome.Exit;
            }
        }

        return NavigationOutcome.Back;
    }
}
