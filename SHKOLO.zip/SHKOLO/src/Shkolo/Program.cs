﻿// Owner: Participant 2 – Presentation Developer (composition root – the only place that knows every layer)
using System.Globalization;
using System.Text;
using Shkolo.Application;
using Shkolo.Application.Abstractions;
using Shkolo.Application.Security;
using Shkolo.Infrastructure;
using Shkolo.Infrastructure.Export;
using Shkolo.Infrastructure.Persistence;
using Shkolo.Infrastructure.Security;
using Shkolo.Presentation.Motion;
using Shkolo.Presentation.Navigation;
using Shkolo.Presentation.Screens;
using Shkolo.Presentation.Theme;
using Spectre.Console;

namespace Shkolo;

public static class Program
{
    private enum RunOutcome
    {
        Exit,
        Restart,
        Failed,
        Unsupported,
    }

    public static int Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;
        CultureInfo.DefaultThreadCurrentCulture = BulgarianNames.Culture;
        CultureInfo.DefaultThreadCurrentUICulture = BulgarianNames.Culture;
        CultureInfo.CurrentCulture = BulgarianNames.Culture;
        CultureInfo.CurrentUICulture = BulgarianNames.Culture;

        var dataDirectory = DataLocation.Resolve(args, AppContext.BaseDirectory);
        var console = AnsiConsole.Console;
        var noMotion = args.Contains("--no-motion", StringComparer.OrdinalIgnoreCase);
        var motion = !noMotion && !Console.IsOutputRedirected && console.Profile.Capabilities.Interactive
            ? MotionSettings.Default
            : MotionSettings.Disabled;

        try
        {
            while (true)
            {
                var outcome = RunOnce(console, dataDirectory, motion);
                switch (outcome)
                {
                    case RunOutcome.Restart:
                        continue;
                    case RunOutcome.Exit:
                        Shkolo.Presentation.Components.Ui.Clear(console);
                        console.MarkupLine($"[{ShkoloTheme.AccentHex}]Довиждане! Данните са записани в[/] {Markup.Escape(dataDirectory)}");
                        return 0;
                    case RunOutcome.Unsupported:
                        return 3;
                    default:
                        return 2;
                }
            }
        }
        catch (Exception ex)
        {
            // Last line of defence: start-up problems (e.g. unreadable data folder) end with a clear message.
            LogError(dataDirectory, ex);
            console.MarkupLine($"[{ShkoloTheme.ErrorHex}]✖ Shkolo не може да стартира: {Markup.Escape(ex.Message)}[/]");
            return 1;
        }
    }

    private static RunOutcome RunOnce(IAnsiConsole console, string dataDirectory, MotionSettings motion)
    {
        var clock = new SystemClock();
        var hasher = new Pbkdf2PasswordHasher();
        var backups = new BackupManager(dataDirectory, clock);
        var initializer = new DatabaseInitializer(clock, hasher);
        var store = new JsonDataStore(dataDirectory, backups, initializer.CreateInitialDatabase, clock, new IntegrityValidator());

        var load = console.Status().Start("Зареждане на данните…", _ => store.Load());
        var readOnly = false;
        switch (load.Status)
        {
            case LoadStatus.Corrupted:
                return RecoveryScreen.Run(console, load, backups, allowReadOnly: false) == RecoveryChoice.Restored ? RunOutcome.Restart : RunOutcome.Failed;
            case LoadStatus.UnsupportedVersion:
                RecoveryScreen.ShowUnsupported(console, load);
                return RunOutcome.Unsupported;
            case LoadStatus.IntegrityProblems:
                var choice = RecoveryScreen.Run(console, load, backups, allowReadOnly: true);
                if (choice == RecoveryChoice.Restored)
                {
                    return RunOutcome.Restart;
                }

                if (choice == RecoveryChoice.Exit)
                {
                    return RunOutcome.Failed;
                }

                readOnly = true;
                break;
        }

        var session = new SessionContext();
        var uow = new UnitOfWork(store, load.Database!, readOnly);
        var exporter = new CsvReportExporter(Path.Combine(dataDirectory, "Exports"), clock);
        var services = new ApplicationServices(uow, session, clock, hasher, exporter, backups, store.DataFilePath);
        var ctx = new ScreenContext(console, services, store.DataFilePath, ex => LogError(dataDirectory, ex), motion);
        BootSequence.Run(console, ctx.Animator, load);

        if (load.Status == LoadStatus.CreatedNew)
        {
            ctx.Notifier.Success("Създадена е нова база с демонстрационни данни. Демо акаунтите са описани в README.md.");
            ctx.Notifier.Pause();
        }

        new ScreenNavigator().Run(new StartScreen(), ctx);
        return services.System.RestartRequired ? RunOutcome.Restart : RunOutcome.Exit;
    }

    private static void LogError(string dataDirectory, Exception ex)
    {
        try
        {
            var logDirectory = Path.Combine(dataDirectory, "Logs");
            Directory.CreateDirectory(logDirectory);
            File.AppendAllText(Path.Combine(logDirectory, "error.log"), $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex}{Environment.NewLine}{Environment.NewLine}");
        }
        catch (IOException)
        {
            // Logging must never crash the application; the error was already shown on screen.
        }
        catch (UnauthorizedAccessException)
        {
            // Same as above: a read-only folder only means the log cannot be written.
        }
    }
}
