// Owner: Participant 3 – Data Developer
using Shkolo.Application.Abstractions;

namespace Shkolo.Infrastructure;

/// <summary>Real system clock.</summary>
public sealed class SystemClock : IClock
{
    public DateTime UtcNow => DateTime.UtcNow;

    public DateTime LocalNow => DateTime.Now;

    public DateOnly Today => DateOnly.FromDateTime(DateTime.Now);
}
