// Owner: Participant 3 – Data Developer
using System.Globalization;
using System.Text;
using Shkolo.Application.Abstractions;

namespace Shkolo.Infrastructure.Export;

/// <summary>
/// Writes reports as CSV that opens correctly in Bulgarian Excel:
/// UTF-8 with BOM, ";" as separator, quoted values when needed.
/// </summary>
public sealed class CsvReportExporter : IReportExporter
{
    private const char Separator = ';';
    private readonly string _exportDirectory;
    private readonly IClock _clock;

    public CsvReportExporter(string exportDirectory, IClock clock)
    {
        _exportDirectory = exportDirectory;
        _clock = clock;
    }

    public string Export(string fileNameStem, IReadOnlyList<string> headers, IEnumerable<IReadOnlyList<string>> rows)
    {
        Directory.CreateDirectory(_exportDirectory);
        var stamp = _clock.LocalNow.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture);
        var path = Path.Combine(_exportDirectory, $"{Sanitize(fileNameStem)}_{stamp}.csv");

        var builder = new StringBuilder();
        AppendLine(builder, headers);
        foreach (var row in rows)
        {
            AppendLine(builder, row);
        }

        File.WriteAllText(path, builder.ToString(), new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
        return path;
    }

    private static void AppendLine(StringBuilder builder, IReadOnlyList<string> values)
    {
        builder.Append(string.Join(Separator, values.Select(Escape)));
        builder.Append("\r\n");
    }

    private static string Escape(string? value)
    {
        value ??= "";
        return value.IndexOfAny([Separator, '"', '\n', '\r']) >= 0
            ? "\"" + value.Replace("\"", "\"\"") + "\""
            : value;
    }

    private static string Sanitize(string stem)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var clean = new string(stem.Select(c => invalid.Contains(c) || c == ' ' ? '_' : c).ToArray());
        return string.IsNullOrWhiteSpace(clean) ? "report" : clean;
    }
}
