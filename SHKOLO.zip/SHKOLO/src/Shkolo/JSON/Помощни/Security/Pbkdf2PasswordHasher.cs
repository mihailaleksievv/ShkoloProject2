// Owner: Participant 3 – Data Developer
using System.Security.Cryptography;
using System.Text;
using Shkolo.Application.Abstractions;

namespace Shkolo.Infrastructure.Security;

/// <summary>
/// PBKDF2-SHA256 password hashing: 100 000 iterations, 16-byte random salt per user, 32-byte key.
/// Comparison is constant-time so timing does not reveal how much of the hash matched.
/// </summary>
public sealed class Pbkdf2PasswordHasher : IPasswordHasher
{
    private const int Iterations = 100_000;
    private const int SaltSize = 16;
    private const int KeySize = 32;
    private static readonly HashAlgorithmName Algorithm = HashAlgorithmName.SHA256;

    public (string Hash, string Salt) Hash(string password)
    {
        ArgumentNullException.ThrowIfNull(password);
        var salt = RandomNumberGenerator.GetBytes(SaltSize);
        var key = Derive(password, salt);
        return (Convert.ToBase64String(key), Convert.ToBase64String(salt));
    }

    public bool Verify(string password, string hash, string salt)
    {
        ArgumentNullException.ThrowIfNull(password);
        byte[] expected;
        byte[] saltBytes;
        try
        {
            expected = Convert.FromBase64String(hash);
            saltBytes = Convert.FromBase64String(salt);
        }
        catch (FormatException)
        {
            // A corrupted stored hash can never match – treat it as a failed verification.
            return false;
        }

        var actual = Derive(password, saltBytes);
        return CryptographicOperations.FixedTimeEquals(actual, expected);
    }

    private static byte[] Derive(string password, byte[] salt)
        => Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(password), salt, Iterations, Algorithm, KeySize);
}
